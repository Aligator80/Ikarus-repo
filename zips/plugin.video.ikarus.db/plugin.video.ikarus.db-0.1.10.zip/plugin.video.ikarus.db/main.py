"""Minimal Kodi movie browser, based on Ikarus directory and playback routing."""
import json
import os
import re
import sys
import time
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import catalog
import metadata
import server_api
import webshare
import stereo
import playback_metadata

PAGE_SIZE = 25
SUBTITLE_SUFFIXES = (".srt", ".sub", ".ass", ".ssa", ".vtt")
PLAYBACK_LISTS = {"watching": 30059, "watched": 30060}


def run(argv):
    addon = xbmcaddon.Addon()
    handle = int(argv[1]) if len(argv) > 1 else -1
    base = argv[0]
    params = dict(parse_qsl(argv[2].lstrip("?"))) if len(argv) > 2 else {}
    action = params.get("action", "")
    text = addon.getLocalizedString
    title = addon.getAddonInfo("name")

    def playback_failed():
        if action in ("choose_play", "resume_play"):
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        else:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())

    def url(**query):
        return base + "?" + urlencode(query)

    def end(ok=True):
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=ok, cacheToDisc=False)

    def error(message_id):
        xbmcgui.Dialog().ok(title, text(message_id))

    def server_error(exc):
        messages = {
            "server_url_missing": 30036,
            "credentials_missing": 30037,
            "server_unavailable": 30038,
            "invalid_credentials": 30039,
            "authorization_required": 30040,
            "not_connected": 30040,
            "catalog_unavailable": 30038,
            "search_failed": 30038,
            "custom_list_missing": 30072,
            "custom_list_exists": 30073,
            "invalid_custom_list_name": 30074,
            "custom_lists_unavailable": 30075,
            "custom_list_movie_missing": 30076,
            "account_mismatch": 30040,
        }
        xbmcgui.Dialog().ok(title, text(messages.get(exc.reason, 30038)))

    def movies():
        return server_api.catalog(addon)

    def custom_list_context(movie_key, list_id=""):
        target = url(action="custom_list_add", movie=movie_key)
        items = [(text(30065), "RunPlugin({})".format(target))]
        if list_id:
            target = url(action="custom_list_remove", list_id=list_id, movie=movie_key)
            items.append((text(30066), "RunPlugin({})".format(target)))
        return items

    def server_connected():
        try:
            server_api.ensure_connection(addon)
            return True
        except server_api.ServerError:
            return False

    def find_menu_node(items, node_id):
        for item in items or []:
            if item.get("id") == node_id:
                return item
            found = find_menu_node(item.get("children", []), node_id)
            if found:
                return found
        return None

    def add_menu_items(items, movie_count=None):
        for node in items or []:
            node_id = str(node.get("id") or "")
            # Serials are not ready for the public catalog yet. Keep the
            # server menu definition intact, but do not expose this entry.
            if node_id == "serials":
                continue
            label = str(node.get("label") or node_id or "Menu")
            if movie_count is not None and node_id in ("movies", "movies_all"):
                label = "{} ({})".format(label, movie_count)
            if node.get("action") == "settings":
                target = url(action="settings")
            elif node_id == "my_lists":
                label = text(30064)
                target = url(action="my_lists")
            elif node_id in PLAYBACK_LISTS:
                target = url(action="movies", mode=node_id)
            elif node.get("action") == "movies":
                target = url(action="movies", mode=node.get("mode", "all"))
            elif node.get("action") == "movies_genre":
                target = url(action="movies", mode="genre")
            else:
                target = url(action="menu_node", node=node.get("id", ""))
            is_folder = (bool(node.get("children")) or node_id in ("movies_search", "my_lists") or node_id in PLAYBACK_LISTS
                         or node.get("action") in ("movies", "movies_genre", "serials"))
            xbmcplugin.addDirectoryItem(handle, target, xbmcgui.ListItem(label=label), is_folder)

    def movie_item(movie, show_status=True):
        def normalized_language(value):
            language = str(value or "").strip().upper()
            aliases = {
                "CZE": "CZ", "CES": "CZ", "CS": "CZ",
                "ENG": "EN", "ENGLISH": "EN",
                "SLO": "SK", "SLK": "SK",
            }
            return aliases.get(language, language)

        languages = []
        # The catalog response provides this compact aggregate.  Sources are
        # also checked to remain compatible with an older server response.
        candidates = movie.get("audio_languages") or []
        if isinstance(candidates, str):
            candidates = [candidates]
        for language in candidates:
            language = normalized_language(language)
            if language and language not in languages:
                languages.append(language)
        for source in movie.get("sources") or []:
            technical = source.get("technical") if isinstance(source, dict) and isinstance(source.get("technical"), dict) else {}
            audio = technical.get("audio") or []
            if isinstance(audio, str):
                audio = [audio]
            for language in audio:
                language = normalized_language(language)
                if language and language not in languages:
                    languages.append(language)

        language = next((code for code in ("CZ", "SK", "EN") if code in languages), languages[0] if languages else "")
        label = ("[{}] ".format(language) if language else "") + movie["title"]
        year = (movie.get("details") or {}).get("year") or movie["year"]
        if year:
            label += " ({})".format(year)
        info, art = metadata.video_info(movie, text)
        playback = (movie.get("playback") or {}) if show_status else {}
        status = playback.get("status")
        if status == "watching":
            label = "[COLOR orange]{}[/COLOR]".format(label)
            info.update(playcount=0, overlay=getattr(xbmcgui, "ICON_OVERLAY_PARTIAL", 8))
        elif status == "watched":
            label = "[COLOR lime]{}[/COLOR]".format(label)
            info.update(playcount=1, overlay=getattr(xbmcgui, "ICON_OVERLAY_WATCHED", 7))
        item = xbmcgui.ListItem(label=label)
        # Some Kodi skins render ListItem.Title instead of ListItem.Label in
        # movie directories. Keep the audio tag in both fields.
        info["title"] = label
        item.setInfo("video", info)
        if status == "watching":
            try:
                item.getVideoInfoTag().setResumePoint(playback["position"], playback["duration"])
            except AttributeError:
                item.setProperty("resumetime", str(playback["position"]))
                item.setProperty("totaltime", str(playback["duration"]))
        item.setArt(art)
        ids = {key: movie[key + "_id"] for key in ("imdb", "tmdb", "csfd") if movie[key + "_id"]}
        if ids:
            item.setUniqueIDs(ids)
        return item

    def resume_label(playback):
        minutes, seconds = divmod(playback["position"], 60)
        hours, minutes = divmod(minutes, 60)
        return text(30061).format(time="{:02d}:{:02d}:{:02d}".format(hours, minutes, seconds))

    def source_size(source):
        technical = source.get("technical") if isinstance(source.get("technical"), dict) else {}
        try:
            return max(0, int(technical.get("size") or source.get("size") or 0))
        except (TypeError, ValueError):
            return 0

    def source_stereo(source):
        technical = source.get("technical") if isinstance(source.get("technical"), dict) else {}
        stereo = technical.get("stereo") if isinstance(technical.get("stereo"), dict) else {}
        label = str(stereo.get("label") or "").strip()
        kodi_mode = str(stereo.get("kodi_mode") or "").strip()
        return {"label": label, "kodi_mode": kodi_mode} if label else {}

    def set_stereo_mode(item, mode):
        if not mode:
            return
        # In Kodi 21 the stereoscopic layout belongs to the video stream
        # details. setInfo("video", {"stereomode": ...}) is ignored there.
        try:
            item.addStreamInfo("video", {"stereomode": mode})
        except (AttributeError, TypeError):
            pass
        item.setProperty("stereomode", mode)

    def source_label(source, already_in_database=False, submitted_for_approval=False, show_source_name=False, in_unassigned=False):
        technical = source.get("technical") if isinstance(source.get("technical"), dict) else {}
        size = source_size(source)
        tags = []
        if size >= 1024 * 1024 * 1024:
            tags.append("[COLOR white][{:.1f} GB][/COLOR]".format(size / float(1024 * 1024 * 1024)))
        elif size >= 1024 * 1024:
            tags.append("[COLOR white][{:.1f} MB][/COLOR]".format(size / float(1024 * 1024)))
        try:
            width = max(0, int(technical.get("width") or 0))
            height = max(0, int(technical.get("height") or 0))
        except (TypeError, ValueError):
            width = height = 0
        quality = str(technical.get("quality") or "").strip()
        name_resolution = source_name_resolution(source.get("name", "")) if not (width and height) else ""
        if quality or height or name_resolution:
            resolution = "{}x{} ({}p)".format(width, height, height) if width and height else ("{}p".format(height) if height else name_resolution)
            quality_text = "{} {}".format(quality, resolution).strip()
            tags.append("[COLOR orange][{}][/COLOR]".format(quality_text))
        def languages(values, limit=0):
            result = []
            for value in values if isinstance(values, list) else []:
                value = str(value).strip().upper()
                if value and value not in result:
                    result.append(value)
                if limit and len(result) == limit:
                    break
            return result
        audio = languages(technical.get("audio", []))
        audio = [value for value in ("CZ", "SK", "EN") if value in audio] + [
            value for value in audio if value not in ("CZ", "SK", "EN")
        ]
        audio = audio[:8]
        subtitles = languages(technical.get("subtitles", []))
        subtitles = [value for value in ("CZ", "SK") if value in subtitles] + [
            value for value in subtitles if value not in ("CZ", "SK")
        ]
        if len(subtitles) > 4:
            subtitles = subtitles[:3] + ["+"]
        if audio:
            tags.append("[COLOR lime][{}][/COLOR]".format(", ".join(audio)))
        if subtitles:
            tags.append("[COLOR red][{}][/COLOR]".format(", ".join(subtitles)))
        stereo = source_stereo(source)
        if stereo:
            tags.append("[COLOR cyan][{}][/COLOR]".format(stereo["label"]))
        label = " ".join(tags)
        if not label:
            label = str(source.get("name") or source.get("id") or "Zdroj WebShare") if show_source_name else "[Zdroj WebShare]"
        if already_in_database:
            return "[COLOR lime]{} [již v databázi][/COLOR]".format(label)
        if submitted_for_approval:
            return "[COLOR orange]{} [odesláno ke schválení][/COLOR]".format(label)
        if in_unassigned:
            return "[COLOR orange]{} [v zatím nezařazených][/COLOR]".format(label)
        return label

    def source_name_resolution(name):
        """Return an explicitly marked resolution hint from a release name."""
        value = str(name or "")
        dimensions = re.search(r"(?<!\d)(\d{3,5})\s*[xX]\s*(\d{3,5})(?!\d)", value)
        if dimensions:
            width, height = dimensions.groups()
            return "{}x{} ({}p, z názvu)".format(width, height, height)
        progressive = re.search(r"(?<!\d)(2160|1440|1080|720|576|540|480)p\b", value, flags=re.I)
        if progressive:
            return "{}p (z názvu)".format(progressive.group(1))
        return ""

    def source_title_hint(name):
        hint = str(name or "")
        hint = re.sub(r"\.[A-Za-z0-9]{2,4}$", "", hint)
        hint = re.sub(r"[._]+", " ", hint)
        hint = re.split(r"\b(?:19|20)\d{2}\b|\b(?:1080|2160|720|480)p\b|\b(?:bluray|bdrip|webrip|web dl|webdl|hdtv|x264|x265|hevc|dvdrip)\b", hint, flags=re.I)[0]
        return " ".join(hint.split()).strip()

    def source_name_title_suggestion(name):
        """Return a readable title portion of a release filename, if present."""
        raw = re.sub(r"\.[A-Za-z0-9]{2,4}$", "", str(name or "").strip())
        # An opaque WebShare identifier has no word delimiter before its
        # extension (for example 3Rx1ZNhfzV.7z). It is not a movie title.
        if not re.search(r"[._\-\s]", raw):
            return ""
        # Uploaders commonly put a Czech title before an underscore and an
        # English release name after it. Prefer the first, human-readable part.
        raw = raw.split("_", 1)[0]
        hint = source_title_hint(raw).strip(" -._")
        words = re.findall(r"[A-Za-zÀ-ž]+", hint)
        if len(words) < 2:
            return ""
        # Avoid presenting generated IDs such as z3wW9nfEuF as a title.
        compact = re.sub(r"[^A-Za-z0-9]", "", hint)
        if len(compact) < 5 or (sum(char.isdigit() for char in compact) * 2 > len(compact)):
            return ""
        return hint[:120].rstrip()

    def confirmed_source_title(source):
        hint = source.get("title_hint") if isinstance(source, dict) else None
        if not isinstance(hint, dict):
            return ""
        title = str(hint.get("title") or "").strip()
        if not title:
            return ""
        try:
            year = int(hint.get("year") or 0)
        except (TypeError, ValueError):
            year = 0
        return "{} ({})".format(title, year) if year else title

    local_source_title_index = None
    csfd_title_index = None

    def csfd_title_hint(csfd_id):
        """Find a title in the compact local CSFD ID index."""
        nonlocal csfd_title_index
        if csfd_title_index is None:
            csfd_title_index = {}
            try:
                path = os.path.join(addon.getAddonInfo("path"), "resources", "csfd_titles.json")
                with open(path, "r", encoding="utf-8") as stream:
                    payload = json.load(stream)
                titles = payload.get("titles") if isinstance(payload, dict) else {}
                if isinstance(titles, dict):
                    csfd_title_index = titles
            except (OSError, ValueError, TypeError, AttributeError):
                pass
        value = csfd_title_index.get(str(csfd_id or "")) if isinstance(csfd_title_index, dict) else None
        if not isinstance(value, list) or not value or not str(value[0] or "").strip():
            return None
        try:
            year = max(0, int(value[1] or 0))
        except (IndexError, TypeError, ValueError):
            year = 0
        return {"title": str(value[0]).strip(), "year": year, "confidence": "csfd_mask_index"}

    def local_source_title_hints(sources):
        nonlocal local_source_title_index
        if local_source_title_index is None:
            by_id, by_name, by_csfd, by_tail = {}, {}, {}, {}

            def remember(index, key, movie):
                if not key:
                    return
                title = str(movie.get("title") or "").strip()
                if not title:
                    return
                value = {"title": title, "year": movie.get("year") or 0, "confidence": "local_catalog"}
                previous = index.get(key)
                if previous is None:
                    index[key] = value
                elif previous.get("title") != title:
                    index[key] = False

            try:
                path = os.path.join(addon.getAddonInfo("path"), "seznam zdroju.json")
                for movie in catalog.load_movies(path):
                    csfd_id = str(movie.get("csfd_id") or "").strip()
                    remember(by_csfd, csfd_id, movie)
                    for catalog_source in movie.get("sources") or []:
                        source_id = str(catalog_source.get("id") or "").strip()
                        source_name = str(catalog_source.get("name") or "").strip()
                        remember(by_id, source_id, movie)
                        remember(by_name, source_name, movie)
                        tail_match = re.search(r"(\d{1,2}z\d{1,2}\.[a-z]{3})$", source_name, re.I)
                        if tail_match:
                            remember(by_tail, tail_match.group(1).lower(), movie)
            except (OSError, ValueError, TypeError, AttributeError):
                pass
            local_source_title_index = (by_id, by_name, by_csfd, by_tail)

        by_id, by_name, by_csfd, by_tail = local_source_title_index
        hints = {}
        for source in sources:
            if not isinstance(source, dict):
                continue
            source_id = str(source.get("id") or "").strip()
            source_name = str(source.get("name") or "").strip()
            stem = re.sub(r"\.[A-Za-z0-9]{2,4}$", "", source_name)
            hint = by_id.get(source_id) or by_name.get(source_name) or by_id.get(stem)
            if not hint:
                du_match = re.match(r"^du(\d{1,2})z(\d{1,2})([a-z]{3})$", stem, re.I)
                if du_match:
                    hint = by_tail.get("{}z{}.{}".format(du_match.group(1), du_match.group(2), du_match.group(3)).lower())
            if not hint and not stem.lower().startswith("du"):
                csfd_match = re.match(r"^([A-Za-z0-9]+?)f", stem, re.I)
                if csfd_match:
                    csfd_id = re.sub(r"\D+", "", csfd_match.group(1))
                    if len(csfd_id) >= 3:
                        hint = by_csfd.get(csfd_id) or csfd_title_hint(csfd_id)
            if isinstance(hint, dict) and str(hint.get("title") or "").strip():
                hints[source_id] = hint
        return hints

    def add_confirmed_source_titles(sources):
        # Versioned marker retries entries cached before local alias matching
        # was added, while avoiding repeated requests for current cache pages.
        pending = [source for source in sources if isinstance(source, dict) and source.get("id") and not source.get("title_hint_checked_v2")]
        if not pending:
            return
        hints = {}
        try:
            hints = server_api.source_title_hints(addon, pending)
        except server_api.ServerError:
            pass
        local_hints = local_source_title_hints(pending)
        for source in pending:
            source["title_hint_checked_v2"] = True
            hint = hints.get(str(source.get("id") or "")) or local_hints.get(str(source.get("id") or ""))
            if isinstance(hint, dict) and str(hint.get("title") or "").strip():
                source["title_hint"] = hint

    def source_search_cache_path():
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(profile):
            os.makedirs(profile)
        return os.path.join(profile, "webshare_search_cache.json")

    def source_search_history_path():
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(profile):
            os.makedirs(profile)
        return os.path.join(profile, "webshare_search_history.json")

    def playback_metadata_path():
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(profile):
            os.makedirs(profile)
        return os.path.join(profile, "source_playback_metadata.json")

    def cached_playback_metadata(source_id):
        try:
            with open(playback_metadata_path(), "r", encoding="utf-8") as stream:
                values = json.load(stream)
            value = values.get(str(source_id or ""), {}) if isinstance(values, dict) else {}
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError, TypeError, AttributeError):
            return {}

    def remember_playback_metadata(source_id, technical):
        source_id = str(source_id or "").strip()
        if not source_id or not isinstance(technical, dict) or not technical:
            return
        path = playback_metadata_path()
        values = {}
        try:
            with open(path, "r", encoding="utf-8") as stream:
                loaded = json.load(stream)
            if isinstance(loaded, dict):
                values = loaded
        except (OSError, ValueError, TypeError):
            pass
        values[source_id] = playback_metadata.merge(values.get(source_id, {}), technical)
        temporary = path + ".tmp"
        try:
            with open(temporary, "w", encoding="utf-8") as stream:
                json.dump(values, stream, ensure_ascii=False)
            os.replace(temporary, path)
        except OSError:
            try:
                os.unlink(temporary)
            except OSError:
                pass

    def language_setting(setting_id, default):
        languages = ("CZ", "SK", "EN", "DE", "FR", "ES", "IT", "PL", "HU", "RU", "JA")
        raw = str(addon.getSetting(setting_id) or "").strip().upper()
        if raw in languages:
            return raw
        try:
            index = int(raw)
        except (TypeError, ValueError):
            index = -1
        return languages[index] if 0 <= index < len(languages) else default

    def language_preferences():
        primary_audio = language_setting("preferred_audio_primary", "CZ")
        secondary_audio = language_setting("preferred_audio_secondary", "SK")
        primary_subtitle = language_setting("preferred_subtitle_primary", "CZ")
        secondary_subtitle = language_setting("preferred_subtitle_secondary", "SK")
        return {
            "audio": [primary_audio] + ([secondary_audio] if secondary_audio != primary_audio else []),
            "subtitles_enabled": str(addon.getSetting("preferred_subtitles_enabled") or "").strip().lower() == "true",
            "subtitles": [primary_subtitle] + ([secondary_subtitle] if secondary_subtitle != primary_subtitle else []),
        }

    def observe_playback(source, player, save_to_server=False, collect_metadata=True):
        preferences = language_preferences()
        playback_metadata.apply_language_preferences(
            player, preferences["audio"], preferences["subtitles_enabled"], preferences["subtitles"]
        )
        if not collect_metadata:
            return
        observed = playback_metadata.observe(player)
        if not observed:
            return
        source["technical"] = playback_metadata.merge(source.get("technical", {}), observed)
        remember_playback_metadata(source.get("id"), source["technical"])
        if save_to_server:
            try:
                server_api.update_source_technical(addon, source)
            except server_api.ServerError:
                pass
        return True

    def source_id_cache_path():
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(profile):
            os.makedirs(profile)
        return os.path.join(profile, "server_source_ids.json")

    def submitted_source_ids_path():
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(profile):
            os.makedirs(profile)
        return os.path.join(profile, "submitted_source_ids.json")

    def submitted_source_ids():
        try:
            with open(submitted_source_ids_path(), "r", encoding="utf-8") as stream:
                values = json.load(stream)
            return {str(value) for value in values if str(value)} if isinstance(values, list) else set()
        except (OSError, ValueError, TypeError):
            return set()

    def remember_submitted_source(source_id):
        source_id = str(source_id or "").strip()
        if not source_id:
            return
        values = submitted_source_ids()
        values.add(source_id)
        path = submitted_source_ids_path()
        temporary = path + ".tmp"
        try:
            with open(temporary, "w", encoding="utf-8") as stream:
                json.dump(sorted(values), stream)
            os.replace(temporary, path)
        except OSError:
            try:
                os.unlink(temporary)
            except OSError:
                pass

    def known_source_ids(refresh=False):
        path = source_id_cache_path()
        cached_values = set()
        try:
            with open(path, "r", encoding="utf-8") as stream:
                cached = json.load(stream)
            cached_values = {str(value) for value in cached.get("ids", []) if str(value)}
            if not refresh and time.time() - float(cached.get("saved_at") or 0) < 10 * 60:
                return cached_values
        except (OSError, ValueError, TypeError, AttributeError):
            pass
        try:
            values = server_api.source_ids(addon)
        except server_api.ServerError:
            return cached_values
        temporary = path + ".tmp"
        try:
            with open(temporary, "w", encoding="utf-8") as stream:
                json.dump({"saved_at": time.time(), "ids": sorted(values)}, stream)
            os.replace(temporary, path)
        except OSError:
            try:
                os.unlink(temporary)
            except OSError:
                pass
        return values

    def load_source_search_cache(query, page, sort):
        try:
            with open(source_search_cache_path(), "r", encoding="utf-8") as stream:
                cached = json.load(stream)
            if not isinstance(cached, dict) or str(cached.get("query") or "").casefold() != str(query or "").casefold():
                return []
            cached_sort = cached.get("sort") or "largest"
            if cached_sort != sort:
                return []
            if time.time() - float(cached.get("saved_at") or 0) > 6 * 60 * 60:
                return []
            pages = cached.get("pages") if isinstance(cached.get("pages"), dict) else {"0": cached.get("sources", [])}
            sources = pages.get(str(page), [])
            if not isinstance(sources, list):
                return []
            sources = [item for item in sources if isinstance(item, dict) and item.get("id")]
            # Version 4 added width/height.  Refresh older pages so labels do
            # not show a derived quality followed by an incorrect 0p suffix.
            if any(not isinstance(item.get("technical"), dict) or not item["technical"].get("scanned_at") or int(item["technical"].get("metadata_version") or 0) < 4 for item in sources):
                return []
            return sources
        except (OSError, ValueError, TypeError):
            return []

    def save_source_search_cache(query, page, sort, sources):
        path = source_search_cache_path()
        temporary = path + ".tmp"
        pages = {}
        try:
            with open(path, "r", encoding="utf-8") as stream:
                previous = json.load(stream)
            if isinstance(previous, dict) and str(previous.get("query") or "").casefold() == str(query or "").casefold() and previous.get("sort") == sort and isinstance(previous.get("pages"), dict):
                pages = previous["pages"]
        except (OSError, ValueError, TypeError):
            pass
        pages[str(page)] = sources
        payload = {"query": query, "sort": sort, "pages": pages, "saved_at": time.time()}
        try:
            with open(temporary, "w", encoding="utf-8") as stream:
                json.dump(payload, stream, ensure_ascii=False)
            os.replace(temporary, path)
        except OSError:
            try:
                os.unlink(temporary)
            except OSError:
                pass

    def load_source_search_history():
        try:
            with open(source_search_history_path(), "r", encoding="utf-8") as stream:
                history = json.load(stream)
            if not isinstance(history, list):
                return []
            return [str(item).strip() for item in history if str(item).strip()][:25]
        except (OSError, ValueError, TypeError):
            return []

    def save_source_search_history(history):
        path = source_search_history_path()
        temporary = path + ".tmp"
        try:
            with open(temporary, "w", encoding="utf-8") as stream:
                json.dump(history[:25], stream, ensure_ascii=False)
            os.replace(temporary, path)
        except OSError:
            try:
                os.unlink(temporary)
            except OSError:
                pass

    def add_source_search_history(query):
        query = str(query or "").strip()
        if not query:
            return
        history = [item for item in load_source_search_history() if item.casefold() != query.casefold()]
        history.insert(0, query)
        save_source_search_history(history)

    def add_source_search_results(query, page, sort, found):
        xbmcplugin.setContent(handle, "movies")
        xbmcplugin.setPluginCategory(handle, 'Hledání „{}“ — strana {}'.format(query, page + 1))
        # Search must use the current server catalog. Otherwise a recently
        # approved source could remain visible until the local ID cache expires.
        existing_ids = known_source_ids(refresh=True)
        submitted_ids = submitted_source_ids()
        try:
            unassigned_ids = {
                str(item.get("id") or "").strip()
                for item in server_api.unassigned_sources(addon)
                if isinstance(item, dict) and item.get("id")
            }
        except server_api.ServerError:
            # A temporary server error must not make source search unusable.
            unassigned_ids = set()
        add_confirmed_source_titles(found)
        for source in found:
            source_id = str(source.get("id") or "")
            source_name = str(source.get("name") or source_id)
            if not source_id or source_id in existing_ids:
                continue
            source["technical"] = playback_metadata.merge(
                source.get("technical", {}), cached_playback_metadata(source_id)
            )
            in_unassigned = source_id in unassigned_ids
            item = xbmcgui.ListItem(label=source_label(source, False, source_id in submitted_ids, True, in_unassigned))
            # source_play starts xbmc.Player directly so Kodi can inspect the
            # real WebShare path and expose its stereoscopic mode.
            item.setProperty("IsPlayable", "false")
            title_hint = confirmed_source_title(source)
            info = {"title": source_name}
            if title_hint:
                info["plot"] = "Možný název: {}".format(title_hint)
            else:
                filename_hint = source_name_title_suggestion(source_name)
                info["plot"] = "Návrh podle názvu zdroje: {}".format(filename_hint) if filename_hint else "Možný název filmu zatím není znám."
            if in_unassigned:
                info["plot"] = "Zdroj už je v seznamu Zatím nezařazené.\n\n{}".format(info["plot"])
            info["plotoutline"] = info["plot"]
            item.setInfo("video", info)
            context = [("Hledat název na TMDB", "RunPlugin({})".format(url(action="source_tmdb", source_id=source_id, source_name=source_name, source_hint=title_hint)))]
            if addon.getSetting("server_role").strip().lower() in ("admin", "moderator") and not in_unassigned:
                context.append(("Přidat do nezařazených podle TMDB", "RunPlugin({})".format(url(action="source_unassigned", source_id=source_id, source_name=source_name))))
            item.addContextMenuItems(context, replaceItems=False)
            xbmcplugin.addDirectoryItem(handle, url(action="source_play", source_id=source_id, source_name=source_name, source_origin="search"), item, False)
        if page > 0:
            previous = xbmcgui.ListItem(label="Předchozí stránka ({})".format(page))
            previous.setArt({"icon": "DefaultFolderBack.png"})
            xbmcplugin.addDirectoryItem(handle, url(action="source_search_run", query=query, sort=sort, page=page - 1), previous, True)
        if len(found) == PAGE_SIZE:
            next_page = xbmcgui.ListItem(label="Další stránka ({})".format(page + 2))
            next_page.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(handle, url(action="source_search_run", query=query, sort=sort, page=page + 1), next_page, True)

    if action == "settings":
        addon.openSettings()
        end()
        return
    if action == "login":
        try:
            webshare.get_token(addon, force=True)
            addon.setSetting("status", text(30008))
            xbmcgui.Dialog().notification(title, text(30009), xbmcgui.NOTIFICATION_INFO)
        except webshare.WebshareError as exc:
            addon.setSetting("status", text(exc.message_id))
            error(exc.message_id)
        return
    if action == "server_login":
        try:
            profile = server_api.login(addon)
            xbmcgui.Dialog().notification(title, text(30041), xbmcgui.NOTIFICATION_INFO)
        except server_api.ServerError as exc:
            addon.setSetting("server_status", text(30042))
            server_error(exc)
        end()
        return
    if action == "server_logout":
        server_api.logout(addon)
        xbmcgui.Dialog().notification(title, text(30043), xbmcgui.NOTIFICATION_INFO)
        end()
        return
    if action == "source_search":
        xbmcplugin.setContent(handle, "files")
        xbmcplugin.addDirectoryItem(handle, url(action="source_search_input", sort="largest"), xbmcgui.ListItem(label="Nové hledání podle největšího"), True)
        xbmcplugin.addDirectoryItem(handle, url(action="source_search_input", sort="recent"), xbmcgui.ListItem(label="Nové hledání podle nejnovějšího"), True)
        xbmcplugin.addDirectoryItem(handle, url(action="source_search_history"), xbmcgui.ListItem(label="Historie hledání"), True)
        end()
        return
    if action == "source_search_history":
        xbmcplugin.setContent(handle, "files")
        history = load_source_search_history()
        if not history:
            xbmcgui.Dialog().notification(title, "Historie hledání je prázdná.", xbmcgui.NOTIFICATION_INFO)
        for query in history:
            xbmcplugin.addDirectoryItem(handle, url(action="source_search_run", query=query, sort="recent", page=0), xbmcgui.ListItem(label=query), True)
        end()
        return
    if action == "source_search_input":
        query = xbmcgui.Dialog().input("Hledat nové zdroje pro filmy", type=xbmcgui.INPUT_ALPHANUM).strip()
        if not query:
            end(False)
            return
        sort = params.get("sort", "recent")
        if sort not in ("largest", "recent"):
            sort = "recent"
        # Replace the input folder with results. It keeps the result page in
        # Kodi navigation, so Back returns to the previous result page rather
        # than opening the text input again.
        target = url(action="source_search_run", query=query, sort=sort, page=0)
        end()
        xbmc.sleep(100)
        xbmc.executebuiltin('Container.Update("{}",replace)'.format(target))
        return
    if action == "source_search_run":
        query = params.get("query", "").strip()
        try:
            page = max(0, int(params.get("page", "0")))
        except (TypeError, ValueError):
            page = 0
        sort = params.get("sort", "recent")
        if sort not in ("largest", "recent"):
            sort = "recent"
        if not query:
            end(False)
            return
        cached_sources = load_source_search_cache(query, page, sort)
        if cached_sources:
            add_source_search_results(query, page, sort, cached_sources)
            end()
            return
        try:
            found = webshare.search(query, limit=PAGE_SIZE, offset=page * PAGE_SIZE, sort=sort)
        except webshare.WebshareError as exc:
            error(exc.message_id)
            end(False)
            return
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        if not found:
            xbmcgui.Dialog().notification(title, "WebShare nic nenalezl.", xbmcgui.NOTIFICATION_INFO)
            end()
            return
        try:
            found = webshare.enrich_sources(found, webshare.get_token(addon))
        except webshare.WebshareError as exc:
            error(exc.message_id)
            end(False)
            return
        add_confirmed_source_titles(found)
        save_source_search_cache(query, page, sort, found)
        add_source_search_history(query)
        add_source_search_results(query, page, sort, found)
        end()
        return
    if action == "source_play":
        ident = params.get("source_id", "").strip()
        source = {"id": ident, "name": params.get("source_name", ident), "technical": cached_playback_metadata(ident)}
        try:
            link = webshare.resolve(ident, webshare.get_token(addon))
        except webshare.WebshareError as exc:
            error(exc.message_id)
            xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
            return
        playback_link = webshare.kodi_playback_url(link)
        item = xbmcgui.ListItem(label=params.get("source_name", ident))
        # WebShare filenames are not reliable extensions: a video can be
        # named .7z, .raa, .nes, or any other suffix.  Explicitly select the
        # video player so Kodi does not offer an emulator based on a mask.
        item.setMimeType("video/x-matroska")
        item.setContentLookup(False)
        item.setPath(playback_link)
        item.setProperty("IsPlayable", "false")
        end()
        player = xbmc.Player()
        player.play(playback_link, item)
        observe_playback(source, player, params.get("source_origin") == "database")
        return
    if action == "person_info":
        person = metadata.fetch_person(params.get("person_id", ""))
        if not person:
            xbmcgui.Dialog().notification(title, "Informace o osobě nejsou dostupné.", xbmcgui.NOTIFICATION_INFO)
            end(False)
            return
        lines = [person.get("name") or params.get("person_name", "Osoba")]
        for label, value in (("Obor", person.get("department")), ("Narození", person.get("birthday")),
                             ("Úmrtí", person.get("deathday")), ("Místo narození", person.get("place")),
                             ("Počet titulů", person.get("credit_count"))):
            if value:
                lines.extend(["", "{}: {}".format(label, value)])
        if person.get("biography"):
            lines.extend(["", "Životopis:", person["biography"]])
        xbmcgui.Dialog().textviewer(person.get("name") or "Osoba", "\n".join(lines))
        end()
        return
    if action == "movie_media_video":
        site = params.get("site", "").strip().lower()
        video_key = params.get("video_key", "").strip()
        if site == "youtube" and video_key:
            xbmc.Player().play("plugin://plugin.video.youtube/play/?video_id=" + video_key)
        else:
            xbmcgui.Dialog().notification(title, "Toto video nelze v Kodi přehrát.", xbmcgui.NOTIFICATION_INFO)
        return
    if action in ("movie_menu", "movie_section", "movie_people", "movie_media", "movie_media_images", "movie_media_videos"):
        movie_key = params.get("movie", "").strip()
        try:
            entries = movies()
            movie = next((item for item in entries if item.get("key") == movie_key), None)
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        if not movie:
            error(30013)
            end(False)
            return
        if action in ("movie_media", "movie_media_images", "movie_media_videos"):
            metadata.enrich([movie], xbmcvfs.translatePath(addon.getAddonInfo("profile")))
            details = movie.get("details") or {}
            media = details.get("media") or {}
            if action == "movie_media":
                xbmcplugin.setContent(handle, "files")
                choices = (("Nejoblíbenější", "movie_media_images", "DefaultPicture.png", len(media.get("popular") or [])),
                           ("Videa", "movie_media_videos", "DefaultAddonVideo.png", len(media.get("videos") or [])),
                           ("Pozadí", "movie_media_images", "DefaultPicture.png", len(media.get("backdrops") or [])),
                           ("Plakáty", "movie_media_images", "DefaultPicture.png", len(media.get("posters") or [])))
                for label, target, icon, count in choices:
                    item = xbmcgui.ListItem(label="{} ({})".format(label, count))
                    item.setArt({"icon": icon})
                    query = {"action": target, "movie": movie_key}
                    if target == "movie_media_images":
                        query["kind"] = "backdrops" if label == "Pozadí" else ("posters" if label == "Plakáty" else "popular")
                    xbmcplugin.addDirectoryItem(handle, url(**query), item, True)
                end()
                return
            if action == "movie_media_images":
                kind = params.get("kind", "").strip()
                images = media.get(kind) or []
                xbmcplugin.setContent(handle, "images")
                for index, image in enumerate(images, 1):
                    if not isinstance(image, dict) or not image.get("url"):
                        continue
                    label = ("Pozadí" if kind == "backdrops" else ("Plakát" if kind == "posters" else "Obrázek")) + " " + str(index)
                    if image.get("language"):
                        label += " [" + str(image["language"]) + "]"
                    item = xbmcgui.ListItem(label=label)
                    item.setArt({"thumb": str(image.get("thumb") or image["url"]), "icon": str(image.get("thumb") or image["url"]), "poster": str(image.get("thumb") or image["url"]), "fanart": str(image["url"])})
                    xbmcplugin.addDirectoryItem(handle, str(image["url"]), item, False)
                end()
                return
            xbmcplugin.setContent(handle, "videos")
            for video in media.get("videos") or []:
                if not isinstance(video, dict) or not video.get("key"):
                    continue
                label = str(video.get("name") or "Video")
                if video.get("type") or video.get("site"):
                    label += "  [{}]".format(" | ".join(part for part in (str(video.get("type") or ""), str(video.get("site") or "")) if part))
                item = xbmcgui.ListItem(label=label)
                thumb = str(video.get("thumb") or "DefaultAddonVideo.png")
                item.setArt({"thumb": thumb, "icon": thumb, "poster": thumb})
                item.setProperty("IsPlayable", "true")
                xbmcplugin.addDirectoryItem(handle, url(action="movie_media_video", site=video.get("site", ""), video_key=video["key"], title=video.get("name", "Video")), item, False)
            end()
            return
        if action == "movie_people":
            metadata.enrich([movie], xbmcvfs.translatePath(addon.getAddonInfo("profile")))
            details = movie.get("details") or {}
            section = params.get("section", "").strip()
            people = (details.get("people") or {}).get(section) or []
            xbmcplugin.setContent(handle, "actors")
            for person in people:
                if not isinstance(person, dict) or not person.get("id") or not person.get("name"):
                    continue
                person_item = xbmcgui.ListItem(label=str(person["name"]))
                if person.get("role"):
                    person_item.setLabel2(str(person["role"]))
                person_item.setInfo("video", {"title": str(person["name"]), "studio": str(person.get("role") or "")})
                profile = str(person.get("profile") or "")
                person_item.setArt({"thumb": profile or "DefaultActor.png", "icon": profile or "DefaultActor.png", "poster": profile or "DefaultActor.png"})
                xbmcplugin.addDirectoryItem(handle, url(action="person_info", person_id=person["id"], person_name=person["name"]), person_item, False)
            if not people:
                xbmcgui.Dialog().notification(title, "Pro tuto položku nejsou dostupné osoby.", xbmcgui.NOTIFICATION_INFO)
            end()
            return
        if action == "movie_section":
            metadata.enrich([movie], xbmcvfs.translatePath(addon.getAddonInfo("profile")))
            details = movie.get("details") or {}
            section = params.get("section", "").strip()
            if section == "Základní informace":
                lines = [movie.get("title", "")]
                for label, value in (("Původní název", details.get("originaltitle")), ("Rok", details.get("year") or movie.get("year")), ("Žánr", " / ".join(details.get("genre") or movie.get("genres") or [])), ("Hodnocení TMDB", "{:.1f}/10 ({} hlasů)".format(float(details.get("rating") or movie.get("rating") or 0), int(details.get("votes") or 0)) if details.get("votes") else ""), ("Popis", details.get("plot"))):
                    if value:
                        lines.extend(["", "{}: {}".format(label, value)])
            else:
                values = (details.get("sections") or {}).get(section) or []
                lines = [str(value) for value in values] or ["Pro tuto položku nejsou dostupné informace."]
            xbmcgui.Dialog().textviewer(section or "Informace o filmu", "\n".join(lines))
            end()
            return
        metadata.enrich([movie], xbmcvfs.translatePath(addon.getAddonInfo("profile")))
        xbmcplugin.setContent(handle, "files")
        playback = movie.get("playback") or {}
        if playback.get("status") == "watching":
            resume_item = xbmcgui.ListItem(label=resume_label(playback))
            xbmcplugin.addDirectoryItem(handle, url(action="resume_play", movie=movie_key), resume_item, False)
        play_item = movie_item(movie)
        play_item.setProperty("IsPlayable", "false")
        play_item.addContextMenuItems(custom_list_context(movie_key), replaceItems=False)
        xbmcplugin.addDirectoryItem(handle, url(action="choose_play", movie=movie_key), play_item, False)
        details = movie.get("details") or {}
        sections = details.get("sections") or {}
        people_sections = details.get("people") or {}
        for section in ("Základní informace", "Herci", "Režie", "Scénář", "Produkce", "Kamera", "Hudba / zvuk", "Média"):
            values = people_sections.get(section) if section in people_sections else sections.get(section) or []
            if section == "Média":
                values = (details.get("media") or {}).get("videos") or []
            label = section if section in ("Základní informace", "Média") else "{} ({})".format(section, len(values))
            section_item = xbmcgui.ListItem(label=label)
            section_item.setArt({"icon": "DefaultFolder.png"})
            target_action = "movie_people" if section in people_sections else "movie_section"
            if section == "Média":
                target_action = "movie_media"
            xbmcplugin.addDirectoryItem(handle, url(action=target_action, movie=movie_key, section=section), section_item, target_action in ("movie_people", "movie_media"))
        end()
        return
    if action in ("source_tmdb", "source_unassigned"):
        source = {"id": params.get("source_id", "").strip(), "name": params.get("source_name", "").strip()}
        source["technical"] = cached_playback_metadata(source["id"])
        if not source["id"]:
            end(False)
            return
        is_unassigned = action == "source_unassigned"
        use_tmdb = not is_unassigned or xbmcgui.Dialog().yesno(title, "Vyhledat a přiřadit film z TMDB?", "Ne zvolí uložení pouze s pracovním názvem.")
        if use_tmdb:
            default_query = params.get("source_hint", "").strip() or source_title_hint(source["name"])
            query = xbmcgui.Dialog().input("Hledat název na TMDB", defaultt=default_query, type=xbmcgui.INPUT_ALPHANUM)
            if not query:
                end()
                return
            found = metadata.search_movies(query)
            if not found:
                xbmcgui.Dialog().ok(title, "Na TMDB nebyl nalezen žádný film. Zkuste upravit název.")
                end(False)
                return
            labels = ["{}{}  [TMDB {}]".format(movie["title"], " ({})".format(movie["year"]) if movie["year"] else "", movie["tmdb_id"]) for movie in found]
            selected = xbmcgui.Dialog().select("Vyberte film z TMDB", labels)
            if selected < 0:
                end()
                return
            movie = found[selected]
        else:
            working_title = xbmcgui.Dialog().input("Pracovní název", defaultt=source_title_hint(source["name"]), type=xbmcgui.INPUT_ALPHANUM)
            if not working_title:
                end()
                return
            movie = {"title": working_title, "year": 0, "tmdb_id": "", "tmdb_type": "movie"}
        confirmation = "Přidat zdroj do zatím nezařazených?" if is_unassigned else "Odeslat zdroj ke schválení?"
        tmdb_line = "TMDB ID: {}\n".format(movie["tmdb_id"]) if movie.get("tmdb_id") else ""
        if not xbmcgui.Dialog().yesno(title, "{}\n{}\n{}{}".format(confirmation, movie["title"], tmdb_line, source["name"])):
            end()
            return
        try:
            # Save complete technical data at submission time.  This includes
            # the actual WebShare metadata and the small MKV track header for
            # embedded subtitles and the 3D StereoMode flag.
            scanned = webshare.submission_technical(source["id"], webshare.get_token(addon))
            source["technical"] = playback_metadata.merge(scanned, source.get("technical", {}))
        except webshare.WebshareError:
            source["technical"] = {}
        try:
            if is_unassigned:
                result = server_api.save_unassigned_source(addon, source, movie)
                message = "Zdroj byl uložen do zatím nezařazených." if result.get("status") == "saved" else "Zdroj už je v zatím nezařazených."
            else:
                result = server_api.submit_source(addon, source, movie)
                if result.get("status") == "pending":
                    remember_submitted_source(source["id"])
                message = "Zdroj byl odeslán ke schválení." if result.get("status") == "pending" else "Zdroj už byl odeslán nebo schválen."
            xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except server_api.ServerError as exc:
            server_error(exc)
        end()
        return
    if action == "unassigned_sources":
        try:
            sources = server_api.unassigned_sources(addon)
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        xbmcplugin.setContent(handle, "files")
        for source in sources:
            movie_label = str(source.get("title") or "Nezařazený film")
            if source.get("year"):
                movie_label += " ({})".format(source["year"])
            label = "{} — {}".format(movie_label, source_label(source, show_source_name=True))
            item = xbmcgui.ListItem(label=label)
            item.setProperty("IsPlayable", "true")
            item.setInfo("video", {"title": movie_label, "year": int(source.get("year") or 0)})
            if addon.getSetting("server_role").strip().lower() in ("admin", "moderator"):
                item.addContextMenuItems([("Přiřadit TMDB", "RunPlugin({})".format(url(action="unassigned_assign_tmdb", item_id=source.get("item_id", ""), source_name=source.get("name", ""), title=source.get("title", ""))))], replaceItems=False)
            xbmcplugin.addDirectoryItem(handle, url(action="source_play", source_id=source.get("id", ""), source_name=source.get("name", "")), item, False)
        end()
        return
    if action == "unassigned_assign_tmdb":
        item_id = params.get("item_id", "").strip()
        if not item_id:
            end(False)
            return
        query = xbmcgui.Dialog().input("Hledat název na TMDB", defaultt=params.get("title", "") or source_title_hint(params.get("source_name", "")), type=xbmcgui.INPUT_ALPHANUM)
        if not query:
            end()
            return
        found = metadata.search_movies(query)
        if not found:
            xbmcgui.Dialog().ok(title, "Na TMDB nebyl nalezen žádný film. Zkuste upravit název.")
            end(False)
            return
        labels = ["{}{}  [TMDB {}]".format(movie["title"], " ({})".format(movie["year"]) if movie["year"] else "", movie["tmdb_id"]) for movie in found]
        selected = xbmcgui.Dialog().select("Vyberte film z TMDB", labels)
        if selected < 0:
            end()
            return
        try:
            server_api.assign_unassigned_tmdb(addon, item_id, found[selected])
            xbmcgui.Dialog().notification(title, "TMDB bylo přiřazeno.", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except server_api.ServerError as exc:
            server_error(exc)
        end()
        return
    if action == "source_stereo":
        movie_key = params.get("movie", "").strip()
        try:
            entries = movies()
            movie = next((item for item in entries if item.get("key") == movie_key), None)
            sources = server_api.movie_sources(addon, movie_key)
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        if not movie or not sources:
            xbmcgui.Dialog().notification(title, "Pro tento film nejsou dostupné zdroje.", xbmcgui.NOTIFICATION_WARNING)
            end(False)
            return
        selected = xbmcgui.Dialog().select("Vyberte zdroj pro nastavení 3D", [source_label(source) for source in sources])
        if selected < 0:
            end()
            return
        modes = [("3D SBS – obraz vedle sebe", "sbs_lr"), ("3D TAB – obraz nad sebou", "tab_tb"), ("2D / odstranit ruční označení 3D", "mono")]
        mode_index = xbmcgui.Dialog().select("Vyberte režim zdroje", [item[0] for item in modes])
        if mode_index < 0:
            end()
            return
        try:
            server_api.set_source_stereo(addon, sources[selected], modes[mode_index][1])
            xbmcgui.Dialog().notification(title, "Režim zdroje byl uložen.", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except server_api.ServerError as exc:
            server_error(exc)
        end()
        return
    if action in ("source_report", "source_correct"):
        movie_key = params.get("movie", "").strip()
        try:
            entries = movies()
            movie = next((item for item in entries if item.get("key") == movie_key), None)
            sources = server_api.movie_sources(addon, movie_key)
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        if not movie or not sources:
            xbmcgui.Dialog().notification(title, "Pro tento film nejsou dostupné zdroje.", xbmcgui.NOTIFICATION_WARNING)
            end(False)
            return
        labels = [source_label(source) for source in sources]
        selected = xbmcgui.Dialog().select("Vyberte zdroj", labels)
        if selected < 0:
            end()
            return
        source = sources[selected]
        if action == "source_report":
            if not xbmcgui.Dialog().yesno(title, "Nahlásit tento zdroj k prověření?\n{}\n{}".format(movie.get("title", ""), source.get("name", ""))):
                end()
                return
            try:
                result = server_api.report_source(addon, movie, source)
                message = "Hlášení bylo odesláno ke kontrole." if not result.get("duplicate") else "Tento zdroj už čeká na kontrolu."
                xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO)
            except server_api.ServerError as exc:
                server_error(exc)
            end()
            return
        query = xbmcgui.Dialog().input("Najít správný film na TMDB", defaultt=movie.get("title", ""), type=xbmcgui.INPUT_ALPHANUM)
        if not query:
            end()
            return
        found = metadata.search_movies(query)
        if not found:
            xbmcgui.Dialog().ok(title, "Na TMDB nebyl nalezen žádný film. Zkuste upravit název.")
            end(False)
            return
        labels = ["{}{}  [TMDB {}]".format(item["title"], " ({})".format(item["year"]) if item["year"] else "", item["tmdb_id"]) for item in found]
        selected = xbmcgui.Dialog().select("Vyberte správný film z TMDB", labels)
        if selected < 0:
            end()
            return
        correct_movie = found[selected]
        if not xbmcgui.Dialog().yesno(title, "Převést zdroj k tomuto filmu?\n{}\n{}".format(correct_movie["title"], source.get("name", ""))):
            end()
            return
        try:
            server_api.correct_source(addon, source, correct_movie)
            xbmcgui.Dialog().notification(title, "Zdroj byl opraven a čeká na doplnění metadat.", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except server_api.ServerError as exc:
            server_error(exc)
        end()
        return
    if action == "source_verify":
        try:
            pending = server_api.pending_sources(addon)
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        if not pending:
            xbmcgui.Dialog().notification(title, "Žádné zdroje nečekají na schválení.", xbmcgui.NOTIFICATION_INFO)
            end()
            return
        xbmcplugin.setContent(handle, "movies")
        for suggestion in pending:
            source_id = str(suggestion.get("webshare_id") or "")
            suggestion_id = str(suggestion.get("id") or "")
            if not source_id or not suggestion_id:
                continue
            movie_title = str(suggestion.get("title") or "Bez názvu")
            year = int(suggestion.get("year") or 0)
            label = movie_title + (" ({})".format(year) if year else "")
            item = xbmcgui.ListItem(label=label)
            item.setProperty("IsPlayable", "true")
            item.setInfo("video", {"title": movie_title, "year": year})
            item.setLabel2(source_label({"name": suggestion.get("source_name"), "id": source_id, "technical": suggestion.get("technical")}, show_source_name=True))
            item.addContextMenuItems([
                ("Schválit zdroj", "RunPlugin({})".format(url(action="source_approve", suggestion_id=suggestion_id, source_name=suggestion.get("source_name", "")))),
                ("Zamítnout zdroj", "RunPlugin({})".format(url(action="source_reject", suggestion_id=suggestion_id))),
            ], replaceItems=False)
            xbmcplugin.addDirectoryItem(handle, url(action="source_play", source_id=source_id, source_name=suggestion.get("source_name", source_id)), item, False)
        end()
        return
    if action == "source_approve":
        suggestion_id = params.get("suggestion_id", "").strip()
        if not suggestion_id:
            end(False)
            return
        if not xbmcgui.Dialog().yesno(title, "Schválit tento zdroj a zařadit jej do filmového seznamu?"):
            end()
            return
        try:
            server_api.approve_source(addon, suggestion_id)
            xbmcgui.Dialog().notification(title, "Zdroj byl schválen.", xbmcgui.NOTIFICATION_INFO)
        except server_api.ServerError as exc:
            server_error(exc)
        end()
        return
    if action == "source_reject":
        suggestion_id = params.get("suggestion_id", "").strip()
        if not suggestion_id:
            end(False)
            return
        if not xbmcgui.Dialog().yesno(title, "Zamítnout tento zdroj?"):
            end()
            return
        try:
            server_api.reject_source(addon, suggestion_id)
            xbmcgui.Dialog().notification(title, "Zdroj byl zamítnut.", xbmcgui.NOTIFICATION_INFO)
        except server_api.ServerError as exc:
            server_error(exc)
        end()
        return
    if action == "playback_history":
        xbmcplugin.setContent(handle, "files")
        for mode, label_id in PLAYBACK_LISTS.items():
            xbmcplugin.addDirectoryItem(handle, url(action="movies", mode=mode),
                                        xbmcgui.ListItem(label=text(label_id)), True)
        end()
        return
    if action == "menu_node" and params.get("node") == "my_lists":
        action = "my_lists"
    if action == "my_lists":
        try:
            _, lists = server_api.custom_lists(addon)
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        xbmcplugin.setContent(handle, "files")
        xbmcplugin.setPluginCategory(handle, text(30064))
        for row in lists:
            item = xbmcgui.ListItem(label=row["name"])
            item.setArt({"icon": "DefaultFolder.png"})
            target = url(action="movies", mode="custom_list", list_id=row["id"])
            xbmcplugin.addDirectoryItem(handle, target, item, True)
        if not lists:
            xbmcgui.Dialog().notification(text(30064), text(30071))
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
        end()
        return
    if action in ("custom_list_add", "custom_list_remove"):
        movie_key = params.get("movie", "").strip()
        if not movie_key:
            end(False)
            return
        dialog = xbmcgui.Dialog()
        try:
            if action == "custom_list_add":
                scope, lists = server_api.custom_lists(addon)
                choice = dialog.contextmenu([text(30067)] + [row["name"] for row in lists])
                if choice < 0:
                    end()
                    return
                if choice == 0:
                    name = dialog.input(text(30067), type=xbmcgui.INPUT_ALPHANUM).strip()
                    if not name:
                        end()
                        return
                    if len(name) > 80:
                        error(30074)
                        end(False)
                        return
                    changed = server_api.update_custom_list(addon, "add", movie_key, scope=scope, name=name)
                else:
                    changed = server_api.update_custom_list(addon, "add", movie_key, scope=scope,
                                                            list_id=lists[choice - 1]["id"])
                dialog.notification(text(30064), text(30068 if changed else 30069))
            else:
                server_api.update_custom_list(addon, "remove", movie_key, list_id=params.get("list_id", ""))
                dialog.notification(text(30064), text(30070))
                xbmc.executebuiltin("Container.Refresh")
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        end()
        return
    if action == "menu_node" and params.get("node") in PLAYBACK_LISTS:
        action = "movies"
        params["mode"] = params["node"]
    if action == "menu_node":
        try:
            menu_data = server_api.menu(addon)
            node = find_menu_node(menu_data.get("items", []), params.get("node", ""))
        except server_api.ServerError as exc:
            server_error(exc)
            end(False)
            return
        if not node:
            end(False)
            return
        if str(node.get("id") or "") == "movies_search":
            action = "movie_search"
        elif node.get("action") == "movies":
            action = "movies"
            params["mode"] = node.get("mode", "all")
        elif node.get("action") == "movies_genre":
            action = "movies"
            params["mode"] = "genre"
        elif node.get("action") == "settings":
            addon.openSettings()
            end()
            return
        elif node.get("children"):
            xbmcplugin.setContent(handle, "files")
            movie_count = None
            if str(node.get("id") or "") == "movies":
                try:
                    movie_count = len(movies())
                except server_api.ServerError:
                    movie_count = None
            add_menu_items(node.get("children"), movie_count)
            end()
            return
        else:
            xbmcgui.Dialog().notification(title, text(30050), xbmcgui.NOTIFICATION_INFO)
            end()
            return
    if action == "movie_search":
        query = xbmcgui.Dialog().input(text(30057), type=xbmcgui.INPUT_ALPHANUM).strip()
        if not query:
            end()
            return
        # Replace the input action in Kodi's navigation history with the
        # result URL.  Back from a played movie therefore restores this
        # result list instead of opening the keyboard again.
        target = url(action="movies", mode="search", query=query)
        end()
        xbmc.sleep(100)
        xbmc.executebuiltin('Container.Update("{}",replace)'.format(target))
        return
    if action == "verify":
        try:
            server_api.ensure_connection(addon)
            sources = catalog.load_sources(os.path.join(xbmcvfs.translatePath(addon.getAddonInfo("path")), "seznam zdroju.json"))
            token = webshare.get_token(addon)
        except (OSError, ValueError):
            error(30014)
            end(False)
            return
        except webshare.WebshareError as exc:
            error(exc.message_id)
            end(False)
            return
        if not xbmcgui.Dialog().yesno(title, text(30025).format(total=len(sources))):
            end()
            return
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create(title, text(30026))
        results = []
        cancelled = False
        try:
            for index, source in enumerate(sources, 1):
                progress_dialog.update(int(100 * (index - 1) / len(sources)), "{} — {}".format(source["title"], source["name"]))
                if progress_dialog.iscanceled():
                    cancelled = True
                    break
                name_lower = source["name"].lower()
                supplemental = name_lower.endswith(SUBTITLE_SUFFIXES)
                result = {"id": source["id"], "name": source["name"], "title": source["title"],
                          "checked_at": int(time.time()), "kind": "supplement" if supplemental else "video"}
                if supplemental:
                    # Subtitles are retained, but they are not standalone videos.
                    result["status"] = "supplement"
                else:
                    try:
                        result.update(webshare.verify_stream(source["id"], token))
                        signature = result.get("content_kind", "")
                        if signature.startswith("archive_"):
                            result["status"] = "unavailable"
                            result["reason"] = signature
                        else:
                            result["status"] = "accessible"
                    except webshare.WebshareError as exc:
                        result["status"] = "unavailable"
                        result["reason"] = exc.reason or "stream_access_failed"
                results.append(result)
        finally:
            progress_dialog.close()
        summary = {"accessible": sum(item["status"] == "accessible" for item in results),
                   "unavailable": sum(item["status"] == "unavailable" for item in results),
                   "supplement": sum(item["kind"] == "supplement" for item in results)}
        output = {"checked_at": int(time.time()), "cancelled": cancelled, "sources": len(sources),
                  "checked": len(results), "summary": summary, "results": results}
        try:
            catalog_path = os.path.join(xbmcvfs.translatePath(addon.getAddonInfo("path")), "seznam zdroju.json")
            catalog.record_verification(catalog_path, results)
        except (OSError, ValueError):
            # The separate profile report still contains all finished checks.
            pass
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        if not os.path.isdir(profile):
            os.makedirs(profile)
        with open(os.path.join(profile, "overeni_zdroju.json"), "w", encoding="utf-8") as stream:
            json.dump(output, stream, ensure_ascii=False, indent=2)
        addon.setSetting("status", text(30028).format(ok=summary["accessible"], failed=summary["unavailable"]))
        xbmcgui.Dialog().ok(title, text(30027).format(ok=summary["accessible"], failed=summary["unavailable"]) + "\n" + text(30029))
        end()
        return
    playback_actions = ("play", "choose_play", "resume_play")
    if action == "movies" or action in playback_actions:
        try:
            if action == "movies" and params.get("mode") == "custom_list":
                list_id = params.get("list_id", "")
                scope, lists = server_api.custom_lists(addon)
                custom_list = next((row for row in lists if row["id"] == list_id), None)
                if custom_list is None:
                    error(30072)
                    end(False)
                    return
                entries = server_api.catalog(addon, scope=scope)
            else:
                entries = movies()
        except server_api.ServerError as exc:
            server_error(exc)
            if action in playback_actions:
                playback_failed()
            else:
                end(False)
            return
        except (OSError, ValueError):
            error(30014)
            if action in playback_actions:
                playback_failed()
            else:
                end(False)
            return
        if action == "movies":
            mode = params.get("mode", "alphabet")
            if mode in PLAYBACK_LISTS:
                entries = [movie for movie in entries if (movie.get("playback") or {}).get("status") == mode]
                entries.sort(key=lambda movie: movie["playback"].get("updated_at", 0), reverse=True)
                xbmcplugin.setPluginCategory(handle, text(PLAYBACK_LISTS[mode]))
            elif mode == "custom_list":
                by_key = {movie["key"]: movie for movie in entries}
                entries = [by_key[key] for key in custom_list["movie_keys"] if key in by_key]
                xbmcplugin.setPluginCategory(handle, custom_list["name"])
            elif mode == "genre":
                # Older server catalogs may not contain genres yet. Keep a
                # temporary client fallback until the server metadata sync is
                # enabled; enriched server rows skip this slow path.
                if not any(movie.get("genres") for movie in entries):
                    metadata.enrich(entries, xbmcvfs.translatePath(addon.getAddonInfo("profile")))
                groups = catalog.group_genres(entries)
                group = params.get("group")
                if group not in groups:
                    xbmcplugin.setContent(handle, "files")
                    for name in groups:
                        item = xbmcgui.ListItem(label="{} ({})".format(name, len(groups[name])))
                        item.setArt({"icon": "DefaultFolder.png"})
                        xbmcplugin.addDirectoryItem(handle, url(action="movies", mode="genre", group=name), item, True)
                    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
                    end()
                    return
                entries = groups[group]
                letter = None
            elif mode == "recent_added":
                entries = [movie for movie in entries if int(movie.get("added_at") or 0) > 0]
                entries = sorted(entries, key=lambda movie: (int(movie.get("added_at") or 0), str(movie.get("title") or "").casefold()), reverse=True)[:200]
                groups = None
                letter = None
            elif mode == "latest":
                entries = [movie for movie in entries if len(str(movie.get("premiere_date") or "")) == 10]
                entries = sorted(entries, key=lambda movie: str(movie.get("premiere_date") or ""), reverse=True)[:200]
                groups = None
                letter = None
            elif mode == "year":
                groups = {}
                for movie in entries:
                    try:
                        year = int(movie.get("year") or 0)
                    except (TypeError, ValueError):
                        year = 0
                    if year > 0:
                        groups.setdefault(str(year), []).append(movie)
                group = str(params.get("group") or "")
                if group not in groups:
                    xbmcplugin.setContent(handle, "files")
                    for year in sorted(groups, key=lambda value: int(value), reverse=True):
                        item = xbmcgui.ListItem(label="{} ({})".format(year, len(groups[year])))
                        item.setArt({"icon": "DefaultFolder.png"})
                        xbmcplugin.addDirectoryItem(handle, url(action="movies", mode="year", group=year), item, True)
                    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
                    end()
                    return
                entries = sorted(groups[group], key=lambda movie: (str(movie.get("title") or "").casefold(), int(movie.get("year") or 0)))
                letter = None
            elif mode == "country":
                groups = {}
                for movie in entries:
                    countries = movie.get("countries") or (movie.get("details") or {}).get("countries") or []
                    if isinstance(countries, str):
                        countries = [countries]
                    # TMDB returns countries in primary-production order.
                    # A movie belongs only to its leading country here; it
                    # must not appear in every co-production category.
                    name = str(countries[0] or "").strip() if countries else ""
                    if name:
                        groups.setdefault(name, []).append(movie)
                group = str(params.get("group") or "")
                if group not in groups:
                    xbmcplugin.setContent(handle, "files")
                    for country in sorted(groups, key=lambda value: (-len(groups[value]), value.casefold())):
                        item = xbmcgui.ListItem(label="{} ({})".format(country, len(groups[country])))
                        item.setArt({"icon": "DefaultFolder.png"})
                        xbmcplugin.addDirectoryItem(handle, url(action="movies", mode="country", group=country), item, True)
                    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
                    end()
                    return
                entries = sorted(groups[group], key=lambda movie: (str(movie.get("title") or "").casefold(), int(movie.get("year") or 0)))
                letter = None
            elif mode == "rating":
                groups = {}
                for movie in entries:
                    try:
                        rating = float(movie.get("rating") or 0)
                    except (TypeError, ValueError):
                        rating = 0
                    if rating <= 0:
                        label = "Bez hodnocení"
                    else:
                        percentage = min(100, int(rating * 10))
                        lower = (percentage // 10) * 10
                        if lower >= 100:
                            lower = 90
                        label = "100–90" if lower >= 90 else "{}–{}".format(lower + 9, lower)
                    groups.setdefault(label, []).append(movie)
                group = str(params.get("group") or "")
                rating_order = ["100–90", "89–80", "79–70", "69–60", "59–50", "49–40", "39–30", "29–20", "19–10", "9–0", "Bez hodnocení"]
                if group not in groups:
                    xbmcplugin.setContent(handle, "files")
                    for label in rating_order:
                        if label not in groups:
                            continue
                        item = xbmcgui.ListItem(label="{} ({})".format(label, len(groups[label])))
                        item.setArt({"icon": "DefaultFolder.png"})
                        xbmcplugin.addDirectoryItem(handle, url(action="movies", mode="rating", group=label), item, True)
                    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
                    end()
                    return
                entries = sorted(groups[group], key=lambda movie: (-float(movie.get("rating") or 0), str(movie.get("title") or "").casefold()))
                letter = None
            elif mode == "search":
                query = str(params.get("query") or "").strip()
                entries = catalog.search_movies(entries, query)
                xbmcplugin.setPluginCategory(handle, 'Hledání „{}“'.format(query))
                groups = None
                letter = None
            elif mode == "alphabet":
                groups = catalog.group_movies(entries)
                letter = params.get("letter")
            else:
                groups = None
                letter = None
            if mode == "alphabet" and letter not in groups:
                xbmcplugin.setContent(handle, "files")
                for group in groups:
                    label = text(30031) if group == "other" else group
                    item = xbmcgui.ListItem(label="{} ({})".format(label, len(groups[group])))
                    item.setArt({"icon": "DefaultFolder.png"})
                    xbmcplugin.addDirectoryItem(handle, url(action="movies", letter=group), item, True)
                xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
                end()
                return
            if mode == "alphabet":
                entries = groups[letter]
            xbmcplugin.setContent(handle, "movies")
            try:
                page = max(0, int(params.get("page", "0")))
            except ValueError:
                page = 0
            page = min(page, max(0, (len(entries) - 1) // PAGE_SIZE))
            selected_movies = entries[page * PAGE_SIZE:(page + 1) * PAGE_SIZE]
            progress_dialog = None

            def progress(done, total):
                nonlocal progress_dialog
                if progress_dialog is None:
                    progress_dialog = xbmcgui.DialogProgress()
                    progress_dialog.create(title, text(30018))
                progress_dialog.update(int(100 * done / total), text(30018))
                return not progress_dialog.iscanceled()

            try:
                metadata.enrich(selected_movies, xbmcvfs.translatePath(addon.getAddonInfo("profile")), progress)
            finally:
                if progress_dialog is not None:
                    progress_dialog.close()
            for movie in selected_movies:
                item = movie_item(movie)
                context = [("Nahlásit zdroj ke kontrole", "RunPlugin({})".format(url(action="source_report", movie=movie["key"])))]
                playback = movie.get("playback") or {}
                if playback.get("status") == "watching":
                    # Kodi uses progress counts for folders, even when the video tag has a resume point.
                    item.setProperties({"inprogress": "1", "total": "1", "watched": "0"})
                    context.insert(0, (resume_label(playback), "RunPlugin({})".format(url(action="resume_play", movie=movie["key"]))))
                context.extend(custom_list_context(movie["key"], list_id if mode == "custom_list" else ""))
                if addon.getSetting("server_role").strip().lower() in ("admin", "moderator"):
                    context.append(("Opravit zařazení zdroje", "RunPlugin({})".format(url(action="source_correct", movie=movie["key"]))))
                    context.append(("Nastavit 3D režim zdroje", "RunPlugin({})".format(url(action="source_stereo", movie=movie["key"]))))
                item.addContextMenuItems(context, replaceItems=False)
                xbmcplugin.addDirectoryItem(handle, url(action="movie_menu", movie=movie["key"]), item, True)
            if not entries:
                message_id = 30063 if mode in PLAYBACK_LISTS or mode == "custom_list" else 30058 if mode == "search" else 30015
                xbmcgui.Dialog().notification(title, text(message_id))
            if (page + 1) * PAGE_SIZE < len(entries):
                label = text(30017).format(page=page + 2, total=(len(entries) + PAGE_SIZE - 1) // PAGE_SIZE)
                item = xbmcgui.ListItem(label=label)
                item.setArt({"icon": "DefaultFolder.png"})
                if mode == "genre":
                    next_url = url(action="movies", mode="genre", group=params.get("group", ""), page=page + 1)
                elif mode == "alphabet":
                    next_url = url(action="movies", mode="alphabet", letter=letter, page=page + 1)
                elif mode == "recent_added":
                    next_url = url(action="movies", mode="recent_added", page=page + 1)
                elif mode == "latest":
                    next_url = url(action="movies", mode="latest", page=page + 1)
                elif mode in ("year", "country", "rating"):
                    next_url = url(action="movies", mode=mode, group=params.get("group", ""), page=page + 1)
                elif mode in PLAYBACK_LISTS:
                    next_url = url(action="movies", mode=mode, page=page + 1)
                elif mode == "custom_list":
                    next_url = url(action="movies", mode=mode, list_id=list_id, page=page + 1)
                elif mode == "search":
                    next_url = url(action="movies", mode="search", query=params.get("query", ""), page=page + 1)
                else:
                    next_url = url(action="movies", mode="all", page=page + 1)
                xbmcplugin.addDirectoryItem(handle, next_url, item, True)
            # Preserve global alphabetic ordering and keep navigation last.
            xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_UNSORTED)
            end()
            return
        movie = next((entry for entry in entries if entry["key"] == params.get("movie")), None)
        if movie is None:
            error(30013)
            playback_failed()
            return
        playback = movie.get("playback") or {}
        resume = action == "resume_play"
        if resume and playback.get("status") != "watching":
            playback_failed()
            return
        try:
            sources = server_api.movie_sources(addon, movie["key"])
        except server_api.ServerError as exc:
            if resume and exc.reason == "movie_not_found":
                error(30062)
            else:
                server_error(exc)
            playback_failed()
            return
        if not sources:
            error(30062 if resume else 30013)
            playback_failed()
            return
        # Sources stored before dimensions were persisted are refreshed once
        # here as well, so labels can show their real resolution.
        if not resume and any(int((source.get("technical") or {}).get("metadata_version") or 0) < 4 for source in sources):
            try:
                token = webshare.get_token(addon)
                for source in sources:
                    if int((source.get("technical") or {}).get("metadata_version") or 0) < 4:
                        source["technical"] = webshare.file_info(source["id"], token)
            except webshare.WebshareError:
                pass
        if resume:
            source = next((row for row in sources if row["id"] == playback["source_id"]), None)
            if not source:
                error(30062)
                playback_failed()
                return
        else:
            sources.sort(key=source_size, reverse=True)
            selected = xbmcgui.Dialog().select(text(30016), [source_label(source) for source in sources])
            if selected < 0:
                playback_failed()
                return
            source = sources[selected]
        try:
            token = webshare.get_token(addon)
            addon.setSetting("status", text(30008))
            link = webshare.resolve(source["id"], token)
        except webshare.WebshareError as exc:
            error(30062 if resume and exc.message_id == 30013 else exc.message_id)
            playback_failed()
            return
        cache = metadata.Cache(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
        try:
            movie["details"] = cache.get(movie["tmdb_id"])[0]
        finally:
            cache.close()
        item = movie_item(movie, show_status=False)
        item.setProperty("IsPlayable", "true")
        stereo_mode = source_stereo(source).get("kodi_mode", "")
        item.setPath(stereo.playback_url(webshare.kodi_playback_url(link), stereo_mode))
        if stereo_mode:
            set_stereo_mode(item, stereo_mode)
        if action != "play":
            # The decoder examines GetPath(), not GetDynPath(). Resolving a
            # plugin URL keeps GetPath() as plugin://, hiding the layout hint.
            end()
        outbox = movie.get("_playback_outbox")
        if outbox:
            import movie_history

            metadata_observed = False

            def start(player):
                if action == "play":
                    xbmcplugin.setResolvedUrl(handle, True, item)
                else:
                    player.play(item.getPath(), item)

            def on_started(player):
                nonlocal metadata_observed
                metadata_observed = observe_playback(
                    source, player, collect_metadata=not bool(source_stereo(source))
                )

            changed = movie_history.observe(
                xbmc, start, item.getPath(), playback["position"] if resume else 0,
                on_started, movie_history.playback_update(movie, source),
                resolved_path=base + argv[2] if action == "play" else "",
            )
            if changed:
                server_api.sync_playback(addon, outbox)
                if xbmc.getInfoLabel("Container.FolderPath").startswith(base):
                    xbmc.executebuiltin("Container.Refresh")
            if metadata_observed:
                try:
                    server_api.update_source_technical(addon, source)
                except server_api.ServerError:
                    pass
        elif action != "play":
            player = xbmc.Player()
            player.play(item.getPath(), item)
            observe_playback(source, player, True, collect_metadata=not bool(source_stereo(source)))
        else:
            xbmcplugin.setResolvedUrl(handle, True, item)
        return
    xbmcplugin.setContent(handle, "files")
    if server_connected():
        try:
            menu_data = server_api.menu(addon)
            movie_count = len(movies())
            add_menu_items(menu_data.get("items", []), movie_count)
            unassigned_count = len(server_api.unassigned_sources(addon))
            xbmcplugin.addDirectoryItem(handle, url(action="unassigned_sources"), xbmcgui.ListItem(label="Zatím nezařazené ({})".format(unassigned_count)), True)
            xbmcplugin.addDirectoryItem(handle, url(action="source_search"), xbmcgui.ListItem(label="Hledat nové zdroje pro filmy"), True)
            if addon.getSetting("server_role").strip().lower() in ("admin", "moderator"):
                pending_count = len(server_api.pending_sources(addon))
                label = "Ověřit zdroje ke schválení ({})".format(pending_count)
                xbmcplugin.addDirectoryItem(handle, url(action="source_verify"), xbmcgui.ListItem(label=label), True)
        except server_api.ServerError as exc:
            server_error(exc)
            xbmcplugin.addDirectoryItem(handle, url(action="settings"), xbmcgui.ListItem(label=text(30001)), False)
    else:
        xbmcplugin.addDirectoryItem(handle, url(action="settings"), xbmcgui.ListItem(label=text(30001)), False)
    end()


if __name__ == "__main__":
    run(sys.argv)












"""Client for the Ikarus server JSON API."""
import json
import os
import sqlite3

import requests
import xbmcvfs

from movie_history import Outbox


class ServerError(Exception):
    def __init__(self, reason="server_error"):
        self.reason = reason
        super().__init__(reason)


def _base_url(addon):
    value = addon.getSetting("server_url").strip()
    if not value:
        raise ServerError("server_url_missing")
    if not value.startswith(("http://", "https://")):
        value = "https://" + value
    return value.rstrip("/")


def _request(addon, action, method="GET", payload=None, token="", *, base_url=None, timeout=20):
    url = (base_url or _base_url(addon)) + "/api.php?action=" + action
    headers = {"User-Agent": "Ikarus DB/0.1.0"}
    if token:
        headers["Authorization"] = "Bearer " + token
    try:
        request_data = {"params": payload} if method == "GET" else {"json": payload}
        response = requests.request(method, url, headers=headers, timeout=timeout, **request_data)
        data = response.json()
    except (requests.RequestException, ValueError):
        raise ServerError("server_unavailable") from None
    if not isinstance(data, dict):
        raise ServerError("server_unavailable")
    if response.status_code >= 400 or not data.get("ok"):
        reason = str(data.get("error") or "server_error")
        if reason == "unknown_action" and action in ("custom_lists", "update_custom_list"):
            reason = "custom_lists_unavailable"
        raise ServerError(reason)
    return data


def login(addon):
    username = addon.getSetting("server_username").strip()
    password = addon.getSetting("server_password")
    if not username or not password:
        raise ServerError("credentials_missing")
    data = _request(addon, "login", "POST", {
        "username": username,
        "password": password,
        "device_name": "Kodi Ikarus DB",
    })
    addon.setSetting("server_access_token", data.get("access_token", ""))
    addon.setSetting("server_refresh_token", data.get("refresh_token", ""))
    profile = get_profile(addon, data.get("access_token", ""))
    save_profile(addon, profile)
    return profile


def get_profile(addon, token=""):
    access = token or addon.getSetting("server_access_token")
    if not access:
        raise ServerError("not_connected")
    return _request(addon, "profile", "GET", token=access).get("user", {})


def refresh(addon):
    refresh_token = addon.getSetting("server_refresh_token")
    if not refresh_token:
        raise ServerError("not_connected")
    data = _request(addon, "refresh", "POST", {"refresh_token": refresh_token})
    addon.setSetting("server_access_token", data.get("access_token", ""))
    addon.setSetting("server_refresh_token", data.get("refresh_token", ""))
    profile = get_profile(addon, data.get("access_token", ""))
    save_profile(addon, profile)
    return profile


def _connection(addon):
    access = addon.getSetting("server_access_token")
    if not access:
        raise ServerError("not_connected")
    try:
        profile = get_profile(addon, access)
        save_profile(addon, profile)
        return access, profile
    except ServerError as exc:
        if exc.reason != "access_token_expired":
            raise
        profile = refresh(addon)
        return addon.getSetting("server_access_token"), profile


def ensure_connection(addon):
    return _connection(addon)[0]


def sync_playback(addon, outbox, access=""):
    try:
        pending = outbox.pending()
        if not pending or _base_url(addon) != outbox.server:
            return
        if not access:
            access, profile = _connection(addon)
            if profile.get("playback_account") != outbox.account or _base_url(addon) != outbox.server:
                return
        for row in pending:
            try:
                _request(addon, "update_playback", "POST", dict(row, account=outbox.account),
                         access, base_url=outbox.server, timeout=4)
            except ServerError as exc:
                if exc.reason not in ("playback_source_missing", "invalid_playback"):
                    return
            outbox.acknowledge(row)
    except (ServerError, OSError, sqlite3.Error):
        pass


def catalog(addon, *, scope=None):
    base_url = _base_url(addon)
    access, profile = _connection(addon)
    if _base_url(addon) != base_url:
        raise ServerError("not_connected")
    account = profile.get("playback_account")
    if scope is not None and (base_url, account) != scope:
        raise ServerError("account_mismatch")
    outbox = None
    if isinstance(account, str) and account:
        path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        outbox = Outbox(path, base_url, account)
        sync_playback(addon, outbox, access)
    data = _request(addon, "movies", "GET", token=access, base_url=base_url)
    if "playback_account" in data and data["playback_account"] != account:
        raise ServerError("not_connected")
    movies = data.get("movies", [])
    if outbox and data.get("playback_account") == account:
        for movie in movies:
            movie["_playback_outbox"] = outbox
    return movies


def _custom_lists_connection(addon):
    base_url = _base_url(addon)
    access, profile = _connection(addon)
    if _base_url(addon) != base_url:
        raise ServerError("account_mismatch")
    account = profile.get("playback_account")
    if not account:
        raise ServerError("custom_lists_unavailable")
    return (base_url, account), access


def custom_lists(addon):
    scope, access = _custom_lists_connection(addon)
    base_url, account = scope
    data = _request(addon, "custom_lists", token=access, base_url=base_url)
    if data.get("account") != account:
        raise ServerError("account_mismatch")
    return scope, data["lists"]


def update_custom_list(addon, operation, movie_key, *, scope=None, list_id="", name=""):
    current_scope, access = _custom_lists_connection(addon)
    if scope is not None and current_scope != scope:
        raise ServerError("account_mismatch")
    base_url, account = current_scope
    data = _request(addon, "update_custom_list", "POST", {
        "account": account, "operation": operation, "movie_key": movie_key,
        "list_id": list_id, "name": name,
    }, token=access, base_url=base_url)
    return data.get("changed", False)


def movie_sources(addon, movie_id):
    access = ensure_connection(addon)
    return _request(addon, "movie_sources", "GET", token=access, payload={"id": movie_id}).get("sources", [])


def report_source(addon, movie, source):
    access = ensure_connection(addon)
    return _request(addon, "report_source", "POST", {
        "webshare_id": source.get("id", ""),
        "source_name": source.get("name", ""),
        "movie_key": movie.get("key", ""),
        "title": movie.get("title", ""),
        "year": movie.get("year", 0),
        "tmdb_id": movie.get("tmdb_id", ""),
        "tmdb_type": movie.get("tmdb_type", "movie"),
        "technical": source.get("technical", {}),
    }, token=access)


def correct_source(addon, source, movie):
    access = ensure_connection(addon)
    return _request(addon, "correct_source", "POST", {
        "webshare_id": source.get("id", ""),
        "source_name": source.get("name", ""),
        "title": movie.get("title", ""),
        "year": movie.get("year", 0),
        "tmdb_id": movie.get("tmdb_id", ""),
        "tmdb_type": movie.get("tmdb_type", "movie"),
    }, token=access)


def set_source_stereo(addon, source, mode):
    access = ensure_connection(addon)
    return _request(addon, "set_source_stereo", "POST", {
        "webshare_id": source.get("id", ""),
        "mode": mode,
    }, token=access)


def update_source_technical(addon, source):
    access = ensure_connection(addon)
    return _request(addon, "update_source_technical", "POST", {
        "webshare_id": source.get("id", ""),
        "technical": source.get("technical", {}),
    }, token=access)


def source_ids(addon):
    """Return WebShare IDs already present in the server catalog."""
    access = ensure_connection(addon)
    values = _request(addon, "source_ids", "GET", token=access).get("source_ids", [])
    return {str(value).strip() for value in values if str(value).strip()}


def source_title_hints(addon, sources):
    """Return server-confirmed movie titles for a small page of WebShare sources."""
    payload = []
    for source in list(sources or [])[:50]:
        if not isinstance(source, dict):
            continue
        ident = str(source.get("id") or "").strip()
        name = str(source.get("name") or "").strip()
        if not ident or not name:
            continue
        technical = source.get("technical") if isinstance(source.get("technical"), dict) else {}
        try:
            size = max(0, int(technical.get("size") or source.get("size") or 0))
        except (TypeError, ValueError):
            size = 0
        payload.append({"id": ident, "name": name[:160], "size": size})
    if not payload:
        return {}
    access = ensure_connection(addon)
    hints = _request(addon, "source_title_hints", "POST", {"sources": payload}, token=access).get("hints", {})
    return hints if isinstance(hints, dict) else {}


def submit_source(addon, source, movie):
    access = ensure_connection(addon)
    return _request(addon, "submit_source", "POST", {
        "webshare_id": source.get("id", ""),
        "source_name": source.get("name", ""),
        "title": movie.get("title", ""),
        "year": movie.get("year", 0),
        "csfd_id": movie.get("csfd_id", ""),
        "tmdb_id": movie.get("tmdb_id", ""),
        "tmdb_type": movie.get("tmdb_type", "movie"),
        "technical": source.get("technical", {}),
    }, token=access)


def save_unassigned_source(addon, source, movie):
    access = ensure_connection(addon)
    return _request(addon, "save_unassigned_source", "POST", {
        "webshare_id": source.get("id", ""),
        "source_name": source.get("name", ""),
        "title": movie.get("title", ""),
        "year": movie.get("year", 0),
        "tmdb_id": movie.get("tmdb_id", ""),
        "tmdb_type": movie.get("tmdb_type", "movie"),
        "technical": source.get("technical", {}),
    }, token=access)


def unassigned_sources(addon):
    access = ensure_connection(addon)
    return _request(addon, "unassigned_sources", "GET", token=access).get("sources", [])


def assign_unassigned_tmdb(addon, item_id, movie):
    access = ensure_connection(addon)
    return _request(addon, "assign_unassigned_tmdb", "POST", {
        "id": item_id,
        "title": movie.get("title", ""),
        "year": movie.get("year", 0),
        "tmdb_id": movie.get("tmdb_id", ""),
        "tmdb_type": movie.get("tmdb_type", "movie"),
    }, token=access)


def pending_sources(addon):
    access = ensure_connection(addon)
    return _request(addon, "pending_sources", "GET", token=access).get("sources", [])


def approve_source(addon, suggestion_id):
    access = ensure_connection(addon)
    return _request(addon, "approve_source", "POST", {
        "id": suggestion_id,
    }, token=access)


def reject_source(addon, suggestion_id):
    access = ensure_connection(addon)
    return _request(addon, "reject_source", "POST", {
        "id": suggestion_id,
    }, token=access)


def menu(addon):
    access = ensure_connection(addon)
    data = _request(addon, "menu", "GET", token=access)
    menu = data.get("menu", {})
    version = str(data.get("menu_version") or "")
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    if not os.path.isdir(profile):
        os.makedirs(profile)
    cache_path = os.path.join(profile, "menu_cache.json")
    if version and os.path.isfile(cache_path):
        try:
            with open(cache_path, "r", encoding="utf-8") as stream:
                cached = json.load(stream)
            if cached.get("version") == version and isinstance(cached.get("menu"), dict):
                return cached["menu"]
        except (OSError, ValueError):
            pass
    temporary = cache_path + ".tmp"
    try:
        with open(temporary, "w", encoding="utf-8") as stream:
            json.dump({"version": version, "menu": menu}, stream, ensure_ascii=False)
        os.replace(temporary, cache_path)
    except OSError:
        try:
            os.unlink(temporary)
        except OSError:
            pass
    return menu


def save_profile(addon, profile):
    addon.setSetting("server_status", "Připojeno")
    addon.setSetting("server_full_name", str(profile.get("full_name") or ""))
    addon.setSetting("server_role", str(profile.get("role") or ""))
    addon.setSetting("server_expires_at", str(profile.get("expires_at") or "Bez omezení"))


def logout(addon):
    access = addon.getSetting("server_access_token")
    if access:
        try:
            _request(addon, "logout", "POST", token=access)
        except ServerError:
            pass
    for setting in ("server_access_token", "server_refresh_token", "server_full_name", "server_role", "server_expires_at"):
        addon.setSetting(setting, "")
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    try:
        os.unlink(os.path.join(profile, "menu_cache.json"))
    except OSError:
        pass
    addon.setSetting("server_status", "Odhlášeno")

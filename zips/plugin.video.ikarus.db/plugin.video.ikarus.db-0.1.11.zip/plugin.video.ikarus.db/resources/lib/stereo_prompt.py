"""Open Kodi's native stereoscopic playback dialog for a newly started video."""
import xbmc


monitor = xbmc.Monitor()
player = xbmc.Player()

# setResolvedUrl() starts playback asynchronously.  Wait briefly for the player
# so the built-in opens its native "Vyberte rezim prehravani" dialog instead of
# doing nothing while Kodi is still resolving the stream.
for _ in range(80):
    if monitor.abortRequested():
        break
    if player.isPlayingVideo():
        xbmc.sleep(250)
        xbmc.executebuiltin("StereoMode")
        break
    xbmc.sleep(100)

"""Pass known source layouts to Kodi 21's decoder without filename guessing."""


def playback_url(link, mode):
    # Kodi VideoPlayer detects SBS/TAB from the full playback path when the
    # container has no stereo flag. HTTP fragments are not sent to WebShare;
    # keep the signed path/query and Kodi protocol options unchanged.
    marker = {"left_right": "sbs", "top_bottom": "tab"}.get(mode)
    if not marker:
        return link
    address, separator, options = link.partition("|")
    address += ("." if "#" in address else "#") + "ikarus.3d." + marker + "."
    return address + (separator + options if separator else "")

"""TMDB metadata adapted from Ikarus TMDB_knihovna.py, cached per movie."""
from concurrent.futures import ThreadPoolExecutor
from functools import partial
import json
import os
import sqlite3
import time

import requests

try:
    from tmdb_config import TMDB_API_KEY
except ImportError:
    TMDB_API_KEY = ""

API = "https://api.themoviedb.org/3/"
IMAGE = "https://image.tmdb.org/t/p/"


def _api_key():
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting("tmdb_api_key").strip() or TMDB_API_KEY
    except (ImportError, RuntimeError):
        return TMDB_API_KEY


def _reader(server_reader):
    api_key = _api_key()
    if not api_key:
        return server_reader

    def read(resource, params):
        response = requests.get(API + resource, params=dict(params, api_key=api_key), timeout=(3, 8))
        if response.status_code == 404:
            return {}
        response.raise_for_status()
        data = response.json()
        return data if isinstance(data, dict) else None

    return read


def image_url(path, size="w500"):
    """Build a TMDB image URL only for a valid TMDB image path."""
    return IMAGE + size + path if isinstance(path, str) and path.startswith("/") else ""


def search_movies(query, limit=20, *, server_reader=None):
    """Return small, user-selected TMDB search results for a new source."""
    query = " ".join(str(query or "").split()).strip()
    read = _reader(server_reader)
    if not query or read is None:
        return []
    try:
        rows = (read("search/movie", {"language": "cs-CZ", "query": query}) or {}).get("results", [])
    except (requests.RequestException, ValueError, TypeError, KeyError):
        return []
    found = []
    for row in rows[:max(1, int(limit))]:
        if not isinstance(row, dict) or not str(row.get("id") or "").isdigit():
            continue
        date = str(row.get("release_date") or "")
        found.append({
            "tmdb_id": str(row["id"]),
            "tmdb_type": "movie",
            "title": str(row.get("title") or row.get("original_title") or "").strip(),
            "original_title": str(row.get("original_title") or "").strip(),
            "year": int(date[:4]) if date[:4].isdigit() else 0,
        })
    return found


def fetch_movie(item, *, read=None, full=True):
    """None means temporary failure; an empty dict means a missing movie."""
    read = read or _reader(None)
    if read is None:
        return None
    if isinstance(item, (tuple, list)):
        ident, media_type = item
    else:
        ident, media_type = item, "movie"
    media_type = "tv" if str(media_type).lower() == "tv" else "movie"
    resource = media_type + "/" + ident
    params = {"language": "cs-CZ"}
    if full:
        params["append_to_response"] = "credits"
    try:
        data = read(resource, params)
        if data == {}:
            return {}
        if not isinstance(data, dict) or str(data.get("id")) != ident:
            return None
        date = str(data.get("first_air_date") if media_type == "tv" else data.get("release_date") or "")
        display_title = str((data.get("name") if media_type == "tv" else data.get("title")) or "").strip()
        if display_title and not any("A" <= character <= "Z" or "a" <= character <= "z" for character in display_title):
            try:
                english_data = read(resource, {"language": "en-US"}) or {}
                english_title = str((english_data.get("name") if media_type == "tv" else english_data.get("title")) or "").strip()
                if english_title:
                    display_title = english_title
            except (requests.RequestException, ValueError, TypeError, KeyError):
                pass
        original_title = str((data.get("original_name") if media_type == "tv" else data.get("original_title")) or "")
        if original_title and not any("A" <= character <= "Z" or "a" <= character <= "z" for character in original_title):
            original_title = display_title
        credits = data.get("credits") if isinstance(data.get("credits"), dict) else {}
        cast = []
        cast_people = []
        for person in credits.get("cast", [])[:50]:
            if not isinstance(person, dict) or not person.get("name"):
                continue
            cast.append("{}{}".format(person["name"], " — " + str(person.get("character")) if person.get("character") else ""))
            if person.get("id"):
                cast_people.append({
                    "id": str(person["id"]), "name": str(person["name"]),
                    "role": str(person.get("character") or ""),
                    "profile": image_url(person.get("profile_path")),
                })
        crew = credits.get("crew") if isinstance(credits.get("crew"), list) else []
        def crew_for(*jobs):
            return [str(person.get("name")) for person in crew if isinstance(person, dict) and person.get("name") and str(person.get("job") or "") in jobs]
        def crew_people(*jobs):
            people = []
            seen = set()
            for person in crew:
                if not isinstance(person, dict) or not person.get("name") or str(person.get("job") or "") not in jobs or not person.get("id"):
                    continue
                person_id = str(person["id"])
                if person_id in seen:
                    continue
                seen.add(person_id)
                people.append({
                    "id": person_id, "name": str(person["name"]),
                    "role": str(person.get("job") or ""),
                    "profile": image_url(person.get("profile_path")),
                })
            return people
        # TMDB filters appended media by the detail language.  Load these endpoints
        # without a language parameter so every available image and video is kept.
        videos, images = None, None
        if full:
            try:
                videos = read(resource + "/videos", {})
                images = read(resource + "/images", {})
            except (requests.RequestException, ValueError, TypeError, KeyError):
                pass
        media_complete = isinstance(videos, dict) and isinstance(images, dict)
        videos = videos if isinstance(videos, dict) else {}
        media_videos = []
        for video in videos.get("results", []):
            if not isinstance(video, dict) or not video.get("key"):
                continue
            site = str(video.get("site") or "").strip()
            key = str(video.get("key") or "").strip()
            media_videos.append({
                "name": str(video.get("name") or "Video"), "type": str(video.get("type") or ""),
                "site": site, "key": key,
                "thumb": "https://i.ytimg.com/vi/{}/hqdefault.jpg".format(key) if site.lower() == "youtube" else "",
            })
        def media_images(kind):
            result = []
            for row in (images.get(kind, []) if isinstance(images, dict) else []):
                if not isinstance(row, dict):
                    continue
                path = row.get("file_path")
                full = image_url(path, "original")
                if full:
                    result.append({"thumb": image_url(path, "w500"), "url": full, "language": str(row.get("iso_639_1") or ""), "votes": int(row.get("vote_count") or 0)})
            return result
        backdrops = media_images("backdrops")
        posters = media_images("posters")
        media = {"videos": media_videos, "backdrops": backdrops, "posters": posters,
                 "popular": sorted(backdrops + posters, key=lambda row: row.get("votes") or 0, reverse=True),
                 "all_languages": media_complete}
        return {
            "title": display_title,
            "originaltitle": original_title,
            "plot": str(data.get("overview") or ""),
            "genre": [str(g["name"]) for g in data.get("genres", []) if isinstance(g, dict) and g.get("name")],
            "year": int(date[:4]) if date[:4].isdigit() else 0,
            "rating": float(data.get("vote_average") or 0),
            "votes": int(data.get("vote_count") or 0),
            "poster": image_url(data.get("poster_path"), "w500"),
            "fanart": image_url(data.get("backdrop_path"), "w1280"),
            "people": {
                "Herci": cast_people,
                "Režie": crew_people("Director"),
                "Scénář": crew_people("Writer", "Screenplay", "Story"),
                "Produkce": crew_people("Producer", "Executive Producer"),
                "Kamera": crew_people("Director of Photography", "Cinematography"),
                "Hudba / zvuk": crew_people("Original Music Composer", "Music", "Sound"),
            },
            "sections": {
                "Herci": cast,
                "Režie": crew_for("Director"),
                "Scénář": crew_for("Writer", "Screenplay", "Story"),
                "Produkce": crew_for("Producer", "Executive Producer"),
                "Kamera": crew_for("Director of Photography", "Cinematography"),
                "Hudba / zvuk": crew_for("Original Music Composer", "Music", "Sound"),
            },
            "media": media,
        }
    except (requests.RequestException, ValueError, TypeError, KeyError):
        # Never log API keys, request URLs or untrusted server responses.
        return None


def fetch_person(person_id, *, server_reader=None):
    """Load a person's Czech TMDB profile when the user explicitly opens it."""
    person_id = str(person_id or "").strip()
    read = _reader(server_reader)
    if not person_id.isdigit() or read is None:
        return {}
    resource = "person/" + person_id
    try:
        data = read(resource, {"language": "cs-CZ", "append_to_response": "combined_credits"})
        if not data:
            return {}
        biography = str(data.get("biography") or "").strip()
        if not biography:
            try:
                english = read(resource, {"language": "en-US"}) or {}
                biography = str(english.get("biography") or "").strip()
            except (requests.RequestException, ValueError, TypeError, KeyError):
                pass
        credits = data.get("combined_credits") if isinstance(data.get("combined_credits"), dict) else {}
        credit_count = len(credits.get("cast") or []) + len(credits.get("crew") or [])
        return {
            "name": str(data.get("name") or "").strip(),
            "department": str(data.get("known_for_department") or "").strip(),
            "birthday": str(data.get("birthday") or "").strip(),
            "deathday": str(data.get("deathday") or "").strip(),
            "place": str(data.get("place_of_birth") or "").strip(),
            "biography": biography,
            "profile": image_url(data.get("profile_path")),
            "credit_count": credit_count,
        }
    except (requests.RequestException, ValueError, TypeError, KeyError):
        return {}


class Cache:
    """SQLite transactions and file locks keep concurrent page loads safe."""
    def __init__(self, profile):
        self.connection = None
        try:
            os.makedirs(profile, exist_ok=True)
            self.connection = sqlite3.connect(os.path.join(profile, "movie_metadata.db"), timeout=2)
            self.connection.execute("CREATE TABLE IF NOT EXISTS movies (id TEXT PRIMARY KEY, checked REAL, data TEXT)")
            self.connection.commit()
        except (OSError, sqlite3.Error):
            self.close()

    def close(self):
        if self.connection is not None:
            self.connection.close()
            self.connection = None

    def get(self, ident):
        try:
            row = self.connection.execute("SELECT checked, data FROM movies WHERE id=?", (ident,)).fetchone() if self.connection else None
            if row:
                data = json.loads(row[1])
                if isinstance(data, dict):
                    return data, row[0] + (30 * 86400 if data else 86400) > time.time()
        except (sqlite3.Error, ValueError, TypeError):
            pass
        return {}, False

    def put(self, ident, data):
        if self.connection is not None:
            try:
                with self.connection:
                    self.connection.execute("INSERT OR REPLACE INTO movies VALUES (?, ?, ?)",
                                            (ident, time.time(), json.dumps(data)))
            except sqlite3.Error:
                pass


def enrich(movies, profile, progress=None, *, server_reader=None, full=True):
    cache = Cache(profile)
    pending = []
    try:
        for movie in movies:
            ident = movie.get("tmdb_id", "")
            if not ident or not ident.isascii() or not ident.isdigit():
                continue
            media_type = "tv" if str(movie.get("tmdb_type", "movie")).lower() == "tv" else "movie"
            cache_key = media_type + ":" + ident
            data, fresh = cache.get(cache_key)
            movie["details"] = data
            if data.get("title"):
                movie["title"] = data["title"]
            needs_readable_title = bool(movie.get("title")) and not any("A" <= character <= "Z" or "a" <= character <= "z" for character in str(movie["title"]))
            media = data.get("media")
            incomplete = full and (not isinstance(media, dict) or not media.get("all_languages")
                                   or not isinstance(data.get("sections"), dict) or not isinstance(data.get("people"), dict))
            if not fresh or (data and (incomplete or (needs_readable_title and not data.get("title")))):
                pending.append((movie, media_type, cache_key))
        read = _reader(server_reader)
        if not pending or read is None:
            return movies
        fetch = partial(fetch_movie, read=read, full=full)
        # Bounded batches allow cancellation and stop promptly during outages.
        with ThreadPoolExecutor(max_workers=4) as pool:
            for start in range(0, len(pending), 4):
                if progress and not progress(start, len(pending)):
                    break
                batch = pending[start:start + 4]
                results = list(pool.map(fetch, [(movie["tmdb_id"], kind) for movie, kind, _ in batch]))
                for (movie, _, cache_key), data in zip(batch, results):
                    if data is not None:
                        movie["details"] = data
                        if data.get("title"):
                            movie["title"] = data["title"]
                        cache.put(cache_key, data)
                if any(data is None for data in results):
                    break
    finally:
        cache.close()
    return movies


def video_info(movie, text):
    details = movie.get("details") or {}
    info = {"title": movie["title"], "mediatype": "movie",
            "year": details.get("year") or movie.get("year") or 0,
            "originaltitle": details.get("originaltitle") or movie.get("original_title") or "",
            "genre": details.get("genre") or movie.get("genres") or []}
    lines = []
    for key, label in (("originaltitle", 30019), ("genre", 30020), ("year", 30021)):
        value = info[key]
        if value:
            if key == "genre":
                value = " / ".join(value)
            lines.append(text(label) + ": " + str(value))
    if details.get("votes"):
        lines.append(text(30022) + ": {:.1f}/10 ({} {})".format(details["rating"], details["votes"], text(30023)))
        info.update(rating=details["rating"], votes=str(details["votes"]))
    elif movie.get("rating"):
        info["rating"] = float(movie["rating"])
        lines.append(text(30022) + ": {:.1f}/10".format(info["rating"]))
    if details.get("plot"):
        lines.extend(["", details["plot"]])
    info["plot"] = "\n".join(lines)
    art = {key: details[key] for key in ("poster", "fanart") if details.get(key)}
    if art.get("poster"):
        art["thumb"] = art["poster"]
        art["icon"] = art["poster"]
    return info, art

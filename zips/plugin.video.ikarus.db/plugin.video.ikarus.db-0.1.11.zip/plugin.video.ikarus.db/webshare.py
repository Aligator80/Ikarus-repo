"""WebShare login, stream resolution, and lightweight stream checks."""
import hashlib
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlencode, urlsplit

import requests
from md5crypto_python3 import md5crypt

API = "https://webshare.cz/api/"
HEADERS = {"User-Agent": "Ikarus DB/0.1.0", "Referer": "https://webshare.cz"}


class WebshareError(Exception):
    def __init__(self, message_id, reason=""):
        self.message_id = message_id
        self.reason = reason
        super().__init__("Webshare request failed")


def api(method, data):
    try:
        response = requests.post(API + method + "/", data=data, headers=HEADERS, timeout=20)
        response.raise_for_status()
        root = ET.fromstring(response.content)
    except (requests.RequestException, ET.ParseError, ValueError):
        raise WebshareError(30012, "api_request_error") from None
    if root.tag != "response" or root.findtext("status") not in ("OK", "FATAL"):
        raise WebshareError(30012, "api_invalid_response")
    return root


def login(username, password):
    root = api("salt", {"username_or_email": username})
    salt = root.findtext("salt") or ""
    if root.findtext("status") != "OK" or not salt:
        raise WebshareError(30011, "login_salt_failed")
    encrypted = hashlib.sha1(md5crypt(password, salt).encode("utf-8")).hexdigest()
    digest = hashlib.md5((username + ":Webshare:" + encrypted).encode("utf-8")).hexdigest()
    root = api("login", {"username_or_email": username, "password": encrypted,
                         "digest": digest, "keep_logged_in": 1})
    token = (root.findtext("token") or "").strip()
    if root.findtext("status") != "OK" or not token:
        raise WebshareError(30011, "login_failed")
    if api("user_data", {"wst": token}).findtext("status") != "OK":
        raise WebshareError(30011, "token_validation_failed")
    return token


def get_token(addon, force=False):
    username = addon.getSetting("username").strip()
    password = addon.getSetting("password")
    if not username or not password:
        addon.setSetting("token", "")
        addon.setSetting("token_owner", "")
        raise WebshareError(30010, "credentials_missing")
    owner = addon.getSetting("token_owner")
    token = addon.getSetting("token")
    if owner != username or force:
        addon.setSetting("token", "")
        addon.setSetting("token_owner", "")
        token = ""
    if token and api("user_data", {"wst": token}).findtext("status") == "OK":
        return token
    addon.setSetting("token", "")
    addon.setSetting("token_owner", "")
    token = login(username, password)
    addon.setSetting("token", token)
    addon.setSetting("token_owner", username)
    return token


def _content_kind(data):
    """Classify a stream prefix without trusting its filename extension."""
    if data.startswith(b"Rar!\x1a\x07"):
        return "archive_rar"
    if data.startswith(b"PK\x03\x04") or data.startswith(b"PK\x05\x06"):
        return "archive_zip"
    if data.startswith(b"7z\xbc\xaf\x27\x1c"):
        return "archive_7z"
    if data.startswith(b"\x1f\x8b"):
        return "archive_gzip"
    if len(data) >= 262 and data[257:262] == b"ustar":
        return "archive_tar"
    if len(data) >= 32774 and data[32769:32774] == b"CD001":
        return "archive_iso"
    if len(data) >= 12 and data[4:8] == b"ftyp":
        return "video_mp4"
    if data.startswith(b"\x1a\x45\xdf\xa3"):
        return "video_matroska"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"AVI ":
        return "video_avi"
    if data.startswith(b"FLV"):
        return "video_flv"
    if data.startswith(b"OggS"):
        return "video_ogg"
    if len(data) >= 189 and data[0] == 0x47 and data[188] == 0x47:
        return "video_mpeg_ts"
    return "unknown"


def resolve(ident, token):
    root = api("file_link", {"ident": ident, "wst": token, "download_type": "video_stream"})
    if root.findtext("status") != "OK":
        raise WebshareError(30013, "file_link_fatal")
    link = (root.findtext("link") or "").strip()
    parsed = urlsplit(link)
    if parsed.scheme not in ("https", "http") or not parsed.netloc:
        raise WebshareError(30013, "invalid_stream_url")
    return link


def kodi_playback_url(link):
    """Attach the WebShare request headers Kodi needs for direct playback.

    The public filename can have an arbitrary suffix (for example ``.raa``),
    therefore Kodi must receive the signed HTTP link as a video stream rather
    than try to identify it from the filename.  Keeping the same headers as
    the API requests also makes subsequent range requests originate from the
    same client context.
    """
    address, separator, options = str(link or "").partition("|")
    if not address:
        return ""
    headers = urlencode(HEADERS)
    if options:
        headers = headers + "&" + options
    return address + "|" + headers


def _stream_rows(root, parent_tag):
    parent = root.find(parent_tag)
    if parent is None:
        return []
    rows = []
    for stream in parent.findall("stream"):
        row = {}
        for child in list(stream):
            row[child.tag] = (child.text or "").strip()
        if row:
            rows.append(row)
    return rows


def _subtitle_rows(root):
    """Read subtitle rows even when WebShare nests them below another node."""
    rows = []
    seen = set()
    for node in root.iter():
        tag = str(node.tag or "").lower()
        if not any(marker in tag for marker in ("subtitle", "sub", "caption", "text")):
            continue
        row = {}
        for child in node.iter():
            key = str(child.tag or "").lower()
            value = (child.text or "").strip()
            if value and key in ("lang", "language", "language_code", "locale", "name", "title", "label"):
                row[key] = value
        language = ""
        for key in ("lang", "language", "language_code", "locale", "name", "title", "label"):
            language = _language_code(row.get(key))
            if language:
                break
        if language and language not in seen:
            rows.append({"language": language})
            seen.add(language)
    return rows


def _language_code(value):
    value = "".join(char for char in str(value or "").lower() if char.isalpha())
    mapping = {
        "cz": "CZ", "cs": "CZ", "cze": "CZ", "ces": "CZ", "czech": "CZ",
        "sk": "SK", "slo": "SK", "slk": "SK", "slovak": "SK",
        "en": "EN", "eng": "EN", "english": "EN",
        "pl": "PL", "pol": "PL", "polish": "PL",
        "de": "DE", "deu": "DE", "ger": "DE", "german": "DE",
        "fr": "FR", "fra": "FR", "fre": "FR", "french": "FR",
        "es": "ES", "spa": "ES", "spanish": "ES",
        "it": "IT", "ita": "IT", "italian": "IT",
    }
    return mapping.get(value, "")


def _stream_languages(streams):
    result = []
    for stream in streams:
        for key in ("lang", "language", "language_code", "locale"):
            language = _language_code(stream.get(key))
            if language and language not in result:
                result.append(language)
    return result


def _text_languages(root, names):
    result = []
    for name in names:
        value = root.findtext(name) or ""
        for part in value.replace(";", ",").replace("/", ",").replace("|", ",").split(","):
            language = _language_code(part)
            if language and language not in result:
                result.append(language)
    return result


def _quality(width, height):
    long_side, short_side = max(width, height), min(width, height)
    if long_side >= 7600 or short_side >= 4000:
        return "8K"
    if long_side >= 3800 or short_side >= 2000:
        return "4K"
    if long_side >= 1900 or short_side >= 1000:
        return "Full HD"
    if long_side >= 1200 or short_side >= 700:
        return "HD"
    return "SD" if long_side or short_side else ""


def _ebml_vint(data, offset, strip_marker):
    if offset >= len(data):
        return None
    first = data[offset]
    mask = 0x80
    length = 1
    while length <= 8 and not (first & mask):
        mask >>= 1
        length += 1
    if length > 8 or offset + length > len(data):
        return None
    value = (first & (mask - 1)) if strip_marker else first
    for index in range(1, length):
        value = (value << 8) | data[offset + index]
    return value, length


def _ebml_uint(data):
    value = 0
    for byte in data:
        value = (value << 8) | byte
    return value


def _mkv_tracks(data):
    """Read subtitle languages and StereoMode from the Matroska track header."""
    if not data.startswith(b"\x1a\x45\xdf\xa3"):
        return {"scan_status": "unsupported_container", "subtitles": [], "stereo": {}}
    tracks = data.find(b"\x16\x54\xae\x6b")
    if tracks < 0:
        return {"scan_status": "mkv_scanned", "subtitles": [], "stereo": {}}
    size = _ebml_vint(data, tracks + 4, True)
    if not size or size[0] <= 0:
        return {"scan_status": "mkv_scanned", "subtitles": [], "stereo": {}}
    start = tracks + 4 + size[1]
    end = min(len(data), start + size[0])
    subtitles = []
    stereo = {}
    position = start
    stereo_modes = {
        1: ("3D SBS", "left_right"), 2: ("3D TAB", "bottom_top"),
        3: ("3D TAB", "top_bottom"), 4: ("3D checkerboard", "checkerboard_rl"),
        5: ("3D checkerboard", "checkerboard_lr"), 6: ("3D radkovane", "row_interleaved_rl"),
        7: ("3D radkovane", "row_interleaved_lr"), 8: ("3D sloupcove", "column_interleaved_rl"),
        9: ("3D sloupcove", "column_interleaved_lr"), 10: ("3D anaglyf", "anaglyph_cyan_red"),
        11: ("3D SBS", "right_left"), 12: ("3D anaglyf", "anaglyph_green_magenta"),
        13: ("3D prokladane", "both_eyes_laced_left"), 14: ("3D prokladane", "both_eyes_laced_right"),
    }
    while position < end:
        element = _ebml_vint(data, position, False)
        if not element:
            break
        position += element[1]
        length = _ebml_vint(data, position, True)
        if not length:
            break
        position += length[1]
        element_end = min(end, position + length[0])
        if element[0] != 0xae:
            position = element_end
            continue
        track_type = 0
        language = ""
        video_start = video_end = -1
        entry = position
        while entry < element_end:
            field = _ebml_vint(data, entry, False)
            if not field:
                break
            entry += field[1]
            field_length = _ebml_vint(data, entry, True)
            if not field_length:
                break
            entry += field_length[1]
            field_end = min(element_end, entry + field_length[0])
            raw = data[entry:field_end]
            if field[0] == 0x83:
                track_type = _ebml_uint(raw)
            elif field[0] == 0x22b59c:
                language = raw.decode("ascii", "ignore").strip()
            elif field[0] == 0xe0:
                video_start, video_end = entry, field_end
            entry = field_end
        if track_type == 17:
            code = _language_code(language)
            if code and code not in subtitles:
                subtitles.append(code)
        if track_type == 1 and video_start >= 0 and not stereo:
            video = video_start
            while video < video_end:
                field = _ebml_vint(data, video, False)
                if not field:
                    break
                video += field[1]
                field_length = _ebml_vint(data, video, True)
                if not field_length:
                    break
                video += field_length[1]
                field_end = min(video_end, video + field_length[0])
                if field[0] == 0x53b8:
                    mode = _ebml_uint(data[video:field_end])
                    if mode in stereo_modes:
                        label, kodi_mode = stereo_modes[mode]
                        stereo = {"mode": mode, "label": label, "kodi_mode": kodi_mode}
                    break
                video = field_end
        position = element_end
    return {"scan_status": "mkv_scanned", "subtitles": subtitles, "stereo": stereo}


def submission_technical(ident, token):
    """Load WebShare metadata and the small MKV header before submitting a source."""
    technical = file_info(ident, token)
    technical["metadata_version"] = 5
    technical["stereo_scan_status"] = "unavailable"
    technical["subtitle_scan_status"] = "unavailable"
    try:
        link = resolve(ident, token)
        response = requests.get(link, headers=dict(HEADERS, Range="bytes=0-1048575"),
                                timeout=20, stream=True, allow_redirects=True)
        try:
            if response.status_code not in (200, 206):
                return technical
            chunks = []
            remaining = 1048576
            for chunk in response.iter_content(chunk_size=65536):
                if not chunk or remaining <= 0:
                    break
                chunks.append(chunk[:remaining])
                remaining -= len(chunks[-1])
            tracks = _mkv_tracks(b"".join(chunks))
        finally:
            response.close()
    except requests.RequestException:
        return technical
    technical["stereo_scan_status"] = tracks["scan_status"]
    technical["subtitle_scan_status"] = tracks["scan_status"]
    technical["stereo"] = tracks["stereo"]
    for language in tracks["subtitles"]:
        if language not in technical["subtitles"]:
            technical["subtitles"].append(language)
    return technical


def file_info(ident, token):
    """Read actual WebShare stream metadata; never infer it from the filename."""
    root = api("file_info", {"ident": ident, "wst": token})
    if root.findtext("status") != "OK":
        raise WebshareError(30012, "file_info_failed")
    try:
        size = int(root.findtext("size") or 0)
    except (TypeError, ValueError):
        size = 0
    try:
        width = int(root.findtext("width") or 0)
        height = int(root.findtext("height") or 0)
    except (TypeError, ValueError):
        width = height = 0
    video_streams = _stream_rows(root, "video")
    audio_streams = _stream_rows(root, "audio")
    subtitle_streams = _subtitle_rows(root)
    subtitle_languages = _stream_languages(subtitle_streams)
    for language in _text_languages(root, ("subtitle_languages", "subtitles", "subs", "subs_langs")):
        if language not in subtitle_languages:
            subtitle_languages.append(language)
    for stream in video_streams:
        try:
            width = max(width, int(stream.get("width") or 0))
            height = max(height, int(stream.get("height") or 0))
        except (TypeError, ValueError):
            pass
    return {
        "scanned_at": int(__import__("time").time()),
        # Version 4 stores the actual dimensions too.  Older cached records
        # only contain the derived quality (for example Full HD), which used
        # to make the UI render an incorrect 0p suffix.
        "metadata_version": 4,
        "size": max(0, size),
        "width": max(0, width),
        "height": max(0, height),
        "quality": _quality(width, height),
        "audio": _stream_languages(audio_streams),
        "subtitles": subtitle_languages,
        "video_streams": video_streams,
        "audio_streams": audio_streams,
        "subtitle_streams": subtitle_streams,
    }


def enrich_sources(sources, token):
    """Add cached file_info metadata to the current search page."""
    sources = [dict(source) for source in sources or []]
    def enrich(source):
        try:
            source["technical"] = file_info(source.get("id", ""), token)
        except WebshareError:
            source["technical"] = {}
        return source
    with ThreadPoolExecutor(max_workers=min(6, max(1, len(sources)))) as executor:
        futures = [executor.submit(enrich, source) for source in sources]
        return [future.result() for future in futures]


def search(query, limit=25, offset=0, sort="largest"):
    """Search public WebShare video files without requiring account login."""
    query = " ".join(str(query or "").split()).strip()
    if not query:
        return []
    if sort not in ("largest", "recent"):
        sort = "largest"
    root = api("search", {"what": query, "category": "video", "offset": max(0, int(offset)),
                           "limit": max(1, int(limit)), "sort": sort})
    if root.findtext("status") != "OK":
        raise WebshareError(30012, "search_failed")
    rows = []
    for item in root.findall("file"):
        ident = (item.findtext("ident") or "").strip()
        name = (item.findtext("name") or ident).strip()
        if ident and ident.isascii() and ident.isalnum():
            try:
                size = int(item.findtext("size") or 0)
            except (TypeError, ValueError):
                size = 0
            rows.append({"id": ident, "name": name, "size": size})
    return rows


def verify_stream(ident, token):
    """Check signed stream access and inspect at most 64 KiB of its content.

    It verifies reachability and detects actual archives. Full decoding remains
    the responsibility of Kodi's player, so unknown data is not rejected.
    """
    link = resolve(ident, token)
    response = None
    try:
        response = requests.get(link, headers=dict(HEADERS, Range="bytes=0-65535"),
                                stream=True, allow_redirects=True, timeout=(10, 20))
        status_code = response.status_code
        content_type = response.headers.get("Content-Type", "")
        if status_code not in (200, 206):
            raise WebshareError(30013, "stream_http_{}".format(status_code))
        data = next(response.iter_content(chunk_size=65536), b"")
    except requests.RequestException:
        raise WebshareError(30013, "stream_network_error") from None
    finally:
        if response is not None:
            response.close()
    if not data:
        raise WebshareError(30013, "stream_empty")
    return {"http_status": status_code, "content_type": content_type,
            "content_kind": _content_kind(data)}

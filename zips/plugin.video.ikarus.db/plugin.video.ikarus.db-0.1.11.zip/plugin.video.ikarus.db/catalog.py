"""Read the schema-v3 source list without changing the source data."""
import json
import os
import tempfile
import unicodedata
from difflib import SequenceMatcher


LETTER_GROUPS = ("0-9",) + tuple("ABCDEFGHIJKLMNOPQRSTUVWXYZ")


def title_group(title):
    """Fold accents and put every title into 0-9 or A-Z."""
    normalized = unicodedata.normalize("NFKD", str(title or "")).upper()
    first = next((char for char in normalized if char.isalnum()), "")
    if first.isdigit():
        return "0-9"
    return first if first in LETTER_GROUPS else "other"


def group_movies(movies):
    groups = {letter: [] for letter in LETTER_GROUPS}
    for movie in movies:
        groups.setdefault(title_group(movie["title"]), []).append(movie)
    for group in groups.values():
        group.sort(key=lambda movie: (str(movie.get("title") or "").casefold(), int(movie.get("year") or 0)))
    return groups


def group_genres(movies):
    """Group enriched movies by TMDB genre, keeping movies without metadata."""
    groups = {}
    for movie in movies:
        genres = movie.get("genres") or (movie.get("details") or {}).get("genre") or []
        names = [str(name).strip() for name in genres if str(name).strip()]
        if not names:
            names = ["Bez žánru"]
        for name in names:
            groups.setdefault(name, []).append(movie)
    for group in groups.values():
        group.sort(key=lambda movie: (str(movie.get("title") or "").casefold(), int(movie.get("year") or 0)))
    return {name: groups[name] for name in sorted(groups, key=str.casefold)}


def _search_text(value):
    value = unicodedata.normalize("NFKD", str(value or ""))
    value = "".join(char for char in value if not unicodedata.combining(char)).casefold()
    return " ".join("".join(char if char.isalnum() else " " for char in value).split())


def _movie_search_score(movie, query):
    query = _search_text(query)
    if not query:
        return 0
    query_words = query.split()
    details = movie.get("details") if isinstance(movie.get("details"), dict) else {}
    values = (movie.get("title"), movie.get("title_cs"), movie.get("original_title"),
              details.get("originaltitle"), details.get("title"))
    best = 0
    for value in values:
        value = _search_text(value)
        if not value:
            continue
        if value == query:
            best = max(best, 1000)
            continue
        if value.startswith(query):
            best = max(best, 930)
            continue
        if query in value:
            best = max(best, 880)
            continue
        words = value.split()
        word_scores = []
        for part in query_words:
            score = 0
            for word in words:
                if word.startswith(part):
                    score = max(score, 1)
                    continue
                # Do not let a one-letter connector such as "s" satisfy a
                # longer query such as "slunce".
                if len(word) >= 3 and part.startswith(word):
                    score = max(score, 1)
                    continue
                # A typo may alter one character of a longer word, but it
                # must still closely resemble that one word.  Comparing the
                # entire title here was too broad ("blade" matched "balada").
                if len(part) >= 5 and abs(len(part) - len(word)) <= 1:
                    ratio = SequenceMatcher(None, part, word).ratio()
                    if ratio >= 0.8:
                        score = max(score, ratio)
            word_scores.append(score)
        if word_scores and all(word_scores):
            best = max(best, int(760 + 80 * min(word_scores) + min(60, len(query) * 2)))
    return best


def search_movies(movies, query, limit=100):
    """Return title matches tolerant of accents, partial input and typos."""
    matches = []
    for movie in movies or []:
        score = _movie_search_score(movie, query)
        if score:
            matches.append((score, movie))
    matches.sort(key=lambda item: (-item[0], str(item[1].get("title") or "").casefold(), int(item[1].get("year") or 0)))
    return [movie for _, movie in matches[:max(1, int(limit))]]


def load_sources(path):
    """Return every catalog source with a valid WebShare identifier.

    The catalog itself is deliberately only read; verification results live in
    the Kodi profile, never alongside the source data.
    """
    with open(path, "r", encoding="utf-8-sig") as stream:
        data = json.load(stream)
    if not isinstance(data, dict) or not isinstance(data.get("zdroje"), list):
        raise ValueError("Invalid source catalog")
    sources = []
    seen = set()
    for row in data["zdroje"]:
        if not isinstance(row, dict):
            continue
        ident = str(row.get("webshare_id") or "").strip()
        if not ident or not ident.isascii() or not ident.isalnum() or ident in seen:
            continue
        seen.add(ident)
        sources.append({
            "id": ident,
            "name": str(row.get("name") or ident),
            "title": str(row.get("title") or row.get("name") or ident),
            "media_type": str(row.get("media_type") or "movie"),
        })
    return sources


def load_movies(path):
    movies = {}

    with open(path, "r", encoding="utf-8-sig") as stream:
        data = json.load(stream)
    if not isinstance(data, dict) or not isinstance(data.get("zdroje"), list):
        raise ValueError("Invalid source catalog")
    for row in data["zdroje"]:
        if (not isinstance(row, dict) or row.get("media_type") not in (None, "", "movie")
                or (isinstance(row.get("availability"), dict) and row["availability"].get("status") == "unavailable")):
            continue
        ident = str(row.get("webshare_id") or "").strip()
        if not ident or not ident.isascii() or not ident.isalnum():
            continue
        csfd = str(row.get("csfd_id") or "").strip()
        key = "csfd:" + csfd if csfd else "ws:" + ident
        title = str(row.get("title") or row.get("name") or ident)
        try:
            year = int(row.get("year") or 0)
        except (TypeError, ValueError):
            year = 0
        if key not in movies:
            movies[key] = {
                "key": key, "title": title, "year": year, "csfd_id": csfd,
                "imdb_id": str(row.get("imdb_id") or ""),
                "tmdb_id": str(row.get("tmdb_id") or ""), "tmdb_type": str(row.get("tmdb_type") or "movie"), "sources": [],
                "has_title": bool(row.get("title")),
            }
        movie = movies[key]
        if row.get("title") and not movie["has_title"]:
            movie.update(title=title, year=year, has_title=True)
        for field in ("imdb_id", "tmdb_id", "tmdb_type"):
            if not movie[field] and row.get(field):
                movie[field] = str(row[field])
        if not any(source["id"] == ident for source in movie["sources"]):
            movie["sources"].append({"id": ident, "name": str(row.get("name") or ident)})
    return sorted(movies.values(), key=lambda item: (item["title"].casefold(), item["year"]))



def record_verification(path, results):
    """Persist only authenticated availability results in the source catalog.

    Existing catalog metadata and untested rows remain intact.  Atomic replace
    prevents a partial JSON file if Kodi or the system exits during the write.
    """
    by_id = {str(item.get("id") or ""): item for item in results}
    if not by_id:
        return 0
    with open(path, "r", encoding="utf-8-sig") as stream:
        data = json.load(stream)
    if not isinstance(data, dict) or not isinstance(data.get("zdroje"), list):
        raise ValueError("Invalid source catalog")
    changed = 0
    for row in data["zdroje"]:
        if not isinstance(row, dict):
            continue
        result = by_id.get(str(row.get("webshare_id") or ""))
        if result is None:
            continue
        row["availability"] = {
            "status": result.get("status", "unknown"),
            "checked_at": result.get("checked_at"),
            "kind": result.get("kind", "video"),
        }
        if result.get("reason"):
            row["availability"]["reason"] = result["reason"]
        if result.get("http_status") is not None:
            row["availability"]["http_status"] = result["http_status"]
        if result.get("content_type"):
            row["availability"]["content_type"] = result["content_type"]
        changed += 1
    directory = os.path.dirname(path) or "."
    descriptor, temporary = tempfile.mkstemp(prefix=".seznam_zdroju_", suffix=".json", dir=directory)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.replace(temporary, path)
    except Exception:
        try:
            os.unlink(temporary)
        except OSError:
            pass
        raise
    return changed




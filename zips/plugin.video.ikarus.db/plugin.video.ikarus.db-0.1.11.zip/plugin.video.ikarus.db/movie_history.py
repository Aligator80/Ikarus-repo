"""Durable playback updates and a Kodi observer for catalog movies."""
from contextlib import closing
import json
import math
import os
import sqlite3
import time
import uuid


class Outbox:
    def __init__(self, profile, server, account):
        self.path = os.path.join(profile, "movie_history.sqlite3")
        self.server = server
        self.account = account

    def _connect(self):
        db = sqlite3.connect(self.path)
        try:
            db.execute("""CREATE TABLE IF NOT EXISTS playback_outbox (
                server TEXT NOT NULL, account TEXT NOT NULL, session TEXT NOT NULL,
                sequence INTEGER NOT NULL, payload TEXT NOT NULL,
                PRIMARY KEY (server, account, session))""")
            return db
        except sqlite3.Error:
            db.close()
            raise

    def put(self, row):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with closing(self._connect()) as db, db:
            db.execute("""INSERT OR REPLACE INTO playback_outbox VALUES (?, ?, ?, ?, ?)""",
                       (self.server, self.account, row["session"], row["sequence"], json.dumps(row)))

    def pending(self):
        if not os.path.isfile(self.path):
            return []
        with closing(self._connect()) as db:
            rows = db.execute("""SELECT payload FROM playback_outbox WHERE server = ? AND account = ?
                                 ORDER BY rowid""", (self.server, self.account)).fetchall()
        return [json.loads(payload) for (payload,) in rows]

    def acknowledge(self, row):
        with closing(self._connect()) as db, db:
            db.execute("""DELETE FROM playback_outbox WHERE server = ? AND account = ?
                          AND session = ? AND sequence = ?""",
                       (self.server, self.account, row["session"], row["sequence"]))


def observe(xbmc, start, path, resume, on_started, save, resolved_path=""):
    """Save only after this movie has actually started playing."""
    def address(value):
        return value.partition("|")[0].partition("#")[0]

    paths = {address(path)}
    if resolved_path:
        paths.add(address(resolved_path))

    class Observer(xbmc.Player):
        def __init__(self):
            super().__init__()
            self.started = False
            self.result = ""

        def playing_source(self):
            try:
                return self.isPlayingVideo() and address(self.getPlayingFile()) in paths
            except RuntimeError:
                return False

        def onAVStarted(self):
            if self.started:
                self.result = self.result or "replaced"
            elif self.playing_source():
                self.started = True

        def onPlayBackEnded(self):
            if self.started and not self.result:
                self.result = "ended"

        def onPlayBackStopped(self):
            if self.started:
                self.result = self.result or "stopped"

        def onPlayBackError(self):
            self.result = self.result or "error"

    player = Observer()
    monitor = xbmc.Monitor()
    start(player)
    deadline = time.monotonic() + 45
    while not player.started:
        if player.result or time.monotonic() >= deadline or monitor.waitForAbort(0.25):
            return

    if resume and not player.result and player.playing_source():
        try:
            player.seekTime(resume)
        except RuntimeError:
            pass

    position, duration = 0.0, 0.0
    last_checkpoint = time.monotonic()
    last_saved = None

    def checkpoint(status):
        nonlocal last_saved
        values = (status, int(position) if status == "watching" else 0, int(duration))
        if status == "watching" and values[1] >= values[2]:
            return
        if values != last_saved and save(*values):
            last_saved = values

    while not player.result and not monitor.abortRequested():
        if not player.playing_source():
            # Kodi can clear the playing file just before delivering the callback.
            monitor.waitForAbort(0.5)
            if player.result or not player.playing_source():
                break
        try:
            current, total = player.getTime(), player.getTotalTime()
            if math.isfinite(current) and math.isfinite(total) and 0 <= current <= total:
                position, duration = current, total
        except RuntimeError:
            pass
        if on_started:
            on_started(player)
            on_started = None
        if time.monotonic() - last_checkpoint >= 15 and 30 <= position < duration:
            checkpoint("watching")
            last_checkpoint = time.monotonic()
        monitor.waitForAbort(0.5)

    if player.result == "ended" or (player.result == "stopped" and duration > 0 and position >= duration * 0.9):
        checkpoint("watched")
    elif 30 <= position < duration:
        checkpoint("watching")
    return last_saved is not None


def playback_update(movie, source):
    session = uuid.uuid4().hex
    revision = (movie.get("playback") or {}).get("revision", 0)
    sequence = 0

    def save(status, position, duration):
        nonlocal sequence
        sequence += 1
        row = dict(movie_key=movie["key"], source_id=source["id"], status=status,
                   position=position, duration=duration, base_revision=revision,
                   session=session, sequence=sequence)
        try:
            movie["_playback_outbox"].put(row)
        except (OSError, sqlite3.Error):
            return False
        return True

    return save

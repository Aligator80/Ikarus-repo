"""Collect technical source metadata exposed by Kodi during playback."""
import time

import xbmc


LANGUAGES = {
    "cs": "CZ", "ces": "CZ", "cze": "CZ", "czech": "CZ",
    "sk": "SK", "slk": "SK", "slo": "SK", "slovak": "SK",
    "en": "EN", "eng": "EN", "english": "EN",
    "pl": "PL", "pol": "PL", "polish": "PL",
    "de": "DE", "deu": "DE", "ger": "DE", "german": "DE",
    "fr": "FR", "fra": "FR", "fre": "FR", "french": "FR",
    "es": "ES", "spa": "ES", "spanish": "ES",
    "it": "IT", "ita": "IT", "italian": "IT",
    "hu": "HU", "hun": "HU", "hungarian": "HU",
    "ru": "RU", "rus": "RU", "russian": "RU",
    "ja": "JA", "jpn": "JA", "japanese": "JA",
}

STEREO_MODES = {
    "left_right": {"mode": 1, "label": "3D SBS", "kodi_mode": "left_right"},
    "split_vertical": {"mode": 1, "label": "3D SBS", "kodi_mode": "left_right"},
    "right_left": {"mode": 11, "label": "3D SBS", "kodi_mode": "right_left"},
    "top_bottom": {"mode": 3, "label": "3D TAB", "kodi_mode": "top_bottom"},
    "split_horizontal": {"mode": 3, "label": "3D TAB", "kodi_mode": "top_bottom"},
    "bottom_top": {"mode": 2, "label": "3D TAB", "kodi_mode": "bottom_top"},
    "row_interleaved": {"mode": 5, "label": "3D prokladane radky", "kodi_mode": "row_interleaved"},
    "col_interleaved": {"mode": 6, "label": "3D prokladane sloupce", "kodi_mode": "col_interleaved"},
    "checkerboard": {"mode": 4, "label": "3D sachovnice", "kodi_mode": "checkerboard"},
    "anaglyph_cyan_red": {"mode": 7, "label": "3D anaglyf", "kodi_mode": "anaglyph_cyan_red"},
    "anaglyph_green_magenta": {"mode": 8, "label": "3D anaglyf", "kodi_mode": "anaglyph_green_magenta"},
}


def _language(value):
    value = str(value or "").strip().lower().replace("_", "-")
    if not value:
        return ""
    if value.upper() in set(LANGUAGES.values()):
        return value.upper()
    base = value.split("-", 1)[0]
    return LANGUAGES.get(value, LANGUAGES.get(base, ""))


def _languages(values):
    result = []
    for value in values or []:
        language = _language(value)
        if language and language not in result:
            result.append(language)
        if len(result) >= 8:
            break
    return result


def _stream_language(stream):
    if isinstance(stream, dict):
        for field in ("language", "lang", "name"):
            language = _language(stream.get(field))
            if language:
                return language
        return ""
    return _language(stream)


def _stream_index(stream, fallback):
    if isinstance(stream, dict):
        for field in ("index", "id"):
            try:
                return int(stream[field])
            except (KeyError, TypeError, ValueError):
                pass
    try:
        return int(fallback)
    except (TypeError, ValueError):
        return None


def _preferred_stream(streams, languages):
    streams = streams if isinstance(streams, list) else []
    for language in languages or []:
        language = _language(language)
        if not language:
            continue
        for fallback, stream in enumerate(streams):
            if _stream_language(stream) == language:
                return _stream_index(stream, fallback), language
    return None, ""


def apply_language_preferences(player, audio_languages, subtitles_enabled, subtitle_languages, timeout=8):
    """Choose Kodi streams after AV start, keeping playback usable on failure."""
    monitor = xbmc.Monitor()
    deadline = time.time() + max(1, int(timeout))
    audio_streams = []
    subtitle_streams = []
    while time.time() < deadline and not monitor.abortRequested():
        try:
            if player.isPlayingVideo():
                audio_streams = player.getAvailableAudioStreams() or []
                subtitle_streams = player.getAvailableSubtitleStreams() or []
                if audio_streams or subtitle_streams:
                    break
        except (AttributeError, RuntimeError):
            return {"audio": "", "subtitle": ""}
        monitor.waitForAbort(0.25)

    selected_audio = ""
    audio_index, selected_audio = _preferred_stream(audio_streams, audio_languages)
    if audio_index is not None:
        try:
            player.setAudioStream(audio_index)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            selected_audio = ""

    selected_subtitle = ""
    if subtitles_enabled:
        subtitle_index, selected_subtitle = _preferred_stream(subtitle_streams, subtitle_languages)
        if subtitle_index is not None:
            try:
                player.setSubtitleStream(subtitle_index)
                player.showSubtitles(True)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                selected_subtitle = ""
    else:
        try:
            player.showSubtitles(False)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    return {"audio": selected_audio, "subtitle": selected_subtitle}


def stereo_from_label(value):
    value = str(value or "").strip().lower().replace("-", "_").replace(" ", "_")
    return dict(STEREO_MODES[value]) if value in STEREO_MODES else {}


def observe(player, timeout=15):
    """Wait for AV start and return metadata Kodi learned from the stream."""
    deadline = time.time() + max(1, int(timeout))
    monitor = xbmc.Monitor()
    started_at = 0.0
    best = {}
    while time.time() < deadline and not monitor.abortRequested():
        try:
            playing = bool(player.isPlayingVideo())
        except RuntimeError:
            playing = False
        if not playing:
            monitor.waitForAbort(0.25)
            continue
        if not started_at:
            started_at = time.time()
        try:
            audio = _languages(player.getAvailableAudioStreams())
        except (AttributeError, RuntimeError):
            audio = []
        try:
            subtitles = _languages(player.getAvailableSubtitleStreams())
        except (AttributeError, RuntimeError):
            subtitles = []
        stereo = stereo_from_label(xbmc.getInfoLabel("VideoPlayer.StereoscopicMode"))
        current = {
            "scanned_at": int(time.time()),
            "metadata_version": 6,
            "playback_scan_status": "scanned",
            "audio": audio,
            "subtitles": subtitles,
        }
        if stereo:
            current["stereo"] = stereo
            current["stereo_scan_status"] = "playback_detected"
        best = current
        # Stream lists can appear slightly later than the picture. Give Kodi
        # a short settling window, while never holding the plugin for long.
        if time.time() - started_at >= 2.0 and (audio or subtitles or stereo):
            break
        monitor.waitForAbort(0.25)
    return best


def merge(base, observed):
    """Merge playback results without erasing richer data already collected."""
    result = dict(base or {})
    observed = observed if isinstance(observed, dict) else {}
    if not observed:
        return result
    for field in ("scanned_at", "metadata_version", "playback_scan_status"):
        if field in observed:
            result[field] = observed[field]
    for field in ("audio", "subtitles"):
        values = []
        for value in list(result.get(field) or []) + list(observed.get(field) or []):
            value = str(value or "").strip().upper()
            if value and value not in values:
                values.append(value)
        if values:
            result[field] = values[:8]
    if not isinstance(result.get("stereo"), dict) or not result["stereo"].get("kodi_mode"):
        if isinstance(observed.get("stereo"), dict) and observed["stereo"].get("kodi_mode"):
            result["stereo"] = dict(observed["stereo"])
            result["stereo_scan_status"] = "playback_detected"
    return result

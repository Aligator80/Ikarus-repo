"""Build the compact CSFD title index used by the Kodi add-on."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "CSFD_ID_DATA.json"
TARGET = ROOT / "plugin.video.ikarus.DB" / "resources" / "csfd_titles.json"

with SOURCE.open(encoding="utf-8") as stream:
    rows = json.load(stream).get("csfd_id_data", {})

entries = {}
for raw_id, row in rows.items():
    if not str(raw_id).isdigit() or not isinstance(row, dict):
        continue
    parsed = row.get("parsed") if isinstance(row.get("parsed"), dict) else {}
    title = str(parsed.get("title_cz") or parsed.get("title_original") or "").strip()
    try:
        year = max(0, int(parsed.get("year") or 0))
    except (TypeError, ValueError):
        year = 0
    if title:
        entries[str(raw_id)] = [title, year]

payload = {"version": 1, "source_count": len(entries), "titles": entries}
with TARGET.open("w", encoding="utf-8") as stream:
    json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    stream.write("\n")
print("Wrote {} titles to {} ({} bytes)".format(len(entries), TARGET, TARGET.stat().st_size))

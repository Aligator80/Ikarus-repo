import copy
from contextlib import contextmanager
import os
import sys
import tempfile
import threading
import unittest
from unittest import mock

from test_storage_regressions import load_lists
from test_playback_accounts import load_module
import resources.lib as lib
from resources.lib import json_storage


def remote_list(slug="one", name="Original", number=1):
    return {"name": name, "ids": {"slug": slug, "trakt": number}, "user": {"username": "owner"}}


def remote_item(number):
    return {"type": "movie", "movie": {"ids": {"tmdb": number}, "title": str(number)}}


class Client:
    def __init__(self):
        self.selected = "A"
        self.local = threading.local()
        self.calls = []
        self.remote = []
        self.items = []
        self.on_fetch = lambda: None
        self.on_create = lambda: None
        self.on_delete_item = lambda: None

    def current_account_id(self):
        return getattr(self.local, "owner", self.selected)

    @contextmanager
    def account_session(self):
        previous = getattr(self.local, "owner", None)
        self.local.owner = self.selected
        try:
            if not self.selected:
                raise RuntimeError("not connected")
            yield self.selected
        finally:
            if previous is None:
                del self.local.owner
            else:
                self.local.owner = previous

    def _request(self, kind, slug=""):
        if self.current_account_id() != self.selected:
            raise RuntimeError("account changed")
        self.calls.append((self.selected, kind, slug))

    def is_connected(self):
        return bool(self.selected)

    def fetch_user_lists(self):
        self._request("overview")
        rows = copy.deepcopy(self.remote)
        self.on_fetch()
        return rows

    def fetch_list_items(self, username, slug, **kwargs):
        self._request("items", slug)
        return {"rows": copy.deepcopy(self.items), "page": 1, "page_count": 1, "item_count": len(self.items)}

    def create_user_list(self, name, **kwargs):
        self._request("create", name)
        self.on_create()
        return remote_list("created", name, 99)

    def update_user_list(self, slug, name, **kwargs):
        self._request("rename", slug)
        return remote_list(slug, name)

    def add_item_to_list(self, slug, *args):
        self._request("add", slug)
        return {"added": {"movies": 1}}

    def remove_item_from_list(self, slug, *args):
        self._request("remove_item", slug)
        self.on_delete_item()
        return {"deleted": {"movies": 1}}

    def delete_user_list(self, slug):
        self._request("remove_list", slug)
        return True


class ListSyncTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.client = Client()
        self.lists = load_lists()
        self.path = os.path.join(self.temp.name, "lists.json")
        self.lists._profile_dir = lambda: self.temp.name
        self.lists.custom_lists_path = lambda: self.path
        self.lists.current_account_id = self.client.current_account_id
        self.lists._device_identity = lambda: {"device_id": "device", "device_name": "Device"}
        self.lists._mark_local_mutation = mock.Mock()
        with mock.patch.dict(sys.modules, {"xbmc": self.lists.xbmc}), mock.patch.object(lib, "i18n", self.lists.i18n, create=True), mock.patch.object(lib, "tmdb_custom_lists", self.lists, create=True), mock.patch.object(lib, "trakt_client", self.client, create=True):
            self.sync = load_module("lists_sync_test", "tmdb_trakt_list_sync.py")
        self.sync._tmdb_enrich_item = lambda item: item
        self.sync.i18n = type("I18n", (), {"T": staticmethod(lambda *args: args[-1])})

    def linked(self, name="Original", slug="one", number=1):
        row = self.lists.create_list(name)
        data = self.lists.load()
        target = next(item for item in data["lists"] if item["id"] == row["id"])
        target.update(trakt_slug=slug, trakt_id=str(number), metadata_pending=False, sync_state="synced")
        self.lists.save(data)
        return row["id"]

    def add(self, list_id, number):
        return self.lists.add_item(list_id, {"media_type": "movie", "tmdb_id": str(number)})

    def pull(self, list_id, numbers):
        self.client.items = [remote_item(n) for n in numbers]
        result = self.sync.sync_local_list_items_from_trakt(list_id)
        self.assertTrue(result["ok"], result)

    def ids(self, list_id):
        return {i["tmdb_id"] for i in self.lists.get_list(list_id)["items"]}

    def test_remote_deletion_and_equal_count_replacement(self):
        row = self.linked()
        self.pull(row, [1, 2])
        self.pull(row, [2, 3])
        self.assertEqual({"2", "3"}, self.ids(row))
        self.pull(row, [])
        self.assertEqual(set(), self.ids(row))
        self.sync.sync_local_list_to_trakt(row)
        self.assertFalse(any(c[1] == "add" for c in self.client.calls))

    def test_offline_add_and_explicit_readd_survive_remote_deletion(self):
        row = self.linked()
        self.pull(row, [1])
        self.add(row, 1)
        self.add(row, 2)
        self.pull(row, [])
        self.assertEqual({"1", "2"}, self.ids(row))
        result = self.sync.sync_local_list_to_trakt(row)
        self.assertEqual(2, result["pushed_items"])
        self.pull(row, [])
        self.assertEqual(set(), self.ids(row))

    def test_legacy_unknown_item_is_retained_without_upload(self):
        row = self.linked()
        self.add(row, 1)
        data = self.lists.load()
        data["lists"][0]["items"][0].pop("sync_add_id")
        self.lists.save(data)
        self.pull(row, [])
        self.assertEqual({"1"}, self.ids(row))
        self.assertEqual(0, self.sync.sync_local_list_to_trakt(row)["pushed_items"])

    def test_invalid_pull_keeps_items_and_baseline(self):
        row = self.linked()
        self.pull(row, [1])
        self.client.items = [remote_item(2), {"type": "movie", "movie": {}}]
        self.assertFalse(self.sync.sync_local_list_items_from_trakt(row)["ok"])
        self.assertEqual({"1"}, self.ids(row))
        self.assertEqual(["movie:1"], self.lists.get_list(row)["trakt_items_snapshot"])

    def test_concurrent_metadata_does_not_prevent_remote_deletion(self):
        row = self.linked()
        self.pull(row, [1])
        def fetch(*args, **kwargs):
            data = self.lists.load()
            data["lists"][0]["items"][0]["title"] = "Enriched title"
            self.lists.save(data)
            return {"rows": [], "page": 1, "page_count": 1, "item_count": 0}
        self.client.fetch_list_items = fetch
        self.assertTrue(self.sync.sync_local_list_items_from_trakt(row)["ok"])
        self.assertEqual(set(), self.ids(row))

    def test_concurrent_readd_survives_remote_deletion(self):
        row = self.linked()
        self.pull(row, [1])
        def fetch(*args, **kwargs):
            self.add(row, 1)
            return {"rows": [], "page": 1, "page_count": 1, "item_count": 0}
        self.client.fetch_list_items = fetch
        self.assertTrue(self.sync.sync_local_list_items_from_trakt(row)["ok"])
        self.assertEqual({"1"}, self.ids(row))

    def test_newer_add_marker_survives_acknowledgement(self):
        row = self.linked()
        self.add(row, 1)
        def push(*args):
            self.add(row, 1)
            return {"added": {"movies": 1}}
        self.client.add_item_to_list = push
        self.assertTrue(self.sync.sync_local_list_to_trakt(row)["ok"])
        self.assertTrue(self.lists.get_list(row)["items"][0].get("sync_add_id"))

    def test_pagination_follows_page_count_even_for_short_page(self):
        row = self.linked()
        def fetch(*args, **kwargs):
            page = kwargs["page"]
            return {"rows": [remote_item(page)], "page": page, "page_count": 2, "item_count": 2}
        self.client.fetch_list_items = fetch
        self.assertTrue(self.sync.sync_local_list_items_from_trakt(row)["ok"])
        self.assertEqual({"1", "2"}, self.ids(row))

    def test_incomplete_page_does_not_authorize_removal(self):
        row = self.linked()
        self.pull(row, [1])
        self.client.fetch_list_items = lambda *a, **k: {"rows": [], "page": 1, "page_count": 1, "item_count": 1}
        self.assertFalse(self.sync.sync_local_list_items_from_trakt(row)["ok"])
        self.assertEqual({"1"}, self.ids(row))

    def test_stale_only_item_is_not_uploaded(self):
        row = self.linked()
        result = self.sync.sync_local_list_to_trakt(row, {"media_type": "movie", "tmdb_id": "1"})
        self.assertEqual(0, result["pushed_items"])

    def test_accounts_have_distinct_lists_and_cannot_edit_each_other(self):
        a = self.linked()
        self.client.selected = "B"
        b = self.linked()
        self.assertNotEqual(a, b)
        self.assertIsNone(self.lists.get_list(a))
        self.assertEqual([b], [row["id"] for row in self.lists.all_lists()])
        self.assertFalse(self.add(a, 10)[0])
        self.assertFalse(self.lists.rename_list(a, "wrong")[0])
        self.assertFalse(self.lists.delete_list(a)[0])
        self.assertEqual(2, len(self.lists.load()["lists"]))

    def test_foreign_and_legacy_lists_are_not_uploaded_or_deleted(self):
        a = self.linked(slug="a")
        self.lists.delete_list(a)
        self.client.selected = ""
        legacy = self.linked("Legacy", "legacy")
        self.client.selected = "B"
        self.client.remote = []
        result = self.sync.sync_now()
        self.assertTrue(result["ok"])
        self.assertEqual([("B", "overview", "")], self.client.calls)
        self.assertIsNotNone(self.lists.get_list(legacy))
        self.assertEqual(1, len(self.lists.load()["deleted_lists"]))

    def test_remote_overview_claims_matching_legacy_list_without_losing_items(self):
        legacy = self.linked(name="Original", slug="one", number=1)
        self.add(legacy, 10)
        data = self.lists.load()
        row = next(row for row in data["lists"] if row["id"] == legacy)
        row.pop("trakt_account_id", None)
        self.lists.save(data)
        self.client.remote = [remote_list()]

        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        rows = self.lists.load()["lists"]
        self.assertEqual(1, len(rows))
        self.assertEqual(legacy, rows[0]["id"])
        self.assertEqual("A", rows[0]["trakt_account_id"])
        self.assertEqual({"10"}, self.ids(legacy))

    def test_matching_legacy_and_current_rows_collapse_into_one_list(self):
        legacy = self.linked(name="Original", slug="one", number=1)
        self.add(legacy, 10)
        duplicate = self.linked(name="Imported copy", slug="one", number=1)
        self.add(duplicate, 20)
        data = self.lists.load()
        next(row for row in data["lists"] if row["id"] == legacy).pop("trakt_account_id", None)
        self.lists.save(data)
        self.client.remote = [remote_list()]

        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        rows = self.lists.load()["lists"]
        self.assertEqual(1, len(rows))
        self.assertEqual(legacy, rows[0]["id"])
        self.assertEqual({"10", "20"}, self.ids(legacy))

    def test_remote_pull_preserves_concurrent_rename_and_add(self):
        list_id = self.linked()
        self.client.remote = [remote_list()]
        self.client.items = [remote_item(1)]
        def edit():
            self.lists.rename_list(list_id, "Local name")
            self.add(list_id, 2)
        self.client.on_fetch = edit
        result = self.sync.sync_now(fetch_items=True, push_items=False)
        self.assertTrue(result["ok"])
        row = self.lists.get_list(list_id)
        self.assertEqual("Local name", row["name"])
        self.assertEqual({"1", "2"}, {item["tmdb_id"] for item in row["items"]})
        self.assertTrue(row["metadata_pending"])
        self.assertEqual("pending", row["sync_state"])

    def test_remote_pull_does_not_resurrect_concurrently_deleted_item(self):
        list_id = self.linked()
        self.add(list_id, 1)
        self.client.remote = [remote_list()]
        self.client.items = [remote_item(1)]
        self.client.on_fetch = lambda: self.lists.delete_item(list_id, "movie", "1")
        self.assertTrue(self.sync.sync_now(push_items=False)["ok"])
        row = self.lists.get_list(list_id)
        self.assertEqual([], row["items"])
        self.assertEqual("1", row["deleted_items"][0]["tmdb_id"])

    def test_acknowledgement_keeps_a_newer_deletion_of_same_item(self):
        list_id = self.linked()
        self.add(list_id, 1)
        self.lists.delete_item(list_id, "movie", "1")
        old = self.lists.get_list(list_id)["deleted_items"][0]["mutation_id"]
        def redelete():
            self.add(list_id, 1)
            self.lists.delete_item(list_id, "movie", "1")
        self.client.on_delete_item = redelete
        self.assertTrue(self.sync.sync_local_item_delete_to_trakt(list_id, "movie", "1")["ok"])
        new = self.lists.get_list(list_id)["deleted_items"]
        self.assertEqual(1, len(new))
        self.assertNotEqual(old, new[0]["mutation_id"])

    def test_local_delete_during_remote_create_keeps_cleanup_link(self):
        list_id = self.lists.create_list("New")["id"]
        self.client.on_create = lambda: self.lists.delete_list(list_id)
        self.assertTrue(self.sync.sync_local_list_to_trakt(list_id)["ok"])
        data = self.lists.load()
        self.assertEqual([], data["lists"])
        self.assertEqual("created", data["deleted_lists"][0]["trakt_slug"])
        self.assertTrue(self.sync.sync_local_list_delete_to_trakt(list_id)["ok"])
        self.assertEqual([], self.lists.load()["deleted_lists"])

    def test_overview_never_creates_remote_lists(self):
        self.lists.create_list("Local")
        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        self.assertEqual([("A", "overview", "")], self.client.calls)

    def test_partial_page_failure_does_not_save_partial_list(self):
        list_id = self.linked()
        before = self.lists.load()
        def fetch(username, slug, **kwargs):
            if kwargs["page"] == 1:
                return {"rows": [remote_item(i) for i in range(1, 101)], "page": 1, "page_count": 2, "item_count": 101}
            raise RuntimeError("page two offline")
        self.client.fetch_list_items = fetch
        self.assertFalse(self.sync.sync_local_list_items_from_trakt(list_id)["ok"])
        self.assertEqual(before, self.lists.load())

    def test_switch_during_request_commits_only_to_original_account(self):
        a = self.linked()
        self.client.selected = "B"
        b = self.linked()
        self.client.selected = "A"
        self.client.remote = [remote_list(name="Remote A")]
        self.client.on_fetch = lambda: setattr(self.client, "selected", "B")
        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        rows = {row["id"]: row for row in self.lists.load()["lists"]}
        self.assertEqual("Remote A", rows[a]["name"])
        self.assertEqual("Original", rows[b]["name"])
        self.assertIsNone(self.lists.get_list(a))

    def test_remote_list_removal_preserves_a_concurrent_local_change(self):
        list_id = self.linked()
        self.client.on_fetch = lambda: self.add(list_id, 1)
        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        self.assertEqual("1", self.lists.get_list(list_id)["items"][0]["tmdb_id"])

    def test_offline_rename_is_not_overwritten_by_overview(self):
        list_id = self.linked()
        self.lists.rename_list(list_id, "Offline name")
        self.client.remote = [remote_list()]
        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        self.assertEqual("Offline name", self.lists.get_list(list_id)["name"])
        self.assertTrue(self.sync.sync_local_list_metadata_to_trakt(list_id)["ok"])
        self.assertFalse(self.lists.get_list(list_id)["metadata_pending"])

    def test_failed_commit_does_not_claim_success(self):
        list_id = self.linked()
        with mock.patch.object(json_storage, "write_json", side_effect=OSError("disk full")):
            result = self.sync.sync_local_list_items_from_trakt(list_id)
        self.assertFalse(result["ok"])

    def test_sync_timer_is_scoped_by_account(self):
        path_a = self.lists._custom_sync_meta_path()
        self.client.selected = "B"
        self.assertNotEqual(path_a, self.lists._custom_sync_meta_path())

    def test_empty_delete_response_keeps_pending_tombstone(self):
        list_id = self.linked()
        self.add(list_id, 1)
        self.lists.delete_item(list_id, "movie", "1")
        self.client.remove_item_from_list = lambda *a: {}
        self.assertFalse(self.sync.sync_local_item_delete_to_trakt(list_id, "movie", "1")["ok"])
        self.assertEqual(1, len(self.lists.get_list(list_id)["deleted_items"]))

    def test_partial_push_failure_is_reported_and_keeps_pending_state(self):
        list_id = self.linked()
        self.add(list_id, 1)
        self.client.add_item_to_list = lambda *a: {}
        result = self.sync.sync_local_list_to_trakt(list_id)
        self.assertFalse(result["ok"])
        self.assertEqual("partial_error", result["mode"])
        self.assertEqual("pending", self.lists.get_list(list_id)["sync_state"])

    def test_full_sync_reports_incomplete_item_pull(self):
        self.linked()
        self.client.remote = [remote_list()]
        self.client.fetch_list_items = mock.Mock(side_effect=RuntimeError("offline"))
        result = self.sync.sync_now(push_items=False)
        self.assertFalse(result["ok"])
        self.assertEqual("partial_error", result["mode"])

    def test_remote_slug_ids_are_distinct_across_accounts(self):
        self.client.remote = [remote_list()]
        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        first = self.lists.all_lists()[0]["id"]
        self.client.selected = "B"
        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        second = self.lists.all_lists()[0]["id"]
        self.assertNotEqual(first, second)
        self.assertEqual(2, len(self.lists.load()["lists"]))

    def test_new_list_with_same_name_does_not_discard_old_deletion(self):
        old_id = self.linked()
        self.lists.delete_list(old_id)
        new_id = self.lists.create_list("Original")["id"]
        self.assertNotEqual(old_id, new_id)
        self.assertEqual(old_id, self.lists.load()["deleted_lists"][0]["id"])

    def test_offline_item_edit_remains_pending_after_readonly_overview(self):
        list_id = self.linked()
        self.add(list_id, 1)
        self.client.remote = [remote_list()]
        self.assertTrue(self.sync.sync_now(fetch_items=False, push_items=False)["ok"])
        self.assertEqual("pending", self.lists.get_list(list_id)["sync_state"])

    def test_failed_metadata_push_keeps_created_remote_link(self):
        list_id = self.lists.create_list("New")["id"]
        self.client.update_user_list = mock.Mock(side_effect=RuntimeError("offline"))
        self.assertFalse(self.sync.sync_now(fetch_items=False)["ok"])
        row = self.lists.get_list(list_id)
        self.assertEqual("created", row["trakt_slug"])
        self.assertTrue(row["metadata_pending"])


if __name__ == "__main__":
    unittest.main()

"""Offline regression tests; all files live in a temporary test profile."""
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from resources.lib import json_storage
import resources.lib as lib


def load_lists():
    xbmc = types.SimpleNamespace(LOGINFO=1, LOGWARNING=2, LOGERROR=3, log=lambda *a: None)
    gist = types.ModuleType("resources.lib.github_gist_sync")
    i18n = types.ModuleType("resources.lib.i18n")
    stubs = {"xbmc": xbmc, "xbmcaddon": types.SimpleNamespace(),
             "xbmcvfs": types.SimpleNamespace(exists=os.path.exists),
             "resources.lib.github_gist_sync": gist, "resources.lib.i18n": i18n}
    spec = importlib.util.spec_from_file_location("lists_under_test", ROOT / "resources/lib/tmdb_custom_lists.py")
    module = importlib.util.module_from_spec(spec)
    with mock.patch.dict(sys.modules, stubs), mock.patch.object(lib, "github_gist_sync", gist, create=True), mock.patch.object(lib, "i18n", i18n, create=True):
        spec.loader.exec_module(module)
    return module


class CustomListTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.lists = load_lists()
        self.path = os.path.join(self.temp.name, "lists.json")
        self.lists.custom_lists_path = lambda: self.path
        self.lists._device_identity = lambda: {"device_id": "test", "device_name": "Test"}
        self.lists._mark_local_mutation = mock.Mock()
        self.row = self.lists.create_list("Original")
        self.list_id = self.row["id"]
        self.lists._mark_local_mutation.reset_mock()

    def inject_before_save(self, action):
        original = self.lists.save
        def save(data, **kwargs):
            self.lists.save = original
            action()
            return original(data, **kwargs)
        self.lists.save = save

    def test_repeated_save_advances_revision_and_stale_copy_is_rejected(self):
        data = self.lists.load()
        stale = self.lists.load()
        self.lists.save(data)
        self.lists.save(data)
        self.assertEqual(3, self.lists.load()["revision"])
        with self.assertRaises(self.lists.ConcurrentListUpdate):
            self.lists.save(stale)

    def test_concurrent_add_and_rename_both_survive(self):
        self.inject_before_save(lambda: self.lists.rename_list(self.list_id, "Renamed"))
        self.assertEqual((True, "added"), self.lists.add_item(self.list_id, {"media_type": "movie", "tmdb_id": "10"}))
        row = self.lists.get_list(self.list_id)
        self.assertEqual("Renamed", row["name"])
        self.assertEqual("10", row["items"][0]["tmdb_id"])

    def test_concurrent_adds_both_survive(self):
        self.inject_before_save(lambda: self.lists.add_item(self.list_id, {"media_type": "tv", "tmdb_id": "10"}))
        self.lists.add_item(self.list_id, {"media_type": "movie", "tmdb_id": "10"})
        self.assertEqual({"tv", "movie"}, {i["media_type"] for i in self.lists.get_list(self.list_id)["items"]})

    def test_deleted_list_is_not_resurrected_by_retry(self):
        self.inject_before_save(lambda: self.lists.delete_list(self.list_id))
        self.assertEqual((False, "list_not_found"), self.lists.add_item(self.list_id, {"media_type": "movie", "tmdb_id": "10"}))
        self.assertIsNone(self.lists.get_list(self.list_id))
        self.assertEqual(self.list_id, self.lists.load()["deleted_lists"][0]["id"])

    def test_enrichment_preserves_new_items_and_does_not_restore_deleted_items(self):
        for number in (1, 2):
            self.lists.add_item(self.list_id, {"media_type": "movie", "tmdb_id": str(number)})
        old_items = self.lists.get_list(self.list_id)["items"]
        old_items[0]["title"] = "Enriched"
        old_items[0]["added_by_device_id"] = "wrong-owner"
        self.lists.delete_item(self.list_id, "movie", "2")
        self.inject_before_save(lambda: self.lists.add_item(self.list_id, {"media_type": "movie", "tmdb_id": "3"}))
        self.lists.replace_list_items_metadata(self.list_id, old_items)
        row = self.lists.get_list(self.list_id)
        self.assertEqual(["1", "3"], [item["tmdb_id"] for item in row["items"]])
        self.assertEqual("Enriched", row["items"][0]["title"])
        self.assertEqual("test", row["items"][0]["added_by_device_id"])
        self.assertEqual("2", row["deleted_items"][0]["tmdb_id"])

    def test_failed_write_does_not_report_success_or_mark_dirty(self):
        with mock.patch.object(json_storage, "write_json", side_effect=OSError("disk full")) as write:
            with self.assertRaises(OSError):
                self.lists.rename_list(self.list_id, "Lost")
        self.assertEqual(1, write.call_count)
        self.lists._mark_local_mutation.assert_not_called()
        self.assertEqual("Original", self.lists.get_list(self.list_id)["name"])

    def test_persistent_conflict_stops_after_bounded_retries(self):
        with mock.patch.object(self.lists, "save", side_effect=self.lists.ConcurrentListUpdate()) as save:
            with self.assertRaises(self.lists.ConcurrentListUpdate):
                self.lists.rename_list(self.list_id, "Busy")
        self.assertEqual(5, save.call_count)
        self.lists._mark_local_mutation.assert_not_called()


class LockTests(unittest.TestCase):
    def test_live_process_probe_does_not_signal_child(self):
        child = subprocess.Popen([sys.executable, "-c", "input()"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        try:
            with mock.patch.object(os, "kill", side_effect=AssertionError("Windows must not signal")) if os.name == "nt" else mock.patch.object(json_storage.time, "time", wraps=time.time):
                self.assertTrue(json_storage._process_is_alive(child.pid))
            self.assertIsNone(child.poll())
        finally:
            child.communicate(b"\n", timeout=10)
        self.assertFalse(json_storage._process_is_alive(child.pid))

    def test_old_active_lock_cannot_be_stolen(self):
        with tempfile.TemporaryDirectory() as temp:
            path = os.path.join(temp, "state.json")
            with json_storage.file_lock(path):
                os.utime(path + ".lock", (1, 1))
                with self.assertRaises(TimeoutError):
                    with json_storage.file_lock(path, timeout=0.1, stale_after=1):
                        self.fail("active lock was stolen")
            self.assertFalse(os.path.exists(path + ".lock"))


if __name__ == "__main__":
    unittest.main()

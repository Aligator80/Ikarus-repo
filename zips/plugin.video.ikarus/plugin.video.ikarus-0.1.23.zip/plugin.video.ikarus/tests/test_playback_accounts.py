"""Account isolation using the real client/queue/sync and a fake HTTP transport."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import types
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from resources.lib import json_storage, tmdb_playback_queue
import resources.lib as lib


def load_module(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / "resources/lib" / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Response:
    status_code = 200
    text = ""
    def __init__(self, data, headers=None):
        self.data = data
        self.headers = headers or {}

    def json(self):
        return copy.deepcopy(self.data)

    def raise_for_status(self):
        pass


class FailedResponse(Response):
    def __init__(self, status_code):
        super().__init__({})
        self.status_code = status_code

    def raise_for_status(self):
        raise RuntimeError("HTTP error")


class AccountIsolationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.settings = {"trakt_client_id": "test-client", "trakt_client_secret": "test-secret"}
        self.calls = []
        self.switch_on_remove = False
        self.switch_on_history_read = False
        self.settings_error = False
        self.settings_uuid = True
        self.username = "alice"
        addon = types.SimpleNamespace(
            getSetting=lambda key: self.settings.get(key, ""),
            setSetting=lambda key, value: self.settings.__setitem__(key, value),
            getAddonInfo=lambda key: self.temp.name if key == "profile" else "",
        )
        xbmc = types.SimpleNamespace(LOGINFO=1, LOGWARNING=2, log=lambda *a: None)
        self.i18n = types.SimpleNamespace(T=lambda *a: a[-1])
        self.state = types.SimpleNamespace(
            playback_state_path=lambda: os.path.join(self.temp.name, "local.json"),
            playback_state_load=lambda **k: {},
            make_source_key=lambda provider, **kw: provider + str(kw.get("source_id")),
            get_status_bucket=lambda row: "finished" if row.get("sources") else "",
        )
        stubs = {"xbmc": xbmc, "xbmcaddon": types.SimpleNamespace(Addon=lambda *a: addon),
                 "xbmcgui": types.SimpleNamespace(),
                 "xbmcvfs": types.SimpleNamespace(translatePath=lambda p: p),
                 "resources.lib.i18n": self.i18n}
        patcher = mock.patch.dict(sys.modules, stubs)
        patcher.start()
        self.addCleanup(patcher.stop)
        patcher = mock.patch.object(lib, "i18n", self.i18n, create=True)
        patcher.start()
        self.addCleanup(patcher.stop)
        self.client = load_module("account_test_client", "trakt_client.py")
        self.client.requests = types.SimpleNamespace(get=self.get, post=self.post, delete=self.delete, HTTPError=RuntimeError)
        with mock.patch.object(lib, "trakt_client", self.client, create=True), mock.patch.object(lib, "tmdb_playback_state", self.state, create=True):
            self.sync = load_module("account_test_sync", "tmdb_playback_sync.py")
        self.login("A")

    def login(self, account):
        self.settings.update(trakt_access_token="token-" + account, trakt_refresh_token="refresh-" + account,
                             trakt_created_at=str(int(time.time())), trakt_expires_in="86400",
                             trakt_account_binding="")

    def identify(self):
        with self.client.account_session() as owner:
            return owner

    def get(self, url, **kwargs):
        token = kwargs["headers"]["Authorization"]
        self.calls.append(("GET", url, token))
        account = token.removeprefix("Bearer token-")
        if url.endswith("/users/settings"):
            if self.settings_error:
                raise RuntimeError("offline")
            return Response({"user": {"username": self.username, "ids": {"uuid": account} if self.settings_uuid else {}}})
        if "/sync/history" in url:
            if self.switch_on_history_read:
                self.login("B")
            return Response([], {"X-Pagination-Page-Count": "0", "X-Pagination-Item-Count": "0"})
        if "/sync/watched/" in url:
            return Response([])
        if "/sync/playback" in url:
            return Response([])
        raise AssertionError(url)

    def post(self, url, **kwargs):
        token = kwargs["headers"]["Authorization"]
        self.calls.append(("POST", url, token))
        if url.endswith("/remove"):
            if self.switch_on_remove:
                self.login("B")
            return Response({"deleted": {"movies": 1}})
        if url.endswith("/sync/history"):
            return Response({"added": {"movies": 1, "episodes": 0}})
        if "/scrobble/" in url:
            return Response({"action": "pause", "progress": 50})
        raise AssertionError(url)

    def delete(self, url, **kwargs):
        self.calls.append(("DELETE", url, kwargs["headers"]["Authorization"]))
        return Response({})

    def test_account_switch_keeps_outbox_and_snapshot_separate(self):
        self.identify()
        operation = self.sync.queue_history_status("movie", "10")
        path_a = self.sync._outbox_path()
        self.sync._snapshot_save({"10": {"sources": {}, "title": "A"}})
        self.sync._sync_meta_save({"remote_history_cursor": "cursor-A"})
        self.login("B")
        self.identify()
        self.assertNotEqual(path_a, self.sync._outbox_path())
        self.assertEqual({}, self.sync._snapshot_load())
        self.assertEqual({}, self.sync._sync_meta_load())
        self.assertEqual(0, self.sync.flush_pending_operations()["sent"])
        self.assertTrue(tmdb_playback_queue.operation_pending(path_a, operation))
        self.assertFalse(any(method == "POST" for method, _, _ in self.calls))
        self.login("A")
        self.identify()
        self.assertEqual(path_a, self.sync._outbox_path())
        self.assertEqual("A", self.sync._snapshot_load()["10"]["title"])
        self.assertEqual(1, self.sync.flush_pending_operations()["sent"])
        self.assertFalse(tmdb_playback_queue.operation_pending(path_a, operation))

    def test_mid_request_switch_does_not_send_remaining_history_to_new_account(self):
        self.identify()
        operation = self.sync.queue_history_status("movie", "10")
        path_a = self.sync._outbox_path()
        self.switch_on_remove = True
        result = self.sync.flush_pending_operations()
        self.assertTrue(result["errors"])
        self.assertTrue(tmdb_playback_queue.operation_pending(path_a, operation))
        writes = [call for call in self.calls if call[0] == "POST"]
        self.assertEqual(1, len(writes))
        self.assertEqual("Bearer token-A", writes[0][2])
        self.assertTrue(writes[0][1].endswith("/remove"))
        self.assertEqual("token-B", self.settings["trakt_access_token"])

    def test_legacy_and_unassigned_operations_are_preserved_without_upload(self):
        legacy = os.path.join(self.temp.name, "tmdb_playback_trakt_outbox.json")
        old_id = tmdb_playback_queue.enqueue_history(legacy, "movie", "10")
        unassigned = self.sync.queue_history_status("movie", "20", account_id="")
        unassigned_path = self.sync._account_path("outbox.json", "")
        self.identify()
        self.assertEqual(0, self.sync.flush_pending_operations()["sent"])
        self.assertTrue(tmdb_playback_queue.operation_pending(legacy, old_id))
        self.assertTrue(tmdb_playback_queue.operation_pending(unassigned_path, unassigned))

    def test_offline_known_account_can_queue_and_use_its_snapshot(self):
        self.identify()
        self.sync._snapshot_save({"10": {"title": "offline", "sources": {}}})
        self.settings["trakt_created_at"] = "1"
        self.client.refresh_token_if_needed = lambda **k: False
        operation = self.sync.queue_history_status("movie", "10")
        self.assertEqual("offline", self.sync.trakt_state()["10"]["title"])
        self.assertTrue(self.sync.operation_pending(operation))
        self.assertEqual(0, self.sync.flush_pending_operations()["sent"])

    def test_unknown_identity_blocks_upload_on_error_or_missing_uuid(self):
        self.sync.queue_history_status("movie", "10")
        for offline in (True, False):
            self.settings_error = offline
            self.settings_uuid = False
            self.assertTrue(self.sync.flush_pending_operations()["errors"])
        self.assertFalse(any(method == "POST" for method, _, _ in self.calls))

    def test_bulk_push_only_includes_sources_owned_by_current_account(self):
        self.identify()
        local = {"10": {"media_type": "movie", "sources": {
            "old": {"status": "finished"},
            "b": {"status": "finished", "trakt_account_id": "B"},
        }}}
        self.assertEqual({}, self.sync._local_push_units(local))
        local["10"]["sources"]["a"] = {"status": "finished", "trakt_account_id": "A"}
        self.assertEqual(1, len(self.sync._local_push_units(local)))

    def test_username_change_and_token_refresh_keep_same_storage(self):
        self.identify()
        original_path = self.sync._outbox_path()
        self.username = "renamed"
        self.assertTrue(self.client._save_token({"access_token": "token-new", "refresh_token": "refresh-new"}, preserve_account=True, expected_refresh_token="refresh-A"))
        self.assertEqual("A", self.client.current_account_id())
        self.assertEqual(original_path, self.sync._outbox_path())
        self.assertNotIn("token-new", self.settings["trakt_account_binding"])

    def test_stale_refresh_cannot_overwrite_new_login(self):
        self.identify()
        self.login("B")
        self.assertFalse(self.client._save_token({"access_token": "token-old", "refresh_token": "old-refresh"}, preserve_account=True, expected_refresh_token="refresh-A"))
        self.assertEqual("token-B", self.settings["trakt_access_token"])

    def test_logout_hides_old_snapshot_and_invalidates_active_session(self):
        self.identify()
        self.sync._snapshot_save({"10": {"sources": {}}})
        with self.client.account_session():
            self.client._clear_auth()
            with self.assertRaises(self.client.AccountChangedError):
                self.client.access_token()
        self.assertEqual("", self.client.current_account_id())
        self.assertEqual({}, self.sync._snapshot_load())

    def test_memory_cache_is_not_reused_for_another_account(self):
        self.identify()
        self.sync._TRAKT_STATE_CACHE = {"10": {"title": "cached-A"}}
        self.sync._TRAKT_STATE_CACHE_TS = time.time()
        self.sync._TRAKT_STATE_CACHE_ACCOUNT = self.sync._snapshot_path()
        self.login("B")
        self.identify()
        self.assertEqual({}, self.sync._trakt_cached_row("10"))

    def test_account_change_during_snapshot_fetch_cannot_write_to_new_account(self):
        self.identify()
        self.sync._snapshot_save({"10": {"title": "saved-A", "sources": {}}})
        path_a = self.sync._snapshot_path()
        self.switch_on_history_read = True
        self.sync.trakt_state(force=True)
        self.assertEqual("saved-A", json_storage.read_json(path_a, {})["10"]["title"])
        self.switch_on_history_read = False
        self.identify()
        self.assertEqual({}, self.sync._snapshot_load())
        self.assertFalse(any(token == "Bearer token-B" and "/sync/" in url for _, url, token in self.calls))

    def test_full_sync_includes_titles_marked_watched_on_trakt(self):
        self.identify()
        self.client.fetch_history_complete = lambda **kwargs: {"rows": [], "item_count": 0}
        self.client.fetch_watched = lambda media_type: [{
            "last_watched_at": "2026-09-18T06:00:00.000Z",
            "movie": {"ids": {"tmdb": "42"}, "title": "Remote watched", "year": 2020},
        }] if media_type == "movies" else []
        self.client.fetch_playback = lambda: []
        state = self.sync.trakt_state(force=True)
        self.assertEqual("finished", state["42"]["sources"]["trakttrakt_finished"]["status"])

    def test_first_verified_account_claims_legacy_snapshot_once(self):
        self.identify()
        legacy = self.sync._legacy_snapshot_path()
        json_storage.write_json(legacy, {"42": {"title": "Legacy", "sources": {}}})
        self.assertTrue(self.sync._migrate_legacy_snapshot())
        self.assertEqual("Legacy", self.sync._snapshot_load()["42"]["title"])
        self.login("B")
        self.identify()
        self.assertFalse(self.sync._migrate_legacy_snapshot())
        self.assertEqual({}, self.sync._snapshot_load())

    def test_private_list_error_does_not_disconnect_trakt_account(self):
        self.identify()
        with self.assertRaises(RuntimeError):
            self.client._raise_for_status(FailedResponse(403), "fetch list items")
        self.assertTrue(self.client.is_connected())
        self.assertEqual("token-A", self.settings["trakt_access_token"])

    def test_parallel_history_pages_inherit_account_credentials(self):
        self.identify()
        seen = []
        def page(**kwargs):
            seen.append(self.client.access_token())
            start = (kwargs["page"] - 1) * 100
            return {"rows": [{"id": n} for n in range(start, start + 100)],
                    "page_count": 3, "item_count": 300}
        self.client._fetch_history_page = page
        with self.client.account_session():
            self.assertEqual(300, len(self.client.fetch_history_complete()["rows"]))
        self.assertEqual(["token-A"] * 3, seen)

    def test_parallel_history_stops_if_account_changes_after_first_page(self):
        self.identify()
        pages = []
        def page(**kwargs):
            pages.append(kwargs["page"])
            self.login("B")
            return {"rows": [{"id": n} for n in range(100)], "page_count": 3, "item_count": 300}
        self.client._fetch_history_page = page
        with self.client.account_session():
            with self.assertRaises(self.client.AccountChangedError):
                self.client.fetch_history_complete()
        self.assertEqual([1], pages)

    def test_playback_keeps_starting_account_when_finished_after_switch(self):
        self.identify()
        sys.modules["xbmc"].Player = object
        sys.modules["xbmcgui"].WindowXMLDialog = object
        sys.modules["xbmcvfs"].exists = os.path.exists
        with mock.patch.object(lib, "trakt_client", self.client, create=True), mock.patch.object(lib, "playback_utils", types.SimpleNamespace(), create=True), mock.patch.object(lib, "tmdb_playback_sync", self.sync, create=True):
            state = load_module("account_test_state", "tmdb_playback_state.py")
            state.threading = None  # Run the flusher synchronously in this test.
            source = state._source_with_account({"provider": "local"})
            self.login("B")
            self.identify()
            state.mark_finished("10", "source", meta={"media_type": "movie"}, source_meta=source,
                                sync_trakt=True, refresh_container=False)
        self.assertEqual("A", state.playback_state_load()["10"]["sources"]["source"]["trakt_account_id"])
        self.assertEqual({}, self.sync._local_push_units(state.playback_state_load()))
        self.assertEqual(1, tmdb_playback_queue.pending_count(self.sync._account_path("outbox.json", "A")))
        self.assertEqual(0, self.sync.pending_operation_count())
        self.assertFalse(any(method == "POST" for method, _, _ in self.calls))

    def test_status_index_dependencies_include_account_even_for_empty_files(self):
        self.identify()
        first = self.sync._status_index_dependencies()
        self.login("B")
        self.identify()
        self.assertNotEqual(first, self.sync._status_index_dependencies())
        self.assertFalse(self.sync._write_status_index({"10": {}}, first))


if __name__ == "__main__":
    unittest.main()

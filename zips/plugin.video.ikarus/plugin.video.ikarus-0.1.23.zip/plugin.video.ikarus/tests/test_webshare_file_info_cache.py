import importlib.util
from pathlib import Path
import sys
import types
import unittest
from unittest import mock

import resources.lib as lib


ROOT = Path(__file__).resolve().parents[1]


def _module(name, **attributes):
    result = types.ModuleType(name)
    result.__getattr__ = lambda missing: (lambda *args, **kwargs: "")
    for key, value in attributes.items():
        setattr(result, key, value)
    return result


def load_sources():
    addon = types.SimpleNamespace(getSetting=lambda key: "", setSetting=lambda key, value: None)
    xbmc = _module("xbmc", LOGWARNING=2, LOGERROR=3, LOGINFO=1, log=lambda *args: None)
    stubs = {
        "xbmc": xbmc,
        "xbmcgui": _module("xbmcgui"),
        "xbmcplugin": _module("xbmcplugin"),
        "xbmcaddon": _module("xbmcaddon", Addon=lambda: addon),
        "xbmcvfs": _module("xbmcvfs"),
        "resources.lib.auto_next_policy": _module("auto_next_policy"),
        "resources.lib.diagnostics": _module("diagnostics"),
        "resources.lib.i18n": _module("i18n"),
        "resources.lib.playback_utils": _module("playback_utils"),
        "resources.lib.source_common": _module("source_common", xml_streams=lambda *args: []),
        "resources.lib.source_labels": _module("source_labels"),
        "resources.lib.ui_theme": _module("ui_theme"),
        "resources.lib.source_sktonline": _module("source_sktonline", **{
            name: (lambda *args, **kwargs: "" if "find" in name else [])
            for name in ("sktonline_abs", "sktonline_extract_download_links", "sktonline_extract_sources_from_scripts", "sktonline_extract_video_sources",
                         "sktonline_find_embed_url_anywhere", "sktonline_guess_label_from_url", "sktonline_merge_sources")
        }),
        "resources.lib.source_hellspy": _module("source_hellspy", hellspy_build_search_url=lambda *args: "",
            hellspy_extract_items_and_next=lambda *args: ([], ""), hellspy_pick_direct_url=lambda *args: ""),
        "resources.lib.source_prehrajto": _module("source_prehrajto", prehrajto_build_search_url=lambda *args: "",
            prehrajto_canonicalize_url=lambda value: value, prehrajto_extract_first_source_from_html=lambda *args: "",
            prehrajto_extract_sources_from_html=lambda *args: [], prehrajto_guess_label_from_url=lambda value: value),
    }
    spec = importlib.util.spec_from_file_location("sources_cache_test", ROOT / "resources/lib/Hledani_zdroje.py")
    module = importlib.util.module_from_spec(spec)
    with mock.patch.object(sys, "argv", ["plugin.py", "1"]), mock.patch.dict(sys.modules, stubs), mock.patch.object(lib, "source_common", stubs["resources.lib.source_common"], create=True):
        spec.loader.exec_module(module)
    return module


class WebShareFileInfoCacheTests(unittest.TestCase):
    def setUp(self):
        self.sources = load_sources()
        self.now = 1000.0
        self.sources.time.time = lambda: self.now

    def test_cache_is_scoped_to_token_and_expires(self):
        self.sources._ws_file_info_cache_put("file", "account-a", {"width": "1920"})
        self.assertEqual({"width": "1920"}, self.sources._ws_file_info_cache_get("file", "account-a"))
        self.assertIsNone(self.sources._ws_file_info_cache_get("file", "account-b"))
        self.sources._ws_file_info_cache_put("file", "account-a", {"width": "1920"})
        self.now += self.sources._WS_FILE_INFO_CACHE_TTL + 1
        self.assertIsNone(self.sources._ws_file_info_cache_get("file", "account-a"))

    def test_negative_result_expires_quickly(self):
        self.sources._ws_file_info_cache_put("file", "account-a", {})
        self.assertEqual({}, self.sources._ws_file_info_cache_get("file", "account-a"))
        self.now += self.sources._WS_FILE_INFO_NEGATIVE_CACHE_TTL + 1
        self.assertIsNone(self.sources._ws_file_info_cache_get("file", "account-a"))

    def test_webshare_keeps_only_plausible_manual_matches_after_confirmed(self):
        rows = [
            {"id": "confirmed", "title": "The Matrix 1999 1080p"},
            {"id": "possible", "title": "Matrix 1080p"},
            {"id": "wrong-year", "title": "The Matrix 2003 1080p"},
            {"id": "episode", "title": "The Matrix S01E02 1080p"},
        ]

        result = self.sources._filter_webshare_candidates(
            rows=rows,
            title="Matrix",
            original_title="The Matrix",
            year="1999",
        )

        self.assertEqual(["confirmed", "possible"], [row["id"] for row in result])
        self.assertEqual(["confirmed", "possible"], [row["_match_confidence"] for row in result])

# -*- coding: utf-8 -*-
import sys
import time
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

import film

import nastaveni

from resources.lib import jine_zdroje         
from resources.lib import TMDB_knihovna
from resources.lib import trakt_client
from resources.lib import informacni_upozorneni
from resources.lib import version_info
from resources.lib import diagnostics
from resources.lib import i18n
from resources.lib import ui_theme
from resources.lib import ui_splash
from resources.lib import ui_settings
from resources.lib import cinema_controller
from resources.lib import cinema_home

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
BASE_PATH = sys.argv[0] if len(sys.argv) > 0 else ""
CINEMA_RETURN_ACTIVE_PROPERTY = "IkarusCinemaReturnActive"
CINEMA_RETURN_AT_PROPERTY = "IkarusCinemaReturnAt"
CINEMA_PLAYBACK_GUARD_PROPERTY = "IkarusCinemaPlaybackGuard"
CINEMA_PLAYBACK_GUARD_AT_PROPERTY = "IkarusCinemaPlaybackGuardAt"
CINEMA_RETURN_SUPPRESS_HOME_MS = 12000


def build_url(query: dict) -> str:
    return BASE_PATH + '?' + urllib.parse.urlencode(query)


def _sync_runtime(module):
    """Kodi reuseLanguageInvoker keeps imported modules alive between clicks."""
    try:
        module.addon_handle = addon_handle
        module.BASE_PATH = BASE_PATH
    except Exception:
        pass


def _refresh_runtime():
    global addon_handle, BASE_PATH
    try:
        addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else addon_handle
    except Exception:
        pass
    try:
        BASE_PATH = sys.argv[0] if len(sys.argv) > 0 else BASE_PATH
    except Exception:
        pass


def _end_directory(succeeded=True):
    try:
        if addon_handle > 0:
            xbmcplugin.endOfDirectory(
                addon_handle,
                succeeded=bool(succeeded),
                updateListing=False,
                cacheToDisc=False,
            )
    except Exception:
        pass


def _execute_builtin(command, wait=False):
    try:
        xbmc.executebuiltin(command, bool(wait))
    except TypeError:
        xbmc.executebuiltin(command)


def _close_busy_dialogs():
    for dialog_name in ("busydialog", "busydialognocancel"):
        _execute_builtin("Dialog.Close(%s)" % dialog_name)


def _consume_cinema_return_suppressed_home():
    try:
        window = xbmcgui.Window(10000)
        if window.getProperty(CINEMA_PLAYBACK_GUARD_PROPERTY) == "1":
            xbmc.log(
                "[IKARUS][CINEMA] suppressed automatic home refresh while Cinema playback is active",
                xbmc.LOGINFO,
            )
            _end_directory(True)
            return True
        if window.getProperty(CINEMA_RETURN_ACTIVE_PROPERTY) != "1":
            return False

        raw_started = window.getProperty(CINEMA_RETURN_AT_PROPERTY)
        try:
            started_ms = int(raw_started or "0")
        except Exception:
            started_ms = 0
        now_ms = int(time.time() * 1000)

        window.clearProperty(CINEMA_RETURN_ACTIVE_PROPERTY)
        window.clearProperty(CINEMA_RETURN_AT_PROPERTY)

        if started_ms and now_ms - started_ms > CINEMA_RETURN_SUPPRESS_HOME_MS:
            return False

        xbmc.log(
            "[IKARUS][CINEMA] suppressed automatic home refresh after playback return",
            xbmc.LOGINFO,
        )
        _end_directory(True)
        return True
    except Exception:
        return False


def _open_selected_query(query):
    action = (query or {}).get("action", "")
    url = build_url(query)
    command_actions = {
        "tmdb.custom.add",
        "tmdb.trakt.add",
        "tmdb.movie.mark.finished",
        "tmdb.movie.watch.clear",
        "tmdb.tv.mark.finished",
        "tmdb.tv.watch.clear",
    }
    playback_actions = {
        "tmdb.movie.source.play",
    }
    if action in playback_actions:
        _close_busy_dialogs()
        _execute_builtin('RunPlugin("%s")' % url)
        _close_busy_dialogs()
        return
    if action.endswith(".open") or action in command_actions:
        _execute_builtin("RunPlugin(%s)" % url)
    else:
        _execute_builtin(f'Container.Update("{url}",replace)')


def _open_settings(end_directory=True):
    if ui_theme.selected_theme_id() == "cinema":
        shown = ui_settings.show_settings()
        if not shown:
            _execute_builtin("Addon.OpenSettings(plugin.video.ikarus)", wait=True)
    else:
        _execute_builtin("Addon.OpenSettings(plugin.video.ikarus)", wait=True)
    if end_directory:
        _end_directory(True)


def _route_guard(label, action, callback):
    with diagnostics.action_scope(label, "delegate"):
        try:
            callback()
        except Exception as e:
            xbmc.log(f"[Ikarus][ERROR] {label} router failed: {repr(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                i18n.T(30900, "Ikarus"),
                i18n.T(30313, "Section could not be loaded. Details are in kodi.log."),
                xbmcgui.NOTIFICATION_ERROR,
                4000,
            )
            diagnostics.finish_failed_action(addon_handle, action)


#--------------------------------------------------------------------------
#                            Hlavní menu Pluginu Ikarus
#--------------------------------------------------------------------------
def _classic_main_menu():
    items = [
        (i18n.T(30300, "Movies"), {"action": "tmdb.movies"}, "DefaultMovies.png", True),
        (i18n.T(30301, "Series"), {"action": "tmdb.series"}, "DefaultTVShows.png", True),
        (i18n.T(30302, "People"), {"action": "tmdb.people"}, "DefaultActor.png", True),
        ("\u010cesk\u00e9 filmy a seri\u00e1ly", {"action": "tmdb.czech"}, "DefaultAddonVideo.png", True),
        (i18n.T(30304, "Watched"), {"action": "tmdb.finished"}, "DefaultInProgressShows.png", True),
        (i18n.T(30305, "In progress"), {"action": "tmdb.started"}, "DefaultInProgressShows.png", True),
        (i18n.T(30306, "My lists"), {"action": "tmdb.custom.lists"}, "DefaultVideoPlaylists.png", True),
        (i18n.T(30307, "Search"), {"action": "tmdb.search"}, "DefaultAddonsSearch.png", True),
        (i18n.T(30308, "Download queue"), {"action": "tmdb.downloads.queue"}, "DefaultAddonProgram.png", True),
        (i18n.T(30309, "Manual source search"), {"action": "other_sources"}, "DefaultFavourites.png", True),
        (i18n.T(30310, "Settings"), {"action": "settings"}, "DefaultProgram.png", False),
    ]

    try:
        if trakt_client.is_connected():
            insert_at = len(items)
            for idx, (_, query, _, _) in enumerate(items):
                if (query or {}).get("action") == "tmdb.search":
                    insert_at = idx
                    break
            items.insert(insert_at, (i18n.T(30311, "Smart lists"), {"action": "tmdb.trakt.smart.lists"}, "DefaultVideoPlaylists.png", True))
            insert_at += 1
            items.insert(insert_at, (i18n.T(30312, "Trakt.TV lists"), {"action": "tmdb.trakt.lists"}, "DefaultVideoPlaylists.png", True))
    except Exception:
        pass

    for label, query, icon_p, is_folder in items:
        url = build_url(query)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon_p, 'thumb': icon_p})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(addon_handle)


def _run_cinema_controller(initial_query=None):
    if ui_theme.selected_theme_id() != "cinema":
        _classic_main_menu()
        return
    controller = cinema_controller.CinemaController(cinema_home.cinema_home_items)
    try:
        outcome = controller.run(initial_query or {"action": "main_menu"})
    finally:
        ui_splash.close_splash(min_duration_ms=0)
    external_query = dict((outcome or {}).get("external_query") or {})

    if not external_query:
        _end_directory(True)
        return
    # The Cinema invocation must be closed before Kodi starts any classic
    # directory action. This prevents overlapping GetDirectory requests.
    _end_directory(True)
    _open_selected_query(external_query)


def _cinema_main_menu():
    _run_cinema_controller({"action": "main_menu"})


def _cinema_movies_menu():
    _run_cinema_controller({"action": "tmdb.movies"})


def _cinema_series_menu():
    _run_cinema_controller({"action": "tmdb.series"})


def main_menu():
    if ui_theme.selected_theme_id() == "classic":
        _classic_main_menu()
        return
    if _consume_cinema_return_suppressed_home():
        return
    _cinema_main_menu()


#--------------------------------------------------------------------------
#                            Router
#--------------------------------------------------------------------------
def _router_impl(paramstring):
    _refresh_runtime()
    # params z querystringu (nepřepisujeme později!)
    params = dict(urllib.parse.parse_qsl(paramstring)) if paramstring else {}
    action = params.get("action")

    base_path = BASE_PATH

    if not action:
        if not informacni_upozorneni.ensure_startup_notice():
            xbmcgui.Dialog().notification(
                i18n.T(30900, "Ikarus"),
                i18n.T(30314, "The plugin will not start without confirming the information notice."),
                xbmcgui.NOTIFICATION_WARNING,
                3500,
            )
            _end_directory(False)
            return
        if str(params.get("_skip_splash") or "").strip() != "1":
            _close_busy_dialogs()
            ui_splash.show_splash(
                keep_open=ui_theme.selected_theme_id() == "cinema"
            )
        main_menu()
        return

    if action == "enable_cinema":
        ui_theme.enable_cinema()
        main_menu()
        return

    if action == "disable_cinema":
        ui_theme.disable_cinema()
        _end_directory(True)
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.ikarus/,replace)")
        return

    if action == "show_info_notice":
        informacni_upozorneni.show_notice(require_confirm=False)
        _end_directory(True)
        return

    if action == "refresh_token":
        nastaveni.refresh_token_now()
        main_menu()
        return

    if action == "check_updates":
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmcgui.Dialog().notification(
            i18n.T(30900, "Ikarus"),
            i18n.T(30315, "Update check has started."),
            xbmcgui.NOTIFICATION_INFO,
            3500,
        )
        _end_directory(True)
        return

    if action == "version_info":
        version_info.main()
        _end_directory(True)
        return

    if action == "ikarus.diagnostics":
        diagnostics.run_self_test(addon_handle)
        return

    if action == "trakt.login":
        trakt_client.login_device_flow()
        _end_directory(True)
        return

    if action == "trakt.logout":
        trakt_client.logout()
        _end_directory(True)
        return

    if action == "trakt.check":
        trakt_client.check_connection(show_notification=True)
        _end_directory(True)
        return

    # --- film sekce ---
    if action.startswith("film."):
        user = addon.getSetting("username") or ""
        pwd  = addon.getSetting("password") or ""
        token = nastaveni.ziskej_token(user, pwd)
        _route_guard("film", action, lambda: film.handle_router(token, addon_handle, base_path, params))
        return

    # --- Jiné zdroje / Test menu ---
    if action == "other_sources" or action.startswith("other."):
        _sync_runtime(jine_zdroje)
        _route_guard("other_sources", action, jine_zdroje.router)
        return

    # --- TMDB menu ---
    if action.startswith("tmdb."):
        if (
            ui_theme.selected_theme_id() == "cinema"
            and cinema_controller.owns_action(action)
        ):
            _run_cinema_controller(params)
            return
        _sync_runtime(TMDB_knihovna)
        _route_guard("tmdb", action, TMDB_knihovna.router)
        return

    if action == "settings":
        _open_settings()
        return

    # fallback – když neznáme akci, aspoň zobrazíme hlavní menu
    main_menu()


def router(paramstring):
    _refresh_runtime()
    params = dict(urllib.parse.parse_qsl(paramstring)) if paramstring else {}
    action = params.get("action") or "main_menu"
    with diagnostics.action_scope("main", action, params):
        return _router_impl(paramstring)


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")

# -*- coding: utf-8 -*-
"""Chronological Cinema filmography for a person."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import ui_person_detail
from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}
LIST_CONTROL = 401


def _full_date(credit):
    value = str(credit.get("release_date") or credit.get("first_air_date") or "").strip()
    return ui_person_detail._date_text(value) if value else "Bez data"


def _rating(credit):
    value = ui_person_detail._rating_value(credit)
    return "TMDB %.1f" % value if value else "Bez hodnocení"


class IkarusPersonCreditsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.item = dict(kwargs.pop("item", {}) or {})
        self.fallback_title = str(kwargs.pop("fallback_title", "Osobnost") or "Osobnost")
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.rows = []
        self.queries = []
        self.selected_query = None
        self._selection_committed = False

    def onInit(self):
        self._set_static_art()
        self._fill()
        self._restore_focus()

    def _set_static_art(self):
        background = ui_theme.fallback_fanart()
        profile = ui_person_detail._image_url(self.item.get("profile_path"), "poster") or "DefaultActor.png"
        try:
            if background:
                self.getControl(10).setImage(background)
            self.getControl(300).setImage(profile)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Osobnost", "Všechny herecké tituly")
        try:
            self.getControl(30).setLabel(str(self.item.get("name") or self.fallback_title))
        except Exception:
            pass

    def _list_item(self, credit):
        media_type = str(credit.get("media_type") or "movie").strip().lower()
        title = str(credit.get("title") or credit.get("name") or "Titul").strip()
        role = str(credit.get("character") or credit.get("job") or "").strip()
        image = ui_person_detail._image_url(credit.get("poster_path"), "poster") or (
            "DefaultTVShows.png" if media_type == "tv" else "DefaultMovies.png"
        )
        item = xbmcgui.ListItem(label=title)
        try:
            item.setLabel2(role)
            item.setProperty("Date", _full_date(credit))
            item.setProperty("Rating", _rating(credit))
            item.setProperty("MediaTypeLabel", "Seriál" if media_type == "tv" else "Film")
            item.setArt({"thumb": image, "icon": image, "poster": image})
        except Exception:
            pass
        return item

    def _fill(self):
        self.rows = ui_person_detail.all_credit_rows(self.item)
        self.queries = []
        control = self.getControl(LIST_CONTROL)
        control.reset()
        for credit in self.rows:
            control.addItem(self._list_item(credit))
            self.queries.append(ui_person_detail._credit_query(credit))
        if not self.rows:
            item = xbmcgui.ListItem(label="Filmografie zatím není k dispozici")
            try:
                item.setLabel2("Pro tuto osobnost nebyly nalezeny žádné tituly.")
                item.setArt({"thumb": "DefaultVideo.png", "icon": "DefaultVideo.png"})
            except Exception:
                pass
            control.addItem(item)
            self.queries.append({})
        try:
            self.getControl(31).setLabel("Celkem titulů: %d" % len(self.rows))
        except Exception:
            pass

    def _restore_focus(self):
        try:
            position = max(0, int(self.restore_state.get("selected_index") or 0))
            position = min(position, max(0, len(self.queries) - 1))
            self.getControl(LIST_CONTROL).selectItem(position)
            self.setFocusId(LIST_CONTROL)
        except Exception:
            pass

    def _selected_query(self):
        if not self.queries:
            return {}
        try:
            position = int(self.getControl(LIST_CONTROL).getSelectedPosition())
        except Exception:
            position = 0
        position = max(0, min(position, len(self.queries) - 1))
        return dict(self.queries[position] or {})

    def _parent_state(self):
        try:
            position = max(0, int(self.getControl(LIST_CONTROL).getSelectedPosition()))
        except Exception:
            position = 0
        return {"focus_id": LIST_CONTROL, "selected_index": position}

    def _finish(self, query):
        if self._selection_committed:
            return
        self._selection_committed = True
        self.selected_query = dict(query or {})
        self.close()

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self._finish({"action": "__back__"})
            return
        if control_id == LIST_CONTROL:
            query = self._selected_query()
            if query:
                query["_cinema_parent"] = self._parent_state()
                self._finish(query)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self._finish({"action": "__back__"})
            return
        if action_id in OPEN_ACTIONS:
            try:
                if int(self.getFocusId()) == LIST_CONTROL:
                    self.onClick(LIST_CONTROL)
                    return
            except Exception:
                pass
        super().onAction(action)


def show_person_credits(item, fallback_title="Osobnost", restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusPersonCreditsDialog(
            "DialogIkarusPersonCredits.xml",
            addon_path,
            "Default",
            "720p",
            item=dict(item or {}),
            fallback_title=fallback_title or "Osobnost",
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][person_credits] Fullscreen filmography failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

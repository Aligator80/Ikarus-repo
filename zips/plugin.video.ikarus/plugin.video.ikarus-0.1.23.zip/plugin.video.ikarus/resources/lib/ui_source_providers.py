# -*- coding: utf-8 -*-
"""Cinema source provider picker."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import ui_theme
from resources.lib import Hledani_zdroje


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}
PROVIDERS_CONTROL = 401


def _title(query):
    return str((query or {}).get("title") or (query or {}).get("media_title") or "Titul").strip()


class IkarusSourceProvidersDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.query = dict(kwargs.pop("query", {}) or {})
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self.providers = []

    def onInit(self):
        self._set_static_art()
        self._load()
        self._fill()
        self._restore_focus()

    def _set_static_art(self):
        try:
            bg = str(self.query.get("fanart") or self.query.get("poster") or "").strip() or ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Zdroje", _title(self.query))
        try:
            self.getControl(30).setLabel(_title(self.query))
        except Exception:
            pass

    def _load(self):
        try:
            self.providers = Hledani_zdroje.cinema_source_provider_options(include_all=True)
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][source_providers] load failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass
            self.providers = []

    def _provider_item(self, row):
        item = xbmcgui.ListItem(label=row.get("label") or "")
        art = ui_theme.provider_art(row.get("provider") or "", "DefaultAddonProgram.png")
        if (row.get("provider") or "") == "all":
            art = ui_theme.provider_art("all", "DefaultAddonProgram.png")
        try:
            item.setArt(art)
            item.setProperty("provider", row.get("provider") or "")
            item.setProperty("homepage", row.get("homepage") or "")
        except Exception:
            pass
        return item

    def _fill(self):
        control = self.getControl(PROVIDERS_CONTROL)
        control.reset()
        if not self.providers:
            item = xbmcgui.ListItem(label="Zadny provider neni povoleny")
            try:
                item.setProperty("IkarusEmpty", "1")
                item.setArt({"icon": "DefaultAddonProgram.png", "thumb": "DefaultAddonProgram.png"})
            except Exception:
                pass
            control.addItem(item)
            return
        for row in self.providers:
            control.addItem(self._provider_item(row))

    def _restore_focus(self):
        try:
            pos = int(self.restore_state.get("selected_index") or 0)
        except Exception:
            pos = 0
        pos = max(0, min(pos, max(0, len(self.providers) - 1)))
        try:
            control = self.getControl(PROVIDERS_CONTROL)
            control.selectItem(pos)
        except Exception:
            pass
        try:
            xbmc.sleep(50)
            self.setFocusId(PROVIDERS_CONTROL)
        except Exception:
            pass

    def _parent_state(self):
        try:
            pos = int(self.getControl(PROVIDERS_CONTROL).getSelectedPosition())
        except Exception:
            pos = 0
        return {
            "query": dict(self.query or {}),
            "selected_index": max(0, pos),
        }

    def _selected_provider(self):
        if not self.providers:
            return {}
        try:
            pos = int(self.getControl(PROVIDERS_CONTROL).getSelectedPosition())
        except Exception:
            pos = 0
        pos = max(0, min(pos, len(self.providers) - 1))
        return dict(self.providers[pos] or {})

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if control_id != PROVIDERS_CONTROL:
            return
        provider = self._selected_provider()
        if not provider:
            return
        query = dict(self.query or {})
        query.update({
            "action": "tmdb.sources.results",
            "provider": provider.get("provider") or "all",
            "provider_label": provider.get("label") or "",
        })
        query["_cinema_parent"] = self._parent_state()
        self.selected_query = query
        self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if action_id in OPEN_ACTIONS:
            try:
                if int(self.getFocusId()) == PROVIDERS_CONTROL:
                    self.onClick(PROVIDERS_CONTROL)
                    return
            except Exception:
                pass
        super().onAction(action)


def show_source_providers(query=None, restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusSourceProvidersDialog(
            "DialogIkarusSourceProviders.xml",
            addon_path,
            "Default",
            "720p",
            query=dict(query or {}),
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][source_providers] dialog failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

# -*- coding: utf-8 -*-
"""Fullscreen series detail for the Ikarus Cinema theme."""

import os

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
ACTION_BUTTONS = {122, 124, 125, 126, 131, 132, 133}
LIST_CONTROLS = {501, 601}
PICKER_LIST_CONTROLS = {701, 711}
DETAIL_CONTROLS = {121, 122, 124, 125, 126, 500, 501, 600, 601, 130, 131, 132, 133}
PICKER_CONTROLS = {700, 701, 710, 711}

ACCENTS = {
    "default": {
        "color": "FF19D9F0",
        "poster": "ikarus_poster_frame_cyan.png",
    },
    "finished": {
        "color": "FF23D86B",
        "poster": "ikarus_poster_frame_green.png",
    },
    "started": {
        "color": "FFFF9F2E",
        "poster": "ikarus_poster_frame_orange.png",
    },
}


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _image_url(path, size="poster"):
    path = (path or "").strip()
    if not path:
        return ""
    if path.lower().startswith(("http://", "https://", "special://")):
        return path
    tmdb = _tmdb()
    if size == "original":
        return tmdb.TMDB_IMAGE_ORIGINAL_BASE + path
    if size == "backdrop":
        return tmdb.TMDB_IMAGE_THUMB_BASE + path
    return tmdb.TMDB_IMAGE_BASE + path


def _title(item, fallback="Serial"):
    try:
        return _tmdb()._tmdb_display_title(item, "tv", fallback or "Serial")
    except Exception:
        return (item or {}).get("name") or (item or {}).get("original_name") or fallback or "Serial"


def _year(item):
    first_air = ((item or {}).get("first_air_date") or "").strip()
    if len(first_air) >= 4 and first_air[:4].isdigit():
        return first_air[:4]
    return ""


def _join_names(rows, key="name", limit=4):
    names = []
    for row in rows or []:
        if isinstance(row, str):
            value = row.strip()
        else:
            value = (row.get(key) or "").strip()
        if value:
            names.append(value)
        if len(names) >= limit:
            break
    return ", ".join(names)


def _runtime_text(minutes):
    try:
        minutes = int(minutes or 0)
    except Exception:
        minutes = 0
    if minutes <= 0:
        return ""
    hours = minutes // 60
    rest = minutes % 60
    if hours and rest:
        return "%d h %d min" % (hours, rest)
    if hours:
        return "%d h" % hours
    return "%d min" % rest


def _episode_runtime_text(item):
    times = (item or {}).get("episode_run_time") or []
    if times:
        return _runtime_text(times[0])
    return ""


def _rating_percent(item):
    rating = (item or {}).get("vote_average") or 0
    try:
        rating = float(rating)
    except Exception:
        rating = 0
    return max(0, min(100, int(round(rating * 10)))) if rating else 0


def _plot_summary(text, limit=260):
    text = " ".join(str(text or "").strip().split())
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0].strip()
    return cut + "..."


def _count_text(value, singular, plural):
    try:
        count = int(value or 0)
    except Exception:
        count = 0
    if count <= 0:
        return ""
    return "%d %s" % (count, singular if count == 1 else plural)


def _skin_media(filename):
    filename = str(filename or "").strip()
    if not filename:
        return ""
    try:
        base = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    except Exception:
        base = ""
    path = os.path.join(base, "resources", "skins", "Default", "media", filename) if base else ""
    return path if path and os.path.exists(path) else filename


def _item_status(item, watch_source=""):
    tmdb_id = str((item or {}).get("id") or "").strip()
    if not tmdb_id:
        return ""
    try:
        tmdb = _tmdb()
        return (tmdb.tmdb_playback_state.get_item_status(tmdb_id) or "").strip().lower()
    except Exception:
        return ""


def _accent_for_status(status):
    status = str(status or "").strip().lower()
    if status == "finished":
        return ACCENTS["finished"]
    if status == "started":
        return ACCENTS["started"]
    return ACCENTS["default"]


def _series_query(item, action, title="", watch_source="", extra=None):
    title = title or _title(item)
    query = {
        "action": action,
        "id": str((item or {}).get("id") or ""),
        "title": title,
        "original_title": ((item or {}).get("original_name") or "").strip(),
    }
    if watch_source:
        query["watch_source"] = watch_source
    if extra:
        query.update(extra)
    return query


def _playback_meta_from_item(item, fallback_title="Serial"):
    item = item or {}
    poster = _image_url(item.get("poster_path"), "poster")
    meta = {
        "title": _title(item, fallback_title),
        "original_title": (item.get("original_name") or "").strip(),
        "year": _year(item),
        "plot": (item.get("overview") or "").strip(),
        "rating": item.get("vote_average"),
        "media_type": "tv",
    }
    if poster:
        meta["poster"] = poster
    return {key: value for key, value in meta.items() if value not in (None, "")}


def _set_image(control, image):
    try:
        if image:
            control.setImage(image)
    except Exception:
        pass


def _set_label(control, label):
    try:
        control.setLabel(label or "")
    except Exception:
        pass


def _set_text(control, text):
    try:
        control.setText(text or "")
    except Exception:
        pass


class IkarusSeriesDetailDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.item = kwargs.pop("item", {}) or {}
        self.fallback_title = kwargs.pop("fallback_title", "Serial") or "Serial"
        self.watch_source = kwargs.pop("watch_source", "") or ""
        self.return_action = kwargs.pop("return_action", "") or ""
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self._list_queries = {}
        self._season_numbers = []
        self._season_detail_cache = {}
        self._last_season_pos = -1
        self._episode_picker_mode = False
        self._status = _item_status(self.item, self.watch_source)
        self._accent = _accent_for_status(self._status)

    def onInit(self):
        self._set_static_art()
        self._set_header()
        self._set_buttons()
        self._fill_cast()
        self._fill_similar()
        self._fill_media()
        self._set_episode_picker_visible(False)
        try:
            focus_id = int(self.restore_state.get("focus_id") or 121)
            selected_index = int(self.restore_state.get("selected_index") or 0)
            if focus_id in LIST_CONTROLS:
                self.getControl(focus_id).selectItem(max(selected_index, 0))
            self.setFocusId(focus_id)
        except Exception:
            pass

    def close(self):
        try:
            self.clearProperty("IkarusSeriesEpisodePicker")
        except Exception:
            pass
        super().close()

    def _selection_context(self):
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = 121
        context = {"focus_id": focus_id}
        if focus_id in LIST_CONTROLS:
            try:
                context["selected_index"] = max(
                    int(self.getControl(focus_id).getSelectedPosition()),
                    0,
                )
            except Exception:
                context["selected_index"] = 0
        return context

    def _select_result(self, query):
        result = dict(query or {})
        result["_cinema_parent"] = self._selection_context()
        self.selected_query = result
        self.close()

    def _set_static_art(self):
        fallback_bg = ui_theme.fallback_fanart()
        series_bg = _image_url(self.item.get("backdrop_path"), "original") or fallback_bg
        poster = _image_url(self.item.get("poster_path"), "poster") or "DefaultTVShows.png"
        _set_image(self.getControl(10), fallback_bg)
        _set_image(self.getControl(11), series_bg)
        ui_theme.set_cinema_header(self)
        _set_image(self.getControl(300), poster)
        _set_image(self.getControl(301), _skin_media(self._accent.get("poster")))

    def _refresh_status_style(self, status):
        self._status = str(status or "").strip().lower()
        self._accent = _accent_for_status(self._status)
        try:
            self.getControl(310).setTextColor(self._accent.get("color") or "FF19D9F0")
        except Exception:
            pass
        _set_image(self.getControl(301), _skin_media(self._accent.get("poster")))

    def _set_header(self):
        title = _title(self.item, self.fallback_title)
        genres = _join_names(self.item.get("genres") or [], limit=2)
        countries = _join_names(self.item.get("origin_country") or [], key=None, limit=3)
        runtime = _episode_runtime_text(self.item)
        seasons = _count_text(self.item.get("number_of_seasons"), "serie", "serie")
        episodes = _count_text(self.item.get("number_of_episodes"), "epizoda", "epizod")
        percent = _rating_percent(self.item)
        meta = []
        for value in (_year(self.item), countries, genres, seasons, episodes, runtime):
            if value:
                meta.append(value)

        title_control = self.getControl(310)
        _set_label(title_control, title)
        try:
            title_control.setTextColor(self._accent.get("color") or "FF19D9F0")
        except Exception:
            pass
        _set_label(self.getControl(311), "   |   ".join(meta))
        _set_text(self.getControl(312), _plot_summary(self.item.get("overview") or ""))
        _set_image(self.getControl(320), _skin_media("ikarus_rating_%03d.png" % percent))
        _set_label(self.getControl(321), "%d%%" % percent if percent else "--")

    def _set_buttons(self):
        title = _title(self.item, self.fallback_title)
        self._button_queries = {
            121: _series_query(self.item, "tmdb.tv.seasons.open", title, self.watch_source),
            122: _series_query(self.item, "tmdb.tv.videos", title, self.watch_source),
            124: {
                "action": "tmdb.custom.add",
                "media_type": "tv",
                "id": str(self.item.get("id") or ""),
                "title": title,
            },
            125: _series_query(self.item, "tmdb.tv.mark.finished", title, self.watch_source),
            126: _series_query(self.item, "tmdb.tv.watch.clear", title, self.watch_source),
            131: _series_query(self.item, "tmdb.tv.media.popular", title, self.watch_source),
            132: _series_query(self.item, "tmdb.tv.media.backdrops", title, self.watch_source),
            133: _series_query(self.item, "tmdb.tv.media.posters", title, self.watch_source),
        }

    def _notify(self, message, level=xbmcgui.NOTIFICATION_INFO):
        try:
            xbmcgui.Dialog().notification("Ikarus", message, level, 2200, sound=False)
        except Exception:
            pass

    def _mark_finished_in_place(self):
        tmdb_id = str((self.item or {}).get("id") or "").strip()
        if not tmdb_id:
            return
        try:
            tmdb = _tmdb()
            meta = _playback_meta_from_item(self.item, self.fallback_title)
            seasons = self.item.get("seasons") or []
            watched_at = tmdb._tmdb_watch_now_iso()
            bulk_items = []
            trakt_episodes = []
            for season in seasons:
                season_number = season.get("season_number")
                if season_number is None:
                    continue
                data = tmdb._tmdb_tv_season_detail(tmdb_id, str(season_number))
                for ep in (data.get("episodes") or []):
                    ep_num = ep.get("episode_number")
                    if ep_num is None:
                        continue
                    bulk_items.append({
                        "season": season_number,
                        "episode": ep_num,
                        "episode_title": (ep.get("name") or "").strip(),
                        "season_name": (season.get("name") or "").strip(),
                    })
                    trakt_episodes.append({
                        "tmdb_id": tmdb_id,
                        "season": season_number,
                        "episode": ep_num,
                        "watched_at": watched_at,
                    })
            marked = tmdb.tmdb_playback_state.mark_episodes_finished_bulk(
                tmdb_id,
                bulk_items,
                meta=meta,
                watched_at=watched_at,
            )
            try:
                tmdb._tmdb_push_trakt_finished_history(episodes=trakt_episodes)
            except Exception:
                pass
            self._refresh_status_style("finished")
            self._notify("Serial oznacen jako zhlednuty (%d ep.)" % marked)
        except Exception as exc:
            self._notify("Oznaceni selhalo: %s" % exc, xbmcgui.NOTIFICATION_ERROR)

    def _clear_watch_in_place(self):
        tmdb_id = str((self.item or {}).get("id") or "").strip()
        if not tmdb_id:
            return
        try:
            tmdb = _tmdb()
            tmdb.tmdb_playback_state.remove_item(tmdb_id)
            try:
                tmdb._tmdb_clear_trakt_watch_state("show", tmdb_id)
            except Exception:
                pass
            self._refresh_status_style("")
            self._notify("Oznaceni zruseno")
        except Exception as exc:
            self._notify("Zruseni selhalo: %s" % exc, xbmcgui.NOTIFICATION_ERROR)

    def _list_item(self, label, label2="", art=None, query=None):
        li = xbmcgui.ListItem(label=label or "")
        try:
            if label2:
                li.setLabel2(label2)
        except Exception:
            pass
        try:
            li.setArt(art or {})
        except Exception:
            pass
        return li

    def _fill_control(self, control_id, rows):
        try:
            control = self.getControl(control_id)
            control.reset()
            self._list_queries[control_id] = []
            for li, query in rows:
                control.addItem(li)
                self._list_queries[control_id].append(query or {})
            if rows:
                control.selectItem(0)
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][series_detail] Fill control %s failed: %s" % (control_id, exc), xbmc.LOGWARNING)
            except Exception:
                pass

    def _season_title(self, season):
        number = season.get("season_number")
        name = (season.get("name") or "").strip()
        if name and name.lower() not in {"season %s" % number, "s\u00e9rie %s" % number, "serie %s" % number}:
            return name
        if number is None:
            return "S\u00e9rie"
        return "S\u00e9rie %s" % number

    def _valid_seasons(self):
        seasons = []
        for season in self.item.get("seasons") or []:
            if not isinstance(season, dict):
                continue
            if season.get("season_number") is None:
                continue
            seasons.append(season)
        regular = []
        for season in seasons:
            try:
                if int(season.get("season_number") or 0) > 0:
                    regular.append(season)
            except Exception:
                pass
        return regular or seasons

    def _fill_seasons(self):
        rows = []
        self._season_numbers = []
        poster = _image_url(self.item.get("poster_path"), "poster") or "DefaultTVShows.png"
        backdrop = _image_url(self.item.get("backdrop_path"), "backdrop") or poster
        for season in self._valid_seasons():
            number = season.get("season_number")
            count = season.get("episode_count")
            label = self._season_title(season)
            label2 = _count_text(count, "epizoda", "epizod") or ""
            image = _image_url(season.get("poster_path"), "poster") or backdrop or poster
            query = {"season_number": str(number), "season_name": label}
            rows.append((self._list_item(label, label2, {"thumb": image, "icon": image, "poster": image}, query), query))
            self._season_numbers.append(number)
        if not rows:
            rows.append((self._list_item("\u017d\u00e1dn\u00e9 s\u00e9rie", "", {"thumb": poster, "icon": poster}, {}), {}))
        self._fill_control(701, rows)

    def _load_season_detail(self, season_number):
        key = str(season_number)
        if key in self._season_detail_cache:
            return self._season_detail_cache.get(key) or {}
        tmdb_id = str((self.item or {}).get("id") or "").strip()
        detail = {}
        if tmdb_id and key:
            try:
                detail = _tmdb()._tmdb_tv_season_detail(tmdb_id, key) or {}
            except Exception as exc:
                try:
                    xbmc.log("[Ikarus][series_detail] Season detail %s failed: %s" % (key, exc), xbmc.LOGWARNING)
                except Exception:
                    pass
        self._season_detail_cache[key] = detail
        return detail

    def _episode_query(self, season_number, season_name, episode):
        title = _title(self.item, self.fallback_title)
        ep_num = episode.get("episode_number") or 0
        ep_name = (episode.get("name") or "").strip() or "Epizoda %s" % ep_num
        try:
            query_text = "%s S%02dE%02d" % (title, int(season_number), int(ep_num))
        except Exception:
            query_text = "%s S%sE%s" % (title, season_number, ep_num)
        return _series_query(self.item, "tmdb.sources.providers", title, self.watch_source, {
            "year": _year(self.item),
            "season": str(season_number),
            "season_number": str(season_number),
            "episode": str(ep_num),
            "episode_title": ep_name,
            "season_name": season_name,
            "query": query_text,
            "mode": "serial_episode",
            "media_type": "tv",
            "poster": _image_url(self.item.get("poster_path"), "poster"),
            "fanart": _image_url(self.item.get("backdrop_path"), "original"),
        })

    def _fill_episodes_for_selected_season(self, season_number, season_name=""):
        detail = self._load_season_detail(season_number)
        episodes = detail.get("episodes") or []
        fallback = _image_url(detail.get("poster_path"), "poster") or _image_url(self.item.get("backdrop_path"), "backdrop") or "DefaultVideo.png"
        rows = []
        for episode in episodes:
            ep_num = episode.get("episode_number") or 0
            ep_name = (episode.get("name") or "").strip() or "Epizoda %s" % ep_num
            try:
                label = "S%02dE%02d" % (int(season_number or 0), int(ep_num or 0))
            except Exception:
                label = "S%sE%s" % (season_number, ep_num)
            image = _image_url(episode.get("still_path"), "backdrop") or fallback
            query = self._episode_query(season_number, season_name, episode)
            rows.append((self._list_item(label, ep_name, {"thumb": image, "icon": image, "poster": image, "landscape": image}, query), query))
        if not rows:
            rows.append((self._list_item("Bez epizod", "", {"thumb": fallback, "icon": fallback}, {}), {}))
        self._fill_control(711, rows)

    def _sync_season_selection(self, force=False):
        try:
            pos = int(self.getControl(701).getSelectedPosition())
        except Exception:
            pos = 0
        if pos < 0:
            pos = 0
        if not force and pos == self._last_season_pos:
            return
        self._last_season_pos = pos
        query = self._selected_list_query(701)
        season_number = query.get("season_number")
        season_name = query.get("season_name") or ""
        if season_number is not None:
            self._fill_episodes_for_selected_season(season_number, season_name)

    def _set_visible(self, control_id, visible):
        try:
            self.getControl(control_id).setVisible(bool(visible))
        except Exception:
            pass

    def _set_episode_picker_visible(self, visible):
        self._episode_picker_mode = bool(visible)
        if visible:
            try:
                self.setProperty("IkarusSeriesEpisodePicker", "true")
            except Exception:
                pass
            for control_id in PICKER_CONTROLS:
                self._set_visible(control_id, True)
            try:
                self.setFocusId(701)
            except Exception:
                pass
            for control_id in DETAIL_CONTROLS:
                self._set_visible(control_id, False)
            return

        for control_id in DETAIL_CONTROLS:
            self._set_visible(control_id, True)
        try:
            self.setFocusId(121)
        except Exception:
            pass
        for control_id in PICKER_CONTROLS:
            self._set_visible(control_id, False)
        try:
            self.clearProperty("IkarusSeriesEpisodePicker")
        except Exception:
            pass

    def _enter_episode_picker(self):
        self._fill_seasons()
        self._sync_season_selection(force=True)
        self._set_episode_picker_visible(True)

    def _leave_episode_picker(self):
        self._set_episode_picker_visible(False)

    def _fill_cast(self):
        rows = []
        cast = ((self.item.get("credits") or {}).get("cast") or [])[:8]
        for person in cast:
            person_id = person.get("id")
            name = (person.get("name") or "").strip()
            character = (person.get("character") or "").strip()
            if not name:
                continue
            image = _image_url(person.get("profile_path"), "poster") or "DefaultActor.png"
            query = {"action": "tmdb.person.detail", "id": str(person_id), "title": name} if person_id else {}
            rows.append((self._list_item(name, character, {"thumb": image, "icon": image, "poster": image}, query), query))
        self._fill_control(501, rows)

    def _fill_similar(self):
        rows = []
        similar = ((self.item.get("similar") or {}).get("results") or [])[:8]
        for series in similar:
            series_id = series.get("id")
            title = _title(series, series.get("name") or "Serial")
            image = _image_url(series.get("backdrop_path"), "backdrop") or _image_url(series.get("poster_path"), "poster") or "DefaultTVShows.png"
            query = _series_query(series, "tmdb.tv.detail.open", title, self.watch_source, {"return_action": self.return_action or "tmdb.series"}) if series_id else {}
            rows.append((self._list_item(title, _year(series), {"thumb": image, "icon": image, "landscape": image}, query), query))
        self._fill_control(601, rows)

    def _fill_media(self):
        self._set_buttons()

    def _selected_list_query(self, control_id):
        rows = self._list_queries.get(control_id) or []
        if not rows:
            return {}
        try:
            pos = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            pos = 0
        if pos < 0 or pos >= len(rows):
            pos = 0
        return dict(rows[pos] or {})

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__", "return_action": self.return_action}
            self.close()
            return
        if control_id == 121:
            self._enter_episode_picker()
            return
        if control_id == 125:
            self._mark_finished_in_place()
            return
        if control_id == 126:
            self._clear_watch_in_place()
            return
        if control_id in ACTION_BUTTONS:
            self._select_result((self._button_queries or {}).get(control_id) or {})
            return
        if control_id in LIST_CONTROLS:
            query = self._selected_list_query(control_id)
            if query:
                self._select_result(query)
            return
        if control_id == 701:
            self._sync_season_selection(force=True)
            try:
                self.setFocusId(711)
            except Exception:
                pass
            return
        if control_id == 711:
            query = self._selected_list_query(control_id)
            if query:
                self._select_result(query)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            if self._episode_picker_mode:
                self._leave_episode_picker()
                return
            self.selected_query = {"action": "__back__", "return_action": self.return_action}
            self.close()
            return
        super().onAction(action)
        if self._episode_picker_mode:
            self._sync_season_selection()


def show_series_detail(item, fallback_title="Serial", watch_source="", return_action="", restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusSeriesDetailDialog(
            "DialogIkarusSeriesDetail.xml",
            addon_path,
            "Default",
            "720p",
            item=item or {},
            fallback_title=fallback_title or "Serial",
            watch_source=watch_source or "",
            return_action=return_action or "",
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][series_detail] Fullscreen detail failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

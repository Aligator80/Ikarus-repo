# -*- coding: utf-8 -*-
"""Fullscreen movie detail for the Ikarus Cinema theme."""

import xbmc
import xbmcaddon
import xbmcgui
import os
from xbmcvfs import translatePath

from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
ACTION_BUTTONS = {121, 122, 124, 125, 126, 131, 132, 133}
LIST_CONTROLS = {501, 601}

ACCENTS = {
    "default": {
        "color": "FF19D9F0",
        "frame": "ikarus_frame_focus.png",
        "poster": "ikarus_poster_frame_cyan.png",
    },
    "finished": {
        "color": "FF23D86B",
        "frame": "ikarus_frame_green.png",
        "poster": "ikarus_poster_frame_green.png",
    },
    "started": {
        "color": "FFFF9F2E",
        "frame": "ikarus_frame_orange.png",
        "poster": "ikarus_poster_frame_orange.png",
    },
}


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _image_url(path, size="poster"):
    path = (path or "").strip()
    if not path:
        return ""
    if path.lower().startswith(("http://", "https://", "special://")):
        return path
    tmdb = _tmdb()
    if size == "original":
        return tmdb.TMDB_IMAGE_ORIGINAL_BASE + path
    if size == "backdrop":
        return tmdb.TMDB_IMAGE_THUMB_BASE + path
    return tmdb.TMDB_IMAGE_BASE + path


def _runtime_text(minutes):
    try:
        minutes = int(minutes or 0)
    except Exception:
        minutes = 0
    if minutes <= 0:
        return ""
    hours = minutes // 60
    rest = minutes % 60
    if hours and rest:
        return "%d h %d min" % (hours, rest)
    if hours:
        return "%d h" % hours
    return "%d min" % rest


def _join_names(rows, key="name", limit=4):
    names = []
    for row in rows or []:
        if isinstance(row, str):
            value = row.strip()
        else:
            value = (row.get(key) or "").strip()
        if value:
            names.append(value)
        if len(names) >= limit:
            break
    return ", ".join(names)


def _title(item, fallback="Film"):
    try:
        return _tmdb()._tmdb_display_title(item, "movie", fallback or "Film")
    except Exception:
        return (item or {}).get("title") or (item or {}).get("original_title") or fallback or "Film"


def _year(item):
    release = ((item or {}).get("release_date") or "").strip()
    if len(release) >= 4 and release[:4].isdigit():
        return release[:4]
    return ""


def _rating_text(item):
    rating = (item or {}).get("vote_average") or 0
    try:
        rating = float(rating)
    except Exception:
        rating = 0
    return "%.1f" % rating if rating else ""


def _rating_percent(item):
    rating = (item or {}).get("vote_average") or 0
    try:
        rating = float(rating)
    except Exception:
        rating = 0
    return max(0, min(100, int(round(rating * 10)))) if rating else 0


def _plot_summary(text, limit=260):
    text = " ".join(str(text or "").strip().split())
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0].strip()
    return cut + "..."


def _country_codes(item, limit=3):
    codes = []
    for row in (item or {}).get("production_countries") or []:
        code = ""
        if isinstance(row, dict):
            code = (row.get("iso_3166_1") or "").strip().upper()
        elif isinstance(row, str):
            code = row.strip().upper()
        if code and code not in codes:
            codes.append(code)
        if len(codes) >= limit:
            break
    return ", ".join(codes)


def _skin_media(filename):
    filename = str(filename or "").strip()
    if not filename:
        return ""
    try:
        base = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    except Exception:
        base = ""
    path = os.path.join(base, "resources", "skins", "Default", "media", filename) if base else ""
    return path if path and os.path.exists(path) else filename


def _item_status(item, watch_source=""):
    tmdb_id = str((item or {}).get("id") or "").strip()
    if not tmdb_id:
        return ""
    try:
        tmdb = _tmdb()
        return (tmdb.tmdb_playback_state.get_item_status(tmdb_id) or "").strip().lower()
    except Exception:
        return ""


def _playback_meta_from_item(item, fallback_title="Film"):
    item = item or {}
    release = (item.get("release_date") or "").strip()
    year = release[:4] if len(release) >= 4 and release[:4].isdigit() else ""
    poster = _image_url(item.get("poster_path"), "poster")
    meta = {
        "title": _title(item, fallback_title),
        "original_title": (item.get("original_title") or "").strip(),
        "year": year,
        "plot": (item.get("overview") or "").strip(),
        "rating": item.get("vote_average"),
        "media_type": "movie",
    }
    if poster:
        meta["poster"] = poster
    return {key: value for key, value in meta.items() if value not in (None, "")}


def _accent_for_status(status):
    status = str(status or "").strip().lower()
    if status == "finished":
        return ACCENTS["finished"]
    if status == "started":
        return ACCENTS["started"]
    return ACCENTS["default"]


def _movie_query(item, action, title="", watch_source="", extra=None):
    title = title or _title(item)
    original = ((item or {}).get("original_title") or "").strip()
    query = {
        "action": action,
        "id": str((item or {}).get("id") or ""),
        "title": title,
        "original_title": original,
    }
    if watch_source:
        query["watch_source"] = watch_source
    if extra:
        query.update(extra)
    return query


def _set_image(control, image):
    try:
        if image:
            control.setImage(image)
    except Exception:
        pass


def _set_label(control, label):
    try:
        control.setLabel(label or "")
    except Exception:
        pass


def _set_text(control, text):
    try:
        control.setText(text or "")
    except Exception:
        pass


class IkarusMovieDetailDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.item = kwargs.pop("item", {}) or {}
        self.fallback_title = kwargs.pop("fallback_title", "Film") or "Film"
        self.watch_source = kwargs.pop("watch_source", "") or ""
        self.return_action = kwargs.pop("return_action", "") or ""
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self._list_queries = {}
        self._status = _item_status(self.item, self.watch_source)
        self._accent = _accent_for_status(self._status)

    def onInit(self):
        self._set_static_art()
        self._set_header()
        self._set_buttons()
        self._fill_cast()
        self._fill_similar()
        self._fill_media()
        try:
            focus_id = int(self.restore_state.get("focus_id") or 121)
            selected_index = int(self.restore_state.get("selected_index") or 0)
            if focus_id in LIST_CONTROLS:
                self.getControl(focus_id).selectItem(max(selected_index, 0))
            self.setFocusId(focus_id)
        except Exception:
            pass

    def _selection_context(self):
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = 121
        context = {"focus_id": focus_id}
        if focus_id in LIST_CONTROLS:
            try:
                context["selected_index"] = max(
                    int(self.getControl(focus_id).getSelectedPosition()),
                    0,
                )
            except Exception:
                context["selected_index"] = 0
        return context

    def _select_result(self, query):
        result = dict(query or {})
        result["_cinema_parent"] = self._selection_context()
        self.selected_query = result
        self.close()

    def _set_static_art(self):
        fallback_bg = ui_theme.fallback_fanart()
        movie_bg = _image_url(self.item.get("backdrop_path"), "original") or fallback_bg
        poster = _image_url(self.item.get("poster_path"), "poster") or "DefaultMovies.png"
        _set_image(self.getControl(10), fallback_bg)
        _set_image(self.getControl(11), movie_bg)
        ui_theme.set_cinema_header(self)
        _set_image(self.getControl(300), poster)
        _set_image(self.getControl(301), _skin_media(self._accent.get("poster")))

    def _refresh_status_style(self, status):
        self._status = str(status or "").strip().lower()
        self._accent = _accent_for_status(self._status)
        try:
            self.getControl(310).setTextColor(self._accent.get("color") or "FF19D9F0")
        except Exception:
            pass
        try:
            _set_image(self.getControl(301), _skin_media(self._accent.get("poster")))
        except Exception:
            pass

    def _set_header(self):
        title = _title(self.item, self.fallback_title)
        year = _year(self.item)
        genres = _join_names(self.item.get("genres") or [], limit=2)
        countries = _country_codes(self.item)
        runtime = _runtime_text(self.item.get("runtime"))
        percent = _rating_percent(self.item)
        meta = []
        if year:
            meta.append(year)
        if countries:
            meta.append(countries)
        if genres:
            meta.append(genres)
        if runtime:
            meta.append(runtime)

        title_control = self.getControl(310)
        _set_label(title_control, title)
        try:
            title_control.setTextColor(self._accent.get("color") or "FF19D9F0")
        except Exception:
            pass
        _set_label(self.getControl(311), "   |   ".join(meta))
        _set_text(self.getControl(312), _plot_summary(self.item.get("overview") or ""))
        _set_image(self.getControl(320), _skin_media("ikarus_rating_%03d.png" % percent))
        _set_label(self.getControl(321), "%d%%" % percent if percent else "--")

    def _set_buttons(self):
        title = _title(self.item, self.fallback_title)
        year = _year(self.item)
        self._button_queries = {
            121: _movie_query(self.item, "tmdb.sources.providers", title, self.watch_source, {
                "year": year,
                "query": title,
                "mode": "movie",
                "media_type": "movie",
                "poster": _image_url(self.item.get("poster_path"), "poster"),
                "fanart": _image_url(self.item.get("backdrop_path"), "original"),
            }),
            122: _movie_query(self.item, "tmdb.movie.videos", title, self.watch_source),
            124: {
                "action": "tmdb.custom.add",
                "media_type": "movie",
                "id": str(self.item.get("id") or ""),
                "title": title,
            },
            125: _movie_query(self.item, "tmdb.movie.mark.finished", title, self.watch_source),
            126: _movie_query(self.item, "tmdb.movie.watch.clear", title, self.watch_source),
            131: _movie_query(self.item, "tmdb.movie.media.popular", title, self.watch_source),
            132: _movie_query(self.item, "tmdb.movie.media.backdrops", title, self.watch_source),
            133: _movie_query(self.item, "tmdb.movie.media.posters", title, self.watch_source),
        }

    def _notify(self, message, level=xbmcgui.NOTIFICATION_INFO):
        try:
            xbmcgui.Dialog().notification("Ikarus", message, level, 2200, sound=False)
        except Exception:
            pass

    def _mark_finished_in_place(self):
        tmdb_id = str((self.item or {}).get("id") or "").strip()
        if not tmdb_id:
            return
        try:
            tmdb = _tmdb()
            meta = _playback_meta_from_item(self.item, self.fallback_title)
            meta["media_type"] = "movie"
            watched_at = tmdb._tmdb_watch_now_iso()
            tmdb.tmdb_playback_state.mark_movie_finished(tmdb_id, meta, watched_at=watched_at)
            try:
                tmdb._tmdb_push_trakt_finished_history(
                    movies=[{"tmdb_id": tmdb_id, "watched_at": watched_at}],
                )
            except Exception:
                pass
            self._refresh_status_style("finished")
            self._notify("Film oznacen jako zhlednuty")
        except Exception as exc:
            self._notify("Oznaceni selhalo: %s" % exc, xbmcgui.NOTIFICATION_ERROR)

    def _clear_watch_in_place(self):
        tmdb_id = str((self.item or {}).get("id") or "").strip()
        if not tmdb_id:
            return
        try:
            tmdb = _tmdb()
            tmdb.tmdb_playback_state.remove_item(tmdb_id)
            try:
                tmdb._tmdb_clear_trakt_watch_state("movie", tmdb_id)
            except Exception:
                pass
            self._refresh_status_style("")
            self._notify("Oznaceni zruseno")
        except Exception as exc:
            self._notify("Zruseni selhalo: %s" % exc, xbmcgui.NOTIFICATION_ERROR)

    def _list_item(self, label, label2="", art=None, query=None):
        li = xbmcgui.ListItem(label=label or "")
        try:
            if label2:
                li.setLabel2(label2)
        except Exception:
            pass
        try:
            li.setArt(art or {})
        except Exception:
            pass
        if query:
            try:
                li.setProperty("query", repr(query))
            except Exception:
                pass
        return li

    def _fill_control(self, control_id, rows):
        try:
            control = self.getControl(control_id)
            control.reset()
            self._list_queries[control_id] = []
            for li, query in rows:
                control.addItem(li)
                self._list_queries[control_id].append(query or {})
            if rows:
                control.selectItem(0)
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][movie_detail] Fill control %s failed: %s" % (control_id, exc), xbmc.LOGWARNING)
            except Exception:
                pass

    def _fill_cast(self):
        rows = []
        cast = ((self.item.get("credits") or {}).get("cast") or [])[:8]
        for person in cast:
            person_id = person.get("id")
            name = (person.get("name") or "").strip()
            character = (person.get("character") or "").strip()
            if not name:
                continue
            image = _image_url(person.get("profile_path"), "poster") or "DefaultActor.png"
            query = {"action": "tmdb.person.detail", "id": str(person_id), "title": name} if person_id else {}
            rows.append((self._list_item(name, character, {"thumb": image, "icon": image, "poster": image}, query), query))
        self._fill_control(501, rows)

    def _fill_similar(self):
        rows = []
        similar = ((self.item.get("similar") or {}).get("results") or [])[:8]
        for movie in similar:
            movie_id = movie.get("id")
            title = _title(movie, movie.get("title") or "Film")
            image = _image_url(movie.get("backdrop_path"), "backdrop") or _image_url(movie.get("poster_path"), "poster") or "DefaultMovies.png"
            query = _movie_query(movie, "tmdb.movie.detail.open", title, self.watch_source, {"return_action": self.return_action or "tmdb.movies"}) if movie_id else {}
            rows.append((self._list_item(title, _year(movie), {"thumb": image, "icon": image, "landscape": image}, query), query))
        self._fill_control(601, rows)

    def _fill_media(self):
        self._set_buttons()

    def _selected_list_query(self, control_id):
        rows = self._list_queries.get(control_id) or []
        if not rows:
            return {}
        try:
            pos = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            pos = 0
        if pos < 0 or pos >= len(rows):
            pos = 0
        return dict(rows[pos] or {})

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__", "return_action": self.return_action}
            self.close()
            return
        if control_id == 125:
            self._mark_finished_in_place()
            return
        if control_id == 126:
            self._clear_watch_in_place()
            return
        if control_id in ACTION_BUTTONS:
            self._select_result((self._button_queries or {}).get(control_id) or {})
            return
        if control_id in LIST_CONTROLS:
            query = self._selected_list_query(control_id)
            if query:
                self._select_result(query)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__back__", "return_action": self.return_action}
            self.close()
            return
        super().onAction(action)


def show_movie_detail(item, fallback_title="Film", watch_source="", return_action="", restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusMovieDetailDialog(
            "DialogIkarusMovieDetail.xml",
            addon_path,
            "Default",
            "720p",
            item=item or {},
            fallback_title=fallback_title or "Film",
            watch_source=watch_source or "",
            return_action=return_action or "",
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][movie_detail] Fullscreen detail failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

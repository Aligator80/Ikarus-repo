# -*- coding: utf-8 -*-
"""Universal Cinema results grid for TMDB movie and series lists."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}
MOVE_UP = 3
PLAYBACK_PAGE_LIMIT = 20
CUSTOM_LIST_PAGE_LIMIT = 20
TRAKT_PAGE_LIMIT = 20


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _custom_lists():
    from resources.lib import tmdb_custom_lists
    return tmdb_custom_lists


def _trakt_client():
    from resources.lib import trakt_client
    return trakt_client


def _image_url(path, size="poster"):
    path = (path or "").strip()
    if not path:
        return ""
    if path.lower().startswith(("http://", "https://")):
        return path
    tmdb = _tmdb()
    base = tmdb.TMDB_IMAGE_THUMB_BASE if size == "backdrop" else tmdb.TMDB_IMAGE_BASE
    return base + path


def _title(row, media_type):
    tmdb = _tmdb()
    if media_type == "tv":
        fallback = row.get("name") or row.get("original_name") or ""
    else:
        fallback = row.get("title") or row.get("original_title") or ""
    try:
        return tmdb._tmdb_display_title(row, media_type, fallback, fetch_alternatives=False)
    except Exception:
        return fallback or "Nezn\u00e1m\u00fd titul"


def _year(row, media_type):
    date = row.get("first_air_date") if media_type == "tv" else row.get("release_date")
    date = date or ""
    return date[:4] if len(date) >= 4 and date[:4].isdigit() else ""


def _rating(row):
    try:
        value = float(row.get("vote_average") or 0)
    except Exception:
        value = 0
    return "%.1f" % value if value else ""


def _media_query(row, media_type):
    title = _title(row, media_type)
    if media_type == "tv":
        return {
            "action": "tmdb.tv.detail.open",
            "id": str(row.get("id") or ""),
            "title": title,
            "original_title": row.get("original_name") or "",
            "return_action": "tmdb.series",
        }
    return {
        "action": "tmdb.movie.detail.open",
        "id": str(row.get("id") or ""),
        "title": title,
        "original_title": row.get("original_title") or "",
        "return_action": "tmdb.movies",
    }


def _normalize_row(row, media_type):
    poster = _image_url(row.get("poster_path"), "poster")
    fanart = _image_url(row.get("backdrop_path"), "backdrop")
    return {
        "id": row.get("id") or "",
        "title": _title(row, media_type),
        "original_title": row.get("original_name" if media_type == "tv" else "original_title") or "",
        "year": _year(row, media_type),
        "rating": _rating(row),
        "plot": row.get("overview") or "",
        "poster": poster,
        "fanart": fanart,
        "query": _media_query(row, media_type),
        "media_type": media_type,
        "media_label": "Seri\u00e1l" if media_type == "tv" else "Film",
    }


def _playback_rating(value):
    try:
        value = float(value or 0)
    except Exception:
        value = 0
    return "%.1f" % value if value else ""


def _playback_query(row, media_type):
    action = "tmdb.tv.detail.open" if media_type == "tv" else "tmdb.movie.detail.open"
    query = {
        "action": action,
        "id": str(row.get("tmdb_id") or ""),
        "title": str(row.get("title") or ""),
        "original_title": str(row.get("original_title") or ""),
        "return_action": "tmdb.started",
    }
    watch_source = str(row.get("watch_source") or "").strip().lower()
    if watch_source:
        query["watch_source"] = watch_source
    return query


def _normalize_playback_row(row, media_type, detail=None):
    tmdb = _tmdb()
    detail = detail if isinstance(detail, dict) else {}
    art = tmdb._tmdb_media_art(detail) if detail else {}
    poster = str(row.get("poster") or art.get("poster") or "").strip()
    fanart = str(
        row.get("fanart")
        or row.get("backdrop")
        or art.get("fanart")
        or ""
    ).strip()
    title = str(row.get("title") or "").strip() or "Nezn\u00e1m\u00fd titul"
    return {
        "id": str(row.get("tmdb_id") or ""),
        "title": title,
        "original_title": str(row.get("original_title") or "").strip(),
        "year": str(row.get("year") or "").strip(),
        "rating": _playback_rating(row.get("rating")),
        "plot": str(row.get("plot") or "").strip(),
        "poster": poster,
        "fanart": fanart,
        "last_played_at": str(row.get("last_played_at") or "").strip(),
        "media_type": media_type,
        "media_label": "Seri\u00e1l" if media_type == "tv" else "Film",
        "query": _playback_query(row, media_type),
    }


def _playback_page(rows, page, page_limit=PLAYBACK_PAGE_LIMIT):
    rows = list(rows or [])
    rows.sort(
        key=lambda item: (
            str(item[0] if len(item) > 0 else ""),
            str(item[1] if len(item) > 1 else ""),
        ),
        reverse=True,
    )
    page_limit = max(int(page_limit or PLAYBACK_PAGE_LIMIT), 1)
    total_pages = max(1, (len(rows) + page_limit - 1) // page_limit)
    page = max(1, min(int(page or 1), total_pages))
    start = (page - 1) * page_limit
    return page, total_pages, rows[start:start + page_limit]


def _fetch_playback_rows(query):
    tmdb = _tmdb()
    try:
        requested_page = max(int((query or {}).get("page") or 1), 1)
    except Exception:
        requested_page = 1
    playback_rows = list(
        tmdb.tmdb_playback_sync.iter_items_by_status(
            "started",
            include_trakt=True,
        )
    )
    page, total_pages, page_rows = _playback_page(
        playback_rows,
        requested_page,
    )
    details = tmdb._tmdb_prefetch_playback_listing_details(page_rows)
    normalized = []
    metadata_updates = []
    for last_played_at, tmdb_id, source_row in page_rows:
        if not isinstance(source_row, dict):
            continue
        row = dict(source_row)
        row["tmdb_id"] = str(row.get("tmdb_id") or tmdb_id or "").strip()
        row["last_played_at"] = str(
            row.get("last_played_at") or last_played_at or ""
        ).strip()
        media_type = "movie" if tmdb._tmdb_is_movie_playback_row(row) else "tv"
        needs_saved_meta = not tmdb._tmdb_playback_row_has_listing_meta(row)
        enriched = tmdb._tmdb_enrich_playback_row(
            row,
            media_type,
            details=details,
        )
        title_repair = tmdb._tmdb_playback_title_repair_meta(row, enriched)
        if title_repair:
            metadata_updates.append((enriched.get("tmdb_id") or "", title_repair))
        if needs_saved_meta and tmdb._tmdb_playback_row_has_listing_meta(enriched):
            persistable = tmdb._tmdb_playback_persistable_meta(enriched)
            if persistable:
                metadata_updates.append((enriched.get("tmdb_id") or "", persistable))
        detail_key = tmdb._tmdb_playback_detail_key(
            media_type,
            enriched.get("tmdb_id"),
        )
        normalized.append(
            _normalize_playback_row(
                enriched,
                media_type,
                detail=details.get(detail_key),
            )
        )
    if metadata_updates:
        tmdb._tmdb_remember_enriched_playback_rows(metadata_updates)
    return (
        "mixed",
        "Pokra\u010dovat ve sledov\u00e1n\u00ed",
        page,
        total_pages,
        normalized,
        "tmdb.started",
        {},
    )


def _custom_item_query(row, media_type, list_id):
    return {
        "action": "tmdb.tv.detail.open"
        if media_type == "tv"
        else "tmdb.movie.detail.open",
        "id": str(row.get("tmdb_id") or row.get("id") or ""),
        "title": str(row.get("title") or ""),
        "original_title": str(row.get("original_title") or ""),
        "return_action": "tmdb.custom.list",
        "list_id": str(list_id or ""),
    }


def _normalize_custom_item(row, list_id):
    media_type = (
        "tv"
        if str((row or {}).get("media_type") or "").strip().lower() == "tv"
        else "movie"
    )
    tmdb_id = str((row or {}).get("tmdb_id") or (row or {}).get("id") or "").strip()
    title = str((row or {}).get("title") or "").strip() or "Nezn\u00e1m\u00fd titul"
    poster = str((row or {}).get("poster") or "").strip()
    fanart = str(
        (row or {}).get("fanart")
        or (row or {}).get("backdrop")
        or ""
    ).strip()
    return {
        "id": tmdb_id,
        "title": title,
        "original_title": str((row or {}).get("original_title") or "").strip(),
        "year": str((row or {}).get("year") or "").strip(),
        "rating": _playback_rating((row or {}).get("rating")),
        "plot": str((row or {}).get("plot") or "").strip(),
        "poster": poster,
        "fanart": fanart,
        "media_type": media_type,
        "media_label": "Seri\u00e1l" if media_type == "tv" else "Film",
        "query": _custom_item_query(row, media_type, list_id),
    }


def _custom_sort_key(row):
    year = str((row or {}).get("year") or "").strip()
    try:
        year_value = int(year)
    except Exception:
        year_value = 0
    return (
        year_value,
        str((row or {}).get("added_at") or ""),
        str((row or {}).get("title") or "").casefold(),
    )


def _fetch_custom_list_rows(query):
    list_id = str((query or {}).get("list_id") or "").strip()
    row = _custom_lists().get_list(list_id) if list_id else None
    title = str(
        (row or {}).get("name")
        or (query or {}).get("name")
        or "Seznam"
    ).strip()
    try:
        requested_page = max(int((query or {}).get("page") or 1), 1)
    except Exception:
        requested_page = 1
    raw_items = [
        item
        for item in ((row or {}).get("items") or [])
        if isinstance(item, dict)
        and str(item.get("tmdb_id") or item.get("id") or "").strip()
        and str(item.get("media_type") or "").strip().lower() in ("movie", "tv")
    ]
    raw_items.sort(key=_custom_sort_key, reverse=True)
    total_pages = max(
        1,
        (len(raw_items) + CUSTOM_LIST_PAGE_LIMIT - 1)
        // CUSTOM_LIST_PAGE_LIMIT,
    )
    page = max(1, min(requested_page, total_pages))
    start = (page - 1) * CUSTOM_LIST_PAGE_LIMIT
    page_items = raw_items[start:start + CUSTOM_LIST_PAGE_LIMIT]
    normalized = [
        _normalize_custom_item(item, list_id)
        for item in page_items
    ]
    return (
        "mixed",
        title,
        page,
        total_pages,
        normalized,
        "tmdb.custom.list",
        {"list_id": list_id, "name": title},
    )


def _trakt_first_image_url(value) -> str:
    if isinstance(value, str):
        text = value.strip()
        return text if text.lower().startswith(("http://", "https://")) else ""
    if isinstance(value, list):
        for item in value:
            found = _trakt_first_image_url(item)
            if found:
                return found
        return ""
    if isinstance(value, dict):
        for key in (
            "full", "medium", "thumb", "url", "poster", "posters",
            "fanart", "background", "backdrop", "backdrops",
        ):
            found = _trakt_first_image_url(value.get(key))
            if found:
                return found
        for item in value.values():
            found = _trakt_first_image_url(item)
            if found:
                return found
    return ""


def _trakt_media_payload(row):
    row = row if isinstance(row, dict) else {}
    if isinstance(row.get("movie"), dict):
        return "movie", row.get("movie") or {}
    if isinstance(row.get("show"), dict):
        return "tv", row.get("show") or {}
    return "", {}


def _trakt_tmdb_id(payload):
    ids = payload.get("ids") if isinstance(payload.get("ids"), dict) else {}
    return str(ids.get("tmdb") or "").strip()


def _trakt_normalized_rows(rows, section=""):
    normalized = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        try:
            item = _tmdb()._trakt_smart_result_row(row, section) if section else dict(row)
        except Exception:
            item = dict(row)
        if not str(item.get("type") or "").strip():
            if isinstance(item.get("movie"), dict):
                item["type"] = "movie"
            elif isinstance(item.get("show"), dict):
                item["type"] = "show"
        _media_type, payload = _trakt_media_payload(item)
        if _trakt_tmdb_id(payload):
            normalized.append(item)
    return normalized


def _trakt_year(payload, media_type):
    value = payload.get("year")
    if value:
        return str(value)
    date = payload.get("first_aired") if media_type == "tv" else payload.get("released")
    date = str(date or "")
    return date[:4] if len(date) >= 4 and date[:4].isdigit() else ""


def _trakt_detail_for_row(row, details=None):
    media_type, payload = _trakt_media_payload(row)
    tmdb_id = _trakt_tmdb_id(payload)
    if not tmdb_id or not isinstance(details, dict):
        return {}
    key = "movie:%s" % tmdb_id if media_type == "movie" else "show:%s" % tmdb_id
    detail = details.get(key)
    return detail if isinstance(detail, dict) else {}


def _trakt_detail_image(detail, key, size="poster"):
    path = str((detail or {}).get(key) or "").strip()
    if not path:
        return ""
    return _image_url(path, size)


def _normalize_trakt_item(row, return_action, details=None):
    media_type, payload = _trakt_media_payload(row)
    tmdb_id = _trakt_tmdb_id(payload)
    if media_type not in ("movie", "tv") or not tmdb_id:
        return {}
    detail = _trakt_detail_for_row(row, details)
    title_key = "name" if media_type == "tv" else "title"
    original_key = "original_name" if media_type == "tv" else "original_title"
    date_key = "first_air_date" if media_type == "tv" else "release_date"
    title = str(detail.get(title_key) or payload.get("title") or "").strip() or "Nezn\u00e1m\u00fd titul"
    original = str(detail.get(original_key) or payload.get("original_title") or payload.get("title") or "").strip()
    poster = _trakt_detail_image(detail, "poster_path", "poster") or _trakt_first_image_url(payload.get("images"))
    fanart = _trakt_detail_image(detail, "backdrop_path", "backdrop") or poster
    if not poster:
        poster = "DefaultTVShows.png" if media_type == "tv" else "DefaultMovies.png"
    query = {
        "action": "tmdb.tv.detail.open" if media_type == "tv" else "tmdb.movie.detail.open",
        "id": tmdb_id,
        "title": title,
        "original_title": original,
        "return_action": return_action,
    }
    return {
        "id": tmdb_id,
        "title": title,
        "original_title": original if original != title else "",
        "year": _year(detail, media_type) if detail.get(date_key) else _trakt_year(payload, media_type),
        "rating": _rating(detail) if detail.get("vote_average") else _playback_rating(payload.get("rating")),
        "plot": str(detail.get("overview") or payload.get("overview") or "").strip(),
        "poster": poster,
        "fanart": fanart or ui_theme.fallback_fanart(),
        "media_type": media_type,
        "media_label": "Seri\u00e1l" if media_type == "tv" else "Film",
        "query": query,
    }


def _fetch_trakt_watchlist_rows(query):
    try:
        page = max(int((query or {}).get("page") or 1), 1)
    except Exception:
        page = 1
    rows = _trakt_normalized_rows(_trakt_client().fetch_watchlist(limit=TRAKT_PAGE_LIMIT, page=page))
    try:
        details = _tmdb()._trakt_prefetch_tmdb_listing_details(rows or []) or {}
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][results] Trakt watchlist TMDB prefetch failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        details = {}
    normalized = [
        item
        for item in (_normalize_trakt_item(row, "tmdb.trakt.watchlist", details) for row in rows)
        if item
    ]
    total_pages = page + 1 if len(rows or []) >= TRAKT_PAGE_LIMIT else page
    return (
        "mixed",
        "Seznam sledovan\u00fdch polo\u017eek",
        page,
        total_pages,
        normalized,
        "tmdb.trakt.watchlist",
        {},
    )


def _fetch_trakt_list_rows(query):
    try:
        page = max(int((query or {}).get("page") or 1), 1)
    except Exception:
        page = 1
    username = str((query or {}).get("user") or "me").strip() or "me"
    slug = str((query or {}).get("slug") or "").strip()
    title = str((query or {}).get("name") or "Trakt.TV seznam").strip()
    item_type = str((query or {}).get("media_type") or "").strip().lower()
    rows = _trakt_normalized_rows(_trakt_client().fetch_list_items(
        username,
        slug,
        limit=TRAKT_PAGE_LIMIT,
        page=page,
        item_type=item_type,
    ) if slug else [], item_type)
    try:
        details = _tmdb()._trakt_prefetch_tmdb_listing_details(rows or []) or {}
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][results] Trakt list TMDB prefetch failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        details = {}
    normalized = [
        item
        for item in (_normalize_trakt_item(row, "tmdb.trakt.list", details) for row in rows)
        if item
    ]
    total_pages = page + 1 if len(rows or []) >= TRAKT_PAGE_LIMIT else page
    persist = {
        "user": username,
        "slug": slug,
        "name": title,
        "media_type": item_type,
    }
    return (
        "mixed",
        title,
        page,
        total_pages,
        normalized,
        "tmdb.trakt.list",
        persist,
    )


def _fetch_trakt_smart_rows(query):
    try:
        page = max(int((query or {}).get("page") or 1), 1)
    except Exception:
        page = 1
    title = str((query or {}).get("name") or "Chytr\u00fd seznam").strip()
    section = str((query or {}).get("section") or "").strip().lower()
    path = str((query or {}).get("path") or "").strip()
    raw_query = str((query or {}).get("query") or "").strip()
    rows = []
    if section in ("movies", "shows", "search") and path:
        rows = _trakt_client().fetch_saved_filter_items(
            path,
            query=raw_query,
            section=section,
            limit=TRAKT_PAGE_LIMIT,
            page=page,
        )
    rows = _trakt_normalized_rows(rows, section)
    try:
        details = _tmdb()._trakt_prefetch_tmdb_listing_details(rows or []) or {}
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][results] Trakt smart TMDB prefetch failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        details = {}
    normalized = [
        item
        for item in (_normalize_trakt_item(row, "tmdb.trakt.smart.list", details) for row in rows)
        if item
    ]
    total_pages = page + 1 if len(rows or []) >= TRAKT_PAGE_LIMIT else page
    persist = {
        "name": title,
        "section": section,
        "path": path,
        "query": raw_query,
    }
    return (
        "mixed",
        title,
        page,
        total_pages,
        normalized,
        "tmdb.trakt.smart.list",
        persist,
    )


def _params_for_query(query):
    action = (query or {}).get("action") or ""
    media_type = "tv" if action.startswith("tmdb.series") else "movie"
    page = 1
    try:
        page = max(int((query or {}).get("page") or 1), 1)
    except Exception:
        page = 1
    endpoint = ""
    params = {}
    title = ""
    next_action = action
    persist = {}

    if action == "tmdb.movies.popular.list":
        endpoint = "/discover/movie"
        title = "Popul\u00e1rn\u00ed"
        params = {"sort_by": "popularity.desc", "include_adult": "false", "include_video": "false"}
    elif action == "tmdb.movies.popular.provider.list":
        endpoint = "/discover/movie"
        title = (query.get("provider_name") or "Slu\u017eba").strip()
        params = {
            "sort_by": "popularity.desc",
            "include_adult": "false",
            "include_video": "false",
            "watch_region": _tmdb().TMDB_REGION,
            "with_watch_providers": query.get("provider_id") or "",
        }
        persist = {"provider_id": query.get("provider_id") or "", "provider_name": title}
    elif action == "tmdb.movies.top_rated":
        endpoint = "/movie/top_rated"
        title = "Hodnocen\u00ed"
    elif action == "tmdb.movies.genre.list":
        endpoint = "/discover/movie"
        title = query.get("genre_name") or "\u017d\u00e1nr"
        params = {"with_genres": query.get("genre_id") or "", "sort_by": "popularity.desc", "include_adult": "false", "include_video": "false"}
        persist = {"genre_id": query.get("genre_id") or "", "genre_name": title}
    elif action == "tmdb.movies.year.list":
        endpoint = "/discover/movie"
        title = query.get("year") or "Rok"
        params = {"primary_release_year": query.get("year") or "", "sort_by": "popularity.desc", "include_adult": "false", "include_video": "false"}
        persist = {"year": query.get("year") or ""}
    elif action == "tmdb.movies.origin_country.list":
        endpoint = "/discover/movie"
        title = query.get("country_name") or "Zem\u011b"
        params = {"with_origin_country": query.get("country_code") or "", "sort_by": "primary_release_date.desc", "include_adult": "false", "include_video": "false"}
        persist = {"country_code": query.get("country_code") or "", "country_name": title}
    elif action == "tmdb.series.popular.list":
        media_type = "tv"
        endpoint = "/discover/tv"
        title = "Popul\u00e1rn\u00ed"
        params = {"sort_by": "first_air_date.desc", "include_adult": "false"}
    elif action == "tmdb.series.popular.provider.list":
        media_type = "tv"
        endpoint = "/discover/tv"
        title = (query.get("provider_name") or "Slu\u017eba").strip()
        params = {
            "sort_by": "first_air_date.desc",
            "include_adult": "false",
            "watch_region": _tmdb().TMDB_REGION,
            "with_watch_providers": query.get("provider_id") or "",
        }
        persist = {"provider_id": query.get("provider_id") or "", "provider_name": title}
    elif action == "tmdb.series.top_rated":
        media_type = "tv"
        endpoint = "/tv/top_rated"
        title = "Hodnocen\u00ed"
    elif action == "tmdb.series.genre.list":
        media_type = "tv"
        endpoint = "/discover/tv"
        title = query.get("genre_name") or "\u017d\u00e1nr"
        params = {"with_genres": query.get("genre_id") or "", "sort_by": "popularity.desc", "include_adult": "false"}
        persist = {"genre_id": query.get("genre_id") or "", "genre_name": title}
    elif action == "tmdb.series.year.list":
        media_type = "tv"
        endpoint = "/discover/tv"
        title = query.get("year") or "Rok"
        params = {"first_air_date_year": query.get("year") or "", "sort_by": "popularity.desc", "include_adult": "false"}
        persist = {"year": query.get("year") or ""}
    elif action == "tmdb.series.origin_country.list":
        media_type = "tv"
        endpoint = "/discover/tv"
        title = query.get("country_name") or "Zem\u011b"
        params = {"with_origin_country": query.get("country_code") or "", "sort_by": "first_air_date.desc", "include_adult": "false"}
        persist = {"country_code": query.get("country_code") or "", "country_name": title}

    return media_type, endpoint, title, page, params, next_action, persist


def _fetch_rows(query):
    action = str((query or {}).get("action") or "")
    if action == "tmdb.started":
        return _fetch_playback_rows(query)
    if action == "tmdb.custom.list":
        return _fetch_custom_list_rows(query)
    if action == "tmdb.trakt.watchlist":
        return _fetch_trakt_watchlist_rows(query)
    if action == "tmdb.trakt.list":
        return _fetch_trakt_list_rows(query)
    if action == "tmdb.trakt.smart.list":
        return _fetch_trakt_smart_rows(query)
    tmdb = _tmdb()
    media_type, endpoint, title, page, params, next_action, persist = _params_for_query(query)
    if not endpoint:
        return media_type, title, page, 1, [], next_action, persist
    api_params = {"language": tmdb.TMDB_LANGUAGE, "page": page}
    if media_type == "movie":
        api_params["region"] = tmdb.TMDB_REGION
    api_params.update(params or {})
    data = tmdb._tmdb_get(endpoint, api_params, timeout=tmdb.TMDB_MENU_TIMEOUT)
    results = data.get("results") or []
    total_pages = int(data.get("total_pages") or 1)
    rows = [_normalize_row(row, media_type) for row in results if row.get("id")]
    return media_type, title, page, total_pages, rows[:24], next_action, persist


def _page_query(base_action, page, persist):
    query = {"action": base_action, "page": str(page)}
    for key, value in (persist or {}).items():
        if value:
            query[key] = value
    return query


class IkarusResultsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.initial_query = dict(kwargs.pop("query", {}) or {})
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self.rows = []
        self.media_type = "movie"
        self.title = ""
        self.page = 1
        self.total_pages = 1
        self.next_action = ""
        self.persist = {}

    def onInit(self):
        self._set_static_art()
        self._load()
        self._fill()
        try:
            self.setFocusId(401 if self.rows else 100)
        except Exception:
            pass

    def _set_static_art(self):
        try:
            bg = ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        action = str((self.initial_query or {}).get("action") or "")
        if action == "tmdb.custom.list":
            ui_theme.set_cinema_header(self, "Seznamy")
        elif action.startswith("tmdb.trakt."):
            ui_theme.set_cinema_header(self, "Trakt.TV")
        elif action == "tmdb.started":
            ui_theme.set_cinema_header(self, "Pokračovat ve sledování")
        elif action.startswith("tmdb.series"):
            ui_theme.set_cinema_header(self, "Seriály")
        else:
            ui_theme.set_cinema_header(self, "Film")

    def _load(self):
        try:
            self.media_type, self.title, self.page, self.total_pages, self.rows, self.next_action, self.persist = _fetch_rows(self.initial_query)
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][results] Fetch failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass
            self.rows = []
        action = str((self.initial_query or {}).get("action") or "")
        if action == "tmdb.custom.list":
            ui_theme.set_cinema_header(self, "Seznamy", self.title)
        elif action.startswith("tmdb.trakt."):
            ui_theme.set_cinema_header(self, "Trakt.TV", self.title)
        elif action == "tmdb.started":
            ui_theme.set_cinema_header(
                self,
                self.title or "Pokračovat ve sledování",
            )
        elif action.startswith("tmdb.series") or self.media_type == "tv":
            ui_theme.set_cinema_header(self, "Seriály", self.title)
        else:
            ui_theme.set_cinema_header(self, "Film", self.title)
        try:
            self.setProperty("IkarusResultsPrevVisible", "1" if self.page > 1 else "0")
            self.setProperty("IkarusResultsNextVisible", "1" if self.page < self.total_pages else "0")
        except Exception:
            pass

    def _list_item(self, row):
        item = xbmcgui.ListItem(label=row.get("title") or "")
        row_media_type = row.get("media_type") or self.media_type
        poster = row.get("poster") or ("DefaultTVShows.png" if row_media_type == "tv" else "DefaultMovies.png")
        fanart = row.get("fanart") or ui_theme.fallback_fanart()
        try:
            item.setArt({"poster": poster, "thumb": poster, "icon": poster, "fanart": fanart or ""})
        except Exception:
            pass
        return item

    def _fill(self):
        try:
            control = self.getControl(401)
            control.reset()
            for row in self.rows:
                control.addItem(self._list_item(row))
            if self.rows:
                selected_index = int(self.restore_state.get("selected_index") or 0)
                selected_index = max(0, min(selected_index, len(self.rows) - 1))
                control.selectItem(selected_index)
                self._set_detail(self.rows[selected_index])
            else:
                self._set_empty()
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][results] Fill failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass

    def _turn_page(self, page):
        self.initial_query = _page_query(self.next_action, page, self.persist)
        self.restore_state = {"selected_index": 0}
        self._load()
        self._fill()
        try:
            self.setFocusId(401 if self.rows else 100)
        except Exception:
            pass

    def _selected_row(self):
        if not self.rows:
            return {}
        try:
            pos = int(self.getControl(401).getSelectedPosition())
        except Exception:
            pos = 0
        if pos < 0 or pos >= len(self.rows):
            pos = 0
        return self.rows[pos]

    def _set_empty(self):
        try:
            self.getControl(30).setLabel("\u017d\u00e1dn\u00e9 polo\u017eky")
            self.getControl(31).setLabel("")
            self.getControl(32).setText("")
        except Exception:
            pass

    def _set_detail(self, row):
        meta = []
        if row.get("media_label"):
            meta.append(row.get("media_label"))
        if row.get("year"):
            meta.append(row.get("year"))
        if row.get("rating"):
            meta.append("* %s" % row.get("rating"))
        if row.get("original_title") and row.get("original_title") != row.get("title"):
            meta.append(row.get("original_title"))
        details = []
        if meta:
            details.append("  |  ".join(meta))
        plot = row.get("plot") or ""
        if plot:
            if details:
                details.append("")
            details.append(plot)
        try:
            self.getControl(30).setLabel(row.get("title") or "")
            self.getControl(31).setLabel("")
            self.getControl(32).setText("\n".join(details))
            fanart = row.get("fanart") or ui_theme.fallback_fanart()
            if fanart:
                self.getControl(11).setImage(fanart)
        except Exception:
            pass

    def onFocus(self, control_id):
        if int(control_id or 0) == 401:
            self._set_detail(self._selected_row())

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if control_id == 150 and self.page > 1:
            self._turn_page(self.page - 1)
            return
        if control_id == 151 and self.page < self.total_pages:
            self._turn_page(self.page + 1)
            return
        if control_id == 401:
            self.selected_query = dict((self._selected_row() or {}).get("query") or {})
            try:
                selected_index = int(self.getControl(401).getSelectedPosition())
            except Exception:
                selected_index = 0
            self.selected_query["_cinema_parent"] = {
                "query": dict(self.initial_query or {}),
                "selected_index": max(selected_index, 0),
            }
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if action_id == MOVE_UP:
            try:
                focus_id = int(self.getFocusId())
                if focus_id == 100:
                    if self.page < self.total_pages:
                        self.setFocusId(151)
                    elif self.page > 1:
                        self.setFocusId(150)
                    return
                if focus_id == 401:
                    if self.page < self.total_pages:
                        self.setFocusId(151)
                    elif self.page > 1:
                        self.setFocusId(150)
                    else:
                        self.setFocusId(100)
                    return
            except Exception:
                pass
        if action_id in OPEN_ACTIONS:
            try:
                if int(self.getFocusId()) == 401:
                    self._set_detail(self._selected_row())
            except Exception:
                pass
        super().onAction(action)
        try:
            if int(self.getFocusId()) == 401:
                self._set_detail(self._selected_row())
        except Exception:
            pass


def show_results(query, restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusResultsDialog(
            "DialogIkarusResults.xml",
            addon_path,
            "Default",
            "720p",
            query=dict(query or {}),
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][results] Dialog failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

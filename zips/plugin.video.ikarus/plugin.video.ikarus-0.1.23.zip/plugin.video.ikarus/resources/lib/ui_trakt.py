# -*- coding: utf-8 -*-
"""Cinema Trakt.TV overview screen."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import trakt_client
from resources.lib import trakt_public_favorites
from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}
SECTION_CONTROLS = (401, 402, 403, 404)
PREVIEW_LIMIT = 6
ROW_LIMIT = 8


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _first_image_url(value) -> str:
    if isinstance(value, str):
        text = value.strip()
        return text if text.lower().startswith(("http://", "https://")) else ""
    if isinstance(value, list):
        for item in value:
            found = _first_image_url(item)
            if found:
                return found
        return ""
    if isinstance(value, dict):
        for key in (
            "full", "medium", "thumb", "url", "poster", "posters",
            "fanart", "background", "backdrop", "backdrops",
        ):
            found = _first_image_url(value.get(key))
            if found:
                return found
        for item in value.values():
            found = _first_image_url(item)
            if found:
                return found
    return ""


def _trakt_payload(row):
    row = row if isinstance(row, dict) else {}
    if isinstance(row.get("movie"), dict):
        return "movie", row.get("movie") or {}
    if isinstance(row.get("show"), dict):
        return "tv", row.get("show") or {}
    return "", {}


def _tmdb_id(payload):
    ids = payload.get("ids") if isinstance(payload.get("ids"), dict) else {}
    return str(ids.get("tmdb") or "").strip()


def _year(payload, media_type):
    value = payload.get("year")
    if value:
        return str(value)
    date = payload.get("first_aired") if media_type == "tv" else payload.get("released")
    date = str(date or "")
    return date[:4] if len(date) >= 4 and date[:4].isdigit() else ""


def _detail_for_row(row, details=None):
    media_type, payload = _trakt_payload(row)
    tmdb_id = _tmdb_id(payload)
    if not tmdb_id or not isinstance(details, dict):
        return {}
    key = "movie:%s" % tmdb_id if media_type == "movie" else "show:%s" % tmdb_id
    detail = details.get(key)
    return detail if isinstance(detail, dict) else {}


def _poster_from_detail(detail):
    poster = str((detail or {}).get("poster_path") or "").strip()
    if not poster:
        return ""
    if poster.lower().startswith(("http://", "https://")):
        return poster
    return _tmdb().TMDB_IMAGE_BASE + poster


def _poster_from_row(row, details=None):
    _media_type, payload = _trakt_payload(row)
    poster = _poster_from_detail(_detail_for_row(row, details))
    if poster:
        return poster
    poster = _first_image_url(payload.get("images"))
    return poster or _fallback_poster()


def _fallback_poster():
    return ui_theme.action_art("tmdb.trakt.lists").get("poster") or "DefaultVideoPlaylists.png"


def _is_fallback_poster(poster):
    poster = str(poster or "").strip()
    return (
        not poster
        or poster.startswith("Default")
        or poster == _fallback_poster()
    )


def _normalized_preview_row(row, section=""):
    if not isinstance(row, dict):
        return {}
    try:
        normalized = _tmdb()._trakt_smart_result_row(row, section) if section else dict(row)
    except Exception:
        normalized = dict(row)
    if not str(normalized.get("type") or "").strip():
        if isinstance(normalized.get("movie"), dict):
            normalized["type"] = "movie"
        elif isinstance(normalized.get("show"), dict):
            normalized["type"] = "show"
    media_type, payload = _trakt_payload(normalized)
    if media_type not in ("movie", "tv") or not _tmdb_id(payload):
        return {}
    return normalized


def _normalized_preview_rows(rows, section=""):
    normalized = []
    for row in rows or []:
        item = _normalized_preview_row(row, section)
        if item:
            normalized.append(item)
    return normalized


def _real_posters(posters):
    real = []
    for poster in posters or []:
        poster = str(poster or "").strip()
        if poster and not _is_fallback_poster(poster) and poster not in real:
            real.append(poster)
    return real


def _filled_posters(posters):
    real = _real_posters(posters)
    if not real:
        return [_fallback_poster()] * PREVIEW_LIMIT
    filled = list(real)
    index = 0
    while len(filled) < PREVIEW_LIMIT:
        filled.append(real[index % len(real)])
        index += 1
    return filled[:PREVIEW_LIMIT]


def _preview_mode(posters):
    return "single" if len(_real_posters(posters)) <= 1 else "collage"


def _watchlist_item(row, details=None):
    media_type, payload = _trakt_payload(row)
    tmdb_id = _tmdb_id(payload)
    if media_type not in ("movie", "tv") or not tmdb_id:
        return {}
    title = str(payload.get("title") or "").strip() or "Nezn\u00e1m\u00fd titul"
    detail = _detail_for_row(row, details)
    if detail:
        title = str(
            detail.get("name" if media_type == "tv" else "title")
            or title
        ).strip() or title
    poster = _poster_from_row(row, details)
    return {
        "label": title,
        "subtitle": _year(payload, media_type),
        "posters": [poster],
        "preview_mode": "single",
        "query": {
            "action": "tmdb.tv.detail.open" if media_type == "tv" else "tmdb.movie.detail.open",
            "id": tmdb_id,
            "title": title,
            "original_title": str(payload.get("original_title") or payload.get("title") or "").strip(),
            "return_action": "tmdb.trakt.watchlist",
        },
    }


def _preview_posters(rows, section=""):
    rows = _normalized_preview_rows(rows, section)
    details = {}
    try:
        details = _tmdb()._trakt_prefetch_tmdb_listing_details(rows) or {}
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][trakt] preview TMDB prefetch failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
    posters = []
    for row in rows or []:
        poster = _poster_from_row(row, details)
        if poster and not _is_fallback_poster(poster) and poster not in posters:
            posters.append(poster)
        if len(posters) >= PREVIEW_LIMIT:
            break
    return _filled_posters(posters)


def _count_text(count):
    try:
        count = int(count or 0)
    except Exception:
        count = 0
    if count == 1:
        return "1 polo\u017eka"
    if count > 1 and count < 5:
        return "%d polo\u017eky" % count
    return "%d polo\u017eek" % count


def _list_slug(row):
    ids = row.get("ids") if isinstance(row.get("ids"), dict) else {}
    return str(ids.get("slug") or row.get("slug") or "").strip()


def _fetch_list_preview(username, slug, item_type=""):
    try:
        return _normalized_preview_rows(trakt_client.fetch_list_items(
            username,
            slug,
            limit=max(PREVIEW_LIMIT * 5, 30),
            page=1,
            item_type=item_type,
        ))
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][trakt] list preview failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return []


def _fetch_smart_preview(row):
    section = str((row or {}).get("section") or "").strip().lower()
    path = str((row or {}).get("path") or "").strip()
    query = str((row or {}).get("query") or "").strip()
    if section not in ("movies", "shows", "search") or not path:
        return []
    try:
        return _normalized_preview_rows(trakt_client.fetch_saved_filter_items(
            path,
            query=query,
            section=section,
            limit=max(PREVIEW_LIMIT * 5, 30),
            page=1,
        ), section)
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][trakt] smart preview failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return []


def _section_label(section):
    section = str(section or "").strip().lower()
    if section == "movies":
        return "Filmy"
    if section == "shows":
        return "Seri\u00e1ly"
    if section == "search":
        return "Media"
    return "Filtr"


def _load_watchlist_rows():
    try:
        raw_rows = trakt_client.fetch_watchlist(limit=ROW_LIMIT, page=1)
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][trakt] watchlist load failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        raw_rows = []
    try:
        details = _tmdb()._trakt_prefetch_tmdb_listing_details(raw_rows or []) or {}
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][trakt] watchlist TMDB prefetch failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        details = {}
    rows = []
    for raw in raw_rows or []:
        item = _watchlist_item(raw, details)
        if item:
            rows.append(item)
    return rows


def _load_smart_rows():
    rows = []
    for section in ("search", "movies", "shows"):
        try:
            source_rows = trakt_client.fetch_saved_filters(section)
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][trakt] smart lists load failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass
            source_rows = []
        for row in source_rows or []:
            if not isinstance(row, dict):
                continue
            item = dict(row)
            item["section"] = str(item.get("section") or section).strip().lower()
            name = str(item.get("name") or "Chytr\u00fd seznam").strip()
            path = str(item.get("path") or "").strip()
            if not name or not path:
                continue
            preview = _fetch_smart_preview(item)
            posters = _preview_posters(preview)
            rows.append({
                "label": name,
                "subtitle": _section_label(item.get("section")),
                "posters": posters,
                "preview_mode": _preview_mode(posters),
                "query": {
                    "action": "tmdb.trakt.smart.list",
                    "name": name,
                    "section": item.get("section") or "",
                    "path": path,
                    "query": str(item.get("query") or "").strip(),
                    "page": "1",
                },
            })
            if len(rows) >= ROW_LIMIT:
                return rows
    return rows


def _load_my_list_rows():
    try:
        source_rows = trakt_client.fetch_user_lists()
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][trakt] user lists load failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        source_rows = []
    rows = []
    for row in source_rows or []:
        if not isinstance(row, dict):
            continue
        slug = _list_slug(row)
        name = str(row.get("name") or "Trakt.TV seznam").strip()
        if not slug:
            continue
        item_type = str(row.get("type") or "").strip().lower()
        preview = _fetch_list_preview("me", slug, item_type)
        posters = _preview_posters(preview)
        rows.append({
            "label": name,
            "subtitle": _count_text(row.get("item_count")),
            "posters": posters,
            "preview_mode": _preview_mode(posters),
            "query": {
                "action": "tmdb.trakt.list",
                "user": "me",
                "slug": slug,
                "name": name,
                "media_type": item_type,
                "page": "1",
            },
        })
        if len(rows) >= ROW_LIMIT:
            break
    return rows


def _load_favorite_rows():
    rows = []
    for row in trakt_public_favorites.all_lists()[:ROW_LIMIT]:
        username = str(row.get("username") or "").strip()
        slug = str(row.get("slug") or "").strip()
        name = str(row.get("name") or "Trakt.TV seznam").strip()
        if not username or not slug:
            continue
        item_type = str(row.get("type") or "").strip().lower()
        preview = _fetch_list_preview(username, slug, item_type)
        posters = _preview_posters(preview)
        rows.append({
            "label": name,
            "subtitle": username,
            "posters": posters,
            "preview_mode": _preview_mode(posters),
            "query": {
                "action": "tmdb.trakt.list",
                "user": username,
                "slug": slug,
                "name": name,
                "media_type": item_type,
                "page": "1",
            },
        })
    return rows


def _empty_row(label, subtitle):
    return {
        "label": label,
        "subtitle": subtitle,
        "posters": [_fallback_poster()] * PREVIEW_LIMIT,
        "preview_mode": "collage",
        "query": {},
    }


class IkarusTraktDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.rows_by_control = {}
        self.selected_query = None

    def onInit(self):
        self._set_static_art()
        self._load()
        self._fill()
        try:
            self.setFocusId(self._initial_focus())
        except Exception:
            pass
        self._set_preview(self._selected_row())

    def _set_static_art(self):
        try:
            bg = ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Trakt.TV")

    def _load(self):
        self.rows_by_control = {
            401: _load_watchlist_rows(),
            402: _load_smart_rows(),
            403: _load_my_list_rows(),
            404: _load_favorite_rows(),
        }
        if not self.rows_by_control[401]:
            self.rows_by_control[401] = [_empty_row("Seznam sledovan\u00fdch polo\u017eek", "Na Traktu je pr\u00e1zdn\u00fd")]
        if not self.rows_by_control[402]:
            self.rows_by_control[402] = [_empty_row("Chytr\u00e9 seznamy", "Na Traktu nejsou nastaven\u00e9")]
        if not self.rows_by_control[403]:
            self.rows_by_control[403] = [_empty_row("Moje seznamy", "Na Traktu nejsou \u017e\u00e1dn\u00e9 seznamy")]
        if not self.rows_by_control[404]:
            self.rows_by_control[404] = [_empty_row("L\u00edbilo se", "Zat\u00edm bez ulo\u017een\u00fdch ve\u0159ejn\u00fdch seznam\u016f")]

    def _fill(self):
        for control_id in SECTION_CONTROLS:
            control = self.getControl(control_id)
            control.reset()
            for row in self.rows_by_control.get(control_id) or []:
                control.addItem(self._list_item(row))
            try:
                selected = 0
                if int(self.restore_state.get("focus_id") or 0) == control_id:
                    selected = int(self.restore_state.get("selected_index") or 0)
                selected = max(0, min(selected, len(self.rows_by_control.get(control_id) or []) - 1))
                control.selectItem(selected)
            except Exception:
                pass

    def _list_item(self, row):
        item = xbmcgui.ListItem(label=row.get("label") or "")
        try:
            item.setProperty("Subtitle", row.get("subtitle") or "")
            item.setProperty("PreviewMode", row.get("preview_mode") or _preview_mode(row.get("posters") or []))
            posters = _filled_posters(row.get("posters") or [])
            for index in range(PREVIEW_LIMIT):
                item.setProperty("Poster%d" % (index + 1), posters[index])
        except Exception:
            pass
        return item

    def _initial_focus(self):
        try:
            focus_id = int(self.restore_state.get("focus_id") or 0)
        except Exception:
            focus_id = 0
        return focus_id if focus_id in SECTION_CONTROLS else 401

    def _selected_position(self, control_id=None):
        control_id = int(control_id or self.getFocusId() or 0)
        if control_id not in SECTION_CONTROLS:
            return 0
        try:
            position = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            position = 0
        rows = self.rows_by_control.get(control_id) or []
        return max(0, min(position, len(rows) - 1)) if rows else 0

    def _selected_row(self):
        try:
            control_id = int(self.getFocusId())
        except Exception:
            control_id = 401
        if control_id not in SECTION_CONTROLS:
            control_id = 401
        rows = self.rows_by_control.get(control_id) or []
        if not rows:
            return {}
        return rows[self._selected_position(control_id)]

    def _set_preview(self, row):
        row = row or {}
        posters = _filled_posters(row.get("posters") or [])
        mode = row.get("preview_mode") or _preview_mode(posters)
        if mode == "single" and _real_posters(posters):
            try:
                self.getControl(46).setImage(_real_posters(posters)[0])
            except Exception:
                pass
            for control_id in (40, 41, 42, 43, 44, 45):
                try:
                    self.getControl(control_id).setImage("")
                except Exception:
                    pass
        else:
            try:
                self.getControl(46).setImage("")
            except Exception:
                pass
            for index, control_id in enumerate((40, 41, 42, 43, 44, 45)):
                try:
                    self.getControl(control_id).setImage(posters[index])
                except Exception:
                    pass
        try:
            self.getControl(30).setLabel(row.get("label") or "")
            self.getControl(31).setLabel(row.get("subtitle") or "")
        except Exception:
            pass

    def onFocus(self, control_id):
        if int(control_id or 0) in SECTION_CONTROLS:
            self._set_preview(self._selected_row())

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if control_id in SECTION_CONTROLS:
            row = self._selected_row()
            query = dict(row.get("query") or {})
            if not query:
                return
            query["_cinema_parent"] = {
                "focus_id": control_id,
                "selected_index": self._selected_position(control_id),
            }
            self.selected_query = query
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if action_id in OPEN_ACTIONS:
            try:
                if int(self.getFocusId()) in SECTION_CONTROLS:
                    self._set_preview(self._selected_row())
            except Exception:
                pass
        super().onAction(action)
        try:
            if int(self.getFocusId()) in SECTION_CONTROLS:
                self._set_preview(self._selected_row())
        except Exception:
            pass


def notify_not_connected():
    try:
        xbmcgui.Dialog().notification(
            "Ikarus / Trakt.TV",
            "Nejste p\u0159ipojeni na Trakt.TV. Nejd\u0159\u00edv se p\u0159ipojte v nastaven\u00ed.",
            xbmcgui.NOTIFICATION_WARNING,
            3500,
            sound=False,
        )
    except Exception:
        pass


def show_trakt(restore_state=None):
    if not trakt_client.is_connected():
        notify_not_connected()
        return {"action": "__back__"}
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusTraktDialog(
            "DialogIkarusTrakt.xml",
            addon_path,
            "Default",
            "720p",
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][trakt] Dialog failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

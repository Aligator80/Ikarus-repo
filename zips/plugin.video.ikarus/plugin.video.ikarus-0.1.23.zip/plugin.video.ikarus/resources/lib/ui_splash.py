# -*- coding: utf-8 -*-
"""Short startup splash screen for the Ikarus skin."""

import time

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath


SPLASH_MS = 4000
_active_dialog = None
_shown_at = 0.0


class IkarusSplashDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.duration_ms = int(kwargs.pop("duration_ms", SPLASH_MS) or SPLASH_MS)
        self.keep_open = bool(kwargs.pop("keep_open", False))
        super().__init__(*args, **kwargs)

    def onInit(self):
        if self.keep_open:
            return
        try:
            monitor = xbmc.Monitor()
            if monitor.waitForAbort(max(250, self.duration_ms) / 1000.0):
                self.close()
                return
        except Exception:
            xbmc.sleep(max(250, self.duration_ms))
        self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = 0
        if action_id in (7, 9, 10, 92, 216, 257, 275, 61467):
            self.close()


def show_splash(duration_ms=SPLASH_MS, keep_open=False):
    global _active_dialog, _shown_at
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        close_splash(min_duration_ms=0)
        dialog = IkarusSplashDialog(
            "DialogIkarusSplash.xml",
            addon_path,
            "Default",
            "720p",
            duration_ms=duration_ms,
            keep_open=keep_open,
        )
        if keep_open:
            _active_dialog = dialog
            _shown_at = time.monotonic()
            dialog.show()
            xbmc.log(
                "[IKARUS][SPLASH] shown keep_open duration_ms=%d" % int(duration_ms),
                xbmc.LOGINFO,
            )
            return True
        dialog.doModal()
        try:
            del dialog
        except Exception:
            pass
        return True
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][splash] Startup splash failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        _active_dialog = None
        _shown_at = 0.0
        return False


def close_splash(min_duration_ms=SPLASH_MS):
    global _active_dialog, _shown_at
    dialog = _active_dialog
    if dialog is None:
        return

    try:
        remaining = max(
            0.0,
            (max(0, int(min_duration_ms or 0)) / 1000.0)
            - (time.monotonic() - _shown_at),
        )
        if remaining:
            try:
                xbmc.Monitor().waitForAbort(remaining)
            except Exception:
                xbmc.sleep(int(remaining * 1000))
        dialog.close()
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][splash] Startup splash close failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
    finally:
        _active_dialog = None
        _shown_at = 0.0


def is_active():
    return _active_dialog is not None


def remaining_ms(duration_ms=SPLASH_MS):
    if _active_dialog is None:
        return 0
    elapsed_ms = int(max(0.0, time.monotonic() - _shown_at) * 1000)
    return max(0, int(duration_ms or 0) - elapsed_ms)

# -*- coding: utf-8 -*-
"""Cinema styled download queue dialog."""

import os
import time

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import download_manager
from resources.lib import i18n
from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}

JOBS_CONTROL = 401
REFRESH_CONTROL = 201
CLEAR_DONE_CONTROL = 202
CLEAR_ALL_CONTROL = 203
CURRENT_BAR_CONTROL = 60
CURRENT_BAR_WIDTH = 780


def _status_label(status):
    labels = {
        "queued": "Čeká",
        "downloading": "Stahuje se",
        "done": "Dokončeno",
        "error": "Chyba",
    }
    status = str(status or "").strip().lower()
    return labels.get(status, status.capitalize() or "Neznámý stav")


def _progress(job):
    try:
        return max(0, min(100, int(job.get("progress") or 0)))
    except Exception:
        return 0


def _queue_signature(jobs):
    return tuple(
        (
            str(job.get("id") or ""),
            str(job.get("status") or ""),
            _progress(job),
            str(job.get("error") or ""),
        )
        for job in (jobs or [])
        if isinstance(job, dict)
    )


class IkarusDownloadsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.jobs = []
        self._signature = ()
        self._last_action_at = 0.0

    def onInit(self):
        self._set_static_art()
        self._reload(keep_position=False)
        try:
            self.setFocusId(JOBS_CONTROL if self.jobs else REFRESH_CONTROL)
        except Exception:
            pass

    def _set_static_art(self):
        try:
            splash = translatePath(
                os.path.join(
                    xbmcaddon.Addon().getAddonInfo("path"),
                    "resources",
                    "skins",
                    "Default",
                    "media",
                    "ikarus_startup_splash.png",
                )
            )
            self.getControl(10).setImage(splash)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Fronta stahování")

    def _counts(self):
        counts = {"queued": 0, "downloading": 0, "done": 0, "error": 0}
        for job in self.jobs:
            status = str(job.get("status") or "").strip().lower()
            if status in counts:
                counts[status] += 1
        return counts

    def _job_item(self, job):
        title = str(job.get("title") or i18n.T(30728, "Source"))
        provider = str(job.get("provider") or "").strip()
        status = str(job.get("status") or "").strip().lower()
        error = str(job.get("error") or "").strip()
        subtitle = provider or "Ikarus"
        if error:
            subtitle += "  |  " + error

        item = xbmcgui.ListItem(label=title)
        try:
            item.setProperty("Provider", subtitle)
            item.setProperty("Status", status)
            item.setProperty("StatusLabel", _status_label(status))
            item.setProperty("Progress", "%d %%" % _progress(job))
            item.setArt(ui_theme.provider_art(provider, "DefaultVideo.png"))
        except Exception:
            pass
        return item

    def _empty_item(self):
        item = xbmcgui.ListItem(label="Fronta je prázdná")
        try:
            item.setProperty("Provider", "Zatím nejsou uloženy žádné položky ke stažení.")
            item.setProperty("Status", "empty")
            item.setProperty("StatusLabel", "")
            item.setProperty("Progress", "")
            item.setArt({"icon": "DefaultAddonProgram.png", "thumb": "DefaultAddonProgram.png"})
        except Exception:
            pass
        return item

    def _reload(self, keep_position=True):
        try:
            position = int(self.getControl(JOBS_CONTROL).getSelectedPosition()) if keep_position else 0
        except Exception:
            position = 0

        self.jobs = [dict(job) for job in (download_manager.get_jobs() or []) if isinstance(job, dict)]
        self._signature = _queue_signature(self.jobs)
        counts = self._counts()

        for control_id, key in ((40, "queued"), (41, "downloading"), (42, "done"), (43, "error")):
            try:
                self.getControl(control_id).setLabel(str(counts.get(key, 0)))
            except Exception:
                pass

        current = next(
            (job for job in self.jobs if str(job.get("status") or "").strip().lower() == "downloading"),
            None,
        )
        self._set_current(current)

        control = self.getControl(JOBS_CONTROL)
        control.reset()
        if self.jobs:
            for job in self.jobs:
                control.addItem(self._job_item(job))
            control.selectItem(max(0, min(position, len(self.jobs) - 1)))
        else:
            control.addItem(self._empty_item())
            control.selectItem(0)

    def _set_current(self, current):
        if current:
            title = str(current.get("title") or i18n.T(30728, "Source"))
            provider = str(current.get("provider") or "Ikarus")
            progress = _progress(current)
            heading = "Právě se stahuje: %s" % title
            detail = "%s   |   %d %%" % (provider, progress)
            width = max(8, int(round(CURRENT_BAR_WIDTH * progress / 100.0)))
        else:
            heading = "Právě se nic nestahuje"
            detail = "Položky ve frontě se spustí automaticky."
            width = 8
        try:
            self.getControl(30).setLabel(heading)
            self.getControl(31).setLabel(detail)
            self.getControl(CURRENT_BAR_CONTROL).setWidth(width)
        except Exception:
            pass

    def _refresh_if_changed(self):
        try:
            jobs = download_manager.get_jobs() or []
            if _queue_signature(jobs) != self._signature:
                self._reload(keep_position=True)
        except Exception:
            pass

    def _clear_done(self):
        removed = download_manager.remove_done_jobs()
        xbmcgui.Dialog().notification(
            "Ikarus",
            "Odstraněno dokončených položek: %d" % removed,
            xbmcgui.NOTIFICATION_INFO,
            2500,
            sound=False,
        )
        self._reload(keep_position=True)

    def _clear_all(self):
        if not self.jobs:
            return
        if not xbmcgui.Dialog().yesno(
            "Vymazat frontu stahování",
            "Opravdu chcete odstranit všechny položky? Probíhající stahování bude ukončeno.",
        ):
            return
        removed = download_manager.remove_all_jobs()
        xbmcgui.Dialog().notification(
            "Ikarus",
            "Fronta byla vymazána: %d položek" % removed,
            xbmcgui.NOTIFICATION_INFO,
            2500,
            sound=False,
        )
        self._reload(keep_position=False)
        try:
            self.setFocusId(REFRESH_CONTROL)
        except Exception:
            pass

    def _activate(self, control_id):
        now = time.monotonic()
        if now - self._last_action_at < 0.25:
            return
        self._last_action_at = now
        if control_id == 100:
            self.close()
        elif control_id == REFRESH_CONTROL:
            self._reload(keep_position=True)
        elif control_id == CLEAR_DONE_CONTROL:
            self._clear_done()
        elif control_id == CLEAR_ALL_CONTROL:
            self._clear_all()

    def onClick(self, control_id):
        self._activate(int(control_id or 0))

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.close()
            return
        if action_id in OPEN_ACTIONS:
            try:
                self._activate(int(self.getFocusId()))
                return
            except Exception:
                pass
        super().onAction(action)
        self._refresh_if_changed()


def show_downloads():
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusDownloadsDialog(
            "DialogIkarusDownloads.xml",
            addon_path,
            "Default",
            "720p",
        )
        dialog.doModal()
        try:
            del dialog
        except Exception:
            pass
        return True
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][downloads] Cinema queue failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return False

# -*- coding: utf-8 -*-
"""Cinema source results dialog."""

import xbmc
import xbmcaddon
import xbmcgui
import json
from xbmcvfs import translatePath

from resources.lib import ui_theme
from resources.lib import Hledani_zdroje


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}
RESULTS_CONTROL = 401
LOADING_ICON_CONTROL = 50
LOADING_STATUS_CONTROL = 51
LOADING_DETAIL_CONTROL = 52
LOADING_BAR_CONTROL = 54
LOADING_BAR_WIDTH = 560


def _title(query):
    return str((query or {}).get("title") or (query or {}).get("media_title") or "Titul").strip()


def _provider_label(query):
    label = str((query or {}).get("provider_label") or "").strip()
    if label:
        return label
    provider = str((query or {}).get("provider") or "all").strip().lower()
    names = {
        "all": "Vse",
        "webshare": "WebShare",
        "prehrajto": "Prehraj.to",
        "hellspy": "Hellspy",
        "sktonline": "SkTonLine",
    }
    return names.get(provider, provider or "Zdroje")


class IkarusSourceResultsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.query = dict(kwargs.pop("query", {}) or {})
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self.rows = []
        self._selection_committed = False

    def onInit(self):
        self._set_static_art()
        self._set_loading(True)
        try:
            self._load()
            self._fill()
        finally:
            self._set_loading(False)
        self._restore_focus()

    def _set_static_art(self):
        try:
            bg = str(self.query.get("fanart") or self.query.get("poster") or "").strip() or ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Zdroje", _provider_label(self.query))
        try:
            self.getControl(30).setLabel(_title(self.query))
            self.getControl(31).setLabel("Provider: %s" % _provider_label(self.query))
        except Exception:
            pass

    def _load(self):
        try:
            provider = str(self.query.get("provider") or "all")
            self.rows = Hledani_zdroje.cinema_source_results(
                self.query,
                provider=provider,
                progress_callback=self._update_search_progress,
            )
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][source_results] load failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass
            self.rows = []

    def _set_loading(self, active):
        try:
            self.setProperty("IkarusSourceSearchActive", "true" if active else "false")
        except Exception:
            pass
        if not active:
            return
        try:
            art = ui_theme.provider_art(self.query.get("provider") or "all", "DefaultAddonsSearch.png")
            self.getControl(LOADING_ICON_CONTROL).setImage(art.get("icon") or "DefaultAddonsSearch.png")
        except Exception:
            pass
        try:
            self.getControl(LOADING_STATUS_CONTROL).setLabel("Připravuji hledání zdrojů...")
            self.getControl(LOADING_DETAIL_CONTROL).setLabel("Čekejte prosím")
            self.getControl(LOADING_BAR_CONTROL).setWidth(8)
        except Exception:
            pass

    def _update_search_progress(self, state):
        state = dict(state or {})
        phase = str(state.get("phase") or "")
        provider_label = str(state.get("provider_label") or "").strip()
        try:
            completed = max(0, int(state.get("completed") or 0))
            total = max(0, int(state.get("total") or 0))
            results = max(0, int(state.get("results") or 0))
        except Exception:
            completed, total, results = 0, 0, 0

        if phase == "search" and provider_label:
            status = "Prohledávám: %s" % provider_label
        elif phase == "provider_done" and provider_label:
            status = "%s dokončeno" % provider_label
        elif phase == "done":
            status = "Dokončuji hledání..."
        else:
            status = "Hledám dostupné zdroje..."

        if total:
            percent = int(round((float(completed) / float(total)) * 100.0))
            if phase == "search":
                percent = min(95, max(4, percent))
            detail = "Poskytovatel %d z %d   |   Nalezeno zdrojů: %d" % (
                min(completed + (1 if phase == "search" else 0), total),
                total,
                results,
            )
        else:
            percent = 100 if phase == "done" else 4
            detail = "Nalezeno zdrojů: %d" % results

        try:
            self.getControl(LOADING_STATUS_CONTROL).setLabel(status)
            self.getControl(LOADING_DETAIL_CONTROL).setLabel(detail)
            width = max(8, int(round(LOADING_BAR_WIDTH * min(100, max(0, percent)) / 100.0)))
            self.getControl(LOADING_BAR_CONTROL).setWidth(width)
        except Exception:
            pass

    def _result_item(self, row):
        label = row.get("label") or ""
        item = xbmcgui.ListItem(label=label)
        try:
            item.setLabel2(row.get("subtitle") or "")
        except Exception:
            pass
        art = ui_theme.provider_art(row.get("provider") or "", "DefaultVideo.png")
        try:
            item.setArt(art)
            item.setInfo("video", {"title": label, "plot": row.get("plot") or ""})
            item.setProperty("provider", row.get("provider") or "")
        except Exception:
            pass
        return item

    def _empty_item(self):
        item = xbmcgui.ListItem(label="Nic nenalezeno")
        try:
            item.setProperty("IkarusEmpty", "1")
            item.setLabel2(_provider_label(self.query))
            item.setArt({"icon": "DefaultAddonProgram.png", "thumb": "DefaultAddonProgram.png"})
        except Exception:
            pass
        return item

    def _fill(self):
        control = self.getControl(RESULTS_CONTROL)
        control.reset()
        if not self.rows:
            control.addItem(self._empty_item())
            return
        for row in self.rows:
            control.addItem(self._result_item(row))

    def _restore_focus(self):
        try:
            pos = int(self.restore_state.get("selected_index") or 0)
        except Exception:
            pos = 0
        pos = max(0, min(pos, max(0, len(self.rows) - 1)))
        try:
            control = self.getControl(RESULTS_CONTROL)
            control.selectItem(pos)
        except Exception:
            pass
        try:
            xbmc.sleep(50)
            self.setFocusId(RESULTS_CONTROL)
        except Exception:
            pass

    def _selected_row(self):
        if not self.rows:
            return {}
        try:
            pos = int(self.getControl(RESULTS_CONTROL).getSelectedPosition())
        except Exception:
            pos = 0
        pos = max(0, min(pos, len(self.rows) - 1))
        return dict(self.rows[pos] or {})

    def _parent_state(self):
        try:
            pos = int(self.getControl(RESULTS_CONTROL).getSelectedPosition())
        except Exception:
            pos = 0
        return {
            "query": dict(self.query or {}),
            "selected_index": max(0, pos),
        }

    def _return_query(self):
        query = {
            key: value
            for key, value in dict(self.query or {}).items()
            if not str(key).startswith("_cinema_") and isinstance(value, (str, int, float, bool))
        }
        query["action"] = "tmdb.sources.results"
        return query

    def _finish(self, query):
        # Kodi can deliver the select action to both onClick and onAction.
        # Commit it once so playback is never launched twice.
        if self._selection_committed:
            return
        self._selection_committed = True
        self.selected_query = dict(query or {})
        self.close()

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self._finish({"action": "__back__"})
            return
        if control_id != RESULTS_CONTROL:
            return
        row = self._selected_row()
        query = dict(row.get("query") or {})
        if not query:
            return
        if str(query.get("action") or "") == "tmdb.movie.source.play":
            # Let the controller close this modal dialog before it starts video.
            # It serializes the full Cinema stack for the post-playback return.
            try:
                query["cinema_return_query"] = json.dumps(
                    self._return_query(),
                    ensure_ascii=False,
                    separators=(",", ":"),
                )
            except Exception:
                pass
        query["_cinema_parent"] = self._parent_state()
        self._finish(query)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self._finish({"action": "__back__"})
            return
        if action_id in OPEN_ACTIONS:
            try:
                if int(self.getFocusId()) == RESULTS_CONTROL:
                    self.onClick(RESULTS_CONTROL)
                    return
            except Exception:
                pass
        super().onAction(action)


def show_source_results(query=None, restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusSourceResultsDialog(
            "DialogIkarusSourceResults.xml",
            addon_path,
            "Default",
            "720p",
            query=dict(query or {}),
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][source_results] dialog failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

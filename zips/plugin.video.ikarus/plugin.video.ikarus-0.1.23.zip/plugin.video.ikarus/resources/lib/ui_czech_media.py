# -*- coding: utf-8 -*-
"""Cinema screen with newest Czech movies and series."""

import datetime

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}
MOVE_UP = 3
MOVE_DOWN = 4
ROW_CONTROLS = {
    "movies": 401,
    "series": 406,
}
CONTROL_ROWS = {
    401: "movies",
    406: "series",
}
PAGE_SCAN_LIMIT = 3
ROW_LIMIT = 20
CZECH_ORIGINAL_LANGUAGE = "cs"


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _today():
    return datetime.date.today().isoformat()


def _image_url(path, size="poster"):
    path = (path or "").strip()
    if not path:
        return ""
    if path.lower().startswith(("http://", "https://")):
        return path
    tmdb = _tmdb()
    base = tmdb.TMDB_IMAGE_THUMB_BASE if size == "backdrop" else tmdb.TMDB_IMAGE_BASE
    return base + path


def _title(row, media_type):
    tmdb = _tmdb()
    if media_type == "tv":
        fallback = row.get("name") or row.get("original_name") or ""
    else:
        fallback = row.get("title") or row.get("original_title") or ""
    try:
        return tmdb._tmdb_display_title(row, media_type, fallback, fetch_alternatives=False)
    except Exception:
        return fallback or "Nezn\u00e1m\u00fd titul"


def _date(row, media_type):
    return (row.get("first_air_date") if media_type == "tv" else row.get("release_date")) or ""


def _valid_premiere(row, media_type, today):
    value = _date(row, media_type).strip()
    if len(value) != 10:
        return False
    return value <= today


def _rating(row):
    try:
        value = float(row.get("vote_average") or 0)
    except Exception:
        value = 0
    return "%.1f" % value if value else ""


def _join_names(rows, key="name", limit=4):
    names = []
    for row in rows or []:
        value = row.get(key) if isinstance(row, dict) else ""
        value = (value or "").strip()
        if value:
            names.append(value)
        if len(names) >= limit:
            break
    return ", ".join(names)


def _query(row, media_type):
    title = _title(row, media_type)
    if media_type == "tv":
        return {
            "action": "tmdb.tv.detail.open",
            "id": str(row.get("id") or ""),
            "title": title,
            "original_title": row.get("original_name") or "",
            "return_action": "tmdb.czech",
        }
    return {
        "action": "tmdb.movie.detail.open",
        "id": str(row.get("id") or ""),
        "title": title,
        "original_title": row.get("original_title") or "",
        "return_action": "tmdb.czech",
    }


def _normalize_row(row, media_type):
    premiere = _date(row, media_type)
    return {
        "id": row.get("id") or "",
        "title": _title(row, media_type),
        "original_title": row.get("original_name" if media_type == "tv" else "original_title") or "",
        "plot": row.get("overview") or "",
        "premiere": premiere,
        "year": premiere[:4] if len(premiere) >= 4 else "",
        "rating": _rating(row),
        "poster": _image_url(row.get("poster_path"), "poster"),
        "fanart": _image_url(row.get("backdrop_path"), "backdrop"),
        "genres": "",
        "seasons": "",
        "episodes": "",
        "media_type": media_type,
        "media_label": "Seri\u00e1l" if media_type == "tv" else "Film",
        "query": _query(row, media_type),
    }


def _sort_newest(rows):
    rows = list(rows or [])
    rows.sort(key=lambda item: str(item.get("premiere") or ""), reverse=True)
    return rows


def _fetch_row(media_type):
    tmdb = _tmdb()
    today = _today()
    if media_type == "tv":
        endpoint = "/discover/tv"
        params = {
            "language": tmdb.TMDB_LANGUAGE,
            "page": "1",
            "sort_by": "first_air_date.desc",
            "first_air_date.lte": today,
            "with_original_language": CZECH_ORIGINAL_LANGUAGE,
            "include_adult": "false",
        }
    else:
        endpoint = "/discover/movie"
        params = {
            "language": tmdb.TMDB_LANGUAGE,
            "region": tmdb.TMDB_REGION,
            "page": "1",
            "sort_by": "primary_release_date.desc",
            "primary_release_date.lte": today,
            "with_original_language": CZECH_ORIGINAL_LANGUAGE,
            "include_adult": "false",
            "include_video": "false",
        }

    rows = []
    for page in range(1, PAGE_SCAN_LIMIT + 1):
        try:
            params["page"] = str(page)
            data = tmdb._tmdb_get(endpoint, params, timeout=tmdb.TMDB_MENU_TIMEOUT, retries=0)
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][czech] TMDB fetch failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass
            break
        for row in data.get("results") or []:
            if row.get("id") and _valid_premiere(row, media_type, today):
                rows.append(_normalize_row(row, media_type))
            if len(rows) >= ROW_LIMIT:
                return _sort_newest(rows)[:ROW_LIMIT]
        try:
            total_pages = int(data.get("total_pages") or 1)
        except Exception:
            total_pages = 1
        if page >= total_pages:
            break
    return _sort_newest(rows)[:ROW_LIMIT]


class IkarusCzechMediaDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self.rows = {"movies": [], "series": []}
        self.focused_row = "movies"
        self._detail_cache = {}

    def onInit(self):
        self._set_static_art()
        self._load()
        self._fill()
        focus_id = int(self.restore_state.get("focus_id") or 401)
        if focus_id not in CONTROL_ROWS:
            focus_id = 401 if self.rows.get("movies") else 406
        try:
            self.setFocusId(focus_id)
        except Exception:
            pass
        self._set_detail(self._selected_detail(focus_id) or {})

    def _set_static_art(self):
        try:
            bg = ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "\u010cesk\u00e9 filmy a seri\u00e1ly")

    def _load(self):
        self.rows = {
            "movies": _fetch_row("movie"),
            "series": _fetch_row("tv"),
        }

    def _fill(self):
        for row_key, control_id in ROW_CONTROLS.items():
            try:
                control = self.getControl(control_id)
                control.reset()
                for row in self.rows.get(row_key) or []:
                    control.addItem(self._list_item(row))
                selected_index = int(self.restore_state.get("%s_index" % row_key) or 0)
                rows = self.rows.get(row_key) or []
                if rows:
                    control.selectItem(max(0, min(selected_index, len(rows) - 1)))
            except Exception as exc:
                try:
                    xbmc.log("[Ikarus][czech] Fill row %s failed: %s" % (control_id, exc), xbmc.LOGWARNING)
                except Exception:
                    pass

    def _list_item(self, row):
        item = xbmcgui.ListItem(label=row.get("title") or "")
        fallback_key = "tmdb.series" if row.get("media_type") == "tv" else "tmdb.movies"
        poster = row.get("poster") or ui_theme.action_art(fallback_key).get("poster") or ""
        fanart = row.get("fanart") or ui_theme.fallback_fanart()
        try:
            item.setArt({"poster": poster, "thumb": poster, "icon": poster, "fanart": fanart or ""})
        except Exception:
            pass
        return item

    def _selected_from_row(self, control_id):
        row_key = CONTROL_ROWS.get(int(control_id or 0), self.focused_row)
        rows = self.rows.get(row_key) or []
        if not rows:
            return None
        try:
            index = int(self.getControl(ROW_CONTROLS[row_key]).getSelectedPosition())
        except Exception:
            index = 0
        if index < 0 or index >= len(rows):
            index = 0
        self.focused_row = row_key
        return rows[index]

    def _detail_cache_key(self, row):
        media_type = str((row or {}).get("media_type") or "")
        tmdb_id = str((row or {}).get("id") or "")
        return "%s:%s" % (media_type, tmdb_id)

    def _selected_detail(self, control_id):
        return self._item_with_detail(self._selected_from_row(control_id) or {})

    def _item_with_detail(self, row):
        if not row:
            return {}
        cache_key = self._detail_cache_key(row)
        if cache_key in self._detail_cache:
            return self._detail_cache[cache_key]
        merged = dict(row)
        tmdb_id = str(row.get("id") or "").strip()
        media_type = str(row.get("media_type") or "").strip()
        if not tmdb_id:
            self._detail_cache[cache_key] = merged
            return merged
        endpoint = "/tv/%s" % tmdb_id if media_type == "tv" else "/movie/%s" % tmdb_id
        try:
            tmdb = _tmdb()
            detail = tmdb._tmdb_get(
                endpoint,
                {"language": tmdb.TMDB_LANGUAGE},
                timeout=5,
                retries=0,
            )
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][czech] Detail fetch failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass
            detail = {}
        if detail:
            merged["plot"] = detail.get("overview") or merged.get("plot") or ""
            merged["genres"] = _join_names(detail.get("genres") or [])
            merged["rating"] = _rating(detail) or merged.get("rating") or ""
            if media_type == "tv":
                merged["premiere"] = detail.get("first_air_date") or merged.get("premiere") or ""
                if detail.get("number_of_seasons"):
                    merged["seasons"] = str(detail.get("number_of_seasons"))
                if detail.get("number_of_episodes"):
                    merged["episodes"] = str(detail.get("number_of_episodes"))
            else:
                merged["premiere"] = detail.get("release_date") or merged.get("premiere") or ""
            if detail.get("poster_path"):
                merged["poster"] = _image_url(detail.get("poster_path"), "poster")
            if detail.get("backdrop_path"):
                merged["fanart"] = _image_url(detail.get("backdrop_path"), "backdrop")
        self._detail_cache[cache_key] = merged
        return merged

    def _restore_payload(self, focus_id):
        payload = {"focus_id": int(focus_id or 401)}
        for row_key, control_id in ROW_CONTROLS.items():
            try:
                payload["%s_index" % row_key] = max(0, int(self.getControl(control_id).getSelectedPosition()))
            except Exception:
                payload["%s_index" % row_key] = 0
        return payload

    def _set_empty(self):
        try:
            self.getControl(30).setLabel("\u010cesk\u00e9 filmy a seri\u00e1ly")
            self.getControl(31).setLabel("")
            self.getControl(32).setText("\u017d\u00e1dn\u00e9 premi\u00e9rovan\u00e9 \u010desk\u00e9 tituly se nepoda\u0159ilo na\u010d\u00edst.")
        except Exception:
            pass

    def _set_detail(self, row):
        if not row:
            self._set_empty()
            return
        details = []
        if row.get("premiere"):
            details.append("Premi\u00e9ra: %s" % row.get("premiere"))
        if row.get("genres"):
            details.append("\u017d\u00e1nr: %s" % row.get("genres"))
        details.append(
            "Hodnocen\u00ed: * %s" % row.get("rating")
            if row.get("rating")
            else "Hodnocen\u00ed: Nehodnoceno"
        )
        if row.get("media_type") == "tv" and (row.get("seasons") or row.get("episodes")):
            details.append(
                "S\u00e9rie / epizody: %s / %s"
                % (row.get("seasons") or "-", row.get("episodes") or "-")
            )
        if row.get("original_title") and row.get("original_title") != row.get("title"):
            details.append("Original: %s" % row.get("original_title"))
        plot = row.get("plot") or ""
        if plot:
            if details:
                details.append("")
            details.append(plot)
        try:
            self.getControl(30).setLabel(row.get("title") or "")
            self.getControl(31).setLabel("")
            self.getControl(32).setText("\n".join(details))
            fanart = row.get("fanart") or ui_theme.fallback_fanart()
            if fanart:
                self.getControl(11).setImage(fanart)
        except Exception:
            pass

    def onFocus(self, control_id):
        if int(control_id or 0) in CONTROL_ROWS:
            self._set_detail(self._selected_detail(control_id) or {})

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if control_id in CONTROL_ROWS:
            row = self._selected_from_row(control_id)
            if not row:
                return
            self.selected_query = dict(row.get("query") or {})
            self.selected_query["_cinema_parent"] = self._restore_payload(control_id)
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if action_id == MOVE_UP:
            try:
                if int(self.getFocusId()) == 406:
                    self.setFocusId(401)
                    return
            except Exception:
                pass
        if action_id == MOVE_DOWN:
            try:
                if int(self.getFocusId()) == 401:
                    self.setFocusId(406)
                    return
            except Exception:
                pass
        if action_id in OPEN_ACTIONS:
            try:
                focus_id = int(self.getFocusId())
            except Exception:
                focus_id = 0
            if focus_id in CONTROL_ROWS:
                self._set_detail(self._selected_detail(focus_id) or {})
        super().onAction(action)
        try:
            focus_id = int(self.getFocusId())
            if focus_id in CONTROL_ROWS:
                self._set_detail(self._selected_detail(focus_id) or {})
        except Exception:
            pass


def show_czech_media(restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusCzechMediaDialog(
            "DialogIkarusCzechMedia.xml",
            addon_path,
            "Default",
            "720p",
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][czech] Dialog failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

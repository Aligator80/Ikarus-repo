# -*- coding: utf-8 -*-
"""Merge a completed remote operation into data edited while it was running."""
import copy

_MISSING = object()


def _key(row, items=False):
    if items:
        return str(row.get("media_type") or "") + ":" + str(row.get("tmdb_id") or "")
    return str(row.get("id") or "")


def _records(rows, items=False):
    return {_key(row, items): row for row in rows or [] if isinstance(row, dict)}


def _merge_fields(base, incoming, current):
    merged = copy.deepcopy(current)
    for field in set(base) | set(incoming):
        before = base.get(field, _MISSING)
        after = incoming.get(field, _MISSING)
        now = current.get(field, _MISSING)
        if field in ("items", "deleted_items"):
            merged[field] = merge_records(base.get(field), incoming.get(field), current.get(field), items=True, membership=(field == "items"))
        elif after != before and now == before:
            if after is _MISSING:
                merged.pop(field, None)
            else:
                merged[field] = copy.deepcopy(after)
    if "items" in merged:
        deleted = set(_records(merged.get("deleted_items"), items=True))
        merged["items"] = [item for item in merged["items"] if _key(item, True) not in deleted]
        if current.get("local_revision") != base.get("local_revision"):
            merged["sync_state"] = "pending"
            if any(current.get(k) != base.get(k) for k in ("name", "trakt_description", "trakt_privacy")):
                merged["metadata_pending"] = True
    return merged


def merge_records(base_rows, incoming_rows, current_rows, items=False, membership=False):
    base = _records(base_rows, items)
    incoming = _records(incoming_rows, items)
    current = _records(current_rows, items)
    result = []
    for key, row in current.items():
        if key not in base:
            result.append(copy.deepcopy(row))
        elif key not in incoming:
            # Only acknowledge exactly the deletion/record seen before the request.
            changed = row.get("sync_add_id") != base[key].get("sync_add_id") if membership else row != base[key]
            if changed:
                result.append(copy.deepcopy(row))
        else:
            result.append(_merge_fields(base[key], incoming[key], row))
    for key, row in incoming.items():
        if key not in base and key not in current:
            result.append(copy.deepcopy(row))
    return result


def merge_snapshot(base, incoming, current, owner):
    """All three views refer to one account; preserve local deletes and new edits."""
    merged = copy.deepcopy(current)
    merged["lists"] = merge_records(base.get("lists"), incoming.get("lists"), current.get("lists"))
    merged["deleted_lists"] = merge_records(base.get("deleted_lists"), incoming.get("deleted_lists"), current.get("deleted_lists"))
    incoming_lists = _records(incoming.get("lists"))
    # A list can be deleted locally while its remote creation is in flight.
    # Keep the returned remote link on the tombstone so the next run can delete it.
    for tomb in merged["deleted_lists"]:
        remote = incoming_lists.get(_key(tomb)) or {}
        for field in ("trakt_slug", "trakt_id", "trakt_username"):
            if not tomb.get(field) and remote.get(field):
                tomb[field] = remote[field]
    tombs = merged["deleted_lists"]
    merged["lists"] = [row for row in merged["lists"] if not any(
        _key(row) == _key(tomb)
        or (row.get("trakt_id") and row.get("trakt_id") == tomb.get("trakt_id"))
        or (row.get("trakt_slug") and row.get("trakt_slug") == tomb.get("trakt_slug"))
        for tomb in tombs)]
    for row in merged["lists"] + merged["deleted_lists"]:
        if row.get("trakt_account_id") != owner:
            raise ValueError("Cannot merge lists owned by another Trakt account")
    return merged

# -*- coding: utf-8 -*-
"""Home item factory shared by Cinema entry points."""

import datetime

from resources.lib import TMDB_knihovna
from resources.lib import i18n
from resources.lib import ui_theme


def cinema_home_items():
    def themed(key, fallback_icon="DefaultFolder.png"):
        return ui_theme.action_art(key, fallback_icon)

    def tmdb_image(endpoint, params=None, prefer="poster"):
        try:
            data = TMDB_knihovna._tmdb_get(
                endpoint,
                params or {"language": "cs-CZ", "region": "CZ", "page": "1"},
                timeout=4,
                retries=0,
            )
            rows = data.get("results") or []
        except Exception:
            rows = []
        for row in rows:
            poster = (row.get("poster_path") or "").strip()
            backdrop = (row.get("backdrop_path") or "").strip()
            if prefer == "backdrop" and backdrop:
                return TMDB_knihovna.TMDB_IMAGE_THUMB_BASE + backdrop
            if poster:
                return TMDB_knihovna.TMDB_IMAGE_BASE + poster
            if backdrop:
                return TMDB_knihovna.TMDB_IMAGE_THUMB_BASE + backdrop
        return ""

    movie_img = tmdb_image("/movie/now_playing", prefer="poster")
    series_img = tmdb_image("/tv/popular", {"language": "cs-CZ", "page": "1"}, prefer="poster")
    czech_img = tmdb_image(
        "/discover/movie",
        {
            "language": "cs-CZ",
            "region": "CZ",
            "page": "1",
            "sort_by": "primary_release_date.desc",
            "primary_release_date.lte": datetime.date.today().isoformat(),
            "with_original_language": "cs",
            "include_adult": "false",
            "include_video": "false",
        },
        prefer="poster",
    )
    continue_img = tmdb_image("/trending/all/day", {"language": "cs-CZ", "page": "1"}, prefer="backdrop")

    return [
        {"control_id": 101, "label": i18n.T(31996, "Continue watching"), "subtitle": i18n.T(30305, "In progress"), "query": {"action": "tmdb.started"}, "art": themed("continue"), "image": continue_img},
        {"control_id": 102, "label": i18n.T(30300, "Movies"), "subtitle": i18n.T(30400, "News"), "query": {"action": "tmdb.movies"}, "art": themed("tmdb.movies"), "image": movie_img},
        {"control_id": 103, "label": i18n.T(30301, "Series"), "subtitle": i18n.T(30401, "Popular"), "query": {"action": "tmdb.series"}, "art": themed("tmdb.series"), "image": series_img},
        {"control_id": 104, "label": "\u010cesk\u00e9 filmy a seri\u00e1ly", "subtitle": "Nejnov\u011bj\u0161\u00ed premi\u00e9ry", "query": {"action": "tmdb.czech"}, "art": themed("tmdb.czech"), "image": czech_img},
        {"control_id": 105, "label": "Seznamy", "subtitle": i18n.T(32001, "Your local and synchronized watch lists."), "query": {"action": "tmdb.custom.lists"}, "art": themed("tmdb.custom.lists")},
        {"control_id": 106, "label": i18n.T(30307, "Search"), "subtitle": i18n.T(32002, "Search movies, series and people from one place."), "query": {"action": "tmdb.search"}, "art": themed("tmdb.search")},
        {"control_id": 107, "label": "Trakt.TV", "subtitle": "Trakt.TV", "query": {"action": "tmdb.trakt.lists"}, "art": themed("tmdb.trakt.lists")},
        {"control_id": 108, "label": i18n.T(30308, "Download queue"), "subtitle": i18n.T(32004, "Downloads and saved source files."), "query": {"action": "tmdb.downloads.queue"}, "art": themed("tmdb.downloads.queue")},
        {"control_id": 109, "label": i18n.T(30310, "Settings"), "subtitle": i18n.T(32007, "Accounts, playback, downloads and appearance."), "query": {"action": "settings"}, "art": themed("settings")},
    ]

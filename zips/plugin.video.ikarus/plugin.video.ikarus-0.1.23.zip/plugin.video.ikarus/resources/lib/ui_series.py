# -*- coding: utf-8 -*-
"""Fullscreen series browser for the Ikarus Cinema theme."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import i18n
from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
MOVE_LEFT = 1
MOVE_RIGHT = 2
ACTION_MOUSE_DRAG = 106
ACTION_MOUSE_LEFT_RELEASE = 108
ACTION_MOUSE_DRAG_END = 109
ACTION_GESTURE_BEGIN = 501
ACTION_GESTURE_ABORT = 505
POSTER_BUTTONS = list(range(401, 411))
ROW_CONTROLS = {
    "day": 401,
    "week": 406,
}
CONTROL_ROWS = {
    401: "day",
    406: "week",
}
SWIPE_STEP = 1
DRAG_STEP_DISTANCE = 120
TAB_BUTTONS = {
    111: "popular",
    112: "top_rated",
    113: "genre",
    114: "year",
    115: "country",
    116: "search",
}


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _image_url(path, size="poster"):
    path = (path or "").strip()
    if not path:
        return ""
    if path.lower().startswith(("http://", "https://")):
        return path
    tmdb = _tmdb()
    base = tmdb.TMDB_IMAGE_THUMB_BASE if size == "backdrop" else tmdb.TMDB_IMAGE_BASE
    return base + path


def _title(item):
    tmdb = _tmdb()
    try:
        return tmdb._tmdb_display_title(item, "tv", item.get("name") or "", fetch_alternatives=False)
    except Exception:
        return item.get("name") or item.get("original_name") or i18n.T(31941, "Neznámý")


def _series_query(item, action="tmdb.tv.detail.open"):
    query = {
        "action": action,
        "id": str(item.get("id") or ""),
        "title": _title(item),
        "original_title": item.get("original_name") or "",
    }
    if action == "tmdb.tv.detail.open":
        query["return_action"] = "tmdb.series"
    return query


def _meta_text(item):
    parts = []
    first_air = item.get("first_air_date") or ""
    if len(first_air) >= 4 and first_air[:4].isdigit():
        parts.append(first_air[:4])
    rating = item.get("vote_average") or 0
    try:
        rating = float(rating)
    except Exception:
        rating = 0
    if rating:
        parts.append("* %.1f" % rating)
    return "  |  ".join(parts)


def _join_names(rows, key="name", limit=4):
    names = []
    for row in rows or []:
        value = row.get(key) if isinstance(row, dict) else ""
        value = (value or "").strip()
        if value:
            names.append(value)
        if len(names) >= limit:
            break
    return ", ".join(names)


COUNTRY_NAMES = {
    "US": "USA",
    "GB": "Velk\u00e1 Brit\u00e1nie",
    "CZ": "\u010cesko",
    "SK": "Slovensko",
    "JP": "Japonsko",
    "KR": "Ji\u017en\u00ed Korea",
    "FR": "Francie",
    "DE": "N\u011bmecko",
    "ES": "\u0160pan\u011blsko",
    "IT": "It\u00e1lie",
    "CA": "Kanada",
    "AU": "Austr\u00e1lie",
}


def _country_names(item, limit=4):
    countries = _join_names((item or {}).get("production_countries") or [], limit=limit)
    if countries:
        return countries
    names = []
    for code in (item or {}).get("origin_country") or []:
        code = str(code or "").strip().upper()
        if code:
            names.append(COUNTRY_NAMES.get(code, code))
        if len(names) >= limit:
            break
    return ", ".join(names)


def _runtime_text(minutes):
    try:
        minutes = int(minutes or 0)
    except Exception:
        minutes = 0
    if minutes <= 0:
        return ""
    hours = minutes // 60
    rest = minutes % 60
    if hours and rest:
        return "%dh %02dm" % (hours, rest)
    if hours:
        return "%dh" % hours
    return "%dm" % rest


def _normalize_series(item):
    poster = _image_url(item.get("poster_path"), "poster")
    fanart = _image_url(item.get("backdrop_path"), "backdrop")
    return {
        "id": item.get("id") or "",
        "title": _title(item),
        "original_title": item.get("original_name") or "",
        "plot": item.get("overview") or "",
        "meta": _meta_text(item),
        "release_date": item.get("first_air_date") or "",
        "rating": item.get("vote_average") or 0,
        "genres": "",
        "countries": "",
        "runtime": "",
        "seasons": "",
        "episodes": "",
        "poster": poster,
        "fanart": fanart,
        "query": _series_query(item),
        "play_query": _series_query(item),
        "trailer_query": _series_query(item, "tmdb.tv.videos"),
        "add_query": {
            "action": "tmdb.custom.add",
            "media_type": "tv",
            "id": str(item.get("id") or ""),
            "title": _title(item),
        },
    }


def _fetch_series(kind="news"):
    tmdb = _tmdb()
    if kind == "day":
        endpoint = "/trending/tv/day"
        params = {
            "language": tmdb.TMDB_LANGUAGE,
            "page": "1",
        }
    elif kind == "week":
        endpoint = "/trending/tv/week"
        params = {
            "language": tmdb.TMDB_LANGUAGE,
            "page": "1",
        }
    elif kind == "popular":
        endpoint = "/discover/tv"
        params = {
            "language": tmdb.TMDB_LANGUAGE,
            "page": "1",
            "sort_by": "popularity.desc",
            "include_adult": "false",
        }
    else:
        endpoint = "/tv/on_the_air"
        params = {
            "language": tmdb.TMDB_LANGUAGE,
            "page": "1",
        }
    try:
        data = tmdb._tmdb_get(endpoint, params, timeout=6, retries=0)
        rows = data.get("results") or []
    except Exception as exc:
        try:
            xbmc.log(f"[Ikarus][series] TMDB fetch failed: {exc}", xbmc.LOGWARNING)
        except Exception:
            pass
        rows = []
    return [_normalize_series(row) for row in rows if row.get("id")][:20]


class IkarusSeriesDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.controller_mode = bool(kwargs.pop("controller_mode", False))
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self.rows = {"day": [], "week": []}
        self.row_offsets = {"day": 0, "week": 0}
        self.focused_item = None
        self._button_map = {}
        self._detail_cache = {}
        self._last_poster_focus = 401
        self._drag_last_x = None
        self._drag_accum_x = 0.0
        self._suppress_next_poster_click = False

    def onInit(self):
        self._set_static_art()
        self._load_news()
        try:
            self.setFocusId(int(self.restore_state.get("focus_id") or 111))
        except Exception:
            pass

    def _select_result(self, query, focus_id=0):
        result = dict(query or {})
        if self.controller_mode:
            result["_cinema_parent"] = {
                "focus_id": int(focus_id or self._last_poster_focus or 111),
            }
        self.selected_query = result
        self.close()

    def _set_static_art(self):
        try:
            bg = ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Seriály")

    def _load_news(self):
        day_series = _fetch_series("day")
        week_series = _fetch_series("week")
        self.rows = {
            "day": day_series or _fetch_series("news"),
            "week": week_series or day_series or _fetch_series("news"),
        }
        self.row_offsets = {"day": 0, "week": 0}
        self._refresh_visible_rows()
        self._select_by_button(401, with_detail=True)

    def _refresh_visible_rows(self):
        self._button_map = {}
        for row_key, control_id in ROW_CONTROLS.items():
            row = self.rows.get(row_key) or []
            self._button_map[control_id] = row
            self._fill_row_control(control_id, row)

    def _refresh_row(self, row_key):
        row = self.rows.get(row_key) or []
        control_id = ROW_CONTROLS.get(row_key)
        if control_id:
            self._button_map[control_id] = row
            self._fill_row_control(control_id, row)

    def _shift_row(self, row_key, delta, focus_id):
        row = self.rows.get(row_key) or []
        control_id = ROW_CONTROLS.get(row_key)
        if not row or not control_id:
            return False
        try:
            control = self.getControl(control_id)
            current = int(control.getSelectedPosition())
            target = min(max(current + delta, 0), len(row) - 1)
            if target == current:
                return False
            control.selectItem(target)
        except Exception:
            return False
        self._select_by_button(control_id)
        try:
            self.setFocusId(control_id)
        except Exception:
            pass
        return True

    def _row_key_for_button(self, control_id):
        return CONTROL_ROWS.get(int(control_id or 0), "")

    def _shift_focused_row(self, delta):
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = 0
        if focus_id not in CONTROL_ROWS:
            focus_id = self._last_poster_focus
        row_key = self._row_key_for_button(focus_id)
        if not row_key:
            return False
        return self._shift_row(row_key, delta, focus_id)

    def _list_item(self, row):
        item = xbmcgui.ListItem(label=row.get("title") or "")
        poster = row.get("poster") or ui_theme.action_art("tmdb.series").get("poster") or ""
        fanart = row.get("fanart") or ui_theme.fallback_fanart()
        try:
            item.setArt({"poster": poster, "thumb": poster, "icon": poster, "fanart": fanart or ""})
        except Exception:
            try:
                item.setThumbnailImage(poster)
            except Exception:
                pass
        try:
            item.setProperty("tmdb_id", str(row.get("id") or ""))
        except Exception:
            pass
        return item

    def _fill_row_control(self, control_id, rows):
        try:
            control = self.getControl(control_id)
            control.reset()
            for row in rows or []:
                control.addItem(self._list_item(row))
            if rows:
                control.selectItem(0)
        except Exception as exc:
            try:
                xbmc.log(f"[Ikarus][series] Fill row {control_id} failed: {exc}", xbmc.LOGWARNING)
            except Exception:
                pass

    def _selected_from_row(self, control_id):
        row_key = self._row_key_for_button(control_id)
        rows = self.rows.get(row_key) or []
        if not rows:
            return None
        try:
            index = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            index = 0
        if index < 0 or index >= len(rows):
            index = 0
        return rows[index]

    def _update_focused_row(self):
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = 0
        if focus_id in CONTROL_ROWS:
            self._last_poster_focus = focus_id
            self._select_by_button(focus_id)

    def _reset_drag(self):
        self._drag_last_x = None
        self._drag_accum_x = 0.0

    def _action_amount(self, action, getter):
        try:
            return float(getter(action) or 0)
        except Exception:
            return 0.0

    def _handle_drag_action(self, action_id, action):
        if action_id in (ACTION_GESTURE_BEGIN,):
            self._reset_drag()
            return False
        if action_id in (ACTION_MOUSE_LEFT_RELEASE, ACTION_MOUSE_DRAG_END, ACTION_GESTURE_ABORT):
            self._reset_drag()
            return False
        if action_id != ACTION_MOUSE_DRAG:
            return False

        amount_x = self._action_amount(action, lambda item: item.getAmount1())
        if self._drag_last_x is None:
            self._drag_last_x = amount_x
            return True

        delta_x = amount_x - self._drag_last_x
        self._drag_last_x = amount_x
        if abs(delta_x) < 1:
            return True

        self._drag_accum_x += delta_x
        if abs(self._drag_accum_x) < DRAG_STEP_DISTANCE:
            return True

        if self._drag_accum_x < 0:
            moved = self._shift_focused_row(SWIPE_STEP)
            self._drag_accum_x += DRAG_STEP_DISTANCE
        else:
            moved = self._shift_focused_row(-SWIPE_STEP)
            self._drag_accum_x -= DRAG_STEP_DISTANCE
        if moved:
            self._suppress_next_poster_click = True
        return True

    def _set_slot(self, index, item):
        image_id = 201 + index
        title_id = 301 + index
        button_id = 401 + index
        if item:
            self._button_map[button_id] = item
        else:
            self._button_map.pop(button_id, None)
        try:
            self.getControl(image_id).setImage(item.get("poster") or ui_theme.action_art("tmdb.series").get("poster") or "")
        except Exception:
            pass
        try:
            self.getControl(title_id).setLabel(item.get("title") or "")
        except Exception:
            pass

    def _select_by_button(self, control_id, with_detail=False):
        control_id = int(control_id or 0)
        if control_id in CONTROL_ROWS:
            item = self._selected_from_row(control_id)
        else:
            item = self._button_map.get(control_id)
        if item:
            item = self._series_with_detail(item)
        self.focused_item = item
        self._set_detail(item or {})

    def _series_with_detail(self, item):
        tmdb_id = str((item or {}).get("id") or "")
        if not tmdb_id:
            return item
        if tmdb_id in self._detail_cache:
            return self._detail_cache[tmdb_id]
        merged = dict(item)
        try:
            tmdb = _tmdb()
            data = tmdb._tmdb_get(
                "/tv/%s" % tmdb_id,
                {"language": tmdb.TMDB_LANGUAGE},
                timeout=5,
                retries=0,
            )
        except Exception:
            data = {}
        if data:
            merged["original_title"] = data.get("original_name") or merged.get("original_title") or ""
            merged["plot"] = data.get("overview") or merged.get("plot") or ""
            merged["release_date"] = data.get("first_air_date") or merged.get("release_date") or ""
            merged["rating"] = data.get("vote_average") or merged.get("rating") or 0
            merged["genres"] = _join_names(data.get("genres") or [])
            merged["countries"] = _country_names(data, limit=3)
            episode_times = data.get("episode_run_time") or []
            merged["runtime"] = _runtime_text(episode_times[0] if episode_times else 0)
            if data.get("number_of_seasons"):
                merged["seasons"] = str(data.get("number_of_seasons"))
            if data.get("number_of_episodes"):
                merged["episodes"] = str(data.get("number_of_episodes"))
            if data.get("backdrop_path"):
                merged["fanart"] = _image_url(data.get("backdrop_path"), "backdrop")
            if data.get("poster_path"):
                merged["poster"] = _image_url(data.get("poster_path"), "poster")
        self._detail_cache[tmdb_id] = merged
        return merged

    def _set_detail(self, item):
        rating = item.get("rating") or 0
        try:
            rating_text = "%.1f" % float(rating) if rating else ""
        except Exception:
            rating_text = ""
        detail_lines = []
        if item.get("release_date"):
            detail_lines.append("Premi\u00e9ra: %s" % item.get("release_date"))
        if item.get("genres"):
            detail_lines.append("\u017d\u00e1nr: %s" % item.get("genres"))
        if rating_text:
            detail_lines.append("Hodnocen\u00ed: * %s" % rating_text)
        if item.get("countries"):
            detail_lines.append("Zem\u011b p\u016fvodu: %s" % item.get("countries"))
        if item.get("seasons") or item.get("episodes"):
            detail_lines.append(
                "S\u00e9rie / epizody: %s / %s"
                % (item.get("seasons") or "-", item.get("episodes") or "-")
            )
        original = item.get("original_title") or ""
        if original and original != item.get("title"):
            detail_lines.append("Original: %s" % original)
        plot = item.get("plot") or ""
        if plot:
            if detail_lines:
                detail_lines.append("")
            detail_lines.append(plot)
        try:
            self.getControl(30).setLabel(item.get("title") or i18n.T(30301, "Series"))
        except Exception:
            pass
        try:
            self.getControl(31).setLabel("")
        except Exception:
            pass
        try:
            self.getControl(32).setText("\n".join(detail_lines))
        except Exception:
            pass
        try:
            fanart = item.get("fanart") or ui_theme.fallback_fanart()
            if fanart:
                self.getControl(11).setImage(fanart)
        except Exception:
            pass
        return
        original = item.get("original_title") or ""
        if original and original != item.get("title"):
            detail_lines.append("Original: %s" % original)
        if item.get("release_date"):
            detail_lines.append("Premiéra: %s" % item.get("release_date"))
        if item.get("genres"):
            detail_lines.append("Žánr: %s" % item.get("genres"))
        if rating_text:
            detail_lines.append("Hodnocení: * %s" % rating_text)
        if item.get("countries"):
            detail_lines.append("Země: %s" % item.get("countries"))
        if item.get("runtime"):
            detail_lines.append("Délka epizody: %s" % item.get("runtime"))
        if item.get("seasons"):
            detail_lines.append("Sérií: %s" % item.get("seasons"))
        if item.get("episodes"):
            detail_lines.append("Epizod: %s" % item.get("episodes"))
        plot = item.get("plot") or ""
        if plot:
            if detail_lines:
                detail_lines.append("")
            detail_lines.append(plot)
        try:
            self.getControl(30).setLabel(item.get("title") or i18n.T(30301, "Series"))
        except Exception:
            pass
        try:
            self.getControl(31).setLabel("")
        except Exception:
            pass
        try:
            self.getControl(32).setText("\n".join(detail_lines))
        except Exception:
            pass
        try:
            fanart = item.get("fanart") or ui_theme.fallback_fanart()
            if fanart:
                self.getControl(11).setImage(fanart)
        except Exception:
            pass

    def onFocus(self, control_id):
        control_id = int(control_id or 0)
        if control_id in CONTROL_ROWS:
            self._last_poster_focus = control_id
            self._select_by_button(control_id)

    def _show_picker(self, picker_type, fallback_action, focus_id):
        if self.controller_mode:
            self._select_result(
                {
                    "action": "__picker__",
                    "media_type": "tv",
                    "picker_type": picker_type,
                },
                focus_id,
            )
            return
        try:
            from resources.lib import ui_popular_providers
            selected = ui_popular_providers.show_picker("tv", picker_type)
        except Exception as exc:
            try:
                xbmc.log(f"[Ikarus][series] {picker_type} picker failed: {exc}", xbmc.LOGWARNING)
            except Exception:
                pass
            selected = {}
        if (selected or {}).get("action") == "__back__":
            try:
                self.setFocusId(focus_id)
            except Exception:
                pass
            return
        self.selected_query = selected or {"action": fallback_action}
        self.close()

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__home__"}
            self.close()
            return
        tab = TAB_BUTTONS.get(control_id)
        if tab == "popular":
            if self.controller_mode:
                self._select_result(
                    {
                        "action": "__picker__",
                        "media_type": "tv",
                        "picker_type": "popular",
                    },
                    111,
                )
                return
            try:
                from resources.lib import ui_popular_providers
                selected = ui_popular_providers.show_popular_providers("tv")
            except Exception as exc:
                try:
                    xbmc.log(f"[Ikarus][series] Popular provider picker failed: {exc}", xbmc.LOGWARNING)
                except Exception:
                    pass
                selected = {}
            if (selected or {}).get("action") == "__back__":
                try:
                    self.setFocusId(111)
                except Exception:
                    pass
                return
            self.selected_query = selected or {"action": "tmdb.series.popular"}
            self.close()
            return
        if tab == "top_rated":
            self._select_result({"action": "tmdb.series.top_rated"}, 112)
            return
        if tab == "genre":
            self._show_picker("genre", "tmdb.series.genre", 113)
            return
        if tab == "year":
            self._show_picker("year", "tmdb.series.year", 114)
            return
        if tab == "country":
            self._show_picker("country", "tmdb.series.origin_country", 115)
            return
        if tab == "search":
            self._select_result({"action": "tmdb.series.search"}, 116)
            return
        if control_id in CONTROL_ROWS:
            if self._suppress_next_poster_click:
                self._suppress_next_poster_click = False
                return
            item = self._selected_from_row(control_id)
            if item:
                self._select_result(item.get("query") or {}, control_id)
            return
        item = self.focused_item or {}
        if not item:
            return
        if control_id == 121:
            self._select_result(item.get("play_query") or {}, control_id)
        elif control_id == 122:
            self._select_result(item.get("trailer_query") or {}, control_id)
        elif control_id == 123:
            self._select_result(item.get("query") or {}, control_id)
        elif control_id == 124:
            self._select_result(item.get("add_query") or {}, control_id)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__home__"}
            self.close()
            return
        if self._handle_drag_action(action_id, action):
            return
        super().onAction(action)
        self._update_focused_row()


def show_series(controller_mode=False, restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusSeriesDialog(
            "DialogIkarusSeries.xml",
            addon_path,
            "Default",
            "720p",
            controller_mode=bool(controller_mode),
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log(f"[Ikarus][series] Fullscreen series failed: {exc}", xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

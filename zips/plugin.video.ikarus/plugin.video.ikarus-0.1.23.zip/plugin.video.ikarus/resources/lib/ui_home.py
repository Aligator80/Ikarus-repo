# -*- coding: utf-8 -*-
"""Fullscreen home screen for themed Ikarus UI."""

import random
import time

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import TMDB_knihovna
from resources.lib import tmdb_playback_sync
from resources.lib import tmdb_custom_lists
from resources.lib import ui_splash
from resources.lib import ui_theme


LIST_COLLAGE_CONTROL_IDS = (610, 611, 612, 613)
RESUME_COLLAGE_CONTROL_IDS = (620, 621, 622, 623, 624, 625)
STARTUP_SPLASH_ALARM = "IkarusHomeSplashHide"


def _poster_url(value):
    value = str(value or "").strip()
    if not value:
        return ""
    if value.startswith("http://") or value.startswith("https://") or value.startswith("special://"):
        return value
    if value.startswith("/"):
        return TMDB_knihovna.TMDB_IMAGE_BASE + value
    return value


def _resume_collage_posters(limit=6):
    posters = []
    try:
        rows = tmdb_playback_sync.iter_items_by_status("started", include_trakt=True)
    except Exception:
        rows = []

    for _, _, row in rows or []:
        if not isinstance(row, dict):
            continue
        poster = _poster_url(row.get("poster") or row.get("thumb") or row.get("icon"))
        if poster and poster not in posters:
            posters.append(poster)
        if len(posters) >= limit:
            break

    if posters:
        original = list(posters)
        while len(posters) < limit:
            posters.append(original[len(posters) % len(original)])
    return posters[:limit]


def _list_collage_posters(limit=4):
    groups = []
    try:
        rows = tmdb_custom_lists.all_lists()
    except Exception:
        rows = []

    for row in rows:
        if not isinstance(row, dict):
            continue
        posters = []
        for item in row.get("items") or []:
            if not isinstance(item, dict):
                continue
            poster = str(item.get("poster") or item.get("thumb") or "").strip()
            if poster and poster not in posters:
                posters.append(poster)
        if posters:
            groups.append(posters)

    if not groups:
        return []

    random.shuffle(groups)
    random.shuffle(groups[0])
    selected = list(groups[0][:limit])

    remaining = []
    for posters in groups[1:]:
        shuffled = list(posters)
        random.shuffle(shuffled)
        for poster in shuffled:
            if poster not in selected and poster not in remaining:
                remaining.append(poster)
    random.shuffle(remaining)
    selected.extend(remaining[:max(0, limit - len(selected))])

    if selected:
        original = list(selected)
        while len(selected) < limit:
            selected.append(original[len(selected) % len(original)])
    return selected[:limit]


class IkarusHomeDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.items = kwargs.get("items") or []
        self.selected_query = None
        self.selected_label = ""
        self.closed = False
        self._control_map = {}
        self._startup_splash = bool(kwargs.get("startup_splash", False))
        self._splash_until = 0.0

    def onInit(self):
        try:
            bg = ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        ui_theme.set_cinema_header(self)

        for row in self.items:
            try:
                control_id = int(row.get("control_id") or 0)
            except Exception:
                control_id = 0
            if control_id:
                self._control_map[control_id] = row
                self._set_tile(control_id, row)

        self._set_list_collage(_list_collage_posters())
        self._set_resume_collage(_resume_collage_posters())

        try:
            self.setFocusId(101)
        except Exception:
            pass

        if self._startup_splash:
            remaining_ms = max(1000, ui_splash.remaining_ms())
            self._splash_until = time.monotonic() + (remaining_ms / 1000.0)
            ui_splash.close_splash(min_duration_ms=0)
            self._schedule_splash_hide(remaining_ms)

    def _schedule_splash_hide(self, remaining_ms):
        seconds = max(1, int((int(remaining_ms or 0) + 999) / 1000))
        minutes, seconds = divmod(seconds, 60)
        try:
            window_id = int(xbmcgui.getCurrentWindowDialogId())
        except Exception:
            window_id = 0
        try:
            xbmc.executebuiltin("CancelAlarm(%s,silent)" % STARTUP_SPLASH_ALARM)
            xbmc.executebuiltin(
                "AlarmClock(%s,SetProperty(IkarusStartupSplash,false,%d),%02d:%02d,silent)"
                % (STARTUP_SPLASH_ALARM, window_id, minutes, seconds)
            )
            xbmc.log(
                "[IKARUS][SPLASH] handoff window_id=%d remaining_ms=%d alarm=%02d:%02d"
                % (window_id, int(remaining_ms or 0), minutes, seconds),
                xbmc.LOGINFO,
            )
        except Exception as exc:
            xbmc.log("[Ikarus][home] Splash hide scheduling failed: %s" % exc, xbmc.LOGWARNING)
            try:
                self.setProperty("IkarusStartupSplash", "false")
            except Exception:
                pass

    def _cancel_splash_hide(self):
        if not self._startup_splash:
            return
        try:
            xbmc.executebuiltin("CancelAlarm(%s,silent)" % STARTUP_SPLASH_ALARM)
        except Exception:
            pass

    def _set_tile(self, control_id, row):
        slot = int(control_id) - 100
        image_id = 200 + slot
        label_id = 300 + slot
        subtitle_id = 400 + slot
        icon_id = 500 + slot
        art = row.get("art") or {}
        image = row.get("image") or art.get("background") or art.get("fanart") or art.get("landscape") or art.get("poster") or art.get("thumb") or ""
        icon = art.get("icon") or ""
        try:
            if image:
                self.getControl(image_id).setImage(image)
        except Exception:
            pass
        try:
            if icon:
                self.getControl(icon_id).setImage(icon)
        except Exception:
            pass
        try:
            self.getControl(label_id).setLabel(row.get("label") or "")
        except Exception:
            pass
        try:
            if subtitle_id == 401:
                self.getControl(subtitle_id).setLabel(row.get("subtitle") or "")
        except Exception:
            pass

    def _set_list_collage(self, posters):
        if posters:
            try:
                self.getControl(205).setImage("")
            except Exception:
                pass
        for control_id, poster in zip(LIST_COLLAGE_CONTROL_IDS, posters or []):
            try:
                self.getControl(control_id).setImage(poster)
            except Exception:
                pass

    def _set_resume_collage(self, posters):
        if posters:
            try:
                self.getControl(201).setImage("")
            except Exception:
                pass
        for idx, control_id in enumerate(RESUME_COLLAGE_CONTROL_IDS):
            poster = posters[idx] if idx < len(posters or []) else ""
            try:
                self.getControl(control_id).setImage(poster)
            except Exception:
                pass

    def onClick(self, control_id):
        if time.monotonic() < self._splash_until:
            return
        row = self._control_map.get(int(control_id or 0))
        if not row:
            return
        self.selected_query = dict(row.get("query") or {})
        self.selected_label = row.get("label") or ""
        self.closed = True
        self._cancel_splash_hide()
        self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if time.monotonic() < self._splash_until:
            if action_id in (9, 10, 92, 216, 247, 257, 275, 61467):
                self.closed = True
                self._cancel_splash_hide()
                self.close()
            return
        if action_id in (9, 10, 92, 216, 247, 257, 275, 61467):
            self.closed = True
            self._cancel_splash_hide()
            self.close()
            return
        super().onAction(action)


def show_home(items):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        startup_splash = ui_splash.is_active()
        dialog = IkarusHomeDialog(
            "DialogIkarusHome.xml",
            addon_path,
            "Default",
            "720p",
            items=items,
            startup_splash=startup_splash,
        )
        if startup_splash:
            dialog.setProperty("IkarusStartupSplash", "true")
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log(f"[Ikarus][home] Fullscreen home failed: {exc}", xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

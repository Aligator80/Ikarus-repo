# -*- coding: utf-8 -*-
"""Fullscreen person detail for the Ikarus Cinema theme."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}
CREDITS_CONTROL = 501


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _image_url(path, size="poster"):
    path = str(path or "").strip()
    if not path:
        return ""
    if path.lower().startswith(("http://", "https://", "special://")):
        return path
    tmdb = _tmdb()
    if size == "original":
        return tmdb.TMDB_IMAGE_ORIGINAL_BASE + path
    if size == "backdrop":
        return tmdb.TMDB_IMAGE_THUMB_BASE + path
    return tmdb.TMDB_IMAGE_BASE + path


def _date_text(value):
    value = str(value or "").strip()
    parts = value.split("-")
    if len(parts) == 3 and all(part.isdigit() for part in parts):
        return "%d. %d. %s" % (int(parts[2]), int(parts[1]), parts[0])
    return value


def _department_label(value):
    labels = {
        "Acting": "Herectví",
        "Directing": "Režie",
        "Writing": "Scénář",
        "Production": "Produkce",
        "Camera": "Kamera",
        "Editing": "Střih",
        "Sound": "Zvuk",
        "Art": "Výprava",
        "Costume & Make-Up": "Kostýmy a masky",
        "Visual Effects": "Vizuální efekty",
        "Creator": "Tvůrce",
    }
    value = str(value or "").strip()
    return labels.get(value, value or "Osobnost")


def _year(item):
    value = str(item.get("release_date") or item.get("first_air_date") or "").strip()
    return value[:4] if len(value) >= 4 and value[:4].isdigit() else ""


def _rating_value(item):
    try:
        return float(item.get("vote_average") or 0)
    except Exception:
        return 0.0


def _vote_count(item):
    try:
        return max(0, int(item.get("vote_count") or 0))
    except Exception:
        return 0


def _popularity(item):
    try:
        return float(item.get("popularity") or 0)
    except Exception:
        return 0.0


def _unique_acting_credits(item):
    combined = item.get("combined_credits") or {}
    source = list(combined.get("cast") or [])
    selected = {}
    for credit in source:
        if not isinstance(credit, dict):
            continue
        media_type = str(credit.get("media_type") or "").strip().lower()
        tmdb_id = str(credit.get("id") or "").strip()
        title = str(
            credit.get("title")
            or credit.get("name")
            or credit.get("original_title")
            or credit.get("original_name")
            or ""
        ).strip()
        if media_type not in ("movie", "tv") or not tmdb_id or not title:
            continue
        key = (media_type, tmdb_id)
        old = selected.get(key)
        if old is None or (
            _rating_value(credit),
            _vote_count(credit),
            _popularity(credit),
        ) > (
            _rating_value(old),
            _vote_count(old),
            _popularity(old),
        ):
            selected[key] = dict(credit)
    return list(selected.values())


def _credit_rows(item, limit=18):
    rows = _unique_acting_credits(item)
    rows.sort(
        key=lambda credit: (
            _rating_value(credit),
            _vote_count(credit),
            _popularity(credit),
            _year(credit),
        ),
        reverse=True,
    )
    return rows[:max(1, int(limit or 18))]


def all_credit_rows(item):
    rows = _unique_acting_credits(item)
    rows.sort(
        key=lambda credit: (
            str(credit.get("release_date") or credit.get("first_air_date") or ""),
            _rating_value(credit),
            _vote_count(credit),
        ),
        reverse=True,
    )
    return rows


def _credit_query(credit):
    media_type = str(credit.get("media_type") or "").strip().lower()
    title = str(credit.get("title") or credit.get("name") or "").strip()
    original = str(credit.get("original_title") or credit.get("original_name") or "").strip()
    return {
        "action": "tmdb.tv.detail.open" if media_type == "tv" else "tmdb.movie.detail.open",
        "id": str(credit.get("id") or ""),
        "title": title,
        "original_title": original,
    }


class IkarusPersonDetailDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.item = dict(kwargs.pop("item", {}) or {})
        self.fallback_title = str(kwargs.pop("fallback_title", "Osobnost") or "Osobnost")
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self._credit_queries = []
        self._selection_committed = False

    def onInit(self):
        self._set_static_art()
        self._set_person_info()
        self._fill_credits()
        self._restore_focus()

    def _set_static_art(self):
        background = ui_theme.fallback_fanart()
        profile = _image_url(self.item.get("profile_path"), "poster") or "DefaultActor.png"
        try:
            if background:
                self.getControl(10).setImage(background)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Osobnost")
        try:
            self.getControl(300).setImage(profile)
        except Exception:
            pass

    def _set_person_info(self):
        name = str(self.item.get("name") or self.fallback_title or "Osobnost").strip()
        profession = _department_label(self.item.get("known_for_department"))
        birthday = _date_text(self.item.get("birthday"))
        deathday = _date_text(self.item.get("deathday"))
        birthplace = str(self.item.get("place_of_birth") or "").strip()
        aliases = [str(value).strip() for value in (self.item.get("also_known_as") or []) if str(value).strip()]
        biography = str(self.item.get("biography") or "").strip()
        if not biography:
            biography = "Biografie této osobnosti zatím není v databázi TMDB k dispozici."

        life = []
        if birthday:
            life.append("Narození: %s" % birthday)
        if deathday:
            life.append("Úmrtí: %s" % deathday)

        try:
            self.getControl(310).setLabel(name)
            self.getControl(311).setLabel(profession)
            self.getControl(312).setLabel("   |   ".join(life))
            self.getControl(313).setLabel("Místo narození: %s" % birthplace if birthplace else "")
            self.getControl(314).setLabel("Také známá/ý jako: %s" % ", ".join(aliases[:4]) if aliases else "")
            self.getControl(330).setText(biography)
        except Exception:
            pass

    def _list_item(self, credit):
        media_type = str(credit.get("media_type") or "movie").strip().lower()
        title = str(credit.get("title") or credit.get("name") or "Titul").strip()
        role = str(credit.get("character") or credit.get("job") or "").strip()
        year = _year(credit)
        details = "   |   ".join(value for value in (year, role) if value)
        image = _image_url(credit.get("poster_path"), "poster") or (
            "DefaultTVShows.png" if media_type == "tv" else "DefaultMovies.png"
        )
        item = xbmcgui.ListItem(label=title)
        try:
            item.setLabel2(details)
            item.setProperty("MediaTypeLabel", "SERIÁL" if media_type == "tv" else "FILM")
            item.setArt({"thumb": image, "icon": image, "poster": image})
        except Exception:
            pass
        return item

    def _fill_credits(self):
        control = self.getControl(CREDITS_CONTROL)
        control.reset()
        self._credit_queries = []
        credits = _credit_rows(self.item)
        for credit in credits:
            control.addItem(self._list_item(credit))
            self._credit_queries.append(_credit_query(credit))
        if not credits:
            item = xbmcgui.ListItem(label="Filmografie zatím není k dispozici")
            try:
                item.setArt({"thumb": "DefaultVideo.png", "icon": "DefaultVideo.png"})
            except Exception:
                pass
            control.addItem(item)
            self._credit_queries.append({})

    def _restore_focus(self):
        try:
            focus_id = int(self.restore_state.get("focus_id") or CREDITS_CONTROL)
            position = max(0, int(self.restore_state.get("selected_index") or 0))
            position = min(position, max(0, len(self._credit_queries) - 1))
            self.getControl(CREDITS_CONTROL).selectItem(position)
            self.setFocusId(focus_id if focus_id in (120, CREDITS_CONTROL) else CREDITS_CONTROL)
        except Exception:
            pass

    def _selection_context(self):
        try:
            focus_id = int(self.getFocusId())
        except Exception:
            focus_id = CREDITS_CONTROL
        try:
            position = max(0, int(self.getControl(CREDITS_CONTROL).getSelectedPosition()))
        except Exception:
            position = 0
        return {"focus_id": focus_id, "selected_index": position}

    def _selected_credit_query(self):
        if not self._credit_queries:
            return {}
        try:
            position = int(self.getControl(CREDITS_CONTROL).getSelectedPosition())
        except Exception:
            position = 0
        position = max(0, min(position, len(self._credit_queries) - 1))
        return dict(self._credit_queries[position] or {})

    def _finish(self, query):
        if self._selection_committed:
            return
        self._selection_committed = True
        self.selected_query = dict(query or {})
        self.close()

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self._finish({"action": "__back__"})
            return
        if control_id == 120:
            query = {
                "action": "tmdb.person.credits.all",
                "id": str(self.item.get("id") or ""),
                "title": str(self.item.get("name") or self.fallback_title or "Osobnost"),
            }
            if query["id"]:
                query["_cinema_parent"] = self._selection_context()
                self._finish(query)
            return
        if control_id == CREDITS_CONTROL:
            query = self._selected_credit_query()
            if query:
                query["_cinema_parent"] = self._selection_context()
                self._finish(query)

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self._finish({"action": "__back__"})
            return
        if action_id in OPEN_ACTIONS:
            try:
                focus_id = int(self.getFocusId())
                if focus_id in (120, CREDITS_CONTROL):
                    self.onClick(focus_id)
                    return
            except Exception:
                pass
        super().onAction(action)


def show_person_detail(item, fallback_title="Osobnost", restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusPersonDetailDialog(
            "DialogIkarusPersonDetail.xml",
            addon_path,
            "Default",
            "720p",
            item=dict(item or {}),
            fallback_title=fallback_title or "Osobnost",
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][person_detail] Fullscreen detail failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

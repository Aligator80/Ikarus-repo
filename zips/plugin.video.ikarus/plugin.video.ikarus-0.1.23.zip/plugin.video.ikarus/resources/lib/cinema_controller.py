# -*- coding: utf-8 -*-
"""Standalone navigation controller for the Ikarus Cinema interface."""

import json
import time

import xbmc
import xbmcgui

from resources.lib import ui_home
from resources.lib import ui_czech_media
from resources.lib import ui_downloads
from resources.lib import ui_lists
from resources.lib import ui_movie_detail
from resources.lib import ui_movies
from resources.lib import ui_person_detail
from resources.lib import ui_person_credits
from resources.lib import ui_popular_providers
from resources.lib import ui_results
from resources.lib import ui_search
from resources.lib import ui_series
from resources.lib import ui_series_detail
from resources.lib import ui_settings
from resources.lib import ui_source_providers
from resources.lib import ui_source_results
from resources.lib import ui_trakt


SCREEN_HOME = "home"
SCREEN_CZECH = "czech"
SCREEN_DOWNLOADS = "downloads"
SCREEN_LISTS = "lists"
SCREEN_MOVIES = "movies"
SCREEN_SERIES = "series"
SCREEN_PICKER = "picker"
SCREEN_RESULTS = "results"
SCREEN_SEARCH = "search"
SCREEN_SOURCE_PROVIDERS = "source_providers"
SCREEN_SOURCE_RESULTS = "source_results"
SCREEN_MOVIE_DETAIL = "movie_detail"
SCREEN_PERSON_DETAIL = "person_detail"
SCREEN_PERSON_CREDITS = "person_credits"
SCREEN_SERIES_DETAIL = "series_detail"
SCREEN_SETTINGS = "settings"
SCREEN_TRAKT = "trakt"

CINEMA_STACK_PARAM = "cinema_stack_json"

VALID_SCREENS = {
    SCREEN_HOME,
    SCREEN_CZECH,
    SCREEN_DOWNLOADS,
    SCREEN_LISTS,
    SCREEN_MOVIES,
    SCREEN_SERIES,
    SCREEN_PICKER,
    SCREEN_RESULTS,
    SCREEN_SEARCH,
    SCREEN_SOURCE_PROVIDERS,
    SCREEN_SOURCE_RESULTS,
    SCREEN_MOVIE_DETAIL,
    SCREEN_PERSON_DETAIL,
    SCREEN_PERSON_CREDITS,
    SCREEN_SERIES_DETAIL,
    SCREEN_SETTINGS,
    SCREEN_TRAKT,
}

RESULT_ACTIONS = {
    "tmdb.started",
    "tmdb.custom.list",
    "tmdb.movies.popular.list",
    "tmdb.movies.popular.provider.list",
    "tmdb.movies.top_rated",
    "tmdb.movies.genre.list",
    "tmdb.movies.year.list",
    "tmdb.movies.origin_country.list",
    "tmdb.series.popular.list",
    "tmdb.series.popular.provider.list",
    "tmdb.series.top_rated",
    "tmdb.series.genre.list",
    "tmdb.series.year.list",
    "tmdb.series.origin_country.list",
    "tmdb.trakt.list",
    "tmdb.trakt.smart.list",
    "tmdb.trakt.watchlist",
}

DETAIL_ACTIONS = {
    "tmdb.movie.detail.open": SCREEN_MOVIE_DETAIL,
    "tmdb.person.detail": SCREEN_PERSON_DETAIL,
    "tmdb.tv.detail.open": SCREEN_SERIES_DETAIL,
}

OWNED_ACTIONS = {
    "",
    "main_menu",
    "tmdb.custom.lists",
    "tmdb.czech",
    "tmdb.downloads.queue",
    "tmdb.movies",
    "tmdb.person.credits.all",
    "tmdb.search",
    "tmdb.series",
    "tmdb.sources.providers",
    "tmdb.sources.results",
    "tmdb.trakt.lists",
} | RESULT_ACTIONS | set(DETAIL_ACTIONS)

MAX_STACK_DEPTH = 20
MAX_TRANSITIONS = 1000
ACTIVE_PROPERTY = "IkarusCinemaControllerActive"
DEPTH_PROPERTY = "IkarusCinemaControllerDepth"


def owns_action(action):
    return str(action or "") in OWNED_ACTIONS


def _clean_query(query):
    return {
        key: value
        for key, value in dict(query or {}).items()
        if not str(key).startswith("_cinema_") and key != CINEMA_STACK_PARAM
    }


def _media_screen(action):
    action = str(action or "")
    if action.startswith("tmdb.series") or action.startswith("tmdb.tv"):
        return SCREEN_SERIES
    return SCREEN_MOVIES


def _frame(screen, payload=None, restore=None):
    return {
        "screen": str(screen or ""),
        "payload": dict(payload or {}),
        "restore": dict(restore or {}),
    }


def _json_safe(value, depth=0):
    if depth > 8:
        return None
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        safe = {}
        for key, val in value.items():
            child = _json_safe(val, depth + 1)
            if child is not None:
                safe[str(key)] = child
        return safe
    if isinstance(value, (list, tuple)):
        return [
            child
            for child in (_json_safe(item, depth + 1) for item in value)
            if child is not None
        ]
    return str(value)


def _serializable_payload(payload):
    payload = dict(payload or {})
    payload.pop("item", None)
    if isinstance(payload.get("query"), dict):
        payload["query"] = _clean_query(payload.get("query") or {})
    return _json_safe(payload) or {}


def _serializable_frame(frame):
    screen = str((frame or {}).get("screen") or "")
    if screen not in VALID_SCREENS:
        return None
    return _frame(
        screen,
        _serializable_payload((frame or {}).get("payload") or {}),
        _json_safe((frame or {}).get("restore") or {}) or {},
    )


def _encode_stack(frames):
    serializable = [
        frame
        for frame in (_serializable_frame(frame) for frame in (frames or []))
        if frame
    ]
    if not serializable:
        return ""
    if serializable[0].get("screen") != SCREEN_HOME:
        serializable.insert(0, _frame(SCREEN_HOME))
    if len(serializable) > MAX_STACK_DEPTH:
        serializable = [serializable[0]] + serializable[-(MAX_STACK_DEPTH - 1):]
    try:
        return json.dumps(serializable, ensure_ascii=False, separators=(",", ":"))
    except Exception:
        return ""


def _decode_stack(raw):
    raw = str(raw or "").strip()
    if not raw:
        return []
    try:
        decoded = json.loads(raw)
    except Exception:
        return []
    if not isinstance(decoded, list):
        return []
    frames = []
    for raw_frame in decoded:
        frame = _serializable_frame(raw_frame)
        if frame:
            frames.append(frame)
    if not frames:
        return []
    if frames[0].get("screen") != SCREEN_HOME:
        frames.insert(0, _frame(SCREEN_HOME))
    if len(frames) > MAX_STACK_DEPTH:
        frames = [frames[0]] + frames[-(MAX_STACK_DEPTH - 1):]
    return frames


class CinemaNavigationStack:
    def __init__(self, frames=None, max_depth=MAX_STACK_DEPTH):
        self.max_depth = max(int(max_depth or MAX_STACK_DEPTH), 2)
        self.frames = [dict(frame or {}) for frame in (frames or []) if frame]

    @property
    def current(self):
        return self.frames[-1] if self.frames else None

    @property
    def depth(self):
        return len(self.frames)

    def push(self, frame):
        if not frame:
            return
        self.frames.append(dict(frame))
        if len(self.frames) > self.max_depth:
            root = self.frames[0]
            self.frames = [root] + self.frames[-(self.max_depth - 1):]

    def pop(self):
        if not self.frames:
            return None
        return self.frames.pop()

    def replace(self, frame):
        if self.frames:
            self.frames[-1] = dict(frame or {})
        elif frame:
            self.frames.append(dict(frame))

    def home(self):
        while len(self.frames) > 1:
            self.frames.pop()


class CinemaController:
    def __init__(self, home_items_factory):
        self.home_items_factory = home_items_factory
        self.stack = CinemaNavigationStack()
        self._home_items = None
        self._started_at = 0.0
        try:
            self.monitor = xbmc.Monitor()
        except Exception:
            self.monitor = None

    def _abort_requested(self):
        try:
            return bool(self.monitor and self.monitor.abortRequested())
        except Exception:
            return False

    def run(self, initial_query=None):
        self.stack = CinemaNavigationStack(self._seed_frames(initial_query))
        self._started_at = time.monotonic()
        self._set_runtime_properties()
        try:
            for _ in range(MAX_TRANSITIONS):
                if self._abort_requested():
                    self._log("abort", self.stack.current or {}, "Kodi shutdown requested")
                    return {}
                frame = self.stack.current
                if not frame:
                    return {}
                self._log("show", frame)
                selected = self._show(frame)
                if self._abort_requested():
                    self._log("abort", frame, "Kodi shutdown requested")
                    return {}
                external = self._apply_selection(frame, selected)
                self._set_runtime_properties()
                if external is not None:
                    self._log("external", frame, external.get("action") or "")
                    return {"external_query": external}
            self._log("guard", self.stack.current, "transition limit reached", xbmc.LOGERROR)
            return {}
        finally:
            self._clear_runtime_properties()

    def _seed_frames(self, query):
        raw_query = dict(query or {})
        restored_frames = _decode_stack(raw_query.get(CINEMA_STACK_PARAM))
        if restored_frames:
            return restored_frames

        query = _clean_query(raw_query)
        action = str(query.get("action") or "main_menu")
        frames = [_frame(SCREEN_HOME)]
        if action in ("", "main_menu"):
            return frames
        if action == "tmdb.started":
            frames.append(_frame(SCREEN_RESULTS, {"query": query}))
            return frames
        if action == "tmdb.czech":
            frames.append(_frame(SCREEN_CZECH))
            return frames
        if action == "tmdb.downloads.queue":
            frames.append(_frame(SCREEN_DOWNLOADS))
            return frames
        if action == "tmdb.custom.lists":
            frames.append(_frame(SCREEN_LISTS))
            return frames
        if action == "tmdb.trakt.lists":
            frames.append(_frame(SCREEN_TRAKT))
            return frames
        if action == "tmdb.search":
            frames.append(_frame(SCREEN_SEARCH, {"query": query}))
            return frames
        if action == "tmdb.sources.providers":
            frames.append(_frame(SCREEN_SOURCE_PROVIDERS, {"query": query}))
            return frames
        if action == "tmdb.sources.results":
            frames.append(_frame(SCREEN_SOURCE_RESULTS, {"query": query}))
            return frames
        if action == "tmdb.person.credits.all":
            frames.append(_frame(SCREEN_PERSON_CREDITS, {"query": query}))
            return frames
        if action == "tmdb.custom.list":
            frames.append(_frame(SCREEN_LISTS))
            frames.append(_frame(SCREEN_RESULTS, {"query": query}))
            return frames
        if action in ("tmdb.trakt.list", "tmdb.trakt.smart.list", "tmdb.trakt.watchlist"):
            frames.append(_frame(SCREEN_TRAKT))
            frames.append(_frame(SCREEN_RESULTS, {"query": query}))
            return frames
        media_screen = _media_screen(action)
        frames.append(_frame(media_screen))
        if action in ("tmdb.movies", "tmdb.series"):
            return frames
        if action in RESULT_ACTIONS:
            frames.append(_frame(SCREEN_RESULTS, {"query": query}))
        elif action in DETAIL_ACTIONS:
            frames.append(_frame(DETAIL_ACTIONS[action], {"query": query}))
        return frames

    def _show(self, frame):
        screen = frame.get("screen") or ""
        payload = frame.get("payload") or {}
        restore = frame.get("restore") or {}
        try:
            if screen == SCREEN_HOME:
                if self._home_items is None:
                    self._home_items = list(self.home_items_factory() or [])
                return ui_home.show_home(self._home_items)
            if screen == SCREEN_CZECH:
                return ui_czech_media.show_czech_media(restore_state=restore)
            if screen == SCREEN_DOWNLOADS:
                if ui_downloads.show_downloads():
                    return {"action": "__back__"}
                return {"action": "tmdb.downloads.queue"}
            if screen == SCREEN_LISTS:
                return ui_lists.show_lists(restore_state=restore)
            if screen == SCREEN_TRAKT:
                return ui_trakt.show_trakt(restore_state=restore)
            if screen == SCREEN_MOVIES:
                return ui_movies.show_movies(controller_mode=True, restore_state=restore)
            if screen == SCREEN_SERIES:
                return ui_series.show_series(controller_mode=True, restore_state=restore)
            if screen == SCREEN_PICKER:
                return ui_popular_providers.show_picker(
                    payload.get("media_type") or "movie",
                    payload.get("picker_type") or "popular",
                    restore_state=restore,
                )
            if screen == SCREEN_RESULTS:
                return ui_results.show_results(
                    payload.get("query") or {},
                    restore_state=restore,
                )
            if screen == SCREEN_SEARCH:
                return ui_search.show_search(
                    payload.get("query") or {},
                    restore_state=restore,
                )
            if screen == SCREEN_SOURCE_PROVIDERS:
                return ui_source_providers.show_source_providers(
                    payload.get("query") or {},
                    restore_state=restore,
                )
            if screen == SCREEN_SOURCE_RESULTS:
                return ui_source_results.show_source_results(
                    payload.get("query") or {},
                    restore_state=restore,
                )
            if screen == SCREEN_MOVIE_DETAIL:
                return self._show_movie_detail(frame)
            if screen == SCREEN_PERSON_DETAIL:
                return self._show_person_detail(frame)
            if screen == SCREEN_PERSON_CREDITS:
                return self._show_person_credits(frame)
            if screen == SCREEN_SERIES_DETAIL:
                return self._show_series_detail(frame)
            if screen == SCREEN_SETTINGS:
                if ui_settings.show_settings():
                    return {"action": "__back__"}
                return {"action": "settings"}
        except Exception as exc:
            self._log("show-failed", frame, repr(exc), xbmc.LOGERROR)
            try:
                xbmcgui.Dialog().notification(
                    "Ikarus",
                    "Obrazovku se nepoda\u0159ilo otev\u0159\u00edt.",
                    xbmcgui.NOTIFICATION_ERROR,
                    3000,
                    sound=False,
                )
            except Exception:
                pass
        return {}

    def _show_movie_detail(self, frame):
        payload = frame.get("payload") or {}
        query = payload.get("query") or {}
        item = payload.get("item") or {}
        if not item:
            item = self._load_detail(query, "movie")
            payload["item"] = item
        if not item:
            return {"action": "__back__"}
        return ui_movie_detail.show_movie_detail(
            item,
            fallback_title=query.get("title") or query.get("original_title") or "Film",
            watch_source=query.get("watch_source") or "",
            return_action="",
            restore_state=frame.get("restore") or {},
        )

    def _show_series_detail(self, frame):
        payload = frame.get("payload") or {}
        query = payload.get("query") or {}
        item = payload.get("item") or {}
        if not item:
            item = self._load_detail(query, "tv")
            payload["item"] = item
        if not item:
            return {"action": "__back__"}
        return ui_series_detail.show_series_detail(
            item,
            fallback_title=query.get("title") or query.get("original_title") or "Seri\u00e1l",
            watch_source=query.get("watch_source") or "",
            return_action="",
            restore_state=frame.get("restore") or {},
        )

    def _show_person_detail(self, frame):
        payload = frame.get("payload") or {}
        query = payload.get("query") or {}
        item = payload.get("item") or {}
        if not item:
            item = self._load_person_detail(query)
            payload["item"] = item
        if not item:
            return {"action": "__back__"}
        return ui_person_detail.show_person_detail(
            item,
            fallback_title=query.get("title") or query.get("name") or "Osobnost",
            restore_state=frame.get("restore") or {},
        )

    def _show_person_credits(self, frame):
        payload = frame.get("payload") or {}
        query = payload.get("query") or {}
        item = payload.get("item") or {}
        if not item:
            item = self._load_person_detail(query)
            payload["item"] = item
        if not item:
            return {"action": "__back__"}
        return ui_person_credits.show_person_credits(
            item,
            fallback_title=query.get("title") or query.get("name") or "Osobnost",
            restore_state=frame.get("restore") or {},
        )

    def _load_detail(self, query, media_type):
        tmdb_id = str((query or {}).get("id") or "").strip()
        if not tmdb_id:
            return {}
        try:
            from resources.lib import TMDB_knihovna as tmdb
            if media_type == "tv":
                item = tmdb._tmdb_tv_detail(tmdb_id, timeout=8) or tmdb._tmdb_tv_listing_detail(tmdb_id)
            else:
                item = tmdb._tmdb_movie_detail(tmdb_id, timeout=8) or tmdb._tmdb_movie_listing_detail(tmdb_id)
            if item:
                tmdb._tmdb_remember_detail_playback_meta(tmdb_id, item, media_type)
            return item or {}
        except Exception as exc:
            self._log("detail-failed", self.stack.current, repr(exc), xbmc.LOGERROR)
            return {}

    def _load_person_detail(self, query):
        person_id = str((query or {}).get("id") or "").strip()
        if not person_id:
            return {}
        try:
            from resources.lib import TMDB_knihovna as tmdb
            item = tmdb._tmdb_person_detail(person_id) or {}
            if item and not str(item.get("biography") or "").strip():
                english = tmdb._tmdb_get(
                    "/person/%s" % person_id,
                    params={"language": "en-US"},
                    timeout=8,
                ) or {}
                if str(english.get("biography") or "").strip():
                    item["biography"] = english.get("biography")
            return item
        except Exception as exc:
            self._log("person-detail-failed", self.stack.current, repr(exc), xbmc.LOGERROR)
            return {}

    def _apply_selection(self, frame, selected):
        selected = dict(selected or {})
        action = str(selected.get("action") or "")
        parent = dict(selected.pop("_cinema_parent", {}) or {})
        if parent:
            frame["restore"] = {
                key: value
                for key, value in parent.items()
                if key != "query"
            }
            if parent.get("query") and frame.get("screen") in (
                SCREEN_RESULTS,
                SCREEN_SEARCH,
                SCREEN_SOURCE_PROVIDERS,
                SCREEN_SOURCE_RESULTS,
            ):
                frame.setdefault("payload", {})["query"] = dict(parent.get("query") or {})
            self.stack.replace(frame)

        if not action or action == "__back__":
            self._back()
            return None
        if action == "__home__":
            self.stack.home()
            return None
        if action == "__picker__":
            self._push(
                _frame(
                    SCREEN_PICKER,
                    {
                        "media_type": selected.get("media_type") or "movie",
                        "picker_type": selected.get("picker_type") or "popular",
                    },
                )
            )
            return None
        if action == "tmdb.movies":
            self._push(_frame(SCREEN_MOVIES))
            return None
        if action == "tmdb.series":
            self._push(_frame(SCREEN_SERIES))
            return None
        if action == "tmdb.custom.lists":
            self._push(_frame(SCREEN_LISTS))
            return None
        if action == "tmdb.trakt.lists":
            self._push(_frame(SCREEN_TRAKT))
            return None
        if action == "tmdb.czech":
            self._push(_frame(SCREEN_CZECH))
            return None
        if action == "tmdb.downloads.queue":
            if frame.get("screen") == SCREEN_DOWNLOADS:
                return _clean_query(selected)
            self._push(_frame(SCREEN_DOWNLOADS))
            return None
        if action == "settings":
            if frame.get("screen") == SCREEN_SETTINGS:
                return _clean_query(selected)
            self._push(_frame(SCREEN_SETTINGS))
            return None
        if action == "tmdb.search":
            self._push(_frame(SCREEN_SEARCH, {"query": _clean_query(selected)}))
            return None
        if action == "tmdb.sources.providers":
            self._push(_frame(SCREEN_SOURCE_PROVIDERS, {"query": _clean_query(selected)}))
            return None
        if action == "tmdb.sources.results":
            self._push(_frame(SCREEN_SOURCE_RESULTS, {"query": _clean_query(selected)}))
            return None
        if action == "tmdb.person.credits.all":
            self._push(_frame(SCREEN_PERSON_CREDITS, {"query": _clean_query(selected)}))
            return None
        if action in RESULT_ACTIONS:
            self._push(_frame(SCREEN_RESULTS, {"query": _clean_query(selected)}))
            return None
        detail_screen = DETAIL_ACTIONS.get(action)
        if detail_screen:
            self._push(_frame(detail_screen, {"query": _clean_query(selected)}))
            return None
        external = _clean_query(selected)
        stack_json = _encode_stack(self.stack.frames)
        if stack_json:
            external[CINEMA_STACK_PARAM] = stack_json
        return external

    def _push(self, frame):
        self.stack.push(frame)
        self._log("push", frame)

    def _back(self):
        old = self.stack.pop()
        self._log("back", old or {})

    def _set_runtime_properties(self):
        try:
            window = xbmcgui.Window(10000)
            window.setProperty(ACTIVE_PROPERTY, "1")
            window.setProperty(DEPTH_PROPERTY, str(self.stack.depth))
        except Exception:
            pass

    def _clear_runtime_properties(self):
        try:
            window = xbmcgui.Window(10000)
            window.clearProperty(ACTIVE_PROPERTY)
            window.clearProperty(DEPTH_PROPERTY)
        except Exception:
            pass

    def _log(self, event, frame, detail="", level=xbmc.LOGINFO):
        try:
            screen = (frame or {}).get("screen") or ""
            elapsed = int((time.monotonic() - self._started_at) * 1000) if self._started_at else 0
            xbmc.log(
                "[IKARUS][CINEMA] event=%s screen=%s depth=%d elapsed_ms=%d %s"
                % (event, screen, self.stack.depth, elapsed, detail or ""),
                level,
            )
        except Exception:
            pass

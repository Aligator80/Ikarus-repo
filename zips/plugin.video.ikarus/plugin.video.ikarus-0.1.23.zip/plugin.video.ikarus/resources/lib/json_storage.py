# -*- coding: utf-8 -*-
import copy
import json
import os
import shutil
import threading
import time
import uuid
from contextlib import contextmanager


def _clone(value):
    try:
        return copy.deepcopy(value)
    except Exception:
        return value


def _notify(logger, message):
    if not logger:
        return
    try:
        logger(message)
    except Exception:
        pass


def _read_candidate(path, expected_type=None):
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    if expected_type is not None and not isinstance(data, expected_type):
        raise ValueError(f"unexpected JSON type: {type(data).__name__}")
    return data


def _temp_path(path, suffix="tmp"):
    return f"{path}.{suffix}.{os.getpid()}.{threading.get_ident()}"


def _replace_with_retry(source, destination, timeout=2.0):
    deadline = time.time() + max(0.1, float(timeout or 0.1))
    while True:
        try:
            os.replace(source, destination)
            return
        except PermissionError:
            if time.time() >= deadline:
                raise
            time.sleep(0.05)


def _write_payload(path, payload, keep_backup=True):
    path = os.path.abspath(path)
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    temp_path = _temp_path(path)
    backup_path = path + ".bak"
    backup_temp = _temp_path(backup_path)
    try:
        with open(temp_path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(payload)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass

        if keep_backup and os.path.isfile(path):
            try:
                _read_candidate(path)
                shutil.copyfile(path, backup_temp)
                _replace_with_retry(backup_temp, backup_path)
            except Exception:
                try:
                    if os.path.exists(backup_temp):
                        os.remove(backup_temp)
                except OSError:
                    pass

        _replace_with_retry(temp_path, path)
    finally:
        for candidate in (temp_path, backup_temp):
            try:
                if os.path.exists(candidate):
                    os.remove(candidate)
            except OSError:
                pass


def write_json(path, data, indent=None, keep_backup=True):
    payload = json.dumps(data, ensure_ascii=False, indent=indent)
    json.loads(payload)
    _write_payload(path, payload, keep_backup=keep_backup)
    return True


def read_json(path, default, expected_type=None, logger=None):
    path = os.path.abspath(path)
    backup_path = path + ".bak"
    main_error = None

    if os.path.isfile(path):
        try:
            return _read_candidate(path, expected_type=expected_type)
        except Exception as exc:
            main_error = exc
            _notify(logger, f"invalid JSON in {path}: {exc}")

    if os.path.isfile(backup_path):
        try:
            data = _read_candidate(backup_path, expected_type=expected_type)
            try:
                write_json(path, data, indent=2, keep_backup=False)
            except Exception as exc:
                _notify(logger, f"JSON recovery write failed for {path}: {exc}")
            _notify(logger, f"JSON recovered from backup: {backup_path}")
            return data
        except Exception as exc:
            _notify(logger, f"invalid JSON backup in {backup_path}: {exc}")

    if main_error is None and not os.path.isfile(path):
        return _clone(default)
    return _clone(default)


def _process_is_alive(pid):
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    if os.name == "nt":
        # os.kill(pid, 0) terminates processes on Windows. Only query a handle.
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
        kernel32.WaitForSingleObject.restype = wintypes.DWORD
        kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
        kernel32.CloseHandle.restype = wintypes.BOOL
        handle = kernel32.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
        if not handle:
            # Only ERROR_INVALID_PARAMETER proves that the PID no longer exists.
            return ctypes.get_last_error() != 87
        try:
            return kernel32.WaitForSingleObject(handle, 0) != 0
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except OSError:
        # Access denied or an unknown error is not proof of a dead owner.
        return True


@contextmanager
def file_lock(path, timeout=5.0, stale_after=30.0):
    lock_path = os.path.abspath(path) + ".lock"
    parent = os.path.dirname(lock_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    deadline = time.monotonic() + max(0.1, float(timeout or 0.1))
    acquired = False
    owner_token = f"{os.getpid()}:{threading.get_ident()}:{uuid.uuid4().hex}"

    def _owner_is_alive():
        try:
            with open(lock_path, "r", encoding="ascii", errors="ignore") as fh:
                pid_text = (fh.read() or "").split(":", 1)[0].strip()
            pid = int(pid_text)
            return _process_is_alive(pid)
        except (ProcessLookupError, ValueError):
            return False
        except PermissionError:
            # A process we cannot signal still exists; its lock must not be stolen.
            return True
        except OSError:
            return True

    def _remove_stale_lock():
        try:
            age = time.time() - os.path.getmtime(lock_path)
            if age > max(1.0, float(stale_after or 1.0)) and not _owner_is_alive():
                os.remove(lock_path)
                return True
        except FileNotFoundError:
            return True
        return False

    while not acquired:
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                os.write(fd, owner_token.encode("ascii", errors="ignore"))
            finally:
                os.close(fd)
            acquired = True
        except PermissionError:
            if not os.path.exists(lock_path):
                if time.monotonic() >= deadline:
                    raise
                time.sleep(0.05)
                continue
            if _remove_stale_lock():
                continue
            if time.monotonic() >= deadline:
                raise TimeoutError(f"timed out waiting for JSON lock: {lock_path}")
            time.sleep(0.05)
        except FileExistsError:
            if _remove_stale_lock():
                continue
            if time.monotonic() >= deadline:
                raise TimeoutError(f"timed out waiting for JSON lock: {lock_path}")
            time.sleep(0.05)

    try:
        yield
    finally:
        if acquired:
            try:
                with open(lock_path, "r", encoding="ascii", errors="ignore") as fh:
                    current_owner = fh.read()
                if current_owner == owner_token:
                    os.remove(lock_path)
            except FileNotFoundError:
                pass


def update_json(path, default, updater, expected_type=None, indent=None, logger=None):
    with file_lock(path):
        data = read_json(path, default, expected_type=expected_type, logger=logger)
        updated = updater(data)
        if updated is None:
            updated = data
        if expected_type is not None and not isinstance(updated, expected_type):
            raise ValueError(f"updater returned unexpected JSON type: {type(updated).__name__}")
        write_json(path, updated, indent=indent, keep_backup=True)
        return updated

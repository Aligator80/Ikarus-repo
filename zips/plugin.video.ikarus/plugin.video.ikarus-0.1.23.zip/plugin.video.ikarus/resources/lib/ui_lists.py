# -*- coding: utf-8 -*-
"""Cinema screen for local and synchronized custom lists."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import tmdb_custom_lists
from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}


def _poster_urls(row, limit=4):
    posters = []
    for item in (row or {}).get("items") or []:
        if not isinstance(item, dict):
            continue
        poster = str(item.get("poster") or item.get("thumb") or "").strip()
        if poster and poster not in posters:
            posters.append(poster)
        if len(posters) >= limit:
            break
    while len(posters) < limit:
        posters.append("DefaultMovies.png")
    return posters[:limit]


def _content_label(row):
    media_types = {
        str(item.get("media_type") or "").strip().lower()
        for item in (row or {}).get("items") or []
        if isinstance(item, dict)
    }
    if media_types == {"movie"}:
        return "Filmy"
    if media_types == {"tv"}:
        return "Seri\u00e1ly"
    if media_types:
        return "Filmy a seri\u00e1ly"
    return "Pr\u00e1zdn\u00fd seznam"


def _sync_label(row):
    sync_state = str((row or {}).get("sync_state") or "").strip().lower()
    if sync_state == "pending":
        return "\u010cek\u00e1 na synchronizaci s Trakt.TV"
    if str((row or {}).get("trakt_slug") or "").strip():
        return "Synchronizov\u00e1no s Trakt.TV"
    return "M\u00edstn\u00ed seznam"


def _normalize_list(row):
    row = dict(row or {})
    items = [item for item in (row.get("items") or []) if isinstance(item, dict)]
    description = str(
        row.get("trakt_description")
        or row.get("description")
        or ""
    ).strip()
    return {
        "id": str(row.get("id") or "").strip(),
        "name": str(row.get("name") or "Seznam").strip() or "Seznam",
        "count": len(items),
        "posters": _poster_urls(row),
        "content_label": _content_label(row),
        "sync_label": _sync_label(row),
        "description": description,
        "source": row,
    }


def _load_rows():
    return [
        _normalize_list(row)
        for row in tmdb_custom_lists.all_lists()
        if isinstance(row, dict) and str(row.get("id") or "").strip()
    ]


class IkarusListsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.rows = []
        self.selected_query = None

    def onInit(self):
        self._set_static_art()
        self._reload()
        try:
            self.setFocusId(401 if self.rows else 150)
        except Exception:
            pass

    def _set_static_art(self):
        try:
            background = ui_theme.fallback_fanart()
            if background:
                self.getControl(10).setImage(background)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Seznamy")

    def _reload(self, select_id=""):
        self.rows = _load_rows()
        control = self.getControl(401)
        control.reset()
        selected_index = 0
        for index, row in enumerate(self.rows):
            control.addItem(self._list_item(row))
            if select_id and row.get("id") == select_id:
                selected_index = index
        if not select_id:
            try:
                selected_index = int(self.restore_state.get("selected_index") or 0)
            except Exception:
                selected_index = 0
        if self.rows:
            selected_index = max(0, min(selected_index, len(self.rows) - 1))
            control.selectItem(selected_index)
            self._set_preview(self.rows[selected_index])
        else:
            self._set_empty_preview()

    def _list_item(self, row):
        item = xbmcgui.ListItem(label=row.get("name") or "")
        posters = list(row.get("posters") or [])
        for index in range(4):
            poster = posters[index] if index < len(posters) else "DefaultMovies.png"
            try:
                item.setProperty("Poster%d" % (index + 1), poster)
            except Exception:
                pass
        try:
            item.setProperty("ListCount", "%d polo\u017eek" % int(row.get("count") or 0))
            item.setProperty("ListSync", row.get("sync_label") or "")
        except Exception:
            pass
        return item

    def _selected_position(self):
        if not self.rows:
            return -1
        try:
            position = int(self.getControl(401).getSelectedPosition())
        except Exception:
            position = 0
        return max(0, min(position, len(self.rows) - 1))

    def _selected_row(self):
        position = self._selected_position()
        return self.rows[position] if position >= 0 else {}

    def _set_preview(self, row):
        posters = list((row or {}).get("posters") or [])
        for index, control_id in enumerate((40, 41, 42, 43)):
            poster = posters[index] if index < len(posters) else "DefaultMovies.png"
            try:
                self.getControl(control_id).setImage(poster)
            except Exception:
                pass
        try:
            self.getControl(30).setLabel(row.get("name") or "")
            self.getControl(31).setLabel(
                "%d polo\u017eek  |  %s"
                % (int(row.get("count") or 0), row.get("content_label") or "")
            )
            self.getControl(32).setLabel(row.get("sync_label") or "")
            self.getControl(33).setText(row.get("description") or "")
        except Exception:
            pass

    def _set_empty_preview(self):
        for control_id in (40, 41, 42, 43):
            try:
                self.getControl(control_id).setImage("DefaultMovies.png")
            except Exception:
                pass
        try:
            self.getControl(30).setLabel("\u017d\u00e1dn\u00e9 seznamy")
            self.getControl(31).setLabel("")
            self.getControl(32).setLabel("")
            self.getControl(33).setText(
                "Vytvo\u0159te prvn\u00ed seznam tla\u010d\u00edtkem Nov\u00fd seznam."
            )
        except Exception:
            pass

    def _notify(self, message, level=xbmcgui.NOTIFICATION_INFO):
        try:
            xbmcgui.Dialog().notification(
                "Ikarus / Seznamy",
                message,
                level,
                3000,
                sound=False,
            )
        except Exception:
            pass

    def _create(self):
        name = xbmcgui.Dialog().input(
            "Nov\u00fd seznam",
            type=xbmcgui.INPUT_ALPHANUM,
        )
        name = str(name or "").strip()
        if not name:
            return
        row = tmdb_custom_lists.create_list(name)
        if not row:
            self._notify(
                "Seznam se nepoda\u0159ilo vytvo\u0159it.",
                xbmcgui.NOTIFICATION_ERROR,
            )
            return
        self.restore_state = {}
        self._reload(str(row.get("id") or ""))
        self.setFocusId(401)
        self._notify("Seznam byl vytvo\u0159en.")

    def _rename(self):
        row = self._selected_row()
        source = row.get("source") or {}
        if not source:
            return
        allowed, mode = tmdb_custom_lists.can_rename_list(source)
        if not allowed:
            owner = tmdb_custom_lists.rename_owner_name(source)
            message = "Seznam lze p\u0159ejmenovat jen na za\u0159\u00edzen\u00ed, kde vznikl."
            if owner:
                message += " (%s)" % owner
            self._notify(message, xbmcgui.NOTIFICATION_WARNING)
            return
        name = xbmcgui.Dialog().input(
            "P\u0159ejmenovat seznam",
            defaultt=row.get("name") or "",
            type=xbmcgui.INPUT_ALPHANUM,
        )
        name = str(name or "").strip()
        if not name or name == row.get("name"):
            return
        ok, mode = tmdb_custom_lists.rename_list(
            row.get("id") or "",
            name,
            description=str(source.get("trakt_description") or "").strip(),
            privacy=str(source.get("trakt_privacy") or "private").strip(),
        )
        if not ok:
            message = (
                "Seznam s t\u00edmto n\u00e1zvem u\u017e existuje."
                if mode == "duplicate"
                else "Seznam se nepoda\u0159ilo p\u0159ejmenovat."
            )
            self._notify(message, xbmcgui.NOTIFICATION_ERROR)
            return
        self._reload(row.get("id") or "")
        self.setFocusId(401)
        self._notify("Seznam byl p\u0159ejmenov\u00e1n.")

    def _delete(self):
        row = self._selected_row()
        source = row.get("source") or {}
        if not source:
            return
        allowed, mode = tmdb_custom_lists.can_delete_list(source)
        if not allowed:
            owner = tmdb_custom_lists.delete_owner_name(source)
            message = "Seznam lze smazat jen na za\u0159\u00edzen\u00ed, kde vznikl."
            if owner:
                message += " (%s)" % owner
            self._notify(message, xbmcgui.NOTIFICATION_WARNING)
            return
        confirmed = xbmcgui.Dialog().yesno(
            "Ikarus / Seznamy",
            "Opravdu smazat seznam %s?" % (row.get("name") or ""),
            nolabel="Zp\u011bt",
            yeslabel="Smazat",
        )
        if not confirmed:
            return
        old_position = self._selected_position()
        deleted, mode = tmdb_custom_lists.delete_list(row.get("id") or "")
        if not deleted:
            self._notify(
                "Seznam se nepoda\u0159ilo smazat.",
                xbmcgui.NOTIFICATION_ERROR,
            )
            return
        self.restore_state = {"selected_index": max(0, old_position - 1)}
        self._reload()
        self.setFocusId(401 if self.rows else 150)
        self._notify("Seznam byl smaz\u00e1n.")

    def onFocus(self, control_id):
        if int(control_id or 0) == 401:
            self._set_preview(self._selected_row())

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if control_id == 150:
            self._create()
            return
        if control_id == 151:
            self._rename()
            return
        if control_id == 152:
            self._delete()
            return
        if control_id == 401:
            row = self._selected_row()
            if not row:
                return
            self.selected_query = {
                "action": "tmdb.custom.list",
                "list_id": row.get("id") or "",
                "name": row.get("name") or "Seznam",
                "page": "1",
                "_cinema_parent": {
                    "selected_index": max(self._selected_position(), 0),
                },
            }
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if action_id in OPEN_ACTIONS:
            try:
                if int(self.getFocusId()) == 401:
                    self._set_preview(self._selected_row())
            except Exception:
                pass
        super().onAction(action)
        try:
            if int(self.getFocusId()) == 401:
                self._set_preview(self._selected_row())
        except Exception:
            pass


def show_lists(restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusListsDialog(
            "DialogIkarusLists.xml",
            addon_path,
            "Default",
            "720p",
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log(
                "[Ikarus][lists] Dialog failed: %s" % exc,
                xbmc.LOGWARNING,
            )
        except Exception:
            pass
        return {}

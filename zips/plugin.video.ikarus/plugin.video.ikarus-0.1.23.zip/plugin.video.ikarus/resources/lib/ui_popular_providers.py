# -*- coding: utf-8 -*-
"""Cinema pickers for popular providers and TMDB browse categories."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}

PICKER_LABELS = {
    "popular": {
        "movie": ("Popul\u00e1rn\u00ed filmy", "Vyber slu\u017ebu"),
        "tv": ("Popul\u00e1rn\u00ed seri\u00e1ly", "Vyber slu\u017ebu"),
    },
    "genre": {
        "movie": ("Filmy podle \u017e\u00e1nru", "Vyber \u017e\u00e1nr"),
        "tv": ("Seri\u00e1ly podle \u017e\u00e1nru", "Vyber \u017e\u00e1nr"),
    },
    "year": {
        "movie": ("Filmy podle roku", "Vyber rok"),
        "tv": ("Seri\u00e1ly podle roku", "Vyber rok"),
    },
    "country": {
        "movie": ("Filmy podle zem\u011b p\u016fvodu", "Vyber zemi p\u016fvodu"),
        "tv": ("Seri\u00e1ly podle zem\u011b p\u016fvodu", "Vyber zemi p\u016fvodu"),
    },
}

COMMON_ORIGIN_COUNTRIES = [
    ("US", "USA"),
    ("CZ", "\u010cesk\u00e1 republika"),
    ("SK", "Slovensko"),
    ("GB", "Velk\u00e1 Brit\u00e1nie"),
    ("DE", "N\u011bmecko"),
    ("FR", "Francie"),
    ("IT", "It\u00e1lie"),
    ("ES", "\u0160pan\u011blsko"),
    ("PL", "Polsko"),
    ("AT", "Rakousko"),
    ("CH", "\u0160v\u00fdcarsko"),
    ("BE", "Belgie"),
    ("NL", "Nizozemsko"),
    ("DK", "D\u00e1nsko"),
    ("SE", "\u0160v\u00e9dsko"),
    ("NO", "Norsko"),
    ("FI", "Finsko"),
    ("IE", "Irsko"),
    ("CA", "Kanada"),
    ("AU", "Austr\u00e1lie"),
    ("NZ", "Nov\u00fd Z\u00e9land"),
    ("JP", "Japonsko"),
    ("KR", "Ji\u017en\u00ed Korea"),
    ("CN", "\u010c\u00edna"),
    ("HK", "Hongkong"),
    ("TW", "Tchaj-wan"),
    ("IN", "Indie"),
    ("TH", "Thajsko"),
    ("TR", "Turecko"),
    ("RU", "Rusko"),
    ("UA", "Ukrajina"),
    ("MX", "Mexiko"),
    ("BR", "Braz\u00edlie"),
    ("AR", "Argentina"),
    ("CL", "Chile"),
    ("CO", "Kolumbie"),
    ("ZA", "Ji\u017en\u00ed Afrika"),
    ("IL", "Izrael"),
    ("EG", "Egypt"),
]

GENRE_ICONS_BY_ID = {
    12: "genre_adventure.png",
    14: "genre_fantasy.png",
    16: "genre_animation.png",
    18: "genre_drama.png",
    27: "genre_horror.png",
    28: "genre_action.png",
    35: "genre_comedy.png",
    36: "genre_history.png",
    37: "genre_western.png",
    53: "genre_thriller.png",
    80: "genre_crime.png",
    99: "genre_documentary.png",
    878: "genre_scifi.png",
    9648: "genre_mystery.png",
    10402: "genre_music.png",
    10749: "genre_romance.png",
    10751: "genre_family.png",
    10752: "genre_war.png",
    10759: "genre_action.png",
    10762: "genre_kids.png",
    10763: "genre_news.png",
    10764: "genre_reality.png",
    10765: "genre_scifi.png",
    10766: "genre_soap.png",
    10767: "genre_talk.png",
    10768: "genre_war.png",
    10770: "genre_tvmovie.png",
}

COMPACT_GENRE_LABELS_BY_ID = {
    10759: "Ak\u010dn\u00ed / dobrod.",
    10765: "Sci-Fi / fantasy",
    10768: "V\u00e1lka / politika",
}


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _provider_rows(media_type):
    tmdb = _tmdb()
    try:
        if media_type == "tv":
            providers = tmdb._tmdb_tv_watch_providers()
        else:
            providers = tmdb._tmdb_movie_watch_providers()
            if not providers:
                providers = tmdb._tmdb_tv_watch_providers()
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][popular] Provider fetch failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        providers = []

    if media_type == "tv":
        rows = [{
            "label": "V\u0161e",
            "icon": "DefaultTVShows.png",
            "query": {"action": "tmdb.series.popular.list", "page": "1"},
        }]
        action = "tmdb.series.popular.provider.list"
    else:
        rows = [{
            "label": "V\u0161e",
            "icon": "DefaultMovies.png",
            "query": {"action": "tmdb.movies.popular.list", "page": "1"},
        }]
        action = "tmdb.movies.popular.provider.list"

    for provider in providers or []:
        provider_id = provider.get("id")
        name = (provider.get("name") or "").strip()
        if not provider_id or not name:
            continue
        rows.append({
            "label": name,
            "icon": provider.get("icon") or "DefaultAddonVideo.png",
            "query": {
                "action": action,
                "provider_id": str(provider_id),
                "provider_name": name,
                "page": "1",
            },
        })
    return rows


def _theme_art(name, fallback):
    try:
        art = ui_theme.theme_asset("art/%s" % name)
        if art:
            return art
    except Exception:
        pass
    return fallback


def _country_icon(code):
    code = (code or "").strip().lower()
    if len(code) == 2:
        icon = _theme_art("flags/%s.png" % code, "")
        if icon:
            return icon
    return _theme_art("tile_country.png", "DefaultCountry.png")


def _genre_icon(genre_id):
    try:
        genre_id = int(genre_id or 0)
    except Exception:
        genre_id = 0
    filename = GENRE_ICONS_BY_ID.get(genre_id)
    if filename:
        icon = _theme_art("genres/%s" % filename, "")
        if icon:
            return icon
    return _theme_art("tile_genre.png", "DefaultGenre.png")


def _genre_label(genre_id, name):
    try:
        genre_id = int(genre_id or 0)
    except Exception:
        genre_id = 0
    return COMPACT_GENRE_LABELS_BY_ID.get(genre_id) or name


def _genre_rows(media_type):
    tmdb = _tmdb()
    try:
        genres = tmdb._tmdb_tv_genres() if media_type == "tv" else tmdb._tmdb_movie_genres()
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][popular] Genre fetch failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        genres = []
    action = "tmdb.series.genre.list" if media_type == "tv" else "tmdb.movies.genre.list"
    rows = []
    for genre in genres or []:
        genre_id = genre.get("id")
        name = (genre.get("name") or "").strip()
        if not genre_id or not name:
            continue
        rows.append({
            "label": _genre_label(genre_id, name),
            "icon": _genre_icon(genre_id),
            "tile_mode": "poster",
            "query": {
                "action": action,
                "genre_id": str(genre_id),
                "genre_name": name,
                "page": "1",
            },
        })
    return rows


def _year_rows(media_type):
    tmdb = _tmdb()
    try:
        years = tmdb._tmdb_tv_years(1900) if media_type == "tv" else tmdb._tmdb_movie_years(1900)
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][popular] Year fetch failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        years = []
    action = "tmdb.series.year.list" if media_type == "tv" else "tmdb.movies.year.list"
    icon = _theme_art("tile_year.png", "DefaultYear.png")
    rows = []
    for year in years or []:
        label = str(year or "").strip()
        if not label:
            continue
        rows.append({
            "label": label,
            "icon": icon,
            "query": {
                "action": action,
                "year": label,
                "page": "1",
            },
        })
    return rows


def _country_rows(media_type):
    action = "tmdb.series.origin_country.list" if media_type == "tv" else "tmdb.movies.origin_country.list"
    rows = []
    for code, name in COMMON_ORIGIN_COUNTRIES:
        if not code or not name:
            continue
        rows.append({
            "label": name,
            "icon": _country_icon(code),
            "query": {
                "action": action,
                "country_code": code,
                "country_name": name,
                "page": "1",
            },
        })
    return rows


def _picker_rows(media_type, picker_type):
    if picker_type == "genre":
        return _genre_rows(media_type)
    if picker_type == "year":
        return _year_rows(media_type)
    if picker_type == "country":
        return _country_rows(media_type)
    return _provider_rows(media_type)


class IkarusPopularProvidersDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.media_type = kwargs.pop("media_type", "movie") or "movie"
        self.picker_type = kwargs.pop("picker_type", "popular") or "popular"
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.rows = []
        self.selected_query = None

    def onInit(self):
        self._set_static_art()
        media_type = "tv" if self.media_type == "tv" else "movie"
        picker_type = self.picker_type if self.picker_type in PICKER_LABELS else "popular"
        self.rows = _picker_rows(media_type, picker_type)
        self._set_header()
        self._fill_providers()
        try:
            self.setFocusId(401)
        except Exception:
            pass

    def _set_static_art(self):
        try:
            bg = ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        ui_theme.set_cinema_header(
            self,
            "Seriály" if self.media_type == "tv" else "Film",
        )

    def _set_header(self):
        media_type = "tv" if self.media_type == "tv" else "movie"
        picker_type = self.picker_type if self.picker_type in PICKER_LABELS else "popular"
        title, subtitle = PICKER_LABELS.get(picker_type, PICKER_LABELS["popular"]).get(
            media_type,
            PICKER_LABELS["popular"]["movie"],
        )
        try:
            self.getControl(30).setLabel(title)
        except Exception:
            pass
        try:
            self.getControl(31).setLabel(subtitle)
        except Exception:
            pass

    def _list_item(self, row):
        label = row.get("label") or ""
        icon = row.get("icon") or "DefaultAddonVideo.png"
        item = xbmcgui.ListItem(label=label)
        try:
            item.setProperty("IkarusTileMode", row.get("tile_mode") or "")
        except Exception:
            pass
        try:
            item.setArt({"thumb": icon, "icon": icon, "poster": icon})
        except Exception:
            try:
                item.setThumbnailImage(icon)
            except Exception:
                pass
        return item

    def _fill_providers(self):
        try:
            control = self.getControl(401)
            control.reset()
            for row in self.rows or []:
                control.addItem(self._list_item(row))
            if self.rows:
                selected_index = int(self.restore_state.get("selected_index") or 0)
                selected_index = max(0, min(selected_index, len(self.rows) - 1))
                control.selectItem(selected_index)
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][popular] Fill providers failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass

    def _selected_row(self):
        if not self.rows:
            return {}
        try:
            pos = int(self.getControl(401).getSelectedPosition())
        except Exception:
            pos = 0
        if pos < 0 or pos >= len(self.rows):
            pos = 0
        return self.rows[pos]

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if control_id == 401:
            self.selected_query = dict((self._selected_row() or {}).get("query") or {})
            try:
                selected_index = int(self.getControl(401).getSelectedPosition())
            except Exception:
                selected_index = 0
            self.selected_query["_cinema_parent"] = {
                "selected_index": max(selected_index, 0),
            }
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        super().onAction(action)


def show_picker(media_type="movie", picker_type="popular", restore_state=None):
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusPopularProvidersDialog(
            "DialogIkarusPopularProviders.xml",
            addon_path,
            "Default",
            "720p",
            media_type="tv" if media_type == "tv" else "movie",
            picker_type=picker_type if picker_type in PICKER_LABELS else "popular",
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][popular] Fullscreen providers failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}


def show_popular_providers(media_type="movie", restore_state=None):
    return show_picker(media_type, "popular", restore_state=restore_state)

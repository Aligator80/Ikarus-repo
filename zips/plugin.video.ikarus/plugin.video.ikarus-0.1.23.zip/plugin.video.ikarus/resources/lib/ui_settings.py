# -*- coding: utf-8 -*-
"""Cinema styled settings dialog backed by Kodi add-on settings."""

import os
import re
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import diagnostics
from resources.lib import i18n
from resources.lib import informacni_upozorneni
from resources.lib import trakt_client
from resources.lib import ui_theme
from resources.lib import version_info

import nastaveni


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}


def _addon():
    return xbmcaddon.Addon()


def _settings_path():
    addon_path = translatePath(_addon().getAddonInfo("path"))
    return os.path.join(addon_path, "resources", "settings.xml")


def _clean_label(text):
    text = str(text or "")
    text = re.sub(r"\[/?B\]", "", text, flags=re.I)
    text = re.sub(r"\[/?COLOR[^\]]*\]", "", text, flags=re.I)
    return " ".join(text.replace("\n", " ").split())


def _label(raw, fallback=""):
    raw = str(raw or "").strip()
    if raw.isdigit():
        return _clean_label(i18n.T(raw, fallback))
    return _clean_label(raw or fallback)


def _split_pipe(value):
    return [part.strip() for part in str(value or "").split("|")]


def _bool_value(value, default=False):
    raw = str(value if value is not None else "").strip().lower()
    if raw == "":
        return bool(default)
    return raw in ("1", "true", "yes", "on")


def _setting_bool(setting_id, default=False):
    try:
        return _bool_value(_addon().getSetting(setting_id), default)
    except Exception:
        return bool(default)


def _extract_action(action_value):
    action_value = str(action_value or "")
    match = re.search(r"[?&]action=([^)&\"']+)", action_value)
    return match.group(1) if match else ""


def _parse_categories():
    try:
        root = ET.parse(_settings_path()).getroot()
    except Exception as exc:
        xbmc.log("[Ikarus][settings] Could not parse settings.xml: %s" % exc, xbmc.LOGWARNING)
        return []

    categories = []
    for category_index, category in enumerate(root.findall("category")):
        raw_settings = list(category.findall("setting"))
        rows = []
        for index, node in enumerate(raw_settings):
            if str(node.get("visible") or "").strip().lower() == "false":
                continue
            row_type = str(node.get("type") or "text").strip().lower()
            label = _label(node.get("label") or "")
            if row_type == "lsep" and not label:
                continue
            row = {
                "id": str(node.get("id") or "").strip(),
                "type": row_type,
                "label": label,
                "default": str(node.get("default") or ""),
                "option": str(node.get("option") or ""),
                "action": _extract_action(node.get("action") or ""),
                "values": _split_pipe(node.get("values") or ""),
                "lvalues": _split_pipe(node.get("lvalues") or ""),
                "enable": str(node.get("enable") or "").strip(),
                "raw_index": index,
                "raw_settings": raw_settings,
            }
            rows.append(row)
        categories.append(
            {
                "index": category_index,
                "label": _label(category.get("label"), "Nastaveni"),
                "rows": rows,
            }
        )
    return categories


def _enum_labels(row):
    values = list(row.get("values") or [])
    lvalues = list(row.get("lvalues") or [])
    labels = []
    for index, value in enumerate(values):
        translated = ""
        if index < len(lvalues) and str(lvalues[index] or "").isdigit():
            translated = i18n.T(lvalues[index], "")
        labels.append(_clean_label(translated or value))
    return labels


def _enum_index(row):
    values = list(row.get("values") or [])
    labels = _enum_labels(row)
    default = str(row.get("default") or "0").strip()
    raw = ""
    try:
        raw = str(_addon().getSetting(row.get("id") or "") or "").strip()
    except Exception:
        pass
    if raw == "":
        raw = default
    for candidate in (raw, default):
        try:
            idx = int(candidate)
            if 0 <= idx < len(labels):
                return idx
        except Exception:
            pass
        if candidate in values:
            return values.index(candidate)
        if candidate in labels:
            return labels.index(candidate)
    return 0


def _row_enabled(row):
    enable = str(row.get("enable") or "").strip().lower()
    if not enable:
        return True
    if enable == "false":
        return False
    match = re.match(r"eq\(-(\d+),\s*true\)", enable)
    if match:
        try:
            offset = int(match.group(1))
            raw_settings = row.get("raw_settings") or []
            target = raw_settings[int(row.get("raw_index") or 0) - offset]
            target_id = str(target.get("id") or "").strip()
            default = _bool_value(target.get("default"), False)
            return _setting_bool(target_id, default)
        except Exception:
            return True
    return True


def _row_value(row):
    row_type = row.get("type")
    setting_id = row.get("id") or ""
    if row_type == "lsep":
        return ""
    if row_type == "action":
        return "Spustit"
    try:
        raw = _addon().getSetting(setting_id)
    except Exception:
        raw = ""
    if raw == "":
        raw = row.get("default") or ""
    if row_type == "bool":
        return "Zapnuto" if _bool_value(raw, _bool_value(row.get("default"), False)) else "Vypnuto"
    if row_type == "enum":
        labels = _enum_labels(row)
        index = _enum_index(row)
        return labels[index] if labels and 0 <= index < len(labels) else ""
    if "hidden" in str(row.get("option") or "").lower() and raw:
        return "*" * min(len(str(raw)), 18)
    return str(raw or "")


def _list_item(row):
    item = xbmcgui.ListItem(label=row.get("label") or "")
    try:
        item.setProperty("Value", _row_value(row))
        item.setProperty("SettingId", row.get("id") or "")
        item.setProperty("SettingType", row.get("type") or "")
        item.setProperty("Enabled", "1" if _row_enabled(row) else "0")
        item.setProperty("IsSection", "1" if row.get("type") == "lsep" else "0")
    except Exception:
        pass
    return item


def _category_item(category):
    return xbmcgui.ListItem(label=category.get("label") or "")


class IkarusSettingsDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.categories = []
        self.category_index = 0
        self.rows = []
        self.closed = False

    def onInit(self):
        self._set_static_art()
        self.categories = _parse_categories()
        self._fill_categories()
        self._select_category(0)
        try:
            self.setFocusId(301)
        except Exception:
            pass

    def _set_static_art(self):
        try:
            splash = translatePath(
                os.path.join(
                    xbmcaddon.Addon().getAddonInfo("path"),
                    "resources",
                    "skins",
                    "Default",
                    "media",
                    "ikarus_startup_splash.png",
                )
            )
            self.getControl(10).setImage(splash)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Nastaveni")

    def _fill_categories(self):
        control = self.getControl(301)
        control.reset()
        for category in self.categories:
            control.addItem(_category_item(category))
        if self.categories:
            control.selectItem(0)

    def _select_category(self, index):
        if not self.categories:
            return
        index = max(0, min(int(index or 0), len(self.categories) - 1))
        self.category_index = index
        try:
            self.getControl(301).selectItem(index)
        except Exception:
            pass
        category = self.categories[index]
        self.rows = list(category.get("rows") or [])
        try:
            self.getControl(40).setLabel(category.get("label") or "")
        except Exception:
            pass
        control = self.getControl(401)
        control.reset()
        for row in self.rows:
            control.addItem(_list_item(row))
        if self.rows:
            control.selectItem(0)
        self._set_help()

    def _selected_position(self):
        if not self.rows:
            return -1
        try:
            position = int(self.getControl(401).getSelectedPosition())
        except Exception:
            position = 0
        return max(0, min(position, len(self.rows) - 1))

    def _selected_row(self):
        position = self._selected_position()
        return self.rows[position] if position >= 0 else {}

    def _reload_rows(self, keep_position=True):
        position = self._selected_position() if keep_position else 0
        self._select_category(self.category_index)
        if self.rows:
            position = max(0, min(position, len(self.rows) - 1))
            try:
                self.getControl(401).selectItem(position)
            except Exception:
                pass
        self._set_help()

    def _set_help(self):
        row = self._selected_row()
        if not row:
            text = "Vyberte kategorii vlevo."
        elif row.get("type") == "lsep":
            text = row.get("label") or ""
        elif not _row_enabled(row):
            text = "Polozka je jen pro cteni nebo je zavisla na predchozi volbe."
        elif row.get("type") == "bool":
            text = "OK prepne hodnotu Zapnuto / Vypnuto."
        elif row.get("type") == "enum":
            text = "OK otevre vyber dostupnych hodnot."
        elif row.get("type") == "action":
            text = "OK spusti akci."
        else:
            text = "OK upravi hodnotu."
        try:
            self.getControl(41).setText(text)
        except Exception:
            pass

    def _edit_bool(self, row):
        setting_id = row.get("id") or ""
        current = _setting_bool(setting_id, _bool_value(row.get("default"), False))
        _addon().setSetting(setting_id, "false" if current else "true")
        self._reload_rows()

    def _edit_enum(self, row):
        labels = _enum_labels(row)
        if not labels:
            return
        index = xbmcgui.Dialog().select(row.get("label") or "Vyber", labels, preselect=_enum_index(row))
        if index < 0:
            return
        _addon().setSetting(row.get("id") or "", str(index))
        self._reload_rows()

    def _edit_text(self, row):
        if not _row_enabled(row):
            return
        setting_id = row.get("id") or ""
        current = _addon().getSetting(setting_id) or row.get("default") or ""
        input_type = getattr(xbmcgui, "INPUT_NUMERIC", 1) if row.get("type") == "number" else getattr(xbmcgui, "INPUT_ALPHANUM", 0)
        option = 0
        if "hidden" in str(row.get("option") or "").lower():
            option = getattr(xbmcgui, "ALPHANUM_HIDE_INPUT", 0)
        value = xbmcgui.Dialog().input(
            row.get("label") or "Hodnota",
            defaultt=str(current or ""),
            type=input_type,
            option=option,
        )
        if value is None:
            return
        _addon().setSetting(setting_id, str(value))
        self._reload_rows()

    def _edit_folder(self, row):
        setting_id = row.get("id") or ""
        current = _addon().getSetting(setting_id) or row.get("default") or ""
        try:
            value = xbmcgui.Dialog().browse(3, row.get("label") or "Slozka", "files", defaultt=current)
        except Exception:
            value = xbmcgui.Dialog().input(row.get("label") or "Slozka", defaultt=current, type=getattr(xbmcgui, "INPUT_ALPHANUM", 0))
        if value:
            _addon().setSetting(setting_id, str(value))
            self._reload_rows()

    def _run_action(self, row):
        action = row.get("action") or ""
        if action == "refresh_token":
            nastaveni.refresh_token_now()
            self._reload_rows()
            return
        if action == "trakt.login":
            trakt_client.login_device_flow()
            self._reload_rows()
            return
        if action == "show_info_notice":
            informacni_upozorneni.show_notice(require_confirm=False)
            self._reload_rows()
            return
        if action == "version_info":
            version_info.main()
            return
        if action == "ikarus.diagnostics":
            diagnostics.run_self_test(0)
            return
        if action == "check_updates":
            xbmc.executebuiltin("UpdateAddonRepos")
            xbmcgui.Dialog().notification(
                i18n.T(30900, "Ikarus"),
                i18n.T(30315, "Update check has started."),
                xbmcgui.NOTIFICATION_INFO,
                3500,
            )

    def _activate_selected(self):
        row = self._selected_row()
        if not row or row.get("type") == "lsep" or not _row_enabled(row):
            return
        row_type = row.get("type")
        if row_type == "bool":
            self._edit_bool(row)
        elif row_type == "enum":
            self._edit_enum(row)
        elif row_type == "action":
            self._run_action(row)
        elif row_type == "folder":
            self._edit_folder(row)
        elif row_type in ("text", "number"):
            self._edit_text(row)

    def onFocus(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 301 and self.categories:
            try:
                self._select_category(int(self.getControl(301).getSelectedPosition()))
            except Exception:
                pass
        if control_id == 401:
            self._set_help()

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.closed = True
            self.close()
            return
        if control_id == 301 and self.categories:
            self._select_category(int(self.getControl(301).getSelectedPosition()))
            try:
                self.setFocusId(401)
            except Exception:
                pass
            return
        if control_id == 401:
            self._activate_selected()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.closed = True
            self.close()
            return
        if action_id in OPEN_ACTIONS:
            try:
                focused = int(self.getFocusId())
            except Exception:
                focused = 0
            if focused == 301 and self.categories:
                self._select_category(int(self.getControl(301).getSelectedPosition()))
                return
            if focused == 401:
                self._activate_selected()
                return
        super().onAction(action)
        self._set_help()


def show_settings():
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusSettingsDialog(
            "DialogIkarusSettings.xml",
            addon_path,
            "Default",
            "720p",
        )
        dialog.doModal()
        try:
            del dialog
        except Exception:
            pass
        return True
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][settings] Cinema settings failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return False

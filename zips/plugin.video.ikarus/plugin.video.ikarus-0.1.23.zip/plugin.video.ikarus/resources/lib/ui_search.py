# -*- coding: utf-8 -*-
"""Cinema search dialog with separate movie, series and people rows."""

import xbmc
import xbmcaddon
import xbmcgui
from xbmcvfs import translatePath

from resources.lib import ui_theme


BACK_ACTIONS = {9, 10, 92, 216, 247, 257, 275, 61467}
OPEN_ACTIONS = {7, 100}
MOVE_UP = 3
MOVE_DOWN = 4

MOVIES_CONTROL = 501
SERIES_CONTROL = 601
PEOPLE_CONTROL = 701
ROW_CONTROLS = (MOVIES_CONTROL, SERIES_CONTROL, PEOPLE_CONTROL)
ROW_KEYS = {
    MOVIES_CONTROL: "movies",
    SERIES_CONTROL: "series",
    PEOPLE_CONTROL: "people",
}
ROW_LABELS = {
    MOVIES_CONTROL: "Filmy",
    SERIES_CONTROL: "Seriály",
    PEOPLE_CONTROL: "Osoby",
}


def _tmdb():
    from resources.lib import TMDB_knihovna
    return TMDB_knihovna


def _image_url(path, size="poster"):
    path = (path or "").strip()
    if not path:
        return ""
    if path.lower().startswith(("http://", "https://", "special://")):
        return path
    tmdb = _tmdb()
    base = tmdb.TMDB_IMAGE_THUMB_BASE if size == "backdrop" else tmdb.TMDB_IMAGE_BASE
    return base + path


def _display_title(row, media_type):
    tmdb = _tmdb()
    if media_type == "tv":
        fallback = row.get("name") or row.get("original_name") or ""
    else:
        fallback = row.get("title") or row.get("original_title") or ""
    try:
        return tmdb._tmdb_display_title(row, media_type, fallback, fetch_alternatives=False)
    except Exception:
        return fallback or "Neznámý titul"


def _year(row, media_type):
    date = row.get("first_air_date") if media_type == "tv" else row.get("release_date")
    date = date or ""
    return date[:4] if len(date) >= 4 and date[:4].isdigit() else ""


def _rating(row):
    try:
        value = float(row.get("vote_average") or 0)
    except Exception:
        value = 0
    return "%.1f" % value if value else ""


def _media_query(row, media_type, search_query):
    title = _display_title(row, media_type)
    if media_type == "tv":
        return {
            "action": "tmdb.tv.detail.open",
            "id": str(row.get("id") or ""),
            "title": title,
            "original_title": row.get("original_name") or "",
            "return_action": "tmdb.search",
            "search_query": search_query,
        }
    return {
        "action": "tmdb.movie.detail.open",
        "id": str(row.get("id") or ""),
        "title": title,
        "original_title": row.get("original_title") or "",
        "return_action": "tmdb.search",
        "search_query": search_query,
    }


def _normalize_media_row(row, media_type, search_query):
    title = _display_title(row, media_type)
    return {
        "id": str(row.get("id") or ""),
        "title": title,
        "subtitle": _year(row, media_type),
        "poster": _image_url(row.get("poster_path"), "poster"),
        "fanart": _image_url(row.get("backdrop_path"), "backdrop"),
        "plot": row.get("overview") or "",
        "rating": _rating(row),
        "query": _media_query(row, media_type, search_query),
    }


def _normalize_person_row(row):
    known_for = []
    for item in row.get("known_for") or []:
        title = item.get("title") or item.get("name") or item.get("original_title") or item.get("original_name") or ""
        if title and title not in known_for:
            known_for.append(title)
        if len(known_for) >= 3:
            break
    return {
        "id": str(row.get("id") or ""),
        "title": row.get("name") or "Neznámá osoba",
        "subtitle": row.get("known_for_department") or "Osoba",
        "poster": _image_url(row.get("profile_path"), "poster"),
        "fanart": ui_theme.fallback_fanart(),
        "plot": ", ".join(known_for),
        "rating": "",
        "query": {
            "action": "tmdb.person.detail",
            "id": str(row.get("id") or ""),
            "title": row.get("name") or "",
        },
    }


def _fetch_endpoint(path, query):
    try:
        return _tmdb()._tmdb_fetch_search_results(path, query, page=1).get("results") or []
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][search] %s failed: %s" % (path, exc), xbmc.LOGWARNING)
        except Exception:
            pass
        return []


def _fetch_rows(query):
    query = (query or "").strip()
    if not query:
        return {"movies": [], "series": [], "people": []}
    movies = [
        _normalize_media_row(row, "movie", query)
        for row in _fetch_endpoint("/search/movie", query)
        if row.get("id")
    ]
    series = [
        _normalize_media_row(row, "tv", query)
        for row in _fetch_endpoint("/search/tv", query)
        if row.get("id")
    ]
    people = [
        _normalize_person_row(row)
        for row in _fetch_endpoint("/search/person", query)
        if row.get("id")
    ]
    return {
        "movies": movies[:18],
        "series": series[:18],
        "people": people[:18],
    }


class IkarusSearchDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.query_text = str(kwargs.pop("query_text", "") or "").strip()
        self.restore_state = dict(kwargs.pop("restore_state", {}) or {})
        super().__init__(*args, **kwargs)
        self.selected_query = None
        self.rows = {"movies": [], "series": [], "people": []}

    def onInit(self):
        self._set_static_art()
        self._load()
        self._fill()
        self._restore_focus()

    def _set_static_art(self):
        try:
            bg = ui_theme.fallback_fanart()
            if bg:
                self.getControl(10).setImage(bg)
        except Exception:
            pass
        ui_theme.set_cinema_header(self, "Vyhledat", self.query_text)
        try:
            self.getControl(30).setLabel("Výsledky pro: %s" % self.query_text)
        except Exception:
            pass

    def _load(self):
        try:
            self.rows = _fetch_rows(self.query_text)
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][search] Fetch failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass
            self.rows = {"movies": [], "series": [], "people": []}

    def _list_item(self, row, fallback_icon):
        item = xbmcgui.ListItem(label=row.get("title") or "")
        try:
            item.setLabel2(row.get("subtitle") or "")
        except Exception:
            pass
        poster = row.get("poster") or fallback_icon
        fanart = row.get("fanart") or ui_theme.fallback_fanart()
        try:
            item.setArt({"poster": poster, "thumb": poster, "icon": poster, "fanart": fanart or ""})
        except Exception:
            pass
        return item

    def _empty_item(self, label):
        item = xbmcgui.ListItem(label=label)
        try:
            item.setProperty("IkarusEmpty", "1")
            item.setArt({"poster": "DefaultFolder.png", "thumb": "DefaultFolder.png", "icon": "DefaultFolder.png"})
        except Exception:
            pass
        return item

    def _fill_row(self, control_id, rows, fallback_icon, empty_label):
        control = self.getControl(control_id)
        control.reset()
        if rows:
            for row in rows:
                control.addItem(self._list_item(row, fallback_icon))
            return
        control.addItem(self._empty_item(empty_label))

    def _fill(self):
        try:
            self._fill_row(MOVIES_CONTROL, self.rows.get("movies") or [], "DefaultMovies.png", "Žádné filmy")
            self._fill_row(SERIES_CONTROL, self.rows.get("series") or [], "DefaultTVShows.png", "Žádné seriály")
            self._fill_row(PEOPLE_CONTROL, self.rows.get("people") or [], "DefaultActor.png", "Žádné osoby")
        except Exception as exc:
            try:
                xbmc.log("[Ikarus][search] Fill failed: %s" % exc, xbmc.LOGWARNING)
            except Exception:
                pass

    def _restore_focus(self):
        focus_id = int(self.restore_state.get("focused_control") or MOVIES_CONTROL)
        if focus_id not in ROW_CONTROLS:
            focus_id = MOVIES_CONTROL
        for control_id in ROW_CONTROLS:
            key = ROW_KEYS[control_id]
            rows = self.rows.get(key) or []
            if not rows:
                continue
            try:
                position = int(self.restore_state.get("%s_index" % key) or 0)
            except Exception:
                position = 0
            position = max(0, min(position, len(rows) - 1))
            try:
                self.getControl(control_id).selectItem(position)
            except Exception:
                pass
        try:
            self.setFocusId(focus_id)
        except Exception:
            try:
                self.setFocusId(100)
            except Exception:
                pass

    def _selected_row(self, control_id):
        key = ROW_KEYS.get(int(control_id or 0))
        if not key:
            return {}
        rows = self.rows.get(key) or []
        if not rows:
            return {}
        try:
            pos = int(self.getControl(control_id).getSelectedPosition())
        except Exception:
            pos = 0
        if pos < 0 or pos >= len(rows):
            pos = 0
        return rows[pos]

    def _parent_state(self, focused_control):
        state = {
            "query": {"action": "tmdb.search", "query": self.query_text},
            "focused_control": int(focused_control or MOVIES_CONTROL),
        }
        for control_id in ROW_CONTROLS:
            key = ROW_KEYS[control_id]
            try:
                state["%s_index" % key] = max(0, int(self.getControl(control_id).getSelectedPosition()))
            except Exception:
                state["%s_index" % key] = 0
        return state

    def onClick(self, control_id):
        control_id = int(control_id or 0)
        if control_id == 100:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if control_id not in ROW_CONTROLS:
            return
        row = self._selected_row(control_id)
        query = dict((row or {}).get("query") or {})
        if not query:
            return
        query["_cinema_parent"] = self._parent_state(control_id)
        self.selected_query = query
        self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in BACK_ACTIONS:
            self.selected_query = {"action": "__back__"}
            self.close()
            return
        if action_id in (MOVE_UP, MOVE_DOWN):
            try:
                focus_id = int(self.getFocusId())
                if focus_id == 100 and action_id == MOVE_DOWN:
                    self.setFocusId(MOVIES_CONTROL)
                    return
                if focus_id == MOVIES_CONTROL and action_id == MOVE_UP:
                    self.setFocusId(100)
                    return
                if focus_id == PEOPLE_CONTROL and action_id == MOVE_DOWN:
                    self.setFocusId(PEOPLE_CONTROL)
                    return
            except Exception:
                pass
        if action_id in OPEN_ACTIONS:
            try:
                focus_id = int(self.getFocusId())
            except Exception:
                focus_id = 0
            if focus_id in ROW_CONTROLS:
                self.onClick(focus_id)
                return
        super().onAction(action)


def _prompt_search_text(initial_text=""):
    try:
        return xbmcgui.Dialog().input(
            "Ikarus / Vyhledat",
            defaultt=str(initial_text or ""),
            type=getattr(xbmcgui, "INPUT_ALPHANUM", 0),
        )
    except TypeError:
        return xbmcgui.Dialog().input("Ikarus / Vyhledat")
    except Exception:
        return ""


def show_search(query=None, restore_state=None):
    query = dict(query or {})
    text = str(query.get("query") or query.get("search_query") or "").strip()
    if not text:
        text = str(_prompt_search_text() or "").strip()
    if not text:
        return {"action": "__back__"}
    addon_path = translatePath(xbmcaddon.Addon().getAddonInfo("path"))
    try:
        dialog = IkarusSearchDialog(
            "DialogIkarusSearch.xml",
            addon_path,
            "Default",
            "720p",
            query_text=text,
            restore_state=dict(restore_state or {}),
        )
        dialog.doModal()
        selected = dict(getattr(dialog, "selected_query", None) or {})
        try:
            del dialog
        except Exception:
            pass
        return selected
    except Exception as exc:
        try:
            xbmc.log("[Ikarus][search] Dialog failed: %s" % exc, xbmc.LOGWARNING)
        except Exception:
            pass
        return {}

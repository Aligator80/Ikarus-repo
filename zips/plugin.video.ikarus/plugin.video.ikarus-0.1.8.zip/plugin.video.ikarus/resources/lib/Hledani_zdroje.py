# -*- coding: utf-8 -*-
import sys
import urllib.parse
import re
import html
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import xbmcvfs
import urllib.request
import http.cookiejar
import json
import xml.etree.ElementTree as ET
import unicodedata

from bs4 import BeautifulSoup

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
BASE_PATH = sys.argv[0] if len(sys.argv) > 0 else ""
_COOKIEJAR = http.cookiejar.CookieJar()
_OPENER = urllib.request.build_opener(
    urllib.request.HTTPCookieProcessor(_COOKIEJAR)
)
_SKT_SESSION = requests.Session()
_SKT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/75.0.3770.142 Safari/537.36"
    ),
    "Referer": "https://online.sktorrent.eu",
    "Accept-Encoding": "identity",
}
_SOURCE_SEARCH_CACHE = {}
_SOURCE_SEARCH_CACHE_TTL = 20 * 60  # 20 minut
_SOURCE_SEARCH_FILTER_VERSION = "episode-filter-v6"
_WS_FILE_INFO_CACHE = {}
_PREHRAJTO_DETAIL_CACHE = {}
_HELLSPY_DEBUG_DUMPED = set()
_HANDLED_REFRESH_TOKENS = {}
_HANDLED_REFRESH_TOKEN_TTL = 10 * 60  # 10 minut



def _setting_enabled(setting_id: str, default: bool = True) -> bool:
    value = (addon.getSetting(setting_id) or "").strip().lower()
    if not value:
        return default
    return value == "true"


def _webshare_connected() -> bool:
    status = (addon.getSetting("status") or "").strip().lower()
    return status in ("připojeno", "pripojeno", "přihlášen", "prihlasen")


def _sanitize_url(url: str) -> str:
    try:
        p = urllib.parse.urlsplit(url)
        path = urllib.parse.quote(p.path, safe="/%")
        query = urllib.parse.quote(p.query, safe="=&%")
        frag = urllib.parse.quote(p.fragment, safe="%")
        return urllib.parse.urlunsplit((p.scheme, p.netloc, path, query, frag))
    except Exception:
        return url

def _http_get(url: str, timeout: int = 25, referer: str = None) -> str:
    url = _sanitize_url(url)
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer

    req = urllib.request.Request(url, headers=headers, method="GET")
    with _OPENER.open(req, timeout=timeout) as resp:
        raw = resp.read()

    try:
        return raw.decode("utf-8", errors="ignore")
    except Exception:
        return raw.decode(errors="ignore")


def _http_get_json(url: str, timeout: int = 25, referer: str = None, origin: str = None) -> dict:
    url = _sanitize_url(url)

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "application/json,*/*",
        "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer
    if origin:
        headers["Origin"] = origin

    req = urllib.request.Request(url, headers=headers, method="GET")

    try:
        with _OPENER.open(req, timeout=timeout) as resp:
            raw = resp.read()
        try:
            txt = raw.decode("utf-8", errors="ignore")
        except Exception:
            txt = raw.decode(errors="ignore")
        return json.loads(txt) if txt else {}
    except Exception:
        return {}

def _skt_http_get(url: str, referer: str = None, timeout: int = 25) -> str:
    headers = dict(_SKT_HEADERS)
    if referer:
        headers["Referer"] = referer

    resp = _SKT_SESSION.get(url, headers=headers, timeout=timeout)
    resp.raise_for_status()
    return resp.text or ""

# -----------------------------------------------
#             STAHOVANI ZDROJE
# -----------------------------------------------

def _get_setting_bool(setting_id: str, default: bool = False) -> bool:
    try:
        val = addon.getSetting(setting_id)
        return str(val).strip().lower() == "true"
    except Exception:
        return default

def _get_setting_text(setting_id: str, default: str = "") -> str:
    try:
        return (addon.getSetting(setting_id) or default).strip()
    except Exception:
        return default

def _ensure_dir(path: str) -> bool:
    try:
        if not path:
            return False
        if xbmcvfs.exists(path):
            return True
        return xbmcvfs.mkdirs(path)
    except Exception:
        return False

def _safe_filename(name: str) -> str:
    name = (name or "").strip()
    if not name:
        name = "zdroj"
    name = re.sub(r'[\\/:*?"<>|]+', "_", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name[:180] or "zdroj"

def _guess_ext_from_url(url: str) -> str:
    ul = (url or "").lower()
    for ext in (".m3u8", ".mp4", ".mkv", ".avi", ".ts", ".webm"):
        if ext in ul:
            return ext
    return ".mp4"


# ---------------------------
# PLAY HELPERS + RESOLVERS
# ---------------------------

def _is_direct_media_url(u: str) -> bool:
    if not u:
        return False
    ul = u.lower()
    return any(ext in ul for ext in (".mp4", ".m3u8", ".ts", ".mkv", ".avi", ".webm"))

def _kodi_url_with_headers(url: str, headers: dict) -> str:
    if not headers:
        return url

    parts = []
    for k, v in headers.items():
        if v is None:
            continue
        vv = str(v)
        vv_enc = urllib.parse.quote_plus(vv, safe="")
        parts.append(f"{k}={vv_enc}")

    return url + "|" + "&".join(parts)

def play_url(title: str, stream_url: str, headers: dict = None):
    try:
        stream_url = _sanitize_url(stream_url)
    except Exception:
        pass

    final_url = stream_url
    if headers:
        final_url = _kodi_url_with_headers(final_url, headers)

    li = xbmcgui.ListItem(label=title)
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    li.setProperty("mimetype", "application/octet-stream")
    li.setPath(final_url)
    li.setInfo("video", {"title": title})

    xbmcplugin.setResolvedUrl(addon_handle, True, li)
    return




def _try_extract_sources_from_html(html_text: str):
    m = re.search(r"var\s+sources\s*=\s*(\[[\s\S]*?\])\s*;", html_text, re.IGNORECASE)
    if not m:
        return None

    arr_txt = m.group(1)

    mf = re.search(r'["\'](?:file|src)["\']\s*:\s*["\']([^"\']+)["\']', arr_txt, re.IGNORECASE)
    if not mf:
        mf = re.search(r'(?:file|src)\s*:\s*["\']([^"\']+)["\']', arr_txt, re.IGNORECASE)

    if mf:
        return html.unescape(mf.group(1)).strip()

    return None

def _prehrajto_guess_label_from_url(u: str) -> str:
    ul = (u or "").lower()
    if ".m3u8" in ul or "/hls" in ul:
        return "HLS"
    if ".mp4" in ul:
        return "MP4"
    if ".ts" in ul:
        return "TS"
    return "Zdroj"

def _prehrajto_source_rank(u: str):
    ul = (u or "").lower()
    if ".m3u8" in ul or "/hls" in ul:
        return (0, 0)
    if ".mp4" in ul:
        return (1, 0)
    if ".ts" in ul:
        return (2, 0)
    return (9, len(ul))

def _prehrajto_extract_sources_from_html(html_text: str, base_url: str):
    if not html_text:
        return []

    txt = html.unescape(html_text)
    arr_txt = txt
    m = re.search(r"var\s+sources\s*=\s*(\[[\s\S]*?\])\s*;", txt, re.IGNORECASE)
    if m:
        arr_txt = m.group(1) or txt

    out = []
    seen = set()

    for mm in re.finditer(r'(?:(?:"|\')?(?:file|src)(?:"|\')?\s*:\s*(?:"|\')([^"\']+?)(?:"|\'))', arr_txt, re.IGNORECASE):
        raw = (mm.group(1) or "").strip()
        if not raw:
            continue
        full = urllib.parse.urljoin(base_url or _PREHRAJTO_BASE, raw)
        full = html.unescape(full).strip()
        if not full or full in seen:
            continue
        seen.add(full)
        out.append({"label": _prehrajto_guess_label_from_url(full), "src": full})

    for mm in re.finditer(r'(https?://[^"\'\s<>]+?(?:\.m3u8|\.mp4|/hls[^"\'\s<>]*)(?:\?[^"\'\s<>]+)?)', txt, re.IGNORECASE):
        raw = (mm.group(1) or "").strip()
        if not raw:
            continue
        full = html.unescape(raw).strip()
        if not full or full in seen:
            continue
        seen.add(full)
        out.append({"label": _prehrajto_guess_label_from_url(full), "src": full})

    for mm in re.finditer(r'(["\'])(/[^"\']+?(?:\.m3u8|\.mp4|/hls[^"\']*)(?:\?[^"\']+)?)\1', txt, re.IGNORECASE):
        raw = (mm.group(2) or "").strip()
        if not raw:
            continue
        full = urllib.parse.urljoin(base_url or _PREHRAJTO_BASE, raw)
        full = html.unescape(full).strip()
        if not full or full in seen:
            continue
        seen.add(full)
        out.append({"label": _prehrajto_guess_label_from_url(full), "src": full})

    out.sort(key=lambda x: _prehrajto_source_rank(x.get("src", "")))
    return out

def _prehrajto_build_headers(page_url: str, stream_url: str) -> dict:
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Referer": _sanitize_url(page_url),
        "Origin": _PREHRAJTO_BASE,
        "Accept": "*/*",
    }
    ck = _cookie_header_for_url(stream_url)
    if ck:
        headers["Cookie"] = ck
    return headers

def prehrajto_try_resolve_and_play(title: str, page_url: str) -> bool:
    direct, headers = _prehrajto_resolve_direct_url(page_url)
    if not direct:
        return False
    play_url(title, direct, headers=headers)
    return True

def _dump_text_to_temp(filename: str, text: str):
    try:
        path = xbmcvfs.translatePath("special://temp/" + filename)
        f = xbmcvfs.File(path, "w")
        f.write(text or "")
        f.close()
        xbmc.log(f"[IKARUS][SKT] dumped: {path}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[IKARUS][SKT] dump failed: {e}", xbmc.LOGERROR)

def _sktonline_parse_tag_attr(tag_attrs: str, name: str) -> str:
    m = re.search(r'\b' + re.escape(name) + r'\s*=\s*"([^"]*)"', tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*'([^']*)'", tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*([^\s>]+)", tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    return ""

def _sktonline_guess_label_from_url(u: str) -> str:
    ul = (u or "").lower()
    m = re.search(r'(\d{3,4})p', ul)
    if m:
        return m.group(1) + "p"
    if ".m3u8" in ul:
        return "HLS"
    if ".mp4" in ul:
        return "MP4"
    return "Zdroj"

def _sktonline_find_embed_url_anywhere(detail_html: str, base_url: str):
    if not detail_html:
        return None

    txt = html.unescape(detail_html)

    m = re.search(r'<iframe\b[^>]*\bsrc\s*=\s*["\']([^"\']*?/embed/[^"\']+)["\']', txt, re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1).strip(), base_url)

    m = re.search(r'(https?://online\.sktorrent\.eu/embed/[a-zA-Z0-9]+)', txt, re.IGNORECASE)
    if m:
        return m.group(1).strip()

    m = re.search(r'(/embed/[a-zA-Z0-9]+)', txt, re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1).strip(), base_url)

    return None

def _sktonline_extract_video_sources(detail_html: str, page_url: str):
    if not detail_html:
        return []

    mv = re.search(r'(<video\b[^>]*>)([\s\S]*?)</video>', detail_html, re.IGNORECASE)
    if not mv:
        return []

    video_open = mv.group(1) or ""
    inner = mv.group(2) or ""
    out = []
    seen = set()

    for sm in re.finditer(r'<source\b([^>]*?)>', inner, re.IGNORECASE):
        attrs = sm.group(1) or ""
        src = _sktonline_parse_tag_attr(attrs, "src")
        if not src:
            continue
        src = html.unescape(src).strip()
        if not src:
            continue
        full = _sktonline_abs(src, page_url)
        if full in seen:
            continue
        seen.add(full)
        label = _sktonline_parse_tag_attr(attrs, "label") or _sktonline_parse_tag_attr(attrs, "res") or _sktonline_parse_tag_attr(attrs, "data-res")
        label = html.unescape(label).strip() if label else _sktonline_guess_label_from_url(full)
        out.append({"label": label, "src": full})

    if not out:
        vsrc = _sktonline_parse_tag_attr(video_open, "src") or _sktonline_parse_tag_attr(video_open, "data-src")
        if vsrc:
            full = _sktonline_abs(html.unescape(vsrc).strip(), page_url)
            out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    return out

def _sktonline_extract_sources_from_scripts(detail_html: str, base_url: str):
    if not detail_html:
        return []
    txt2 = html.unescape(detail_html)

    out = []
    seen = set()

    for m in re.finditer(r'(?:(?:"|\')?(?:file|src)(?:"|\')?\s*:\s*(?:"|\')([^"\']+?)(?:"|\'))', txt2, re.IGNORECASE):
        u = (m.group(1) or "").strip()
        if not u:
            continue
        ul = u.lower()
        if (".mp4" not in ul) and (".m3u8" not in ul) and ("m3u8" not in ul) and ("mp4" not in ul) and ("/hls" not in ul) and ("/stream" not in ul):
            continue
        full = _sktonline_abs(u, base_url)
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    for m in re.finditer(r'(https?://[^"\'\s<>]+?\.(?:m3u8|mp4)(?:\?[^"\'\s<>]+)?)', txt2, re.IGNORECASE):
        u = (m.group(1) or "").strip()
        if not u:
            continue
        if u in seen:
            continue
        seen.add(u)
        out.append({"label": _sktonline_guess_label_from_url(u), "src": u})

    for m in re.finditer(r'(["\'])(/[^"\']+?\.(?:m3u8|mp4)(?:\?[^"\']+)?)\1', txt2, re.IGNORECASE):
        u = (m.group(2) or "").strip()
        if not u:
            continue
        full = _sktonline_abs(u, base_url)
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    return out

def _sktonline_extract_download_links(html_text: str, base_url: str):
    out = []
    seen = set()
    if not html_text:
        return out

    txt2 = html.unescape(html_text)

    for m in re.finditer(r'<a\b([^>]*?)href=["\']([^"\']+)["\']([^>]*)>', txt2, re.IGNORECASE):
        pre = m.group(1) or ""
        href = (m.group(2) or "").strip()
        post = m.group(3) or ""
        if not href:
            continue
        low = href.lower()
        if not any(k in low for k in ("download", "/download/", "/get/", "/file/", "/dl/")):
            continue
        full = _sktonline_abs(href, base_url)
        if full in seen:
            continue
        seen.add(full)
        attrs = (pre + " " + post)
        mt = re.search(r'title=["\']([^"\']+)["\']', attrs, re.IGNORECASE)
        label = html.unescape(mt.group(1)).strip() if mt else _sktonline_guess_label_from_url(full)
        out.append({"label": label, "url": full})

    for m in re.finditer(r'(https?://[^"\'\s<>]+/(?:download|get|file|dl)/[^"\'\s<>]+)', txt2, re.IGNORECASE):
        full = html.unescape(m.group(1)).strip()
        if not full:
            continue
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "url": full})

    return out

def _http_follow_to_final_url(url: str, referer: str = None, timeout: int = 25) -> str:
    url = _sanitize_url(url)
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "*/*",
        "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer

    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with _OPENER.open(req, timeout=timeout) as resp:
            return resp.geturl() or url
    except Exception:
        return url

def _sktonline_merge_sources(*lists):
    out = []
    seen = set()
    for lst in lists:
        for s in (lst or []):
            u = (s.get("src") or "").strip()
            if not u:
                continue
            if u in seen:
                continue
            seen.add(u)
            lab = (s.get("label") or "").strip() or _sktonline_guess_label_from_url(u)
            out.append({"label": lab, "src": u})

    def _rank(label):
        m = re.search(r'(\d{3,4})p', (label or "").lower())
        if m:
            try:
                return -int(m.group(1))
            except Exception:
                pass
        if "hls" in (label or "").lower():
            return -1
        return 0

    out.sort(key=lambda x: _rank(x.get("label", "")))
    return out

def _cookie_header_for_url(url: str) -> str:
    try:
        u = urllib.parse.urlsplit(url)
        host = (u.hostname or "").lower()
        path = u.path or "/"

        def reg_domain(h: str) -> str:
            parts = [p for p in h.split(".") if p]
            return ".".join(parts[-2:]) if len(parts) >= 2 else h

        host_rd = reg_domain(host)

        cookies = []
        for c in _COOKIEJAR:
            dom = (c.domain or "").lstrip(".").lower()
            if not dom:
                continue

            dom_rd = reg_domain(dom)
            ok_domain = (host == dom) or host.endswith("." + dom)

            if not ok_domain and dom_rd and host_rd and (dom_rd == host_rd):
                ok_domain = True

            if not ok_domain:
                continue

            cpath = c.path or "/"
            if path.startswith(cpath):
                cookies.append(f"{c.name}={c.value}")

        return "; ".join(cookies)
    except Exception:
        return ""

def _probe_stream(url: str, headers: dict, timeout: int = 15):
    try:
        u = _sanitize_url(url)
        req_headers = dict(headers or {})
        req_headers.setdefault("Accept", "*/*")
        req_headers.setdefault("Range", "bytes=0-")

        req = urllib.request.Request(u, headers=req_headers, method="GET")
        with _OPENER.open(req, timeout=timeout) as resp:
            ct = resp.headers.get("Content-Type", "")
            code = getattr(resp, "status", None)
            final = resp.geturl()
            xbmc.log(f"[IKARUS][SKT][PROBE] code={code} ct={ct} final={final}", xbmc.LOGWARNING)
            resp.read(256)
    except Exception as e:
        xbmc.log(f"[IKARUS][SKT][PROBE] FAILED: {repr(e)}", xbmc.LOGERROR)

def sktonline_try_resolve_and_play(title: str, page_url: str) -> bool:
    detail_html = ""
    embed_html = ""
    embed_url = ""

    try:
        detail_html = _http_get(page_url, referer=_SKTONLINE_BASE)
    except Exception as e:
        _dump_text_to_temp("skt_detail.html", detail_html)
        _dump_text_to_temp("skt_embed.html", embed_html)
        _dump_text_to_temp("skt_debug.txt", f"page_url={page_url}\nembed_url={embed_url}\nerror={repr(e)}\n")
        return False

    embed_url = _sktonline_find_embed_url_anywhere(detail_html, page_url)
    embed_html = ""
    if embed_url:
        try:
            embed_html = _http_get(embed_url, referer=page_url)
        except Exception as e:
            embed_html = ""
            _dump_text_to_temp("skt_debug.txt", f"page_url={page_url}\nembed_url={embed_url}\nembed_error={repr(e)}\n")

    sources_detail = _sktonline_extract_video_sources(detail_html, page_url)
    sources_embed = _sktonline_extract_video_sources(embed_html, embed_url) if embed_html and embed_url else []

    sources_script_detail = _sktonline_extract_sources_from_scripts(detail_html, page_url)
    sources_script_embed = _sktonline_extract_sources_from_scripts(embed_html, embed_url) if embed_html and embed_url else []

    sources = _sktonline_merge_sources(sources_detail, sources_embed, sources_script_detail, sources_script_embed)

    if not sources:
        dl = []
        dl += _sktonline_extract_download_links(detail_html, page_url)
        if embed_html and embed_url:
            dl += _sktonline_extract_download_links(embed_html, embed_url)

        for it in dl:
            durl = it.get("url")
            if not durl:
                continue
            final = _http_follow_to_final_url(durl, referer=embed_url or page_url)
            if final and _is_direct_media_url(final):
                sources.append({"label": it.get("label") or _sktonline_guess_label_from_url(final), "src": final})

    if not sources:
        return False

    labels = [(s.get("label") or "Zdroj").strip() for s in sources]

    ref = _sanitize_url(page_url)

    base_headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Referer": ref,
        "Origin": "https://online.sktorrent.eu",
        "Accept": "*/*",
    }

    if len(sources) == 1:
        src1 = (sources[0].get("src") or "").strip()
        headers = dict(base_headers)

        ck = _cookie_header_for_url(src1)
        if ck:
            headers["Cookie"] = ck

        xbmc.log(f"[IKARUS][SKT] PLAY: {src1}", xbmc.LOGWARNING)
        xbmc.log(f"[IKARUS][SKT] HDR: {headers}", xbmc.LOGWARNING)
        _probe_stream(src1, headers)
        play_url(title, src1, headers=headers)
        return True

    idx = xbmcgui.Dialog().select("Vyber kvalitu", labels)
    if idx is None or idx < 0:
        return True

    picked = sources[idx]
    stream_url = (picked.get("src") or "").strip()
    if not stream_url:
        return False

    headers = dict(base_headers)
    ck = _cookie_header_for_url(stream_url)
    if ck:
        headers["Cookie"] = ck

    picked_label = (picked.get("label") or "").strip()
    play_title = f"{title} ({picked_label})" if picked_label else title

    xbmc.log(f"[IKARUS][SKT] PLAY: {stream_url}", xbmc.LOGWARNING)
    xbmc.log(f"[IKARUS][SKT] HDR: {headers}", xbmc.LOGWARNING)
    _probe_stream(stream_url, headers)
    play_url(play_title, stream_url, headers=headers)
    return True

def _add_playable_result(label: str, action_query: dict, plot: str = "", icon: str = "DefaultVideo.png"):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        "icon": icon,
        "thumb": icon,
        "poster": icon
    })
    if plot:
        li.setInfo("video", {"title": label, "plot": plot})
    li.setProperty("IsPlayable", "true")

    download_query = dict(action_query or {})
    download_query["action"] = "tmdb.movie.source.download"

    li.addContextMenuItems([
        (
            "Stáhnout zdroj",
            "RunPlugin(%s)" % build_url(download_query)
        )
    ])

    item_url = build_url(action_query)

    try:
        provider = ((action_query or {}).get("provider") or "").strip().lower()
    except Exception:
        provider = ""

    try:
        action_name = ((action_query or {}).get("action") or "").strip()
    except Exception:
        action_name = ""

    if action_name == "tmdb.movie.source.play":
        # This action starts playback itself and records TMDB progress. Marking
        # it as playable makes Kodi expect setResolvedUrl(True) from this item,
        # which can show a false "Playback failed" dialog while video is already playing.
        li.setProperty("IsPlayable", "false")

    try:
        raw_url = ((action_query or {}).get("url") or "").strip()
    except Exception:
        raw_url = ""

    if (
        provider == "webshare"
        and action_name != "tmdb.movie.source.play"
        and raw_url.startswith("plugin://plugin.video.ikarus/?action=film.play")
    ):
        item_url = raw_url
        xbmc.log(f"[IKARUS][WS] clickable item redirected directly to film.play: {raw_url}", xbmc.LOGWARNING)

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=item_url,
        listitem=li,
        isFolder=False
    )

# ---------------------------
# WEBSHARE SEARCH
# ---------------------------

_WS_BASE = "https://webshare.cz"
_WS_API = _WS_BASE + "/api/"
_WS_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/122.0.0.0 Safari/537.36"
    ),
    "Referer": _WS_BASE,
}
_WS_TIMEOUT = 20

def _ws_api(fnct: str, data: dict):
    resp = requests.post(
        _WS_API + fnct + "/",
        data=data,
        headers=_WS_HEADERS,
        timeout=_WS_TIMEOUT
    )
    resp.raise_for_status()
    return resp

def _ws_search_simple(query: str, limit: int = 40, offset: int = 0):
    """
    Minimalistické hledání na WebShare.
    Vrací:
      [{"id": ident, "name": name, "size": size_int}, ...]
    """
    query = " ".join((query or "").split()).strip()
    if not query:
        return []

    data = {
        "what": query,
        "offset": int(offset or 0),
        "limit": int(limit),
        "category": "video",
    }

    try:
        root = ET.fromstring(_ws_api("search", data).content)
        if (root.findtext("status") or "OK") != "OK":
            return []

        out = []
        for f in root.findall("file"):
            ident = (f.findtext("ident") or "").strip()
            name = (f.findtext("name") or "").strip()
            size_raw = (f.findtext("size") or "0").strip()

            try:
                size_int = int(size_raw) if str(size_raw).isdigit() else 0
            except Exception:
                size_int = 0

            if not ident:
                continue

            out.append({
                "id": ident,
                "name": name or ident,
                "size": size_int,
            })

        return out
    except Exception as e:
        xbmc.log(f"[IKARUS][WS] SEARCH FAILED: {repr(e)}", xbmc.LOGERROR)
        return []

def _ws_xml_streams(root, parent_tag: str):
    out = []
    try:
        parent = root.find(parent_tag)
        if parent is None:
            return out
        for stream in parent.findall("stream"):
            row = {}
            for child in list(stream):
                row[child.tag] = (child.text or "").strip()
            if row:
                out.append(row)
    except Exception:
        pass
    return out

def _ws_file_info(ident: str, token: str = ""):
    ident = (ident or "").strip()
    if not ident:
        return {}

    cached = _WS_FILE_INFO_CACHE.get(ident)
    if cached is not None:
        return dict(cached)

    token = (token or "").strip()
    if not token:
        token = _ws_login_token()
    if not token:
        _WS_FILE_INFO_CACHE[ident] = {}
        return {}

    root = None
    for maybe_removed in ("", "true"):
        data = {"ident": ident, "wst": token}
        if maybe_removed:
            data["maybe_removed"] = maybe_removed
        try:
            root = ET.fromstring(_ws_api("file_info", data).content or b"")
        except Exception as e:
            xbmc.log(f"[IKARUS][WS] file_info failed ident={ident}: {repr(e)}", xbmc.LOGWARNING)
            root = None

        if root is not None and (root.findtext("status") or "").strip().upper() == "OK":
            break
        root = None

    if root is None:
        _WS_FILE_INFO_CACHE[ident] = {}
        return {}

    def text(name: str) -> str:
        try:
            return (root.findtext(name) or "").strip()
        except Exception:
            return ""

    info = {
        "ws_file_info": True,
        "ws_info_name": text("name"),
        "file_type": text("type"),
        "width": text("width"),
        "height": text("height"),
        "format": text("format"),
        "fps": text("fps"),
        "bitrate": text("bitrate"),
        "available": text("available"),
        "password": text("password"),
        "removed": text("removed"),
        "removed_at": text("removed_at"),
        "removal_reason": text("removal_reason"),
        "copyrighted": text("copyrighted"),
        "video_streams": _ws_xml_streams(root, "video"),
        "audio_streams": _ws_xml_streams(root, "audio"),
    }

    size_bytes = _source_int_from_any(text("size"), 0)
    if size_bytes > 0:
        info["size_bytes"] = size_bytes

    _WS_FILE_INFO_CACHE[ident] = dict(info)
    return info

def _enrich_webshare_rows(rows):
    rows = list(rows or [])
    if not rows:
        return rows

    token = _ws_login_token()
    if not token:
        return rows

    out = []
    for row in rows:
        item = dict(row)
        ident = (item.get("id") or "").strip()
        if ident:
            info = _ws_file_info(ident, token)
            if info:
                original_size = item.get("size_bytes") or item.get("size") or 0
                item.update(info)
                if not item.get("size_bytes") and original_size:
                    item["size_bytes"] = original_size
        out.append(item)
    return out





def _ws_device_uuid() -> str:
    duuid = _ws_get_setting("ws_device_uuid", "")
    if duuid:
        return duuid

    try:
        import uuid
        duuid = str(uuid.uuid4())
    except Exception:
        duuid = "ikarus-device"

    try:
        addon.setSetting("ws_device_uuid", duuid)
    except Exception:
        pass

    return duuid


def _ws_get_setting(setting_id: str, default: str = "") -> str:
    try:
        return (addon.getSetting(setting_id) or default).strip()
    except Exception:
        return default




def _ws_login_token():
    try:
        from resources.lib import nastaveni
    except Exception:
        try:
            import nastaveni
        except Exception as e:
            xbmc.log(f"[IKARUS][WS][DL] import nastaveni failed: {repr(e)}", xbmc.LOGERROR)
            return ""

    # 1) zkus použít stejný token jako přehrávání
    try:
        token = (addon.getSetting("token") or "").strip()
    except Exception:
        token = ""

    try:
        if token and nastaveni.over_token(token):
            xbmc.log("[IKARUS][WS][DL] using existing shared token", xbmc.LOGWARNING)
            return token
    except Exception as e:
        xbmc.log(f"[IKARUS][WS][DL] over_token(existing) failed: {repr(e)}", xbmc.LOGERROR)

    # 2) vezmi stejné přihlašovací údaje jako playback
    username = ""
    password = ""
    try:
        username = (addon.getSetting("username") or "").strip()
    except Exception:
        pass
    try:
        password = (addon.getSetting("password") or "").strip()
    except Exception:
        pass

    try:
        token = (nastaveni.ziskej_token(username, password) or "").strip()
    except Exception as e:
        xbmc.log(f"[IKARUS][WS][DL] ziskej_token failed: {repr(e)}", xbmc.LOGERROR)
        token = ""

    if token:
        try:
            addon.setSetting("token", token)
        except Exception:
            pass
        try:
            addon.setSetting("ws_token", token)
        except Exception:
            pass
        xbmc.log("[IKARUS][WS][DL] shared token acquired via nastaveni.ziskej_token()", xbmc.LOGWARNING)

    return token

def _ws_file_link(ident: str, token: str, download_type: str = "video_stream"):
    if not ident or not token:
        return ""

    try:
        resp = _ws_api("file_link", {
            "ident": ident,
            "wst": token,
            "download_type": download_type,
            "device_uuid": _ws_device_uuid(),
        })
        raw = resp.content or b""
        xbmc.log(f"[IKARUS][WS] file_link raw ({download_type}): {raw[:500]!r}", xbmc.LOGWARNING)
        root = ET.fromstring(raw)
    except Exception as e:
        xbmc.log(f"[IKARUS][WS] file_link parse failed: {repr(e)}", xbmc.LOGERROR)
        return ""

    status = (root.findtext("status") or "").strip()
    xbmc.log(f"[IKARUS][WS] file_link ident={ident} type={download_type} status={status}", xbmc.LOGWARNING)

    if status.upper() != "OK":
        code = (root.findtext("code") or "").strip()
        message = (root.findtext("message") or "").strip()
        xbmc.log(f"[IKARUS][WS] file_link fail code={code} message={message}", xbmc.LOGERROR)
        return ""

    for tag in ("link", "url", "file_link", "download_link"):
        val = (root.findtext(tag) or "").strip()
        if val:
            xbmc.log(f"[IKARUS][WS] direct link found in <{tag}>: {val[:150]}", xbmc.LOGWARNING)
            return val

    for elem in root.iter():
        txt = (elem.text or "").strip()
        if txt.startswith("http://") or txt.startswith("https://"):
            xbmc.log(f"[IKARUS][WS] direct link found generic in <{elem.tag}>: {txt[:150]}", xbmc.LOGWARNING)
            return txt

    return ""


def _ws_resolve_direct_url(file_id: str):
    ident = (file_id or "").strip()
    xbmc.log(f"[IKARUS][WS][DL] resolve direct for ident={ident}", xbmc.LOGWARNING)

    if not ident:
        return "", {}

    token = _ws_login_token()
    if not token:
        return "", {}

    direct = _ws_file_link(ident, token, "file_download")
    if not direct:
        return "", {}

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "*/*",
        "Referer": _WS_BASE,
        "Cookie": "wst=" + token,
    }

    xbmc.log(f"[IKARUS][WS][DL] resolved direct: {'YES' if direct else 'NO'}", xbmc.LOGWARNING)
    return direct, headers




# ---------------------------
# PREHRAJ.TO SEARCH
# ---------------------------

_PREHRAJTO_BASE = "https://prehrajto.cz"
_PREHRAJTO_SEARCH_PREFIX = "/hledej/"
_PREHRAJTO_PAGINATOR_PARAM = "videoListing-visualPaginator-page"
_PREHRAJTO_DETAIL_RE = re.compile(r"^/[^/]+/[0-9a-f]{10,}$", re.IGNORECASE)

def _build_prehrajto_search_url(query: str, page: int) -> str:
    q = urllib.parse.quote((query or "").strip())
    base = urllib.parse.urljoin(_PREHRAJTO_BASE, f"{_PREHRAJTO_SEARCH_PREFIX}{q}")
    return base + "?" + urllib.parse.urlencode({_PREHRAJTO_PAGINATOR_PARAM: page})

def _canonicalize_prehrajto_url(full: str) -> str:
    u = urllib.parse.urlparse(full)
    qs = [(k, v) for (k, v) in urllib.parse.parse_qsl(u.query, keep_blank_values=True) if k.lower() != "player"]
    new_query = urllib.parse.urlencode(qs, doseq=True)
    return urllib.parse.urlunparse((u.scheme, u.netloc, u.path, u.params, new_query, u.fragment))

def _extract_prehrajto_results(html_text: str):
    results = []
    seen = set()
    html_text = html_text or ""

    for m in re.finditer(r'<a[^>]+href="(?P<href>/[^"]+)"(?P<rest>[^>]*)>', html_text, re.IGNORECASE):
        href = (m.group("href") or "").strip()
        rest = m.group("rest") or ""

        if not href or href.startswith("#") or href.lower().startswith("javascript:"):
            continue
        if not _PREHRAJTO_DETAIL_RE.match(href):
            continue

        full = urllib.parse.urljoin(_PREHRAJTO_BASE, href)
        full = _canonicalize_prehrajto_url(full)

        if full in seen:
            continue
        seen.add(full)

        title = ""
        mt = re.search(r'title="([^"]+)"', rest, re.IGNORECASE)
        if mt:
            title = html.unescape(mt.group(1)).strip()

        if not title or len(title) < 2:
            seg = href.strip("/").split("/", 1)[0]
            title = seg

        title = re.sub(r"\s+", " ", title).strip()

        context_start = max(0, m.start() - 900)
        context_end = min(len(html_text), m.end() + 1800)
        context = html_text[context_start:context_end]
        size_bytes = _source_size_from_text(context)

        results.append({
            "title": title,
            "url": full,
            "size_bytes": size_bytes,
        })

    return results

def _prehrajto_param_values(detail_html: str) -> dict:
    detail_html = detail_html or ""
    if not detail_html:
        return {}

    try:
        soup = BeautifulSoup(detail_html, "html.parser")
        for tag in soup(["script", "style", "noscript"]):
            tag.decompose()
        lines = [
            html.unescape(x).replace("\xa0", " ").strip()
            for x in soup.get_text("\n").splitlines()
            if html.unescape(x).replace("\xa0", " ").strip()
        ]
    except Exception:
        text = re.sub(r"<[^>]+>", "\n", detail_html)
        lines = [
            html.unescape(x).replace("\xa0", " ").strip()
            for x in text.splitlines()
            if html.unescape(x).replace("\xa0", " ").strip()
        ]

    wanted = {
        "nazev souboru": "name",
        "velikost": "size",
        "datum nahrani": "upload_date",
        "delka": "duration",
        "format": "file_type",
        "rozliseni": "resolution",
    }
    labels = set(wanted.keys())
    params = {}

    i = 0
    while i < len(lines):
        label_norm = _norm_text(lines[i]).strip(":")
        key = wanted.get(label_norm)
        if not key:
            i += 1
            continue

        values = []
        j = i + 1
        while j < len(lines):
            next_norm = _norm_text(lines[j]).strip(":")
            if next_norm in labels:
                break
            values.append(lines[j])
            if key != "name":
                break
            j += 1

        value = " ".join(values).strip()
        if value:
            params[key] = re.sub(r"\s+", " ", value).strip()
        i = max(j, i + 1)

    return params

def _prehrajto_metadata_from_detail(detail_html: str) -> dict:
    params = _prehrajto_param_values(detail_html)
    if not params:
        return {}

    meta = {}
    size_bytes = _source_size_from_text(params.get("size") or "")
    if size_bytes > 0:
        meta["size_bytes"] = size_bytes

    if params.get("duration"):
        meta["duration"] = params["duration"]
    if params.get("file_type"):
        meta["file_type"] = params["file_type"].lower().lstrip(".")
    if params.get("upload_date"):
        meta["upload_date"] = params["upload_date"]
    if params.get("name"):
        meta["source_name"] = params["name"]

    res = params.get("resolution") or ""
    m = re.search(r"(\d{3,5})\s*[x×]\s*(\d{3,5})", res, re.IGNORECASE)
    if m:
        meta["width"] = m.group(1)
        meta["height"] = m.group(2)

    return meta

def _prehrajto_detail_metadata(page_url: str) -> dict:
    page_url = (page_url or "").strip()
    if not page_url:
        return {}
    if page_url in _PREHRAJTO_DETAIL_CACHE:
        return dict(_PREHRAJTO_DETAIL_CACHE.get(page_url) or {})

    try:
        detail_html = _http_get(page_url, referer=_PREHRAJTO_BASE)
        meta = _prehrajto_metadata_from_detail(detail_html)
    except Exception as e:
        xbmc.log(f"[IKARUS][PREHRAJTO] detail metadata failed: {repr(e)}", xbmc.LOGWARNING)
        meta = {}

    _PREHRAJTO_DETAIL_CACHE[page_url] = dict(meta or {})
    return meta or {}

def _enrich_prehrajto_rows(rows, limit: int = 30):
    enriched = []
    count = 0

    for row in (rows or []):
        item = dict(row)
        if count < limit:
            meta = _prehrajto_detail_metadata(item.get("url") or "")
            if meta:
                item.update({k: v for k, v in meta.items() if v not in (None, "", [], {}, 0)})
            count += 1
        enriched.append(item)

    return enriched

def prehrajto_search_all_pages(query: str, max_pages: int = 30):
    all_results = []
    seen_urls = set()

    for page in range(1, max_pages + 1):
        url = _build_prehrajto_search_url(query, page)
        html_text = _http_get(url)
        page_results = _extract_prehrajto_results(html_text)

        if not page_results:
            break

        new_added = 0
        for it in page_results:
            if it["url"] in seen_urls:
                continue
            seen_urls.add(it["url"])
            all_results.append(it)
            new_added += 1

        if new_added == 0:
            break

    return all_results


# ---------------------------
# SKTONLINE SEARCH
# ---------------------------

_SKTONLINE_BASE = "https://online.sktorrent.eu/"

def _sktonline_abs(url: str, base: str) -> str:
    return urllib.parse.urljoin(base, url)


def _sktonline_extract_results(results_html: str, base_url: str, wanted_query: str = ""):
    out = []
    seen = set()

    html_doc = BeautifulSoup(results_html or "", "html.parser")
    posts = html_doc.find_all("div", {"class": "well well-sm"}, True)

    for post in posts:
        links = post.select("a")
        spans = post.select("span")
        imgs = post.select("img")

        if not links:
            continue
        if not spans:
            continue
        if not imgs:
            continue

        href = (links[0].get("href") or "").strip()
        if not href:
            continue

        full = _sktonline_abs(href, base_url)
        u = urllib.parse.urlparse(full)

        if u.netloc and ("online.sktorrent.eu" not in u.netloc):
            continue

        path = (u.path or "").strip().lower()
        if not path or path == "/":
            continue

        bad_prefixes = (
            "/search",
            "/albums",
            "/blog",
            "/games",
            "/categories",
            "/community",
            "/signup",
            "/login",
            "/lost",
            "/confirm",
            "/upload",
            "/invite",
            "/notices",
            "/feedback",
            "/static",
        )
        if path.startswith(bad_prefixes):
            continue

        name = ""
        try:
            name = (spans[0].get_text() or "").strip()
        except Exception:
            name = ""

        name = re.sub(r"\s+", " ", name).strip()
        if not name:
            continue

        key = full.lower()
        if key in seen:
            continue
        seen.add(key)

        size_bytes = _source_size_from_text(post.get_text(" ", strip=True))

        out.append({
            "title": name,
            "url": full,
            "size_bytes": size_bytes,
        })

    return out

def _sktonline_find_next_page_url(current_html: str, current_url: str):
    m = re.search(r'<a[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']', current_html or "", re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1), current_url)

    pag = re.search(r'(<ul[^>]*class="[^"]*pagination[^"]*"[^>]*>[\s\S]*?</ul>)', current_html or "", re.IGNORECASE)
    if pag:
        ul = pag.group(1)
        mact = re.search(r'<li[^>]*class="[^"]*\bactive\b[^"]*"[^>]*>[\s\S]*?</li>\s*<li[^>]*>[\s\S]*?<a[^>]+href=["\']([^"\']+)["\']', ul, re.IGNORECASE)
        if mact:
            return _sktonline_abs(mact.group(1), current_url)

        mnext = re.search(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>\s*(?:»|&raquo;|next|další|dalsi|>)\s*</a>', ul, re.IGNORECASE)
        if mnext:
            return _sktonline_abs(mnext.group(1), current_url)

    return None

def sktonline_search_all_pages(query: str, max_pages: int = 50):
    q = " ".join((query or "").split()).strip()
    if not q:
        return []

    q_enc = urllib.parse.quote_plus(q)
    safe_q = _cache_safe_key_part(q)

    search_templates = [
        _SKTONLINE_BASE.rstrip("/") + "/search/videos?type=public&t=a&o=mr&search_query=" + q_enc + "&page={page}",
        _SKTONLINE_BASE.rstrip("/") + "/search/videos?search_query=" + q_enc + "&page={page}",
    ]

    out = []
    seen = set()

    try:
        _skt_http_get(_SKTONLINE_BASE.rstrip("/") + "/", referer=_SKTONLINE_BASE.rstrip("/") + "/")
    except Exception:
        pass

    try:
        _skt_http_get(_SKTONLINE_BASE.rstrip("/") + "/videos", referer=_SKTONLINE_BASE.rstrip("/") + "/")
    except Exception:
        pass

    for tmpl_idx, tmpl in enumerate(search_templates, start=1):
        for page_no in range(1, max_pages + 1):
            cur_url = tmpl.format(page=page_no)

            try:
                cur_html = _skt_http_get(cur_url, referer=_SKTONLINE_BASE.rstrip("/") + "/videos")
            except Exception:
                break

            try:
                _dump_text_to_temp(
                    f"skt_search_{safe_q}_tmpl{tmpl_idx}_page{page_no}.html",
                    cur_html
                )
                _dump_text_to_temp(
                    f"skt_search_{safe_q}_tmpl{tmpl_idx}_page{page_no}.txt",
                    f"query={q}\nurl={cur_url}\n"
                )
            except Exception:
                pass

            results = _sktonline_extract_results(cur_html, cur_url, wanted_query=q)

            new_added = 0
            for r in results:
                u = (r.get("url") or "").strip()
                if not u or u in seen:
                    continue
                seen.add(u)
                out.append(r)
                new_added += 1

            if new_added == 0:
                break

    return out

def build_url(query: dict) -> str:
    return BASE_PATH + "?" + urllib.parse.urlencode(query)

def _cache_safe_key_part(s: str) -> str:
    s = _norm_text(s or "")
    s = s.replace(" ", "_")
    s = re.sub(r"[^a-z0-9_]+", "", s)
    return s[:80] or "x"

def _format_episode_code(season: str, episode: str) -> str:
    try:
        season_i = int(str(season or "").strip())
        episode_i = int(str(episode or "").strip())
        return f"S{season_i:02d}E{episode_i:02d}"
    except Exception:
        season = str(season or "").strip()
        episode = str(episode or "").strip()
        if season and episode:
            return f"S{season}E{episode}"
    return ""

def _build_playback_display_title(meta: dict, fallback_title: str, mode: str = "",
                                  season: str = "", episode: str = "", episode_title: str = "") -> str:
    media_title = str((meta or {}).get("title") or "").strip()
    original_title = str((meta or {}).get("original_title") or "").strip()
    media_title = media_title or original_title or str(fallback_title or "").strip() or "Zdroj"

    if str(mode or "").strip().lower() == "serial_episode":
        code = _format_episode_code(season, episode)
        parts = [media_title]
        if code:
            parts.append(code)
        episode_title = str(episode_title or "").strip()
        if episode_title:
            parts.append(episode_title)
        return " - ".join(parts)

    return media_title

def _with_playback_display_title(play_target: str, display_title: str) -> str:
    if not play_target or not display_title:
        return play_target
    if not str(play_target).startswith("plugin://"):
        return play_target

    try:
        parsed = urllib.parse.urlsplit(play_target)
        query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        action = (query.get("action") or [""])[0]
        if action not in ("film.play", "play"):
            return play_target

        query["name"] = [display_title]
        query["title"] = [display_title]
        query["play_title"] = [display_title]
        new_query = urllib.parse.urlencode(query, doseq=True)
        return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path, new_query, parsed.fragment))
    except Exception:
        return play_target

def _source_cache_key(provider: str, title: str, original_title: str, year: str,
                      mode: str = "", season: str = "", episode: str = "") -> str:
    return "||".join([
        _SOURCE_SEARCH_FILTER_VERSION,
        (provider or "").strip().lower(),
        _norm_text(title or ""),
        _norm_text(original_title or ""),
        (year or "").strip(),
        (mode or "").strip().lower(),
        str(season or "").strip(),
        str(episode or "").strip(),
    ])

def _source_cache_filename(provider: str, title: str, original_title: str, year: str,
                           mode: str = "", season: str = "", episode: str = "") -> str:
    return (
        "ikarus_sources_"
        + _cache_safe_key_part(_SOURCE_SEARCH_FILTER_VERSION)
        + "_"
        + _cache_safe_key_part(provider)
        + "_"
        + _cache_safe_key_part(title)
        + "_"
        + _cache_safe_key_part(original_title)
        + "_"
        + _cache_safe_key_part(year)
        + "_"
        + _cache_safe_key_part(mode)
        + "_"
        + _cache_safe_key_part(season)
        + "_"
        + _cache_safe_key_part(episode)
        + ".json"
    )
def _source_cache_path(provider: str, title: str, original_title: str, year: str,
                       mode: str = "", season: str = "", episode: str = "") -> str:
    fname = _source_cache_filename(provider, title, original_title, year, mode, season, episode)
    return xbmcvfs.translatePath("special://temp/" + fname)

def _source_cache_get(provider: str, title: str, original_title: str, year: str,
                      mode: str = "", season: str = "", episode: str = ""):
    import time

    key = _source_cache_key(provider, title, original_title, year, mode, season, episode)
    now = time.time()

    mem = _SOURCE_SEARCH_CACHE.get(key)
    if mem:
        ts = float(mem.get("ts") or 0)
        if (now - ts) <= _SOURCE_SEARCH_CACHE_TTL:
            return mem.get("rows") or []

    path = _source_cache_path(provider, title, original_title, year, mode, season, episode)
    if not xbmcvfs.exists(path):
        return None

    try:
        f = xbmcvfs.File(path, "r")
        raw = f.read()
        f.close()

        data = json.loads(raw or "{}")
        ts = float(data.get("ts") or 0)
        rows = data.get("rows") or []

        if (now - ts) > _SOURCE_SEARCH_CACHE_TTL:
            return None

        _SOURCE_SEARCH_CACHE[key] = {
            "ts": ts,
            "rows": rows,
        }
        return rows
    except Exception as e:
        xbmc.log(f"[IKARUS][SRC CACHE] READ FAILED: {repr(e)}", xbmc.LOGERROR)
        return None
    
def _source_cache_set(provider: str, title: str, original_title: str, year: str, rows,
                      mode: str = "", season: str = "", episode: str = ""):
    import time

    key = _source_cache_key(provider, title, original_title, year, mode, season, episode)
    now = time.time()
    rows = list(rows or [])

    _SOURCE_SEARCH_CACHE[key] = {
        "ts": now,
        "rows": rows,
    }

    path = _source_cache_path(provider, title, original_title, year, mode, season, episode)

    try:
        payload = {
            "ts": now,
            "provider": provider,
            "title": title,
            "original_title": original_title,
            "year": year,
            "mode": mode,
            "season": season,
            "episode": episode,
            "rows": rows,
        }
        f = xbmcvfs.File(path, "w")
        f.write(json.dumps(payload, ensure_ascii=False))
        f.close()
    except Exception as e:
        xbmc.log(f"[IKARUS][SRC CACHE] WRITE FAILED: {repr(e)}", xbmc.LOGERROR)

def _source_cache_clear(provider: str, title: str, original_title: str, year: str,
                        mode: str = "", season: str = "", episode: str = ""):
    key = _source_cache_key(provider, title, original_title, year, mode, season, episode)
    _SOURCE_SEARCH_CACHE.pop(key, None)

    path = _source_cache_path(provider, title, original_title, year, mode, season, episode)
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
    except Exception:
        pass

def _refresh_token_already_handled(token: str) -> bool:
    import time

    token = (token or "").strip()
    if not token:
        return False

    now = time.time()

    # úklid starých tokenů
    stale = []
    for k, ts in _HANDLED_REFRESH_TOKENS.items():
        try:
            if (now - float(ts)) > _HANDLED_REFRESH_TOKEN_TTL:
                stale.append(k)
        except Exception:
            stale.append(k)

    for k in stale:
        _HANDLED_REFRESH_TOKENS.pop(k, None)

    ts = _HANDLED_REFRESH_TOKENS.get(token)
    if ts is None:
        return False

    try:
        return (now - float(ts)) <= _HANDLED_REFRESH_TOKEN_TTL
    except Exception:
        return False

def _mark_refresh_token_handled(token: str):
    import time
    token = (token or "").strip()
    if not token:
        return
    _HANDLED_REFRESH_TOKENS[token] = time.time()

def _get_param(name: str, default: str = "") -> str:
    if len(sys.argv) < 3 or not sys.argv[2]:
        return default
    params = urllib.parse.parse_qs(sys.argv[2][1:])
    return params.get(name, [default])[0]


def _end(content="files"):
    try:
        xbmcplugin.setContent(addon_handle, content)
    except Exception:
        pass
    xbmcplugin.endOfDirectory(addon_handle)

def _add_result_dir(label: str, query: dict, plot: str = "", icon: str = "DefaultVideo.png"):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        "icon": icon,
        "thumb": icon,
        "poster": icon
    })
    if plot:
        li.setInfo("video", {"title": label, "plot": plot})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(query),
        listitem=li,
        isFolder=True
    )

def _add_dir(label: str, query: dict, icon: str = "DefaultFolder.png"):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        "icon": icon,
        "thumb": icon,
        "poster": icon
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(query),
        listitem=li,
        isFolder=True
    )

def _add_command_item(label: str, query: dict, icon: str = "DefaultAddonProgram.png"):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        "icon": icon,
        "thumb": icon,
        "poster": icon
    })
    li.setProperty("IsPlayable", "false")

    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url(query),
        listitem=li,
        isFolder=False
    )

def _add_file(label: str, plot: str = "", icon: str = "DefaultVideo.png"):
    li = xbmcgui.ListItem(label=label)
    li.setArt({
        "icon": icon,
        "thumb": icon,
        "poster": icon
    })
    if plot:
        li.setInfo("video", {"title": label, "plot": plot})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url="",
        listitem=li,
        isFolder=False
    )

def _refresh_current_container():
    try:
        xbmc.executebuiltin("Container.Refresh")
    except Exception:
        pass

def _finish_command_action():
    try:
        xbmcplugin.endOfDirectory(
            addon_handle,
            succeeded=True,
            updateListing=False,
            cacheToDisc=False
        )
    except Exception:
        pass

def _placeholder_dir(title: str, extra: str = ""):
    xbmcplugin.setPluginCategory(addon_handle, title)
    xbmcplugin.setContent(addon_handle, "files")

    text = "Na této sekci se pracuje."
    if extra:
        text += " " + extra

    _add_file(text, icon="DefaultAddonProgram.png")
    _end("files")

def _norm_text(s: str) -> str:
    s = (s or "").lower().strip()
    s = "".join(
        ch for ch in unicodedata.normalize("NFKD", s)
        if not unicodedata.combining(ch)
    )

    repl = {
        "á": "a", "ä": "a", "č": "c", "ď": "d", "é": "e", "ě": "e",
        "í": "i", "ľ": "l", "ĺ": "l", "ň": "n", "ó": "o", "ô": "o",
        "ř": "r", "ŕ": "r", "š": "s", "ť": "t", "ú": "u", "ů": "u",
        "ý": "y", "ž": "z",
    }
    for a, b in repl.items():
        s = s.replace(a, b)

    s = s.replace("&", " and ")
    s = s.replace("+", " ")
    s = s.replace("/", " ")
    s = s.replace("-", " ")
    s = s.replace("_", " ")

    s = re.sub(r"[^\w\s]", " ", s, flags=re.UNICODE)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def _search_safe_text(s: str) -> str:
    s = _norm_text(s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def _is_generic_episode_title(s: str) -> bool:
    s_norm = _norm_text(s or "")
    if not s_norm:
        return False

    # sjednocení tvarů
    toks = [t for t in s_norm.split() if t]
    if not toks:
        return False

    generic_words = {
        "epizoda", "epizode", "epizody",
        "epizoda.", "epizode.", "epizody.",
        "epizoda:", "epizode:", "epizody:",
        "episode", "episodes",
        "dil", "dilu", "diel", "dielu",
        "cast", "část", "part", "sekce"
    }

    # povolíme i tvary typu:
    # "1 epizoda", "epizoda 1", "1. epizoda", "díl 1", "epizóda 1"
    cleaned = []
    for t in toks:
        tt = t.strip(".:-_")
        if tt:
            cleaned.append(tt)

    if not cleaned:
        return False

    # když jsou tam jen čísla + obecná slova pro epizodu, bereme to jako generický název
    non_generic = []
    has_generic_word = False

    for t in cleaned:
        if t in generic_words:
            has_generic_word = True
            continue
        if re.fullmatch(r"\d+", t):
            continue
        non_generic.append(t)

    if has_generic_word and not non_generic:
        return True

    # ještě tvar čistě "1", "01" apod. samotný nebereme jako smysluplný název epizody
    if len(cleaned) == 1 and re.fullmatch(r"\d+", cleaned[0]):
        return True

    return False

def _episode_title_allowed_extra_tokens():
    return {
        "cz", "sk", "en", "dab", "czdab", "skdab", "dual", "multi",
        "tit", "titulky", "sub", "subs", "czsub", "sksub", "engsub", "forced",
        "hd", "fhd", "uhd", "sd", "hdr", "dv", "hevc", "x264", "x265", "h264", "h265",
        "aac", "ac3", "dd", "ddp", "ddp5", "atmos", "dts",
        "webrip", "webdl", "web", "dl", "bluray", "bdrip", "dvdrip", "hdtv", "tvrip", "tv", "rip", "dvb",
        "mkv", "mp4", "avi",
        "proper", "repack", "extended", "uncut",
        "nf", "netflix", "amzn", "amazon", "dsnp", "disney", "hbo", "max",
        "s01", "s02", "s03", "s04", "s05", "s06", "s07", "s08", "s09", "s10",
        "e01", "e02", "e03", "e04", "e05", "e06", "e07", "e08", "e09", "e10",
        "epizoda", "episode", "dil", "diel"
    }

def _is_clean_episode_title_match(candidate_title: str, episode_title: str) -> bool:
    cand_tokens = _title_tokens(candidate_title)
    ep_tokens = _title_tokens(episode_title)

    if not cand_tokens or not ep_tokens:
        return False

    # najdi souvislý blok tokenů epizody v kandidátu
    hit_pos = -1
    ep_len = len(ep_tokens)

    for i in range(0, len(cand_tokens) - ep_len + 1):
        if cand_tokens[i:i + ep_len] == ep_tokens:
            hit_pos = i
            break

    if hit_pos < 0:
        return False

    before = cand_tokens[:hit_pos]
    after = cand_tokens[hit_pos + ep_len:]
    extras = before + after

    allowed = _episode_title_allowed_extra_tokens()

    # povol:
    # - žádné extra tokeny
    # - jen pár technických tokenů
    # - čísla / rozlišení / SxxEyy / 1x02 apod.
    if not extras:
        return True

    if len(extras) > 5:
        return False

    for t in extras:
        if t in allowed:
            continue
        if re.fullmatch(r"\d{1,4}p?", t):
            continue
        if re.fullmatch(r"s\d{1,2}e\d{1,2}", t):
            continue
        if re.fullmatch(r"\d{1,2}x\d{1,2}", t):
            continue
        if re.fullmatch(r"e\d{1,2}", t):
            continue
        if re.fullmatch(r"s\d{1,2}", t):
            continue
        return False

    return True

def _serial_episode_unknown_tokens(candidate_title: str, title: str, original_title: str,
                                   episode_title: str, season_name: str = ""):
    cand_tokens = _title_tokens(candidate_title)
    if not cand_tokens:
        return []

    allowed = set()

    allowed.update(_title_tokens(title))
    allowed.update(_title_tokens(original_title))
    allowed.update(_title_tokens(episode_title))
    allowed.update(_title_tokens(season_name))

    allowed.update(_episode_title_allowed_extra_tokens())

    out = []

    for t in cand_tokens:
        if t in allowed:
            continue
        if re.fullmatch(r"(19\d{2}|20\d{2}|21\d{2})", t):
            continue
        if re.fullmatch(r"\d{1,4}p?", t):
            continue
        if re.fullmatch(r"s\d{1,2}e\d{1,2}", t):
            continue
        if re.fullmatch(r"\d{1,2}x\d{1,2}", t):
            continue
        if re.fullmatch(r"e\d{1,2}", t):
            continue
        if re.fullmatch(r"s\d{1,2}", t):
            continue
        if re.fullmatch(r"\d+", t):
            continue
        out.append(t)

    return out

def _title_connector_tokens():
    return {
        "a", "an", "and", "the", "of", "to", "in", "on", "for", "with",
        "o", "i", "v", "ve", "na", "do", "z", "ze", "se", "s",
    }

def _serial_specific_title_tokens(title: str, original_title: str):
    local = [t for t in _title_tokens(title) if t not in _title_connector_tokens()]
    orig = [t for t in _title_tokens(original_title) if t not in _title_connector_tokens()]

    local_set = set(local)
    orig_set = set(orig)
    all_tokens = local_set | orig_set
    if not all_tokens:
        return set()

    shared = local_set & orig_set if local_set and orig_set and local_set != orig_set else set()
    specific = all_tokens - shared

    if specific:
        return specific

    tokens = local or orig
    if len(tokens) >= 4:
        return set(tokens[3:])

    return set()

def _serial_episode_identity_issue(candidate_title: str, title: str, original_title: str,
                                   episode_title: str, season_name: str = ""):
    unknown = _serial_episode_unknown_tokens(
        candidate_title=candidate_title,
        title=title,
        original_title=original_title,
        episode_title=episode_title,
        season_name=season_name
    )
    if not unknown:
        return False, []

    cand_norm = _norm_text(candidate_title)
    if (title and _norm_text(title) in cand_norm) or (original_title and _norm_text(original_title) in cand_norm):
        return False, unknown

    specific = _serial_specific_title_tokens(title, original_title)
    if not specific:
        return False, unknown

    cand_tokens = set(_title_tokens(candidate_title))
    specific_hit = len(specific & cand_tokens)
    local_core = [t for t in _title_tokens(title) if t not in _title_connector_tokens()]
    orig_core = [t for t in _title_tokens(original_title) if t not in _title_connector_tokens()]

    if max(len(local_core), len(orig_core)) <= 1 and specific_hit >= 1:
        return False, unknown

    if specific_hit == 0:
        return True, unknown
    if len(specific) >= 2 and specific_hit < 2:
        return True, unknown

    return False, unknown

def _query_variants_for_search(title: str, original_title: str, year: str):
    title = (title or "").strip()
    original_title = (original_title or "").strip()
    year = (year or "").strip()

    out = []
    seen = set()

    def add(q):
        q = " ".join((q or "").split()).strip()
        if not q:
            return
        k = q.lower()
        if k in seen:
            return
        seen.add(k)
        out.append(q)

    # původní varianty
    add(title)
    add(original_title)
    if title and year:
        add(f"{title} {year}")
    if original_title and year and original_title.lower() != title.lower():
        add(f"{original_title} {year}")

    # bez diakritiky / normalizované varianty
    safe_title = _search_safe_text(title)
    safe_orig = _search_safe_text(original_title)

    add(safe_title)
    add(safe_orig)
    if safe_title and year:
        add(f"{safe_title} {year}")
    if safe_orig and year:
        add(f"{safe_orig} {year}")

    # kratší tokenové varianty
    title_tokens = _title_tokens(title)
    orig_tokens = _title_tokens(original_title)

    if len(title_tokens) >= 2:
        add(" ".join(title_tokens[:2]))
        add(" ".join(title_tokens[-2:]))

    if len(orig_tokens) >= 2:
        add(" ".join(orig_tokens[:2]))
        add(" ".join(orig_tokens[-2:]))

    # bez krátkých spojek/předložek – pro weby, které hledají lépe přes klíčová slova
    stop_words = {"a", "i", "v", "ve", "na", "do", "od", "z", "ze", "u", "s", "nad", "pod", "pro"}

    short_title_tokens = [t for t in title_tokens if t not in stop_words]
    short_orig_tokens = [t for t in orig_tokens if t not in stop_words]

    if len(short_title_tokens) >= 2:
        add(" ".join(short_title_tokens))
        add(" ".join(short_title_tokens[:3]))
        add(" ".join(short_title_tokens[-3:]))

    if len(short_orig_tokens) >= 2:
        add(" ".join(short_orig_tokens))
        add(" ".join(short_orig_tokens[:3]))
        add(" ".join(short_orig_tokens[-3:]))

    # kratší + rok
    if len(title_tokens) >= 2 and year:
        add(" ".join(title_tokens[:2]) + f" {year}")
        add(" ".join(title_tokens[-2:]) + f" {year}")

    if len(orig_tokens) >= 2 and year:
        add(" ".join(orig_tokens[:2]) + f" {year}")
        add(" ".join(orig_tokens[-2:]) + f" {year}")

    return out


def _season_episode_code(season: str, episode: str) -> str:
    try:
        s = int(season)
        e = int(episode)
        return f"S{s:02d}E{e:02d}"
    except Exception:
        return ""

def _episode_query_number_variants(season: str, episode: str):
    try:
        s = int(str(season or "").strip())
        e = int(str(episode or "").strip())
    except Exception:
        return []
    if s <= 0 or e <= 0:
        return []
    return [
        f"S{s:02d}E{e:02d}",
        f"{s:02d}x{e:02d}",
        f"{s}x{e:02d}",
        f"{s}.{e:02d}",
    ]

def _episode_number_match_info(text: str, season: str, episode: str):
    try:
        s = int(str(season or "").strip())
        e = int(str(episode or "").strip())
    except Exception:
        return False, False, "", 0
    if s <= 0 or e <= 0:
        return False, False, "", 0

    raw = text or ""
    strong_patterns = [
        (r"\b[Ss]\s*0*%d\s*[Ee]\s*0*%d\b" % (s, e), "S%02dE%02d" % (s, e)),
        (r"\b0*%d\s*[xX]\s*0*%d\b" % (s, e), "%dx%02d" % (s, e)),
        (r"\b0*%d[.]\s*0*%d\b" % (s, e), "%d.%02d" % (s, e)),
    ]
    for pattern, label in strong_patterns:
        if re.search(pattern, raw):
            return True, False, label, 2

    explicit_wrong = False
    for m in re.finditer(r"\b[Ss]\s*0*(\d{1,2})\s*[Ee]\s*0*(\d{1,3})\b", raw):
        try:
            if int(m.group(1)) != s or int(m.group(2)) != e:
                explicit_wrong = True
        except Exception:
            pass
    for m in re.finditer(r"\b0*(\d{1,2})\s*[xX]\s*0*(\d{1,3})\b", raw):
        try:
            if int(m.group(1)) != s or int(m.group(2)) != e:
                explicit_wrong = True
        except Exception:
            pass
    for m in re.finditer(r"\b0*(\d{1,2})[.]\s*0*(\d{1,3})\b", raw):
        try:
            if int(m.group(1)) != s or int(m.group(2)) != e:
                explicit_wrong = True
        except Exception:
            pass
    if explicit_wrong:
        return False, True, "", 0

    weak_patterns = [
        (r"\b[Ee][Pp]?\s*[.]?\s*0*%d\b" % e, "E%02d" % e),
        (r"\b[Ee]pisode\s*0*%d\b" % e, "Episode %d" % e),
        (r"\b[Dd][ií]l\s*0*%d\b" % e, "Dil %d" % e),
        (r"\b[Dd]iel\s*0*%d\b" % e, "Diel %d" % e),
        (r"\b[Pp]art[.]?\s*0*%d\b" % e, "Part %d" % e),
    ]
    for pattern, label in weak_patterns:
        if re.search(pattern, raw):
            return True, False, label, 1

    wrong = False
    for m in re.finditer(r"\b[Ss]\s*0*(\d{1,2})\s*[Ee]\s*0*(\d{1,3})\b", raw):
        try:
            if int(m.group(1)) != s or int(m.group(2)) != e:
                wrong = True
        except Exception:
            pass
    for m in re.finditer(r"\b0*(\d{1,2})\s*[xX]\s*0*(\d{1,3})\b", raw):
        try:
            if int(m.group(1)) != s or int(m.group(2)) != e:
                wrong = True
        except Exception:
            pass
    for m in re.finditer(r"\b0*(\d{1,2})[.]\s*0*(\d{1,3})\b", raw):
        try:
            if int(m.group(1)) != s or int(m.group(2)) != e:
                wrong = True
        except Exception:
            pass
    for m in re.finditer(r"\b(?:[Ee][Pp]?|[Ee]pisode|[Dd][ií]l|[Dd]iel|[Pp]art[.]?)\s*[.]?\s*0*(\d{1,3})\b", raw):
        try:
            if int(m.group(1)) != e:
                wrong = True
        except Exception:
            pass

    return False, wrong, "", 0


def _extract_episode_codes(text: str):
    s = _norm_text(text or "")
    flat = s.replace(" ", "")

    out = set()

    for m in re.finditer(r"s(\d{1,2})e(\d{1,2})", flat, re.IGNORECASE):
        try:
            out.add(f"S{int(m.group(1)):02d}E{int(m.group(2)):02d}")
        except Exception:
            pass

    for m in re.finditer(r"(\d{1,2})x(\d{1,2})", flat, re.IGNORECASE):
        try:
            out.add(f"S{int(m.group(1)):02d}E{int(m.group(2)):02d}")
        except Exception:
            pass

    for m in re.finditer(r"\b0*(\d{1,2})[.]\s*0*(\d{1,3})\b", text or "", re.IGNORECASE):
        try:
            out.add(f"S{int(m.group(1)):02d}E{int(m.group(2)):02d}")
        except Exception:
            pass

    return sorted(out)

def _serial_name_match_strength(candidate_title: str, title: str, original_title: str) -> int:
    cand_tokens = set(_title_tokens(candidate_title))
    local_tokens = set(_title_tokens(title))
    orig_tokens = set(_title_tokens(original_title))

    local_phrase = bool(title and _norm_text(title) in _norm_text(candidate_title))
    orig_phrase = bool(original_title and _norm_text(original_title) in _norm_text(candidate_title))

    local_hit = len(local_tokens & cand_tokens) if local_tokens else 0
    orig_hit = len(orig_tokens & cand_tokens) if orig_tokens else 0

    strength = 0

    if local_phrase:
        strength = max(strength, 3)
    elif len(local_tokens) >= 2 and local_hit >= 2:
        strength = max(strength, 2)
    elif len(local_tokens) == 1 and local_hit >= 1:
        strength = max(strength, 1)

    if orig_phrase:
        strength = max(strength, 3)
    elif len(orig_tokens) >= 2 and orig_hit >= 2:
        strength = max(strength, 2)
    elif len(orig_tokens) == 1 and orig_hit >= 1:
        strength = max(strength, 1)

    return strength


def _filter_sktonline_serial_episode_rows(rows, title: str, original_title: str,
                                          season: str, episode: str, episode_title: str,
                                          season_name: str = ""):
    wanted_code = _season_episode_code(season, episode)
    ep_norm = _norm_text(episode_title or "")

    prepared = []

    for row in (rows or []):
        cand_title = (row.get("title") or "").strip()
        if not cand_title:
            continue

        ok, _why = _is_candidate_relevant(
            candidate_title=cand_title,
            title=title,
            original_title=original_title,
            year="",
            mode="serial_episode",
            season=season,
            episode=episode,
            episode_title=episode_title,
            season_name=season_name
        )
        if not ok:
            continue

        name_strength = _serial_name_match_strength(cand_title, title, original_title)
        if name_strength < 2:
            continue

        cand_codes = _extract_episode_codes(cand_title)
        cand_norm = _norm_text(cand_title)

        wrong_episode = False
        exact_episode = False

        if wanted_code:
            if wanted_code in cand_codes:
                exact_episode = True
            elif cand_codes:
                wrong_episode = True

        ep_title_hit = bool(ep_norm and ep_norm in cand_norm)

        if wrong_episode:
            continue

        base_score, reasons = _score_candidate(
            candidate_title=cand_title,
            title=title,
            original_title=original_title,
            year="",
            mode="serial_episode",
            season=season,
            episode=episode,
            episode_title=episode_title,
            season_name=season_name
        )

        score = int(base_score)

        if exact_episode:
            score += 120
            reasons = list(reasons) + [f"přesná shoda epizody {wanted_code}"]

        if ep_title_hit:
            score += 40
            reasons = list(reasons) + ["shoda názvu epizody"]

        score += name_strength * 20
        reasons = list(reasons) + [f"shoda seriálu: {name_strength}"]

        item = dict(row)
        item["_score"] = score
        item["_why"] = reasons
        prepared.append(item)

    prepared.sort(key=lambda x: (x.get("_score", 0), x.get("title", "")), reverse=True)
    return prepared

def _title_tokens(s: str):
    s = _norm_text(s)
    if not s:
        return []
    return [x for x in s.split(" ") if x]

def _extract_years(text: str):
    years = []
    for m in re.finditer(r"(19\d{2}|20\d{2}|21\d{2})", text or ""):
        years.append(m.group(1))
    return years

def _has_episode_marker(text: str) -> bool:
    s = _norm_text(text)

    if re.search(r"\bs\d{1,2}e\d{1,2}\b", s):
        return True
    if re.search(r"\b\d{1,2}x\d{1,2}\b", s):
        return True

    toks = set(_title_tokens(text))
    episode_words = {
        "season", "serie", "serial", "epizoda", "episode", "episodes",
        "dil", "diel", "s01", "s02", "s03", "s04", "s05", "s06", "s07", "s08",
    }
    return bool(toks & episode_words)

def _has_music_marker(text: str) -> bool:
    toks = set(_title_tokens(text))
    music_words = {
        "song", "audio", "album", "karaoke", "lyrics", "lyric", "remix",
        "mix", "live", "concert", "videoklip", "klip", "ost", "soundtrack",
        "music", "mp3", "flac",
    }
    return bool(toks & music_words)

def _is_candidate_relevant(candidate_title: str, title: str, original_title: str, year: str,
                           mode: str = "", season: str = "", episode: str = "",
                           episode_title: str = "", season_name: str = ""):
    cand_raw = (candidate_title or "").strip()
    cand = _norm_text(cand_raw)

    local_title = (title or "").strip()
    orig_title = (original_title or "").strip()
    wanted_year = (year or "").strip()

    if not cand:
        return False, "prázdný název"

    # tvrdé bloky – ale už bez dabingu
    noise_words = {
        "trailer", "ukazka", "sample", "cam", "ts", "workprint",
        "bonus", "soundtrack"
    }
    cand_tokens = set(_title_tokens(cand_raw))

    if noise_words & cand_tokens:
        return False, "obsahuje šum"

    if _has_music_marker(cand_raw):
        return False, "vypadá jako hudba"

    if (mode or "").strip() != "serial_episode":
        if _has_episode_marker(cand_raw):
            return False, "vypadá jako epizoda seriálu"

    local_tokens = set(_title_tokens(local_title))
    orig_tokens = set(_title_tokens(orig_title))

    local_hit = len(local_tokens & cand_tokens) if local_tokens else 0
    orig_hit = len(orig_tokens & cand_tokens) if orig_tokens else 0

    local_phrase = bool(local_title and _norm_text(local_title) in cand)
    orig_phrase = bool(orig_title and _norm_text(orig_title) in cand)

    cand_years = _extract_years(cand_raw)

    if wanted_year and cand_years and wanted_year not in cand_years:
        return False, "jiný rok"

    strong_local = False
    if local_tokens:
        if local_phrase:
            strong_local = True
        elif len(local_tokens) >= 2 and local_hit >= 2:
            strong_local = True
        elif len(local_tokens) == 1 and local_hit >= 1 and wanted_year and wanted_year in cand_years:
            strong_local = True

    strong_orig = False
    if orig_tokens:
        if len(orig_tokens) >= 2:
            if orig_phrase or orig_hit >= 2:
                strong_orig = True
        else:
            if orig_phrase and wanted_year and wanted_year in cand_years:
                strong_orig = True

    if (mode or "").strip() == "serial_episode":
        code = _season_episode_code(season, episode)
        cand_norm = _norm_text(cand_raw)
        ep_title_norm = _norm_text(episode_title or "")
        generic_ep_title = _is_generic_episode_title(episode_title)
        number_hit, wrong_number, number_label, number_strength = _episode_number_match_info(
            cand_raw, season, episode
        )
        number_with_ep_title = bool(number_hit and ep_title_norm and not generic_ep_title and ep_title_norm in cand_norm)

        if wrong_number and not number_hit:
            return False, "jiná epizoda"

        strong_episode = False
        exact_episode_code = False
        clean_episode_title_match = False

        if number_hit:
            strong_episode = True
            exact_episode_code = number_strength >= 2
        elif code and code.lower() in cand_norm.replace(" ", ""):
            strong_episode = True
            exact_episode_code = True
        elif ep_title_norm and not generic_ep_title and ep_title_norm in cand_norm:
            if _is_clean_episode_title_match(cand_raw, episode_title):
                strong_episode = True
                clean_episode_title_match = True
            else:
                return False, "název epizody je v cizím kontextu"

        if not strong_episode:
            return False, "slabá shoda epizody"

        if clean_episode_title_match:
            return True, ""

        if number_with_ep_title:
            return True, ""

        identity_issue, _identity_unknown = _serial_episode_identity_issue(
            candidate_title=cand_raw,
            title=title,
            original_title=original_title,
            episode_title=episode_title,
            season_name=season_name
        )
        if identity_issue:
            return False, "cizí název seriálu"

        if local_phrase or orig_phrase:
            return True, ""

    if not strong_local and not strong_orig:
        return False, "slabá shoda názvu"

    return True, ""

def _score_candidate(candidate_title: str, title: str, original_title: str, year: str,
                     mode: str = "", season: str = "", episode: str = "", episode_title: str = "",
                     season_name: str = ""):
    cand_raw = (candidate_title or "").strip()
    cand = _norm_text(cand_raw)

    local_title = _norm_text(title)
    orig_title = _norm_text(original_title)
    wanted_year = (year or "").strip()

    score = 0
    reasons = []

    if not cand:
        return -999, ["prázdný název"]

    if local_title and cand == local_title:
        score += 100
        reasons.append("přesná shoda lokálního názvu")

    if orig_title and cand == orig_title:
        score += 100
        reasons.append("přesná shoda originálního názvu")

    if local_title and local_title in cand:
        score += 50
        reasons.append("obsahuje lokální název")

    orig_token_count = len(_title_tokens(original_title))
    if orig_title and orig_title in cand:
        if orig_token_count >= 2:
            score += 50
            reasons.append("obsahuje originální název")
        else:
            score += 15
            reasons.append("obsahuje jednoslovný originální název")

    cand_tokens = set(_title_tokens(cand_raw))
    local_tokens = set(_title_tokens(title))
    orig_tokens = set(_title_tokens(original_title))
    season_tokens = set(_title_tokens(season_name))

    if local_tokens:
        hit = len(local_tokens & cand_tokens)
        score += hit * 8
        if hit:
            reasons.append(f"shoda tokenů lokálního názvu: {hit}")

    if orig_tokens:
        hit = len(orig_tokens & cand_tokens)
        if len(orig_tokens) >= 2:
            score += hit * 8
            if hit:
                reasons.append(f"shoda tokenů originálního názvu: {hit}")
        else:
            score += hit * 3
            if hit:
                reasons.append(f"shoda tokenů jednoslovného originálního názvu: {hit}")

    if season_tokens:
        hit = len(season_tokens & cand_tokens)
        score += hit * 6
        if hit:
            reasons.append(f"shoda tokenů názvu série: {hit}")

    cand_years = _extract_years(cand_raw)
    if wanted_year:
        if wanted_year in cand_years:
            score += 40
            reasons.append("souhlasí rok")
        elif cand_years:
            score -= 140
            reasons.append("jiný rok")

    noise_words = {
        "trailer", "ukazka", "sample", "cam", "ts", "workprint",
        "titulky", "bonus", "soundtrack"
    }
    noise_hit = len(noise_words & cand_tokens)
    if noise_hit:
        score -= noise_hit * 80
        reasons.append("obsahuje šum")

    if "czdab" in cand_tokens:
        score += 35
        reasons.append("obsahuje CZ dabing")
    elif "dabing" in cand_tokens or "dab" in cand_tokens:
        score += 20
        reasons.append("obsahuje dabing")

    if "skdab" in cand_tokens:
        score += 10
        reasons.append("obsahuje SK dabing")

    if (mode or "").strip() == "serial_episode":
        code = _season_episode_code(season, episode)
        cand_flat = cand.replace(" ", "")
        ep_norm = _norm_text(episode_title or "")
        generic_ep_title = _is_generic_episode_title(episode_title)
        clean_ep_match = _is_clean_episode_title_match(cand_raw, episode_title) if ep_norm else False
        number_hit, wrong_number, number_label, number_strength = _episode_number_match_info(
            cand_raw, season, episode
        )
        number_with_ep_title = bool(number_hit and ep_norm and not generic_ep_title and ep_norm in cand)

        if wrong_number and not number_hit:
            score -= 180
            reasons.append("jina epizoda")

        if number_hit:
            bonus = 90 if number_strength >= 2 else 60
            score += bonus
            reasons.append(f"obsahuje epizodu {number_label or code}")
        elif code and code.lower() in cand_flat:
            score += 80
            reasons.append(f"obsahuje epizodu {code}")

        if ep_norm and not generic_ep_title and ep_norm in cand:
            if clean_ep_match:
                score += 40
                reasons.append("obsahuje čistý název epizody")

                if cand == ep_norm:
                    score += 60
                    reasons.append("přesná shoda názvu epizody")
                elif cand.startswith(ep_norm):
                    score += 25
                    reasons.append("začíná názvem epizody")
                elif cand.endswith(ep_norm):
                    score += 25
                    reasons.append("končí názvem epizody")
            elif number_hit:
                score += 65
                reasons.append("obsahuje nazev epizody a spravne cislo")
            else:
                # kompromis:
                # když sedí seriál + epizoda + title epizody, ale je tam 1 cizí token navíc
                # (např. Rise), nedáme plný bonus, ale ani to úplně nezabijeme
                unknown = _serial_episode_unknown_tokens(
                    candidate_title=cand_raw,
                    title=title,
                    original_title=original_title,
                    episode_title=episode_title,
                    season_name=season_name
                )

                if len(unknown) <= 1:
                    score += 45
                    reasons.append("obsahuje název epizody s malým přesahem")
                else:
                    score -= 120
                    reasons.append("název epizody je v cizím kontextu")

        identity_issue, unknown = _serial_episode_identity_issue(
            candidate_title=cand_raw,
            title=title,
            original_title=original_title,
            episode_title=episode_title,
            season_name=season_name
        )

        if unknown and not number_with_ep_title:
            if identity_issue:
                score -= 220
                reasons.append("cizí název seriálu: " + ", ".join(unknown[:4]))
            elif number_hit and (local_title and local_title in cand or orig_title and orig_title in cand):
                pass
            else:
                penalty = min(len(unknown), 4) * 35
                score -= penalty
                reasons.append("cizí tokeny: " + ", ".join(unknown[:4]))

    return score, reasons

def _filter_candidates(rows, title: str, original_title: str, year: str, min_score: int = 35,
                       mode: str = "", season: str = "", episode: str = "", episode_title: str = "",
                       season_name: str = ""):
    scored = []

    for row in (rows or []):
        cand_title = (row.get("title") or "").strip()

        ok, why_not = _is_candidate_relevant(
            candidate_title=cand_title,
            title=title,
            original_title=original_title,
            year=year,
            mode=mode,
            season=season,
            episode=episode,
            episode_title=episode_title,
            season_name=season_name
        )
        if not ok:
            continue

        score, reasons = _score_candidate(
            candidate_title=cand_title,
            title=title,
            original_title=original_title,
            year=year,
            mode=mode,
            season=season,
            episode=episode,
            episode_title=episode_title,
            season_name=season_name
        )

        if score < min_score:
            continue

        item = dict(row)
        item["_score"] = score
        item["_why"] = reasons
        scored.append(item)

    scored.sort(key=lambda x: (x.get("_score", 0), x.get("title", "")), reverse=True)
    return scored

def _provider_result(title: str, url: str = "", provider: str = "", year: str = "", plot: str = "", **extra):
    row = {
        "title": (title or "").strip(),
        "url": (url or "").strip(),
        "provider": (provider or "").strip(),
        "year": (year or "").strip(),
        "plot": (plot or "").strip(),
    }

    for k, v in (extra or {}).items():
        row[k] = v

    return row

def _source_int_from_any(value, default: int = 0) -> int:
    try:
        if value is None:
            return default
        if isinstance(value, (int, float)):
            return int(value)
        text = str(value).strip()
        if not text:
            return default
        if re.fullmatch(r"\d+", text):
            return int(text)

        size_from_text = _source_size_from_text(text)
        if size_from_text > 0:
            return size_from_text
    except Exception:
        pass
    return default

def _source_size_from_text(text: str) -> int:
    try:
        if not text:
            return 0

        s = html.unescape(str(text))
        s = re.sub(r"<[^>]+>", " ", s)
        s = s.replace("\xa0", " ")
        s = re.sub(r"\s+", " ", s).strip()
        if not s:
            return 0

        # Match explicit file sizes only. Plain numbers are intentionally
        # ignored here so duration/year/count values are not mistaken for size.
        unit_re = (
            r"tb|tib|gb|gib|mb|mib|kb|kib|"
            r"bajt(?:u|y|ů)?|byte(?:s)?|b"
        )
        m = re.search(
            r"(?<!\d)(\d+(?:[ \u00a0]\d{3})*(?:[.,]\d+)?|\d+(?:[.,]\d+)?)\s*(" + unit_re + r")\b",
            s,
            re.IGNORECASE
        )
        if not m:
            return 0

        num_text = re.sub(r"[ \u00a0]", "", m.group(1)).replace(",", ".")
        num = float(num_text)
        unit = m.group(2).lower()

        if unit in ("tb", "tib"):
            mult = 1024 ** 4
        elif unit in ("gb", "gib"):
            mult = 1024 ** 3
        elif unit in ("mb", "mib"):
            mult = 1024 ** 2
        elif unit in ("kb", "kib"):
            mult = 1024
        else:
            mult = 1

        return int(num * mult)
    except Exception:
        return 0

def _source_size_from_mapping(value) -> int:
    if not isinstance(value, (dict, list, tuple)):
        return _source_size_from_text(value)

    if isinstance(value, dict):
        preferred = []
        fallback_text = []

        for key, val in value.items():
            key_norm = re.sub(r"[^a-z0-9]", "", str(key).lower())
            if any(x in key_norm for x in ("filesize", "sizebytes", "bytes", "contentlength")) or key_norm == "size":
                preferred.append(val)
            elif key_norm in ("description", "desc", "text", "label", "meta"):
                fallback_text.append(val)

        for val in preferred:
            n = _source_int_from_any(val, 0)
            if n > 0:
                return n

        for val in value.values():
            if isinstance(val, (dict, list, tuple)):
                n = _source_size_from_mapping(val)
                if n > 0:
                    return n

        for val in fallback_text:
            n = _source_size_from_text(val)
            if n > 0:
                return n

        return 0

    for item in value:
        n = _source_size_from_mapping(item)
        if n > 0:
            return n
    return 0

def _source_first_from_mapping(value, key_names):
    wanted = set()
    for key in key_names or []:
        wanted.add(re.sub(r"[^a-z0-9]", "", str(key).lower()))

    def walk(node):
        if isinstance(node, dict):
            for key, val in node.items():
                key_norm = re.sub(r"[^a-z0-9]", "", str(key).lower())
                if key_norm in wanted and val not in (None, "", [], {}):
                    if isinstance(val, (dict, list, tuple)):
                        nested = walk(val)
                        if nested not in (None, "", [], {}):
                            return nested
                    else:
                        return val
            for val in node.values():
                nested = walk(val)
                if nested not in (None, "", [], {}):
                    return nested
        elif isinstance(node, (list, tuple)):
            for val in node:
                nested = walk(val)
                if nested not in (None, "", [], {}):
                    return nested
        return None

    return walk(value)

def _source_collect_dicts_from_mapping(value, key_names):
    wanted = set()
    for key in key_names or []:
        wanted.add(re.sub(r"[^a-z0-9]", "", str(key).lower()))

    out = []

    def add_dicts(node):
        if isinstance(node, dict):
            out.append(node)
        elif isinstance(node, (list, tuple)):
            for item in node:
                add_dicts(item)

    def walk(node):
        if isinstance(node, dict):
            for key, val in node.items():
                key_norm = re.sub(r"[^a-z0-9]", "", str(key).lower())
                if key_norm in wanted:
                    add_dicts(val)
                if isinstance(val, (dict, list, tuple)):
                    walk(val)
        elif isinstance(node, (list, tuple)):
            for val in node:
                walk(val)

    walk(value)
    return out

def _source_size_bytes(row: dict) -> int:
    if not isinstance(row, dict):
        return 0

    for key in (
        "size_bytes", "size", "filesize", "file_size", "fileSize",
        "bytes", "contentLength", "content_length"
    ):
        n = _source_int_from_any(row.get(key), 0)
        if n > 0:
            return n

    for key in ("size_label", "size_text", "plot"):
        n = _source_int_from_any(row.get(key), 0)
        if n > 0:
            return n
    return 0

def _source_fmt_size(value) -> str:
    n = _source_int_from_any(value, 0)
    if n <= 0:
        return ""

    units = ["B", "KB", "MB", "GB", "TB"]
    f = float(n)
    idx = 0
    while f >= 1024 and idx < len(units) - 1:
        f /= 1024.0
        idx += 1

    if idx == 0:
        return f"{int(f)} {units[idx]}"
    return f"{f:.1f} {units[idx]}"

def _source_fmt_bitrate(value) -> str:
    n = _source_int_from_any(value, 0)
    if n <= 0:
        return str(value).strip() if value else ""

    units = ["bps", "Kbps", "Mbps", "Gbps"]
    f = float(n)
    idx = 0
    while f >= 1024 and idx < len(units) - 1:
        f /= 1024.0
        idx += 1

    if idx == 0:
        return f"{int(f)} {units[idx]}"

    text = f"{f:.2f}".rstrip("0").rstrip(".")
    return f"{text} {units[idx]}"

def _source_quality_from_dimensions(width, height) -> str:
    try:
        w = int(str(width or "0").strip() or "0")
    except Exception:
        w = 0
    try:
        h = int(str(height or "0").strip() or "0")
    except Exception:
        h = 0

    if w >= 7600 or h >= 4000:
        return "8K"
    if w >= 3800 or h >= 2000:
        return "4K"
    if h >= 1000:
        return "1080p"
    if h >= 700:
        return "720p"
    if h >= 470:
        return "480p"
    return ""

def _source_quality_from_text(text: str) -> str:
    raw = text or ""
    low = raw.lower()
    norm = _norm_text(raw)

    if re.search(r"\b(4320p|8k)\b", low):
        return "8K"
    if re.search(r"\b(2160p|4k|uhd)\b", low):
        return "4K"

    for q in ("1080p", "720p", "576p", "480p", "360p"):
        if q in low:
            return q

    if re.search(r"\bfull\s*hd\b", low) or "fullhd" in norm:
        return "1080p"
    if re.search(r"\bhd\b", norm):
        return "HD"
    if re.search(r"\bsd\b", norm):
        return "SD"

    return ""

def _source_codec_from_text(text: str) -> str:
    low = (text or "").lower()
    norm = _norm_text(text or "")

    if "av1" in norm:
        return "AV1"
    if "hevc" in norm or "x265" in norm or "h265" in norm or "h 265" in norm:
        return "HEVC"
    if "x264" in norm or "h264" in norm or "h 264" in norm:
        return "x264"
    if "xvid" in low:
        return "Xvid"
    return ""

def _source_audio_from_text(text: str) -> str:
    norm = _norm_text(text or "")
    flat = norm.replace(" ", "")

    hits = []
    if any(x in flat for x in ("czdab", "czdabbing", "ceskydabing")) or "cz dab" in norm or "cesky dabing" in norm:
        hits.append("CZ dab")
    elif re.search(r"\bcz\b", norm) and re.search(r"\b(dab|dabing|dubbing)\b", norm):
        hits.append("CZ dab")
    elif re.search(r"\bcz\b", norm):
        hits.append("CZ")

    if any(x in flat for x in ("skdab", "skdabbing", "slovenskydabing")) or "sk dab" in norm or "slovensky dabing" in norm:
        hits.append("SK dab")
    elif re.search(r"\bsk\b", norm) and re.search(r"\b(dab|dabing|dubbing)\b", norm):
        hits.append("SK dab")
    elif re.search(r"\bsk\b", norm):
        hits.append("SK")

    if re.search(r"\b(en|eng|english)\b", norm):
        hits.append("EN")

    out = []
    for h in hits:
        if h not in out:
            out.append(h)
    return " + ".join(out[:3])

def _source_subtitles_from_text(text: str) -> str:
    norm = _norm_text(text or "")
    flat = norm.replace(" ", "")

    hits = []
    if any(x in flat for x in ("cztit", "cztitulky", "czsub", "czsubs")) or "cz tit" in norm:
        hits.append("CZ tit")
    elif re.search(r"\bcz\b", norm) and re.search(r"\b(tit|titulky|sub|subs)\b", norm):
        hits.append("CZ tit")

    if any(x in flat for x in ("sktit", "sktitulky", "sksub", "sksubs")) or "sk tit" in norm:
        hits.append("SK tit")
    elif re.search(r"\bsk\b", norm) and re.search(r"\b(tit|titulky|sub|subs)\b", norm):
        hits.append("SK tit")

    if re.search(r"\b(en|eng|english)\b", norm) and re.search(r"\b(tit|sub|subs|subtitle|subtitles)\b", norm):
        hits.append("EN tit")

    out = []
    for h in hits:
        if h not in out:
            out.append(h)
    return " + ".join(out[:3])

def _source_metadata(row: dict) -> dict:
    row = row or {}
    title = row.get("title") or ""
    plot = row.get("plot") or ""
    text = f"{title} {plot}"

    size_bytes = _source_size_bytes(row)
    quality = (
        str(row.get("quality") or row.get("resolution") or "").strip()
        or _source_quality_from_dimensions(row.get("width"), row.get("height"))
        or _source_quality_from_text(text)
    )
    codec = str(row.get("codec") or row.get("format") or "").strip() or _source_codec_from_text(text)
    audio = str(row.get("audio") or row.get("audio_lang") or "").strip() or _source_audio_from_text(text)
    subtitles = str(row.get("subtitles") or row.get("subs") or row.get("subs_langs") or "").strip() or _source_subtitles_from_text(text)

    return {
        "size_bytes": size_bytes,
        "size": _source_fmt_size(size_bytes),
        "quality": quality,
        "codec": codec,
        "audio": audio,
        "subtitles": subtitles,
    }

def _source_label_suffix(row: dict, score=None) -> str:
    meta = _source_metadata(row)
    tags = []

    for value in (meta.get("size"), meta.get("quality"), meta.get("audio")):
        if value and value not in tags:
            tags.append(value)

    if score is not None:
        tags.append(f"score {score}")

    if not tags:
        return ""
    return "  " + " ".join(f"[{x}]" for x in tags)

def _webshare_source_name(row: dict) -> str:
    row = row or {}
    for key in ("ws_info_name", "title", "name", "id"):
        value = str(row.get(key) or "").strip()
        if value:
            return value
    return "WebShare zdroj"

def _webshare_lang_code(value) -> str:
    text = _norm_text(str(value or ""))
    if not text:
        return ""

    compact = text.replace(" ", "")
    mapping = {
        "cz": "CZ", "cs": "CZ", "cze": "CZ", "ces": "CZ", "czech": "CZ", "cesky": "CZ",
        "sk": "SK", "slo": "SK", "slk": "SK", "slovak": "SK", "slovensky": "SK",
        "en": "EN", "eng": "EN", "english": "EN",
    }
    if compact in mapping:
        return mapping[compact]
    for token in text.split():
        if token in mapping:
            return mapping[token]
    return ""

def _webshare_langs_from_streams(streams) -> list:
    if isinstance(streams, dict):
        streams = [streams]
    out = []
    for stream in (streams or []):
        if not isinstance(stream, dict):
            continue
        for key in ("lang", "language", "language_code", "locale"):
            code = _webshare_lang_code(stream.get(key))
            if code and code not in out:
                out.append(code)
    return out

def _webshare_langs_from_text(value) -> list:
    out = []
    for chunk in re.split(r"[,;/+| ]+", str(value or "")):
        code = _webshare_lang_code(chunk)
        if code and code not in out:
            out.append(code)
    return out

def _webshare_language_tags(row: dict) -> list:
    row = row or {}
    audio = _webshare_langs_from_streams(row.get("audio_streams"))
    if not audio:
        audio = _webshare_langs_from_text(row.get("audio") or row.get("audio_lang"))

    subtitles = (
        _webshare_langs_from_streams(row.get("subtitle_streams"))
        or _webshare_langs_from_text(row.get("subtitles") or row.get("subs") or row.get("subs_langs"))
    )

    tags = []
    if audio:
        tags.append(",".join(audio[:3]))
    if subtitles:
        tags.append(",".join(subtitles[:3]))
    return tags

def _webshare_audio_langs(row: dict) -> list:
    row = row or {}
    audio = _webshare_langs_from_streams(row.get("audio_streams"))
    if not audio:
        audio = _webshare_langs_from_text(row.get("audio") or row.get("audio_lang"))
    return audio

def _webshare_audio_rank(row: dict) -> int:
    langs = _webshare_audio_langs(row)
    if "CZ" in langs:
        return 4
    if "SK" in langs:
        return 3
    if "EN" in langs:
        return 2
    return 1

def _webshare_quality_tag(row: dict) -> str:
    row = row or {}
    direct = str(row.get("quality") or row.get("resolution") or "").strip()
    if direct:
        return direct

    quality = _source_quality_from_dimensions(row.get("width"), row.get("height"))
    if quality:
        return quality

    best_w = 0
    best_h = 0
    streams = row.get("video_streams") or []
    if isinstance(streams, dict):
        streams = [streams]
    for stream in streams:
        if not isinstance(stream, dict):
            continue
        w = _source_int_from_any(stream.get("width"), 0)
        h = _source_int_from_any(stream.get("height"), 0)
        if h > best_h or (h == best_h and w > best_w):
            best_w, best_h = w, h
    return _source_quality_from_dimensions(best_w, best_h)

def _webshare_quality_rank(row: dict) -> int:
    quality = (_webshare_quality_tag(row) or "").strip().lower()
    if not quality:
        return 0
    if quality in ("8k", "4320p"):
        return 8000
    if quality in ("4k", "uhd", "2160p"):
        return 4000
    m = re.search(r"(\d{3,4})p", quality)
    if m:
        try:
            return int(m.group(1))
        except Exception:
            return 0
    if quality == "hd":
        return 700
    if quality == "sd":
        return 400
    return 0

def _webshare_sort_key(row: dict):
    row = row or {}
    return (
        _webshare_audio_rank(row),
        _webshare_quality_rank(row),
        _source_size_bytes(row),
        row.get("_score", 0),
        _webshare_source_name(row).lower(),
    )

def _sort_webshare_rows(rows) -> list:
    return sorted((row for row in (rows or []) if isinstance(row, dict)),
                  key=_webshare_sort_key, reverse=True)

def _webshare_media_display_name(media_title: str, year: str) -> str:
    title = str(media_title or "").strip()
    if not title:
        return ""

    year_text = str(year or "").strip()
    m = re.search(r"(19\d{2}|20\d{2}|21\d{2})", year_text)
    if m:
        year_text = m.group(1)
    else:
        year_text = ""

    if year_text and f"({year_text})" not in title:
        return f"{title} ({year_text})"
    return title

def _webshare_label_name(row: dict, media_title: str = "", year: str = "") -> str:
    if row and row.get("ws_file_info") and "CZ" in _webshare_audio_langs(row):
        media_name = _webshare_media_display_name(media_title, year)
        if media_name:
            return media_name
    return _webshare_source_name(row)

def _webshare_display_label(row: dict, media_title: str = "", year: str = "") -> str:
    row = row or {}
    name = _webshare_label_name(row, media_title=media_title, year=year)
    if not row.get("ws_file_info"):
        return name

    tags = []

    for tag in _webshare_language_tags(row):
        if tag and tag not in tags:
            tags.append(tag)

    quality = _webshare_quality_tag(row)
    if quality and quality not in tags:
        tags.append(quality)

    size = _source_fmt_size(_source_size_bytes(row))
    if size and size not in tags:
        tags.append(size)

    if not tags:
        return name
    return "".join(f"[{tag}]" for tag in tags) + " " + name

def _webshare_group_key(row: dict, media_title: str = "", year: str = "") -> str:
    return _cache_safe_key_part(_webshare_display_label(row, media_title=media_title, year=year))

def _group_webshare_rows(rows, media_title: str = "", year: str = "") -> list:
    groups = []
    index = {}

    for row in _sort_webshare_rows(rows):
        if not isinstance(row, dict):
            continue
        key = _webshare_group_key(row, media_title=media_title, year=year)
        if key not in index:
            group = {
                "key": key,
                "label": _webshare_display_label(row, media_title=media_title, year=year),
                "rows": [],
            }
            index[key] = group
            groups.append(group)
        index[key]["rows"].append(row)

    return groups

def _source_stream_line(stream: dict, kind: str = "video") -> str:
    stream = stream or {}
    if kind == "video":
        parts = []
        width = str(stream.get("width") or "").strip()
        height = str(stream.get("height") or "").strip()
        if width and height:
            parts.append(f"{width}x{height}")
        fmt = str(stream.get("format") or "").strip()
        if fmt:
            parts.append(fmt)
        fps = str(stream.get("fps") or "").strip()
        if fps:
            parts.append(f"{fps} fps")
        bitrate = _source_fmt_bitrate(stream.get("bitrate"))
        if bitrate:
            parts.append(bitrate)
        return ", ".join(parts)

    parts = []
    fmt = str(stream.get("format") or "").strip()
    if fmt:
        parts.append(fmt)
    channels = str(stream.get("channels") or "").strip()
    if channels:
        parts.append(f"{channels} ch")
    lang = str(stream.get("lang") or stream.get("language") or "").strip()
    if lang:
        parts.append(lang)
    bitrate = _source_fmt_bitrate(stream.get("bitrate"))
    if bitrate:
        parts.append(bitrate)
    return ", ".join(parts)

def _source_duration_text(value) -> str:
    try:
        if value in (None, "", [], {}):
            return ""
        if isinstance(value, str) and ":" in value:
            return value.strip()
        sec = float(value)
        if sec <= 0:
            return ""
        sec = int(round(sec))
        h = sec // 3600
        m = (sec % 3600) // 60
        s = sec % 60
        if h:
            return f"{h}:{m:02d}:{s:02d}"
        return f"{m}:{s:02d}"
    except Exception:
        return str(value).strip() if value else ""

def _source_detail_lines(row: dict, score=None):
    row = row or {}
    meta = _source_metadata(row)
    lines = []

    provider_name = (row.get("provider") or "").strip()
    if provider_name:
        lines.append(f"Provider: {provider_name}")

    if meta.get("size"):
        lines.append(f"Velikost: {meta['size']}")
    file_type = str(row.get("file_type") or row.get("type") or "").strip()
    if file_type:
        lines.append(f"Typ: {file_type}")
    if meta.get("quality"):
        lines.append(f"Kvalita: {meta['quality']}")

    video_streams = row.get("video_streams") or []
    if isinstance(video_streams, dict):
        video_streams = [video_streams]
    has_video_stream = any(_source_stream_line(stream, "video") for stream in video_streams)

    if not has_video_stream and meta.get("codec"):
        lines.append(f"Kodek: {meta['codec']}")
    width = str(row.get("width") or "").strip()
    height = str(row.get("height") or "").strip()
    if not has_video_stream and width and height:
        lines.append(f"Rozliseni: {width}x{height}")
    fps = str(row.get("fps") or "").strip()
    if not has_video_stream and fps:
        lines.append(f"FPS: {fps}")
    bitrate = _source_fmt_bitrate(row.get("bitrate"))
    if not has_video_stream and bitrate:
        lines.append(f"Bitrate: {bitrate}")
    duration = _source_duration_text(row.get("duration"))
    if duration:
        lines.append(f"Delka: {duration}")
    upload_date = str(row.get("upload_date") or "").strip()
    if upload_date:
        lines.append(f"Nahrano: {upload_date}")
    if meta.get("audio"):
        lines.append(f"Zvuk: {meta['audio']}")
    if meta.get("subtitles"):
        lines.append(f"Titulky: {meta['subtitles']}")

    for stream in video_streams:
        stream_line = _source_stream_line(stream, "video")
        if stream_line:
            lines.append(f"Video stream: {stream_line}")

    audio_streams = row.get("audio_streams") or []
    if isinstance(audio_streams, dict):
        audio_streams = [audio_streams]
    for stream in audio_streams:
        stream_line = _source_stream_line(stream, "audio")
        if stream_line:
            lines.append(f"Audio stream: {stream_line}")

    available = str(row.get("available") or "").strip().lower()
    if available in ("0", "false", "no", "ne"):
        lines.append("Dostupne: Ne")

    password = str(row.get("password") or "").strip().lower()
    if password in ("1", "true", "yes", "ano"):
        lines.append("Heslo: Ano")

    copyrighted = str(row.get("copyrighted") or "").strip().lower()
    if copyrighted in ("1", "true", "yes", "ano"):
        lines.append("Copyright: Ano")

    removed = str(row.get("removed") or "").strip().lower()
    if removed in ("1", "true", "yes", "ano"):
        lines.append("Odstraneno: Ano")
        removal_reason = str(row.get("removal_reason") or "").strip()
        if removal_reason:
            lines.append(f"Duvod odstraneni: {removal_reason}")

    if score is not None:
        lines.append(f"Shoda: score {score}")

    query = (row.get("query") or "").strip()
    if query:
        lines.append(f"Dotaz: {query}")

    why = row.get("_why") or []
    if why:
        lines.append("")
        lines.append("Duvody shody:")
        lines.extend(str(x) for x in why if str(x).strip())

    return lines


def _merge_provider_rows(*groups):
    out = []
    seen = set()

    for group in groups:
        for row in (group or []):
            title = (row.get("title") or "").strip()
            url = (row.get("url") or "").strip()
            key = (title.lower(), url.lower())

            if not title:
                continue
            if key in seen:
                continue
            seen.add(key)
            out.append(dict(row))

    return out

def _provider_prehrajto(query: str, title: str, original_title: str, year: str):
    q = (query or "").strip()
    if not q:
        return []

    found = prehrajto_search_all_pages(q, max_pages=30)

    rows = []
    for it in (found or []):
        rows.append(_provider_result(
            title=it.get("title") or "",
            url=it.get("url") or "",
            provider="prehrajto",
            year="",
            plot=f"Přehraj.to | dotaz: {q}",
            query=q,
            size_bytes=_source_size_bytes(it),
        ))

    return rows

def _provider_sktonline(query: str, title: str, original_title: str, year: str):
    q = " ".join((query or "").split()).strip()
    if not q:
        return []

    try:
        found = sktonline_search_all_pages(q, max_pages=5)
    except Exception:
        found = []

    rows = []
    seen_urls = set()

    for it in (found or []):
        url = (it.get("url") or "").strip()
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)

        row_title = (it.get("title") or "").strip()
        if not row_title:
            row_title = url

        rows.append(_provider_result(
            title=row_title,
            url=url,
            provider="sktonline",
            year="",
            plot=f"SkTonLine | dotaz: {q}",
            query=q,
            size_bytes=_source_size_bytes(it),
        ))

    return rows

def _provider_webshare(query: str, title: str, original_title: str, year: str,
                       limit: int = 40, max_pages: int = 1):
    q = " ".join((query or "").split()).strip()
    if not q:
        return []

    found = []
    try:
        limit = max(1, int(limit or 40))
    except Exception:
        limit = 40
    try:
        max_pages = max(1, int(max_pages or 1))
    except Exception:
        max_pages = 1

    for page in range(max_pages):
        offset = page * limit
        try:
            batch = _ws_search_simple(q, limit=limit, offset=offset) or []
        except Exception:
            batch = []
        if not batch:
            break
        found.extend(batch)
        if len(batch) < limit:
            break

    rows = []
    seen_ids = set()

    for it in (found or []):
        ident = (it.get("id") or "").strip()
        if not ident or ident in seen_ids:
            continue
        seen_ids.add(ident)

        row_title = (it.get("name") or "").strip() or ident
        size_int = int(it.get("size") or 0)

        play_url = (
            "plugin://plugin.video.ikarus/"
            "?action=film.play&id=" + urllib.parse.quote_plus(ident) +
            "&ident=" + urllib.parse.quote_plus(ident)
        )

        plot = f"WebShare | dotaz: {q}"

        rows.append(_provider_result(
            title=row_title,
            url=play_url,
            provider="webshare",
            year="",
            plot=plot,
            id=ident,
            query=q,
            size_bytes=size_int,
        ))

    return rows

_HELLSPY_API_BASE = "https://api.hellspy.to"
_HELLSPY_SEARCH_ENDPOINT = _HELLSPY_API_BASE + "/gw/search"
_HELLSPY_SITE_BASE = "https://www.hellspy.to/"
_HELLSPY_LIMIT = 64

def _cookie_header_for_url_basic(url: str) -> str:
    try:
        u = urllib.parse.urlsplit(url)
        host = (u.hostname or "").lower()
        path = u.path or "/"

        cookies = []
        for c in _COOKIEJAR:
            dom = (c.domain or "").lstrip(".").lower()
            if not dom:
                continue
            if not (host == dom or host.endswith("." + dom)):
                continue
            cpath = c.path or "/"
            if path.startswith(cpath):
                cookies.append(f"{c.name}={c.value}")

        return "; ".join(cookies)
    except Exception:
        return ""

def _hellspy_build_search_url(query: str, offset: int, limit: int) -> str:
    return _HELLSPY_SEARCH_ENDPOINT + "?" + urllib.parse.urlencode({
        "query": query,
        "offset": str(offset),
        "limit": str(limit),
    })

def _hellspy_extract_items_and_next(payload: dict):
    if not isinstance(payload, dict):
        return [], None
    items = payload.get("items")
    if not isinstance(items, list):
        items = []
    nxt = payload.get("nextOffset")
    try:
        nxt = int(nxt) if nxt is not None else None
    except Exception:
        nxt = None
    return items, nxt

def _hellspy_pick_direct_url(item: dict) -> str:
    if not isinstance(item, dict):
        return ""

    candidates = []

    for key in (
        "stream", "streamUrl", "hls", "hlsUrl", "mp4", "mp4Url",
        "url", "file", "fileUrl", "download", "downloadUrl"
    ):
        v = item.get(key)
        if isinstance(v, str) and v.strip():
            candidates.append(v.strip())

    media = item.get("media")
    if isinstance(media, dict):
        for key in ("url", "hls", "hlsUrl", "mp4", "mp4Url"):
            v = media.get(key)
            if isinstance(v, str) and v.strip():
                candidates.append(v.strip())

    streams = item.get("streams")
    if isinstance(streams, dict):
        for key in ("hls", "mp4", "url"):
            v = streams.get(key)
            if isinstance(v, str) and v.strip():
                candidates.append(v.strip())

    if isinstance(streams, list):
        for s in streams:
            if isinstance(s, dict):
                v = s.get("url") or s.get("src") or s.get("file")
                if isinstance(v, str) and v.strip():
                    candidates.append(v.strip())

    for u in candidates:
        if _is_direct_media_url(u):
            return u

    return ""

def _hellspy_get_stream(video_id: str, video_hash: str) -> str:
    if not video_id or not video_hash:
        return ""

    try:
        response = requests.get(
            f"{_HELLSPY_API_BASE}/gw/video/{video_id}/{video_hash}/download",
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/122.0.0.0 Safari/537.36"
                ),
                "Accept": "*/*",
                "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
                "Accept-Encoding": "identity",
                "Connection": "close",
                "Referer": "https://www.hellspy.to/",
                "Origin": "https://www.hellspy.to",
            },
            allow_redirects=False,
            timeout=25
        )

        if response.status_code in (301, 302, 303, 307, 308):
            return (response.headers.get("Location") or "").strip()

        return ""
    except Exception:
        return ""

def _hellspy_dump_first_item(query: str, item: dict):
    qkey = _cache_safe_key_part(query or "hellspy")
    if qkey in _HELLSPY_DEBUG_DUMPED:
        return
    _HELLSPY_DEBUG_DUMPED.add(qkey)

    try:
        payload = json.dumps(item or {}, ensure_ascii=False, indent=2, sort_keys=True)
        _dump_text_to_temp(f"ikarus_hellspy_first_item_{qkey}.json", payload)
    except Exception as e:
        xbmc.log(f"[IKARUS][HELLSPY] debug dump failed: {repr(e)}", xbmc.LOGWARNING)

def _hellspy_streams_from_item(item: dict, kind: str):
    if not isinstance(item, dict):
        return []

    if kind == "video":
        candidate_keys = (
            "video", "videos", "videoStream", "videoStreams",
            "stream", "streams", "media", "sources", "files"
        )
        width_keys = ("width", "w", "videoWidth")
        height_keys = ("height", "h", "videoHeight")
        format_keys = ("format", "codec", "videoCodec", "videoFormat")
        bitrate_keys = ("bitrate", "videoBitrate")
        fps_keys = ("fps", "frameRate", "framerate")
    else:
        candidate_keys = (
            "audio", "audios", "audioStream", "audioStreams",
            "audioTrack", "audioTracks", "tracks", "media", "streams"
        )
        format_keys = ("format", "codec", "audioCodec", "audioFormat")
        bitrate_keys = ("bitrate", "audioBitrate")
        channels_keys = ("channels", "channelCount", "audioChannels")
        lang_keys = ("lang", "language", "audioLanguage", "locale")

    out = []
    seen = set()

    candidates = _source_collect_dicts_from_mapping(item, candidate_keys)
    if kind == "video":
        candidates.append(item)

    for cand in candidates:
        if not isinstance(cand, dict):
            continue

        if kind == "video":
            stream = {
                "width": _source_first_from_mapping(cand, width_keys),
                "height": _source_first_from_mapping(cand, height_keys),
                "format": _source_first_from_mapping(cand, format_keys),
                "fps": _source_first_from_mapping(cand, fps_keys),
                "bitrate": _source_first_from_mapping(cand, bitrate_keys),
            }
        else:
            stream = {
                "format": _source_first_from_mapping(cand, format_keys),
                "channels": _source_first_from_mapping(cand, channels_keys),
                "lang": _source_first_from_mapping(cand, lang_keys),
                "bitrate": _source_first_from_mapping(cand, bitrate_keys),
            }

        stream = {k: str(v).strip() for k, v in stream.items() if v not in (None, "", [], {})}
        if not stream:
            continue

        key = tuple(sorted(stream.items()))
        if key in seen:
            continue
        seen.add(key)
        out.append(stream)

    return out

def _hellspy_metadata_from_item(item: dict):
    if not isinstance(item, dict):
        return {}

    meta = {
        "size_bytes": _source_size_from_mapping(item),
        "width": _source_first_from_mapping(item, ("width", "w", "videoWidth")),
        "height": _source_first_from_mapping(item, ("height", "h", "videoHeight")),
        "format": _source_first_from_mapping(item, ("format", "codec", "videoCodec", "videoFormat")),
        "fps": _source_first_from_mapping(item, ("fps", "frameRate", "framerate")),
        "bitrate": _source_first_from_mapping(item, ("bitrate", "videoBitrate")),
        "duration": _source_first_from_mapping(item, ("duration", "durationSec", "durationSeconds", "length")),
        "file_type": _source_first_from_mapping(item, ("type", "extension", "ext", "fileType", "mime")),
        "video_streams": _hellspy_streams_from_item(item, "video"),
        "audio_streams": _hellspy_streams_from_item(item, "audio"),
    }

    return {k: v for k, v in meta.items() if v not in (None, "", [], {}, 0)}

def _provider_hellspy(query: str, title: str = "", original_title: str = "", year: str = ""):
    q = " ".join((query or "").split()).strip()
    if not q:
        return []

    seen = set()
    out = []
    offset = 0
    next_offset = None
    max_pages = 20

    for _page in range(1, max_pages + 1):
        use_offset = next_offset if next_offset is not None else offset
        url = _hellspy_build_search_url(q, use_offset, _HELLSPY_LIMIT)

        payload = _http_get_json(
            url,
            referer="https://www.hellspy.to/",
            origin="https://www.hellspy.to"
        )
        items, nxt = _hellspy_extract_items_and_next(payload)

        if not items:
            break

        added = 0
        for it in items:
            row_title = (it.get("title") or "").strip()
            vid = str(it.get("id") or "").strip()
            hsh = str(it.get("fileHash") or it.get("hash") or "").strip()

            if not row_title or not vid or not hsh:
                continue

            item_url = f"{_HELLSPY_SITE_BASE}video/{hsh}/{vid}"
            if item_url in seen:
                continue
            seen.add(item_url)

            direct = _hellspy_pick_direct_url(it)
            _hellspy_dump_first_item(q, it)

            plot_lines = [
                f"Hellspy | dotaz: {q}",
            ]
            meta = {
                "query": q,
                "size_bytes": _source_size_from_mapping(it),
                "quality": str(it.get("resolution") or it.get("quality") or "").strip(),
                "duration": (it.get("duration") or it.get("length") or ""),
            }
            meta.update(_hellspy_metadata_from_item(it))

            out.append(_provider_result(
                title=row_title,
                url=item_url,
                provider="hellspy",
                year="",
                plot="\n".join(plot_lines),
                direct=direct,
                id=vid,
                fileHash=hsh,
                **meta,
            ))
            added += 1

        if added == 0:
            break

        if nxt is not None and nxt != use_offset:
            next_offset = nxt
        else:
            offset = use_offset + _HELLSPY_LIMIT
            next_offset = None

    return out

_SOURCE_PROVIDERS = {
    "prehrajto": _provider_prehrajto,
    "sktonline": _provider_sktonline,
    "hellspy": _provider_hellspy,
    "webshare": _provider_webshare,
}

def _build_candidate_queries(title: str, original_title: str, year: str,
                             mode: str = "", season: str = "", episode: str = "", episode_title: str = "",
                             provider_name: str = ""):
    provider_name = (provider_name or "").strip().lower()
    mode = (mode or "").strip()

    out = []
    seen = set()

    def add_query(q):
        q = _search_safe_text(q)
        if not q:
            return
        k = q.lower()
        if k in seen:
            return
        seen.add(k)
        out.append(q)

    if provider_name == "prehrajto":
        add_query(title)
        add_query(original_title)

        if mode == "serial_episode":
            if not _is_generic_episode_title(episode_title):
                add_query(episode_title)

        return out

    if mode == "serial_episode":
        out = []
        seen = set()

        def add_query(q):
            q = _search_safe_text(q)
            if not q:
                return
            k = q.lower()
            if k in seen:
                return
            seen.add(k)
            out.append(q)

        if provider_name == "webshare":
            add_query(original_title)
            add_query(title)
            if not _is_generic_episode_title(episode_title):
                add_query(episode_title)
            for base in (original_title, title):
                base = (base or "").strip()
                if not base:
                    continue
                for number in _episode_query_number_variants(season, episode):
                    add_query(f"{base} {number}")
            if episode_title and not _is_generic_episode_title(episode_title):
                for number in _episode_query_number_variants(season, episode):
                    add_query(f"{episode_title} {number}")
        else:
            add_query(title)
            add_query(original_title)
            add_query(episode_title)

        return out

    return _query_variants_for_search(title, original_title, year)

def _run_provider_multi(provider_name: str, title: str, original_title: str, year: str,
                        mode: str = "", season: str = "", episode: str = "", episode_title: str = "",
                        season_name: str = ""):
    fn = _SOURCE_PROVIDERS.get((provider_name or "").strip())
    if not fn:
        return []

    queries = _build_candidate_queries(
        title=title,
        original_title=original_title,
        year=year,
        mode=mode,
        season=season,
        episode=episode,
        episode_title=episode_title,
        provider_name=provider_name
    )

    groups = []
    for q in queries:
        if (provider_name or "").strip().lower() == "webshare" and mode == "serial_episode":
            rows = fn(
                query=q,
                title=title,
                original_title=original_title,
                year=year,
                limit=100,
                max_pages=5
            ) or []
        else:
            rows = fn(
                query=q,
                title=title,
                original_title=original_title,
                year=year
            ) or []
        groups.append(rows)

    merged = _merge_provider_rows(*groups)

    filtered = _filter_candidates(
        rows=merged,
        title=title,
        original_title=original_title,
        year=year,
        min_score=35,
        mode=mode,
        season=season,
        episode=episode,
        episode_title=episode_title,
        season_name=season_name
    )

    provider_key = (provider_name or "").strip().lower()
    if provider_key == "webshare":
        filtered = _enrich_webshare_rows(filtered)
    elif provider_key == "prehrajto":
        filtered = _enrich_prehrajto_rows(filtered)

    return filtered

def _run_provider_sktonline_raw_debug(title: str, original_title: str):
    fn = _SOURCE_PROVIDERS.get("sktonline")
    if not fn:
        return []

    queries = []
    seen_q = set()

    def add_query(q):
        q = _search_safe_text(q)
        if not q:
            return
        k = q.lower()
        if k in seen_q:
            return
        seen_q.add(k)
        queries.append(q)

    add_query(title)
    add_query(original_title)

    all_rows = []

    for q in queries:
        rows = fn(
            query=q,
            title=title,
            original_title=original_title,
            year=""
        ) or []

        if rows:
            all_rows = _merge_provider_rows(all_rows, rows)

    return all_rows

def _provider_is_enabled_for_auto_next(provider_name: str) -> bool:
    provider_name = (provider_name or "").strip().lower()
    if provider_name == "prehrajto":
        return _setting_enabled("show_prehrajto", default=True)
    if provider_name == "hellspy":
        return _setting_enabled("show_hellspy", default=True)
    if provider_name == "sktonline":
        return _setting_enabled("show_sktonline", default=True)
    if provider_name == "webshare":
        return _setting_enabled("show_webshare", default=True) and _webshare_connected()
    return False

def _tmdb_auto_next_provider_order(preferred_provider: str = ""):
    order = ["prehrajto", "hellspy", "sktonline", "webshare"]
    preferred_provider = (preferred_provider or "").strip().lower()
    if preferred_provider in order:
        order.remove(preferred_provider)
        order.insert(0, preferred_provider)
    return [p for p in order if _provider_is_enabled_for_auto_next(p)]

def _tmdb_auto_next_language_score(row: dict) -> int:
    title = (row or {}).get("title") or ""
    plot = (row or {}).get("plot") or ""
    tokens = set(_title_tokens(f"{title} {plot}"))
    text = _norm_text(f"{title} {plot}")

    cz_tokens = {
        "czdab", "czdabing", "ceskydabing", "cesky", "czech",
        "cz", "ceske", "ceska",
    }
    sk_tokens = {
        "skdab", "skdabing", "slovenskydabing", "slovensky", "slovak",
        "sk", "slovenske", "slovenska",
    }
    sub_tokens = {"titulky", "sub", "subs", "subtitle", "subtitles", "czsub", "czsubs"}
    original_tokens = {"en", "eng", "english", "original", "orig", "vo"}

    score = 0
    if tokens & cz_tokens:
        score += 120
    if tokens & sk_tokens:
        score += 70
    if "dabing" in tokens or "dab" in tokens or "dabing" in text:
        score += 45
    if tokens & sub_tokens:
        score -= 45
    if tokens & original_tokens:
        score -= 15
    return score


def _tmdb_auto_next_pick_best(rows, require_cz_dabing: bool = True):
    prepared = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        if not ((row.get("url") or "").strip() or (row.get("direct") or "").strip()):
            continue
        lang_score = _tmdb_auto_next_language_score(row)
        if require_cz_dabing and lang_score < 45:
            continue
        item = dict(row)
        item["_auto_next_lang_score"] = lang_score
        prepared.append(item)

    if not prepared:
        return None

    prepared.sort(
        key=lambda x: (
            x.get("_auto_next_lang_score", 0),
            x.get("_score", 0),
            x.get("title", ""),
        ),
        reverse=True,
    )
    return prepared[0]

def find_best_tmdb_episode_source(title: str, original_title: str, year: str,
                                  season: str, episode: str, episode_title: str,
                                  preferred_provider: str = "",
                                  require_cz_dabing: bool = True,
                                  season_name: str = ""):
    """
    Tiche hledani pro autoplay dalsi TMDB epizody. Vraci prvni nejlepsi radek
    podle stejneho filtrovani a cache, ktere pouziva UI seznam zdroju.
    """
    for provider in _tmdb_auto_next_provider_order(preferred_provider):
        try:
            cached_rows = _source_cache_get(
                provider=provider,
                title=title,
                original_title=original_title,
                year=year,
                mode="serial_episode",
                season=season,
                episode=episode
            )

            if cached_rows is not None:
                filtered = cached_rows
            elif provider == "sktonline":
                raw_rows = _run_provider_sktonline_raw_debug(
                    title=title,
                    original_title=original_title
                )
                filtered = _filter_sktonline_serial_episode_rows(
                    rows=raw_rows,
                    title=title,
                    original_title=original_title,
                    season=season,
                    episode=episode,
                    episode_title=episode_title,
                    season_name=season_name
                )
                _source_cache_set(
                    provider=provider,
                    title=title,
                    original_title=original_title,
                    year=year,
                    rows=filtered,
                    mode="serial_episode",
                    season=season,
                    episode=episode
                )
            else:
                filtered = _run_provider_multi(
                    provider_name=provider,
                    title=title,
                    original_title=original_title,
                    year=year,
                    mode="serial_episode",
                    season=season,
                    episode=episode,
                    episode_title=episode_title,
                    season_name=season_name
                )
                _source_cache_set(
                    provider=provider,
                    title=title,
                    original_title=original_title,
                    year=year,
                    rows=filtered,
                    mode="serial_episode",
                    season=season,
                    episode=episode
                )

            picked = _tmdb_auto_next_pick_best(filtered, require_cz_dabing=require_cz_dabing)
            if picked:
                return picked
        except Exception as e:
            try:
                xbmc.log(f"[IKARUS][AUTO NEXT] provider={provider} failed: {e}", xbmc.LOGWARNING)
            except Exception:
                pass

    return None

def build_tmdb_episode_source_play_url(row: dict, tmdb_id: str, title: str,
                                       original_title: str, year: str,
                                       season: str, episode: str,
                                       episode_title: str, season_name: str = "") -> str:
    row = row or {}
    provider_name = (row.get("provider") or "").strip()
    row_url = (row.get("url") or "").strip()
    row_direct = (row.get("direct") or "").strip()
    return build_url({
        "action": "tmdb.movie.source.play",
        "provider": provider_name,
        "tmdb_id": tmdb_id,
        "title": row.get("title") or title,
        "media_title": title,
        "url": row_url,
        "direct": row_direct,
        "id": row.get("id") or "",
        "fileHash": row.get("fileHash") or "",
        "original_title": original_title,
        "year": year,
        "mode": "serial_episode",
        "season": season,
        "episode": episode,
        "episode_title": episode_title,
        "season_name": season_name,
    })

def source_search_stub_menu():
    provider = _get_param("provider", "").strip()
    tmdb_id = _get_param("tmdb_id", "").strip() or _get_param("id", "").strip()
    query = _get_param("query", "").strip()
    title = _get_param("title", "Film").strip()
    original_title = _get_param("original_title", "").strip()
    year = _get_param("year", "").strip()
    mode = _get_param("mode", "").strip()
    season = _get_param("season", "").strip()
    episode = _get_param("episode", "").strip()
    episode_title = _get_param("episode_title", "").strip()
    season_name = _get_param("season_name", "").strip()
    force_refresh = _get_param("force_refresh", "").strip() == "1"
    refresh_token = _get_param("refresh_token", "").strip()

    xbmcplugin.setPluginCategory(addon_handle, f"Zdroje / Výsledky / {title}")
    xbmcplugin.setContent(addon_handle, "files")

    if not provider:
        def _provider_label(base_label: str, provider_name: str) -> str:
            try:
                from resources.lib import tmdb_playback_state
                provider_status = (
                    tmdb_playback_state.get_provider_status(
                        tmdb_id=tmdb_id,
                        provider=provider_name,
                        season=season if mode == "serial_episode" else None,
                        episode=episode if mode == "serial_episode" else None,
                    )
                    if tmdb_id else ""
                )
            except Exception:
                provider_status = ""

            if provider_status == "finished":
                return f"[COLOR lime]{base_label}[/COLOR]"
            if provider_status == "started":
                return f"[COLOR orange]{base_label}[/COLOR]"
            return base_label

        show_prehrajto = _setting_enabled("show_prehrajto", default=True)
        show_hellspy = _setting_enabled("show_hellspy", default=True)
        show_sktonline = _setting_enabled("show_sktonline", default=True)
        show_webshare = _setting_enabled("show_webshare", default=True) and _webshare_connected()

        def _add_filtered_result_dir(query=None, **kwargs):
            provider_name = (((query or {}).get("provider")) or "").strip().lower()
            if provider_name == "prehrajto" and not show_prehrajto:
                return
            if provider_name == "hellspy" and not show_hellspy:
                return
            if provider_name == "sktonline" and not show_sktonline:
                return
            if provider_name == "webshare" and not show_webshare:
                return
            label = str(kwargs.get("label") or "")
            if label and "[COLOR " not in label:
                kwargs["label"] = _provider_label(label, provider_name)
            return _add_result_dir(query=query, **kwargs)

        _add_filtered_result_dir(
            label="Přehraj.to",
            query={
                "action": "tmdb.movie.sources.search.stub",
                "provider": "prehrajto",
                "tmdb_id": tmdb_id,
                "query": query,
                "title": title,
                "original_title": original_title,
                "year": year,
                "mode": mode,
                "season": season,
                "episode": episode,
                "episode_title": episode_title,
                "season_name": season_name,
            },
            plot=f"Hledat na Přehraj.to\nDotaz: {query}",
            icon="DefaultAddonProgram.png"
        )

        _add_filtered_result_dir(
            label=_provider_label("Hellspy", "hellspy"),
            query={
                "action": "tmdb.movie.sources.search.stub",
                "provider": "hellspy",
                "tmdb_id": tmdb_id,
                "query": query,
                "title": title,
                "original_title": original_title,
                "year": year,
                "mode": mode,
                "season": season,
                "episode": episode,
                "episode_title": episode_title,
                "season_name": season_name,
            },
            plot=f"Hledat na Hellspy\nDotaz: {query}",
            icon="DefaultAddonProgram.png"
        )

        _add_filtered_result_dir(
            label=_provider_label("SkTonLine", "sktonline"),
            query={
                "action": "tmdb.movie.sources.search.stub",
                "provider": "sktonline",
                "tmdb_id": tmdb_id,
                "query": query,
                "title": title,
                "original_title": original_title,
                "year": year,
                "mode": mode,
                "season": season,
                "episode": episode,
                "episode_title": episode_title,
                "season_name": season_name,
            },
            plot=f"Hledat na SkTonLine\nDotaz: {query}",
            icon="DefaultAddonProgram.png"
        )

        _add_filtered_result_dir(
            label=_provider_label("WebShare", "webshare"),
            query={
                "action": "tmdb.movie.sources.search.stub",
                "provider": "webshare",
                "tmdb_id": tmdb_id,
                "query": query,
                "title": title,
                "original_title": original_title,
                "year": year,
                "mode": mode,
                "season": season,
                "episode": episode,
                "episode_title": episode_title,
                "season_name": season_name,
            },
            plot=f"Hledat na WebShare\nDotaz: {query}",
            icon="DefaultAddonProgram.png"
        )

        _end("files")
        return

    try:
        if force_refresh and not _refresh_token_already_handled(refresh_token):
            _source_cache_clear(
                provider=provider,
                title=title,
                original_title=original_title,
                year=year,
                mode=mode,
                season=season,
                episode=episode
            )
            _mark_refresh_token_handled(refresh_token)
            cached_rows = None
        else:
            cached_rows = _source_cache_get(
                provider=provider,
                title=title,
                original_title=original_title,
                year=year,
                mode=mode,
                season=season,
                episode=episode
            )

        if cached_rows is not None:
            filtered = cached_rows
            xbmc.log(
                f"[IKARUS][SRC CACHE] HIT provider={provider} title={title} year={year} mode={mode} season={season} episode={episode}",
                xbmc.LOGWARNING
            )
        else:
            xbmc.log(
                f"[IKARUS][SRC CACHE] MISS provider={provider} title={title} year={year} mode={mode} season={season} episode={episode}",
                xbmc.LOGWARNING
            )

            if provider == "sktonline":
                raw_rows = _run_provider_sktonline_raw_debug(
                    title=title,
                    original_title=original_title
                )

                if mode == "serial_episode":
                    filtered = _filter_sktonline_serial_episode_rows(
                        rows=raw_rows,
                        title=title,
                        original_title=original_title,
                        season=season,
                        episode=episode,
                        episode_title=episode_title,
                        season_name=season_name
                    )
                else:
                    filtered = raw_rows
            else:
                filtered = _run_provider_multi(
                    provider_name=provider,
                    title=title,
                    original_title=original_title,
                    year=year,
                    mode=mode,
                    season=season,
                    episode=episode,
                    episode_title=episode_title,
                    season_name=season_name
                )

            _source_cache_set(
                provider=provider,
                title=title,
                original_title=original_title,
                year=year,
                rows=filtered,
                mode=mode,
                season=season,
                episode=episode
            )

    except Exception as e:
        _add_file(
            label="Chyba hledání",
            plot=f"Provider: {provider}\nDotaz: {query}\nChyba: {repr(e)}",
            icon="DefaultAddonProgram.png"
        )
        _end("files")
        return

    _add_result_dir(
        label="Obnovit zdroje",
        query={
            "action": "tmdb.movie.sources.search.stub",
            "provider": provider,
            "tmdb_id": tmdb_id,
            "query": query,
            "title": title,
            "original_title": original_title,
            "year": year,
            "mode": mode,
            "season": season,
            "episode": episode,
            "episode_title": episode_title,
            "season_name": season_name,
            "force_refresh": "1",
            "refresh_token": str(__import__("time").time()),
        },
        plot=(
            f"Provider: {provider}\n"
            f"Dotaz: {query}\n"
            "Vynutí nové hledání a přepíše cache výsledků."
        ),
        icon="DefaultAddonsSearch.png"
    )

    if not filtered:
        _add_file(
            label="Nic nenalezeno",
            plot=(
                f"Provider: {provider}\n"
                f"Dotaz: {query}\n"
                f"Název: {title}\n"
                f"Originální název: {original_title}\n"
                f"Rok: {year}\n"
                f"Mode: {mode}\n"
                f"Série: {season}\n"
                f"Epizoda: {episode}\n"
                f"Název epizody: {episode_title}\n"
                f"\n"
                f"Debug dump: special://temp/skt_search_{_cache_safe_key_part(title or query)}_page1.html\n"
                f"Debug info: special://temp/skt_search_{_cache_safe_key_part(title or query)}_debug.txt"
            ),
            icon="DefaultAddonProgram.png"
        )
        _end("files")
        return

    if provider == "webshare":
        _add_webshare_result_rows(
            rows=filtered,
            tmdb_id=tmdb_id,
            media_title=title,
            original_title=original_title,
            year=year,
            mode=mode,
            season=season,
            episode=episode,
            episode_title=episode_title,
            season_name=season_name,
            group_items=False
        )
        _end("files")
        return

    for row in filtered:
        label = row.get("title") or "Bez názvu"
        provider_name = row.get("provider") or ""
        row_url = row.get("url") or ""
        row_direct = row.get("direct") or ""
        row_id = row.get("id") or ""
        row_file_hash = row.get("fileHash") or ""

        score = row.get("_score", None)
        show_label = label + _source_label_suffix(row, score)
        lines = _source_detail_lines(row, score)

        try:
            from resources.lib import tmdb_playback_state
            source_key = tmdb_playback_state.make_source_key(
                provider=provider_name,
                url=row_url,
                direct=row_direct,
                source_id=row_id,
                file_hash=row_file_hash,
            )
            src_status = (
                tmdb_playback_state.find_source_status(
                    tmdb_id=tmdb_id,
                    provider=provider_name,
                    url=row_url,
                    direct=row_direct,
                    source_id=row_id,
                    file_hash=row_file_hash,
                    title=label,
                )
                if tmdb_id else ""
            )
        except Exception:
            src_status = ""

        if src_status == "finished":
            show_label = f"[COLOR lime]{show_label}[/COLOR]"
        elif src_status == "started":
            show_label = f"[COLOR orange]{show_label}[/COLOR]"
        elif src_status == "delete":
            show_label = f"[COLOR red]{show_label}[/COLOR]"

        _add_playable_result(
            label=show_label,
            action_query={
                "action": "tmdb.movie.source.play",
                "provider": provider_name,
                "tmdb_id": tmdb_id,
                "title": row.get("title") or label,
                "media_title": title,
                "url": row_url,
                "direct": row_direct,
                "id": row_id,
                "fileHash": row_file_hash,
                "original_title": original_title,
                "year": year,
                "mode": mode,
                "season": season,
                "episode": episode,
                "episode_title": episode_title,
                "season_name": season_name,
            },
            plot="\n".join(lines),
            icon="DefaultVideo.png"
        )

    _end("files")
    
def _source_row_status(row: dict, tmdb_id: str, lookup_title: str = "") -> str:
    try:
        from resources.lib import tmdb_playback_state
        return (
            tmdb_playback_state.find_source_status(
                tmdb_id=tmdb_id,
                provider=row.get("provider") or "",
                url=row.get("url") or "",
                direct=row.get("direct") or "",
                source_id=row.get("id") or "",
                file_hash=row.get("fileHash") or "",
                title=lookup_title or row.get("title") or "",
            )
            if tmdb_id else ""
        )
    except Exception:
        return ""

def _source_status_color(label: str, status: str) -> str:
    if status == "finished":
        return f"[COLOR lime]{label}[/COLOR]"
    if status == "started":
        return f"[COLOR orange]{label}[/COLOR]"
    if status == "delete":
        return f"[COLOR red]{label}[/COLOR]"
    return label

def _source_action_query(row: dict, tmdb_id: str, media_title: str, original_title: str,
                         year: str, mode: str, season: str, episode: str,
                         episode_title: str, season_name: str, play_title: str = "") -> dict:
    row = row or {}
    return {
        "action": "tmdb.movie.source.play",
        "provider": row.get("provider") or "",
        "tmdb_id": tmdb_id,
        "title": play_title or row.get("title") or "Zdroj",
        "media_title": media_title,
        "url": row.get("url") or "",
        "direct": row.get("direct") or "",
        "id": row.get("id") or "",
        "fileHash": row.get("fileHash") or "",
        "original_title": original_title,
        "year": year,
        "mode": mode,
        "season": season,
        "episode": episode,
        "episode_title": episode_title,
        "season_name": season_name,
    }

def _add_webshare_playable_row(row: dict, tmdb_id: str, media_title: str, original_title: str,
                               year: str, mode: str, season: str, episode: str,
                               episode_title: str, season_name: str, label_prefix: str = ""):
    label = _webshare_display_label(row, media_title=media_title, year=year)
    if label_prefix:
        label = f"{label_prefix}{label}"

    score = row.get("_score", None)
    lines = _source_detail_lines(row, score)
    source_name = _webshare_source_name(row)
    status = _source_row_status(row, tmdb_id, lookup_title=source_name)
    show_label = _source_status_color(label, status)

    _add_playable_result(
        label=show_label,
        action_query=_source_action_query(
            row=row,
            tmdb_id=tmdb_id,
            media_title=media_title,
            original_title=original_title,
            year=year,
            mode=mode,
            season=season,
            episode=episode,
            episode_title=episode_title,
            season_name=season_name,
            play_title=source_name,
        ),
        plot="\n".join(lines),
        icon="DefaultVideo.png"
    )

def _webshare_group_query(group_key: str, tmdb_id: str, media_title: str, original_title: str,
                          year: str, mode: str, season: str, episode: str,
                          episode_title: str, season_name: str) -> dict:
    return {
        "action": "tmdb.movie.sources.webshare.group",
        "provider": "webshare",
        "tmdb_id": tmdb_id,
        "group": group_key,
        "title": media_title,
        "original_title": original_title,
        "year": year,
        "mode": mode,
        "season": season,
        "episode": episode,
        "episode_title": episode_title,
        "season_name": season_name,
    }

def _add_webshare_result_rows(rows, tmdb_id: str, media_title: str, original_title: str,
                              year: str, mode: str, season: str, episode: str,
                              episode_title: str, season_name: str, group_items: bool = False):
    groups = _group_webshare_rows(rows, media_title=media_title, year=year)

    for group in groups:
        group_rows = group.get("rows") or []
        if not group_rows:
            continue

        if len(group_rows) > 1 and not group_items:
            label = f"{group.get('label') or _webshare_display_label(group_rows[0], media_title=media_title, year=year)}  [{len(group_rows)} zdroje]"
            plot = "\n".join([
                f"WebShare skupina: {len(group_rows)} totozne zdroje",
                "",
                "Po rozkliknuti se zobrazi jednotlive soubory.",
            ] + _source_detail_lines(group_rows[0], group_rows[0].get("_score", None)))
            _add_result_dir(
                label=label,
                query=_webshare_group_query(
                    group_key=group.get("key") or "",
                    tmdb_id=tmdb_id,
                    media_title=media_title,
                    original_title=original_title,
                    year=year,
                    mode=mode,
                    season=season,
                    episode=episode,
                    episode_title=episode_title,
                    season_name=season_name,
                ),
                plot=plot,
                icon="DefaultFolder.png"
            )
            continue

        if group_items and len(group_rows) > 1:
            for idx, row in enumerate(group_rows, 1):
                _add_webshare_playable_row(
                    row=row,
                    tmdb_id=tmdb_id,
                    media_title=media_title,
                    original_title=original_title,
                    year=year,
                    mode=mode,
                    season=season,
                    episode=episode,
                    episode_title=episode_title,
                    season_name=season_name,
                    label_prefix=f"{idx}. "
                )
        else:
            _add_webshare_playable_row(
                row=group_rows[0],
                tmdb_id=tmdb_id,
                media_title=media_title,
                original_title=original_title,
                year=year,
                mode=mode,
                season=season,
                episode=episode,
                episode_title=episode_title,
                season_name=season_name,
            )

def source_webshare_group_menu():
    tmdb_id = _get_param("tmdb_id", "").strip()
    group_key = _get_param("group", "").strip()
    title = _get_param("title", "").strip()
    original_title = _get_param("original_title", "").strip()
    year = _get_param("year", "").strip()
    mode = _get_param("mode", "").strip()
    season = _get_param("season", "").strip()
    episode = _get_param("episode", "").strip()
    episode_title = _get_param("episode_title", "").strip()
    season_name = _get_param("season_name", "").strip()

    xbmcplugin.setPluginCategory(addon_handle, "WebShare zdroje")
    xbmcplugin.setContent(addon_handle, "files")

    rows = _source_cache_get(
        provider="webshare",
        title=title,
        original_title=original_title,
        year=year,
        mode=mode,
        season=season,
        episode=episode
    )
    if rows is None:
        rows = _run_provider_multi(
            provider_name="webshare",
            title=title,
            original_title=original_title,
            year=year,
            mode=mode,
            season=season,
            episode=episode,
            episode_title=episode_title,
            season_name=season_name
        )

    selected = []
    for group in _group_webshare_rows(rows, media_title=title, year=year):
        if (group.get("key") or "") == group_key:
            selected = group.get("rows") or []
            break

    if not selected:
        _add_file("Skupina zdroju uz neni dostupna. Zkuste obnovit zdroje.", icon="DefaultAddonProgram.png")
        _end("files")
        return

    _add_webshare_result_rows(
        rows=selected,
        tmdb_id=tmdb_id,
        media_title=title,
        original_title=original_title,
        year=year,
        mode=mode,
        season=season,
        episode=episode,
        episode_title=episode_title,
        season_name=season_name,
        group_items=True
    )
    _end("files")

def source_play():
    provider = _get_param("provider", "").strip().lower()
    title = _get_param("title", "Zdroj").strip() or "Zdroj"
    url = _get_param("url", "").strip()
    tmdb_id = _get_param("tmdb_id", "").strip() or _get_param("id", "").strip()
    media_title = _get_param("media_title", "").strip()
    original_title = _get_param("original_title", "").strip()
    year = _get_param("year", "").strip()

    if not provider:
        xbmcgui.Dialog().ok("Zdroje", "Chybí provider.")
        return

    def _tmdb_meta():
        meta = {
            "title": media_title or title,
            "original_title": original_title,
            "year": year,
        }
        if not tmdb_id:
            return meta

        try:
            from resources.lib import TMDB_knihovna as tmdb_lib
            mode = (_get_param("mode", "") or "").strip()
            if mode == "serial_episode":
                fetched = tmdb_lib._tmdb_playback_tv_meta(tmdb_id)
            else:
                fetched = tmdb_lib._tmdb_playback_movie_meta(tmdb_id)
            if fetched:
                meta.update(fetched)
        except Exception:
            pass
        return meta

    def _play_tracked(play_target: str, headers: dict = None, source_id: str = "", file_hash: str = "", direct_url: str = ""):
        if not tmdb_id:
            play_url(title, play_target, headers=headers)
            return

        from resources.lib import tmdb_playback_state

        meta = _tmdb_meta()
        mode = (_get_param("mode", "") or "").strip()
        season = (_get_param("season", "") or "").strip()
        episode = (_get_param("episode", "") or "").strip()
        episode_title = (_get_param("episode_title", "") or "").strip()
        season_name = (_get_param("season_name", "") or "").strip()
        display_title = _build_playback_display_title(
            meta,
            fallback_title=media_title or title,
            mode=mode,
            season=season,
            episode=episode,
            episode_title=episode_title,
        )
        effective_play_target = _with_playback_display_title(play_target, display_title)
        source_meta = {
            "provider": provider,
            "source_id": source_id,
            "file_hash": file_hash,
            "direct": direct_url,
            "url": url,
            "play_url": effective_play_target,
            "title": title,
            "media_title": media_title,
            "original_title": original_title,
            "year": year,
            "display_title": display_title,
            "mode": mode,
            "season": season,
            "episode": episode,
            "episode_title": episode_title,
            "season_name": season_name,
        }
        source_key = tmdb_playback_state.make_source_key(
            provider=provider,
            url=url,
            direct=direct_url,
            source_id=source_id,
            file_hash=file_hash,
        )
        resume_sec = tmdb_playback_state.ask_resume(tmdb_id, source_key)
        if resume_sec == "__cancel__":
            return
        tmdb_playback_state.play_and_record_progress(
            tmdb_id=tmdb_id,
            source_key=source_key,
            play_url=effective_play_target,
            headers=headers,
            meta=meta,
            resume_sec=resume_sec,
            source_meta=source_meta,
        )

    if provider == "prehrajto":
        if _is_direct_media_url(url):
            _play_tracked(url)
            return

        resolved, headers = _prehrajto_resolve_direct_url(url)
        if resolved:
            _play_tracked(resolved, headers=headers, direct_url=resolved)
            return

        xbmcgui.Dialog().ok(
            "Přehraj.to",
            "Nepodařilo se získat přímý odkaz ze stránky (FREE cesta).\n"
            "Na stránce se nepodařilo najít 'var sources' s položkou 'file/src'.\n\n"
            f"URL:\n{url}"
        )
        return

    if provider == "sktonline":
        if _is_direct_media_url(url):
            _play_tracked(url)
            return

        resolved, headers = _sktonline_resolve_direct_url(url)
        if resolved:
            _play_tracked(resolved, headers=headers, direct_url=resolved)
            return

        xbmcgui.Dialog().ok(
            "SkTonLine",
            "Nepodařilo se získat přímé zdroje z detailu / embedu."
            "Nenašel jsem <video>/<source>, přímé odkazy ve <script>, ani funkční download redirect.\n\n"
            f"URL:\n{url}"
        )
        return

    if provider == "hellspy":
        direct = _get_param("direct", "").strip()
        video_id = _get_param("id", "").strip()
        video_hash = _get_param("fileHash", "").strip()
        resolved, headers = _hellspy_resolve_direct_url(url, direct, video_id, video_hash)
        if resolved:
            _play_tracked(
                resolved,
                headers=headers,
                source_id=video_id,
                file_hash=video_hash,
                direct_url=resolved,
            )
            return

        xbmcgui.Dialog().ok(
            "Hellspy",
            "Nepodařilo se získat stream URL.\n\n"
            f"URL:\n{url}"
        )
        return

    if provider == "webshare":
        video_id = _get_param("id", "").strip()

        if not video_id:
            xbmcgui.Dialog().ok(
                "WebShare",
                "Chybí identifikátor souboru."
            )
            return

        try:
            old_play_url = (
                "plugin://plugin.video.ikarus/"
                "?action=film.play&id=" + urllib.parse.quote_plus(video_id) +
                "&ident=" + urllib.parse.quote_plus(video_id)
            )

            xbmc.log(f"[IKARUS][WS] redirect playback to film.py ident={video_id}", xbmc.LOGWARNING)

            _play_tracked(old_play_url, source_id=video_id)
            return

        except Exception as e:
            xbmcgui.Dialog().ok(
                "WebShare",
                "Nepodařilo se spustit WebShare zdroj přes film.py.\n\n"
                f"ID:\n{video_id}\n\n"
                f"Chyba:\n{e}"
            )
            return
        
    xbmcgui.Dialog().ok("Zdroje", f"Neznámý provider: {provider}")

def _prehrajto_resolve_direct_url(page_url: str):
    try:
        detail_html = _http_get(page_url, referer=_PREHRAJTO_BASE)
    except Exception:
        return "", {}

    sources = _prehrajto_extract_sources_from_html(detail_html, page_url)
    if not sources:
        direct = _try_extract_sources_from_html(detail_html)
        if direct:
            if direct.startswith("/"):
                direct = urllib.parse.urljoin(_PREHRAJTO_BASE, direct)
            sources = [{"label": _prehrajto_guess_label_from_url(direct), "src": direct.strip()}]

    for item in sources:
        src = (item.get("src") or "").strip()
        if not src:
            continue

        final = _http_follow_to_final_url(src, referer=page_url)
        candidate = (final or src).strip()
        if not candidate:
            continue

        if _is_direct_media_url(candidate):
            headers = _prehrajto_build_headers(page_url, candidate)
            try:
                xbmc.log(
                    f"[IKARUS][PREHRAJTO] selected {item.get('label') or 'Zdroj'} final={candidate}",
                    xbmc.LOGWARNING,
                )
            except Exception:
                pass
            return candidate, headers

    return "", {}

def _sktonline_resolve_direct_url(page_url: str):
    detail_html = ""
    embed_html = ""
    embed_url = ""

    try:
        detail_html = _http_get(page_url, referer=_SKTONLINE_BASE)
    except Exception:
        return "", {}

    embed_url = _sktonline_find_embed_url_anywhere(detail_html, page_url)
    if embed_url:
        try:
            embed_html = _http_get(embed_url, referer=page_url)
        except Exception:
            embed_html = ""

    sources_detail = _sktonline_extract_video_sources(detail_html, page_url)
    sources_embed = _sktonline_extract_video_sources(embed_html, embed_url) if embed_html and embed_url else []
    sources_script_detail = _sktonline_extract_sources_from_scripts(detail_html, page_url)
    sources_script_embed = _sktonline_extract_sources_from_scripts(embed_html, embed_url) if embed_html and embed_url else []

    sources = _sktonline_merge_sources(sources_detail, sources_embed, sources_script_detail, sources_script_embed)

    if not sources:
        dl = []
        dl += _sktonline_extract_download_links(detail_html, page_url)
        if embed_html and embed_url:
            dl += _sktonline_extract_download_links(embed_html, embed_url)

        for it in dl:
            durl = it.get("url")
            if not durl:
                continue
            final = _http_follow_to_final_url(durl, referer=embed_url or page_url)
            if final and _is_direct_media_url(final):
                sources.append({"label": it.get("label") or _sktonline_guess_label_from_url(final), "src": final})

    if not sources:
        return "", {}

    picked = sources[0]
    if len(sources) > 1:
        labels = [(s.get("label") or "Zdroj").strip() for s in sources]
        idx = xbmcgui.Dialog().select("Vyber kvalitu", labels)
        if idx is None or idx < 0:
            return "", {}
        picked = sources[idx]

    stream_url = (picked.get("src") or "").strip()
    if not stream_url:
        return "", {}

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Referer": _sanitize_url(page_url),
        "Origin": "https://online.sktorrent.eu",
        "Accept": "*/*",
    }

    ck = _cookie_header_for_url(stream_url)
    if ck:
        headers["Cookie"] = ck

    return stream_url, headers

def _hellspy_resolve_direct_url(url: str, direct: str, video_id: str, video_hash: str):
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Referer": "https://www.hellspy.to/",
        "Origin": "https://www.hellspy.to",
        "Accept": "*/*",
    }

    if direct:
        ck = _cookie_header_for_url_basic(direct)
        if ck:
            headers["Cookie"] = ck
        return direct, headers

    if url and _is_direct_media_url(url):
        ck = _cookie_header_for_url_basic(url)
        if ck:
            headers["Cookie"] = ck
        return url, headers

    if video_id and video_hash:
        resolved = _hellspy_get_stream(video_id, video_hash)
        if resolved:
            ck = _cookie_header_for_url_basic(resolved)
            if ck:
                headers["Cookie"] = ck
            return resolved, headers

    return "", {}

def _resolve_download_target(provider: str, title: str, url: str, direct: str = "", video_id: str = "", video_hash: str = ""):
    provider = (provider or "").strip().lower()

    if provider == "prehrajto":
        if _is_direct_media_url(url):
            return url, {}
        return _prehrajto_resolve_direct_url(url)

    if provider == "sktonline":
        if _is_direct_media_url(url):
            return url, {}
        return _sktonline_resolve_direct_url(url)

    if provider == "hellspy":
        return _hellspy_resolve_direct_url(url, direct, video_id, video_hash)

    if provider == "webshare":
        return _ws_resolve_direct_url(video_id)

    return "", {}

def source_download():
    provider = _get_param("provider", "").strip().lower()
    title = _get_param("title", "Zdroj").strip() or "Zdroj"
    url = _get_param("url", "").strip()
    direct = _get_param("direct", "").strip()
    video_id = _get_param("id", "").strip()
    video_hash = _get_param("fileHash", "").strip()

    if not _get_setting_bool("download_enable", True):
        xbmcgui.Dialog().ok("Stahování", "Stahování je v nastavení vypnuté.")
        return

    download_dir = _get_setting_text("download_path", "")
    if not download_dir:
        xbmcgui.Dialog().ok("Stahování", "Není nastavena cílová složka pro stahování.")
        return

    if not _ensure_dir(download_dir):
        xbmcgui.Dialog().ok("Stahování", f"Nepodařilo se vytvořit / otevřít cílovou složku:\n{download_dir}")
        return

    resolved_url = ""
    headers = {}

    if provider == "webshare":
        if not video_id:
            xbmcgui.Dialog().ok(
                "Stahování",
                "Chybí WebShare identifikátor souboru."
            )
            return

        ext = ".mp4"
    else:
        resolved_url, headers = _resolve_download_target(
            provider=provider,
            title=title,
            url=url,
            direct=direct,
            video_id=video_id,
            video_hash=video_hash
        )

        if not resolved_url:
            xbmcgui.Dialog().ok(
                "Stahování",
                "Nepodařilo se získat přímý odkaz pro stažení.\n\n"
                f"Provider: {provider}\n"
                f"ID: {video_id}\n"
                f"URL: {url}"
            )
            return

        ext = _guess_ext_from_url(resolved_url)

    file_name = _safe_filename(title) + ext

    if _get_setting_bool("download_ask_name", True):
        custom = xbmcgui.Dialog().input("Název souboru", defaultt=file_name, type=xbmcgui.INPUT_ALPHANUM)
        if not custom:
            return
        custom = _safe_filename(custom)
        if "." not in custom:
            custom += ext
        file_name = custom

    dst_path = download_dir.rstrip("/\\") + "/" + file_name

    if xbmcvfs.exists(dst_path) and not _get_setting_bool("download_overwrite", False):
        yes = xbmcgui.Dialog().yesno(
            "Stahování",
            f"Soubor už existuje:\n{file_name}\n\nPřepsat jej?"
        )
        if not yes:
            return

    from resources.lib import download_manager

    ws_token = ""

    if provider == "webshare":
        try:
            ws_token = (_ws_login_token() or "").strip()
        except Exception as e:
            xbmc.log(f"[IKARUS][WS][DL] enqueue token failed: {repr(e)}", xbmc.LOGERROR)
            ws_token = ""

    job = download_manager.add_job(
        title=file_name,
        provider=provider,
        resolved_url=resolved_url,
        headers=headers,
        dst_path=dst_path,
        source_id=video_id if provider == "webshare" else "",
        ws_token=ws_token if provider == "webshare" else ""
    )

    xbmcgui.Dialog().notification(
        "Stahování",
        f"Přidáno do fronty: {file_name}",
        xbmcgui.NOTIFICATION_INFO,
        3000,
        sound=False
    )


def downloads_queue_clear_done():
    from resources.lib import download_manager

    removed = download_manager.remove_done_jobs()

    xbmcgui.Dialog().notification(
        "Stahování",
        f"Smazáno hotových položek: {removed}",
        xbmcgui.NOTIFICATION_INFO,
        3000,
        sound=False
    )

    _refresh_current_container()
    _finish_command_action()
    return


def downloads_queue_clear_all():
    from resources.lib import download_manager

    removed = download_manager.remove_all_jobs()

    msg = f"Fronta byla smazána: {removed} položek."
    if removed:
        msg += " Probíhající stahování bylo ukončeno."

    xbmcgui.Dialog().notification(
        "Stahování",
        msg,
        xbmcgui.NOTIFICATION_INFO,
        3000,
        sound=False
    )

    _refresh_current_container()
    _finish_command_action()
    return


def downloads_queue_menu():
    from resources.lib import download_manager

    xbmcplugin.setPluginCategory(addon_handle, "Stahování / Fronta")
    xbmcplugin.setContent(addon_handle, "files")

    _add_command_item(
        "Smazat stažené",
        {"action": "tmdb.downloads.queue.clear_done"},
        "DefaultAddonProgram.png"
    )

    _add_command_item(
        "Smazat vše",
        {"action": "tmdb.downloads.queue.clear_all"},
        "DefaultAddonProgram.png"
    )

    counts = download_manager.get_job_counts()
    current = download_manager.get_current_job()
    jobs = download_manager.get_jobs()
    current_id = (current or {}).get("id") or ""

    if current:
        title = current.get("title") or "Zdroj"
        progress = int(current.get("progress") or 0)
        _add_file(f"[B]Právě se stahuje:[/B] {title}  [{progress}%]", icon="DefaultAddonProgram.png")
    else:
        _add_file("[B]Právě se stahuje:[/B] nic", icon="DefaultAddonProgram.png")

    _add_file(
        f"Ve frontě: {counts.get('queued', 0)} | Stahuje se: {counts.get('downloading', 0)} | Hotovo: {counts.get('done', 0)} | Chyba: {counts.get('error', 0)}",
        icon="DefaultAddonProgram.png"
    )

    if not jobs:
        _add_file("Fronta je prázdná.", icon="DefaultAddonProgram.png")
        _end("files")
        return

    for job in jobs:
        st = (job.get("status") or "").strip().lower()
        if current_id and (job.get("id") or "") == current_id and st == "downloading":
            continue
        title = job.get("title") or "Zdroj"
        progress = int(job.get("progress") or 0)

        if st == "downloading":
            label = f"[STAHUJE SE] {title} [{progress}%]"
        elif st == "queued":
            label = f"[VE FRONTĚ] {title}"
        elif st == "done":
            label = f"[HOTOVO] {title}"
        elif st == "error":
            err = (job.get("error") or "").strip()
            label = f"[CHYBA] {title}"
            if err:
                label += f" - {err}"
        else:
            label = f"[{st.upper() or 'UNKNOWN'}] {title}"

        _add_file(label, icon="DefaultVideo.png")

    _end("files")


def router():
    action = _get_param("action", "")

    if action == "tmdb.movie.sources.search.stub":
        source_search_stub_menu()
        return

    if action == "tmdb.movie.sources.webshare.group":
        source_webshare_group_menu()
        return

    if action == "tmdb.movie.source.play":
        source_play()
        return

    if action == "tmdb.movie.source.download":
        source_download()
        return

    if action == "tmdb.downloads.queue":
        downloads_queue_menu()
        return

    if action == "tmdb.downloads.queue.clear_done":
        downloads_queue_clear_done()
        return

    if action == "tmdb.downloads.queue.clear_all":
        downloads_queue_clear_all()
        return

    _placeholder_dir("Zdroje", f"(neznámá akce: {action})")

if __name__ == "__main__":
    router()
    

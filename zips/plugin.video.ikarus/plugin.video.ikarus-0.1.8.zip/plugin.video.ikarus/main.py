# -*- coding: utf-8 -*-
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

import film

import nastaveni

from resources.lib import jine_zdroje         
from resources.lib import TMDB_knihovna
from resources.lib import github_gist_sync
from resources.lib import trakt_client

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
BASE_PATH = sys.argv[0] if len(sys.argv) > 0 else ""


def build_url(query: dict) -> str:
    return BASE_PATH + '?' + urllib.parse.urlencode(query)


#--------------------------------------------------------------------------
#                            Hlavní menu Pluginu Ikarus
#--------------------------------------------------------------------------
def main_menu():
    items = [
        ("Film",                              {"action": "tmdb.movies"},          "DefaultMovies.png", True),
        ("Seriály",                           {"action": "tmdb.series"},          "DefaultTVShows.png", True),
        ("Osoby",                             {"action": "tmdb.people"},          "DefaultActor.png", True),
        ("Trendující",                        {"action": "tmdb.trending"},        "DefaultAddonVideo.png", True),
        ("Zhlédnuté",                         {"action": "tmdb.finished"},        "DefaultInProgressShows.png", True),
        ("Rozkoukané",                        {"action": "tmdb.started"},         "DefaultInProgressShows.png", True),
        ("Moje seznamy",                      {"action": "tmdb.custom.lists"},    "DefaultVideoPlaylists.png", True),
        ("Vyhledat",                          {"action": "tmdb.search"},          "DefaultAddonsSearch.png", True),
        ("Fronta stahování",                  {"action": "tmdb.downloads.queue"}, "DefaultAddonProgram.png", True),
        ("Ruční hledání na Přehraj.to/Hellspy/SkTonLine/WebShare",{"action": "other_sources"},  "DefaultFavourites.png", True),
        ("Nastavení",                        {"action": "settings"},       "DefaultProgram.png", False),
    ]

    try:
        if trakt_client.is_connected():
            insert_at = len(items)
            for idx, (_, query, _, _) in enumerate(items):
                if (query or {}).get("action") == "tmdb.search":
                    insert_at = idx
                    break
            items.insert(insert_at, ("Chytré seznamy", {"action": "tmdb.trakt.smart.lists"}, "DefaultVideoPlaylists.png", True))
            insert_at += 1
            items.insert(insert_at, ("Trakt.TV seznamy", {"action": "tmdb.trakt.lists"}, "DefaultVideoPlaylists.png", True))
    except Exception:
        pass

    for label, query, icon_p, is_folder in items:
        url = build_url(query)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': icon_p, 'thumb': icon_p})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(addon_handle)


#--------------------------------------------------------------------------
#                            Router
#--------------------------------------------------------------------------
def router(paramstring):
    # params z querystringu (nepřepisujeme později!)
    params = dict(urllib.parse.parse_qsl(paramstring)) if paramstring else {}
    action = params.get("action")

    user = addon.getSetting("username") or ""
    pwd  = addon.getSetting("password") or ""
    token = nastaveni.ziskej_token(user, pwd)

    base_path = BASE_PATH

    if not action:
        main_menu()
        return

    if action == "refresh_token":
        nastaveni.refresh_token_now()
        main_menu()
        return

    if action == "check_updates":
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmcgui.Dialog().notification(
            "Ikarus",
            "Kontrola aktualizací byla spuštěna.",
            xbmcgui.NOTIFICATION_INFO,
            3500,
        )
        try:
            if addon_handle > 0:
                xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
        except Exception:
            pass
        return

    if action == "gist_import_from_file":
        ok, msg = github_gist_sync.import_settings_from_file()
        icon = xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR
        xbmcgui.Dialog().notification("GitHub Gist", msg, icon, 3500)
        try:
            if addon_handle > 0:
                xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
        except Exception:
            pass
        return

    if action == "trakt.login":
        trakt_client.login_device_flow()
        return

    if action == "trakt.logout":
        trakt_client.logout()
        return

    if action == "trakt.check":
        trakt_client.check_connection(show_notification=True)
        return

    # --- film sekce ---
    if action.startswith("film."):
        film.handle_router(token, addon_handle, base_path, params)
        return

    # --- Jiné zdroje / Test menu ---
    if action == "other_sources" or action.startswith("other."):
        jine_zdroje.router()
        return

    # --- TMDB menu ---
    if action.startswith("tmdb."):
        TMDB_knihovna.router()
        return

    if action == "settings":
        xbmc.executebuiltin("Addon.OpenSettings(plugin.video.ikarus)")
        return

    # fallback – když neznáme akci, aspoň zobrazíme hlavní menu
    main_menu()


if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")

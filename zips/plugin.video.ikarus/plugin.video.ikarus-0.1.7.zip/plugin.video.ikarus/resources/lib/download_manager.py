# -*- coding: utf-8 -*-
import json
import time
import uuid
import re

import xbmc
import xbmcaddon
import xbmcvfs


addon = xbmcaddon.Addon()


def _profile_dir():
    return xbmcvfs.translatePath(addon.getAddonInfo("profile"))


def _queue_path():
    return _profile_dir().rstrip("/\\") + "/download_queue.json"


def _ensure_profile():
    path = _profile_dir()
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def _safe_filename(name: str) -> str:
    name = (name or "").strip()
    if not name:
        name = "zdroj"
    name = re.sub(r'[\\/:*?"<>|]+', "_", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name[:180] or "zdroj"


def _read_queue():
    _ensure_profile()
    path = _queue_path()

    if not xbmcvfs.exists(path):
        return {"jobs": []}

    try:
        f = xbmcvfs.File(path, "r")
        raw = f.read()
        f.close()
        data = json.loads(raw or "{}")
        if not isinstance(data, dict):
            return {"jobs": []}
        jobs = data.get("jobs")
        if not isinstance(jobs, list):
            jobs = []
        return {"jobs": jobs}
    except Exception as e:
        xbmc.log(f"[IKARUS][DL] queue read failed: {repr(e)}", xbmc.LOGERROR)
        return {"jobs": []}


def _write_queue(data):
    _ensure_profile()
    path = _queue_path()
    try:
        f = xbmcvfs.File(path, "w")
        f.write(json.dumps(data, ensure_ascii=False))
        f.close()
        return True
    except Exception as e:
        xbmc.log(f"[IKARUS][DL] queue write failed: {repr(e)}", xbmc.LOGERROR)
        return False


def add_job(title: str, provider: str, resolved_url: str, headers: dict, dst_path: str, source_id: str = "", ws_token: str = ""):
    data = _read_queue()
    jobs = data.get("jobs") or []

    job = {
        "id": str(uuid.uuid4()),
        "title": title or "Zdroj",
        "provider": provider or "",
        "resolved_url": resolved_url or "",
        "headers": headers or {},
        "dst_path": dst_path or "",
        "source_id": source_id or "",
        "ws_token": ws_token or "",
        "status": "queued",
        "progress": 0,
        "error": "",
        "created_ts": int(time.time()),
        "started_ts": 0,
        "finished_ts": 0,
    }

    jobs.append(job)
    data["jobs"] = jobs
    _write_queue(data)
    return job


def get_jobs():
    return (_read_queue().get("jobs") or [])


def get_job(job_id: str):
    if not job_id:
        return None

    jobs = get_jobs()
    for job in jobs:
        if (job.get("id") or "") == job_id:
            return job
    return None


def find_next_job():
    jobs = get_jobs()
    for job in jobs:
        if (job.get("status") or "") == "queued":
            return job
    return None


def update_job(job_id: str, **changes):
    data = _read_queue()
    jobs = data.get("jobs") or []
    changed = False

    for job in jobs:
        if (job.get("id") or "") == job_id:
            for k, v in changes.items():
                job[k] = v
            changed = True
            break

    if changed:
        data["jobs"] = jobs
        _write_queue(data)

    return changed




def get_job_counts():
    jobs = get_jobs()

    out = {
        "queued": 0,
        "downloading": 0,
        "done": 0,
        "error": 0,
        "all": len(jobs),
    }

    for job in jobs:
        st = (job.get("status") or "").strip().lower()
        if st in out:
            out[st] += 1

    return out


def get_current_job():
    jobs = get_jobs()
    for job in jobs:
        if (job.get("status") or "") == "downloading":
            return job
    return None

def reset_stuck_downloading_jobs():
    data = _read_queue()
    jobs = data.get("jobs") or []
    changed = 0

    for job in jobs:
        st = (job.get("status") or "").strip().lower()
        if st == "downloading":
            job["status"] = "queued"
            job["progress"] = 0
            job["error"] = "obnoveno po přerušeném stahování"
            changed += 1

    if changed:
        data["jobs"] = jobs
        _write_queue(data)

    return changed


def remove_done_jobs():
    data = _read_queue()
    jobs = data.get("jobs") or []

    new_jobs = []
    removed = 0

    for job in jobs:
        st = (job.get("status") or "").strip().lower()
        if st == "done":
            removed += 1
            continue
        new_jobs.append(job)

    if removed:
        data["jobs"] = new_jobs
        _write_queue(data)

    return removed





def remove_all_jobs(keep_downloading: bool = False):
    data = _read_queue()
    jobs = data.get("jobs") or []
    if not keep_downloading:
        removed = len(jobs)

        if removed:
            data["jobs"] = []
            _write_queue(data)

        return removed

    new_jobs = []
    removed = 0

    for job in jobs:
        st = (job.get("status") or "").strip().lower()
        if st == "downloading":
            new_jobs.append(job)
            continue
        removed += 1

    if removed:
        data["jobs"] = new_jobs
        _write_queue(data)

    return removed

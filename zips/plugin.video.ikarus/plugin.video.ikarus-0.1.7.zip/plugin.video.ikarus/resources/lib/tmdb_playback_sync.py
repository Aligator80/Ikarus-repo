# -*- coding: utf-8 -*-
import copy
import time

import xbmc

from resources.lib import tmdb_playback_state
from resources.lib import trakt_client


_TRAKT_STATE_CACHE = None
_TRAKT_STATE_CACHE_TS = 0.0
_TRAKT_STATE_CACHE_TTL = 60.0


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log(f"[IKARUS][TMDB PLAYBACK SYNC] {msg}", level)
    except Exception:
        pass


def _str(value):
    return str(value or "").strip()


def _to_int(value):
    try:
        text = _str(value)
        if not text:
            return None
        return int(text)
    except Exception:
        return None


def _to_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default


def _date_from_row(row: dict, fallback: str = "") -> str:
    for key in ("paused_at", "last_watched_at", "watched_at", "listed_at", "updated_at"):
        value = _str((row or {}).get(key))
        if value:
            return value
    return fallback


def _media_meta(media: dict, media_type: str) -> dict:
    ids = media.get("ids") if isinstance(media.get("ids"), dict) else {}
    tmdb_id = _str(ids.get("tmdb"))
    title = _str(media.get("title"))
    year = _str(media.get("year"))
    rating = media.get("rating")
    meta = {
        "tmdb_id": tmdb_id,
        "title": title,
        "original_title": _str(media.get("original_title")),
        "year": year,
        "rating": rating,
        "media_type": media_type,
    }
    if media_type in ("tv", "show", "series"):
        meta["media_type"] = "tv"
        total = media.get("aired_episodes") or media.get("episode_count") or media.get("episodes")
        total_i = _to_int(total)
        if total_i is not None:
            meta["total_episodes"] = total_i
    return meta


def _ensure_row(state: dict, tmdb_id: str, meta: dict) -> dict:
    tmdb_id = _str(tmdb_id)
    row = state.get(tmdb_id)
    if not isinstance(row, dict):
        row = {}
    row["tmdb_id"] = tmdb_id
    row["sources"] = row.get("sources") if isinstance(row.get("sources"), dict) else {}
    for key in ("title", "original_title", "year", "poster", "plot", "rating", "media_type", "total_episodes", "total_seasons"):
        value = (meta or {}).get(key)
        if value not in (None, ""):
            row[key] = value
    state[tmdb_id] = row
    return row


def _set_row_dates(row: dict, when: str):
    when = _str(when)
    if not when:
        return
    if not _str(row.get("last_played_at")) or when > _str(row.get("last_played_at")):
        row["last_played_at"] = when
    if not _str(row.get("updated_at")) or when > _str(row.get("updated_at")):
        row["updated_at"] = when


def _add_movie_source(state: dict, movie: dict, status: str, when: str, progress: float = 100.0):
    meta = _media_meta(movie or {}, "movie")
    tmdb_id = _str(meta.get("tmdb_id"))
    if not tmdb_id:
        return
    row = _ensure_row(state, tmdb_id, meta)
    ratio = max(0.0, min(1.0, float(progress or 0.0) / 100.0))
    source_key = tmdb_playback_state.make_source_key(
        provider="trakt",
        url=f"trakt://movie/{tmdb_id}",
        source_id=f"trakt_{status}",
    )
    row["sources"][source_key] = {
        "provider": "trakt",
        "source_id": f"trakt_{status}",
        "url": f"trakt://movie/{tmdb_id}",
        "title": "Trakt.TV",
        "mode": "movie",
        "status": status,
        "last_position_sec": ratio,
        "last_duration_sec": 1.0,
        "last_ratio": ratio,
    }
    if status == "finished":
        row["sources"][source_key]["last_finished_at"] = when
    else:
        row["sources"][source_key]["last_started_at"] = when
    _set_row_dates(row, when)


def _add_episode_source(state: dict, show: dict, season, episode, status: str, when: str,
                        progress: float = 100.0, episode_title: str = ""):
    meta = _media_meta(show or {}, "tv")
    tmdb_id = _str(meta.get("tmdb_id"))
    season_i = _to_int(season)
    episode_i = _to_int(episode)
    if not tmdb_id or season_i is None or episode_i is None:
        return
    row = _ensure_row(state, tmdb_id, meta)
    ratio = max(0.0, min(1.0, float(progress or 0.0) / 100.0))
    source_id = f"trakt_{status}_s{season_i:03d}e{episode_i:04d}"
    url = f"trakt://show/{tmdb_id}/season/{season_i}/episode/{episode_i}"
    source_key = tmdb_playback_state.make_source_key(
        provider="trakt",
        url=url,
        source_id=source_id,
    )
    row["sources"][source_key] = {
        "provider": "trakt",
        "source_id": source_id,
        "url": url,
        "title": episode_title or f"Trakt.TV S{season_i:02d}E{episode_i:02d}",
        "mode": "serial_episode",
        "season": str(season_i),
        "episode": str(episode_i),
        "episode_title": episode_title,
        "status": status,
        "last_position_sec": ratio,
        "last_duration_sec": 1.0,
        "last_ratio": ratio,
    }
    if status == "finished":
        row["sources"][source_key]["last_finished_at"] = when
    else:
        row["sources"][source_key]["last_started_at"] = when
    _set_row_dates(row, when)


def _merge_watched_movies(state: dict):
    for row in trakt_client.fetch_watched("movies"):
        if not isinstance(row, dict):
            continue
        movie = row.get("movie") if isinstance(row.get("movie"), dict) else {}
        when = _date_from_row(row)
        _add_movie_source(state, movie, "finished", when, progress=100.0)


def _merge_watched_shows(state: dict):
    for row in trakt_client.fetch_watched("shows"):
        if not isinstance(row, dict):
            continue
        show = row.get("show") if isinstance(row.get("show"), dict) else {}
        when = _date_from_row(row)
        seasons = row.get("seasons") if isinstance(row.get("seasons"), list) else []
        for season_row in seasons:
            if not isinstance(season_row, dict):
                continue
            season = season_row.get("number")
            episodes = season_row.get("episodes") if isinstance(season_row.get("episodes"), list) else []
            for episode_row in episodes:
                if not isinstance(episode_row, dict):
                    continue
                episode = episode_row.get("number")
                ep_when = _date_from_row(episode_row, fallback=when)
                _add_episode_source(state, show, season, episode, "finished", ep_when, progress=100.0)


def _watched_show_episode_rows() -> list:
    out = []
    for row in trakt_client.fetch_watched("shows"):
        if not isinstance(row, dict):
            continue
        show = row.get("show") if isinstance(row.get("show"), dict) else {}
        meta = _media_meta(show, "tv")
        tmdb_id = _str(meta.get("tmdb_id"))
        show_title = _str(meta.get("title"))
        when = _date_from_row(row)
        if not tmdb_id:
            continue
        seasons = row.get("seasons") if isinstance(row.get("seasons"), list) else []
        for season_row in seasons:
            if not isinstance(season_row, dict):
                continue
            season = _to_int(season_row.get("number"))
            episodes = season_row.get("episodes") if isinstance(season_row.get("episodes"), list) else []
            for episode_row in episodes:
                if not isinstance(episode_row, dict):
                    continue
                episode = _to_int(episode_row.get("number"))
                if season is None or episode is None:
                    continue
                ep_when = _date_from_row(episode_row, fallback=when)
                episode_title = _str(episode_row.get("title"))
                ep_code = f"S{season:02d}E{episode:02d}"
                display_title = f"{show_title} - {ep_code}"
                if episode_title:
                    display_title = f"{display_title} {episode_title}"
                item = dict(meta)
                item.update({
                    "tmdb_id": tmdb_id,
                    "media_type": "tv",
                    "title": display_title,
                    "display_title": display_title,
                    "show_title": show_title,
                    "season": str(season),
                    "episode": str(episode),
                    "episode_title": episode_title,
                    "last_played_at": ep_when,
                    "updated_at": ep_when,
                    "sources": {},
                })
                _add_episode_source(
                    {tmdb_id: item},
                    show,
                    season,
                    episode,
                    "finished",
                    ep_when,
                    progress=100.0,
                    episode_title=episode_title,
                )
                key = f"{tmdb_id}:s{season:03d}e{episode:04d}"
                out.append((ep_when, key, item))
    out.sort(key=lambda item: item[0], reverse=True)
    return out


def _merge_playback(state: dict):
    for row in trakt_client.fetch_playback():
        if not isinstance(row, dict):
            continue
        progress = _to_float(row.get("progress"), default=0.0)
        when = _date_from_row(row)
        media_type = _str(row.get("type")).lower()
        if media_type == "movie" and isinstance(row.get("movie"), dict):
            _add_movie_source(state, row.get("movie"), "started", when, progress=progress)
        elif media_type == "episode":
            show = row.get("show") if isinstance(row.get("show"), dict) else {}
            episode_data = row.get("episode") if isinstance(row.get("episode"), dict) else {}
            _add_episode_source(
                state,
                show,
                episode_data.get("season"),
                episode_data.get("number"),
                "started",
                when,
                progress=progress,
                episode_title=_str(episode_data.get("title")),
            )


def trakt_state(force: bool = False) -> dict:
    global _TRAKT_STATE_CACHE, _TRAKT_STATE_CACHE_TS
    if not trakt_client.is_connected():
        return {}

    now = time.time()
    if (
        not force
        and isinstance(_TRAKT_STATE_CACHE, dict)
        and (now - _TRAKT_STATE_CACHE_TS) < _TRAKT_STATE_CACHE_TTL
    ):
        return copy.deepcopy(_TRAKT_STATE_CACHE)

    state = {}
    try:
        _merge_watched_movies(state)
        _merge_watched_shows(state)
        _merge_playback(state)
    except Exception as e:
        _log(f"trakt state load error: {e}", xbmc.LOGWARNING)

    _TRAKT_STATE_CACHE = copy.deepcopy(state)
    _TRAKT_STATE_CACHE_TS = now
    return copy.deepcopy(state)


def trakt_item_status(media_type: str, tmdb_id: str) -> str:
    tmdb_id = _str(tmdb_id)
    media_type = _str(media_type).lower()
    if media_type == "tv":
        media_type = "show"
    if not tmdb_id:
        return ""
    row = trakt_state().get(tmdb_id)
    if not isinstance(row, dict):
        return ""
    return tmdb_playback_state.get_status_bucket(row)


def merged_state(force_remote: bool = False, include_trakt: bool = True) -> dict:
    try:
        local_state = tmdb_playback_state.playback_state_load(force_remote=force_remote)
    except Exception:
        local_state = {}

    try:
        state = copy.deepcopy(local_state if isinstance(local_state, dict) else {})
    except Exception:
        state = dict(local_state if isinstance(local_state, dict) else {})

    if not include_trakt or not trakt_client.is_connected():
        return state

    try:
        _merge_watched_movies(state)
        _merge_watched_shows(state)
        _merge_playback(state)
    except Exception as e:
        _log(f"trakt merge error: {e}", xbmc.LOGWARNING)
    return state


def _state_rows(state: dict) -> list:
    out = []
    for tmdb_id, row in (state or {}).items():
        if not isinstance(row, dict):
            continue
        out.append((_str(row.get("last_played_at")), tmdb_id, row))
    out.sort(key=lambda item: item[0], reverse=True)
    return out


def _state_rows_by_status(state: dict, status: str) -> list:
    status = _str(status).lower()
    out = []
    for tmdb_id, row in (state or {}).items():
        if not isinstance(row, dict):
            continue
        if tmdb_playback_state.get_status_bucket(row) != status:
            continue
        out.append((_str(row.get("last_played_at")), tmdb_id, row))
    out.sort(key=lambda item: item[0], reverse=True)
    return out


def iter_trakt_watched_items():
    state = {}
    if not trakt_client.is_connected():
        return []
    try:
        _merge_watched_movies(state)
        _merge_watched_shows(state)
    except Exception as e:
        _log(f"trakt watched load error: {e}", xbmc.LOGWARNING)
    return _state_rows_by_status(state, "finished")


def iter_trakt_playback_items():
    state = {}
    if not trakt_client.is_connected():
        return []
    try:
        _merge_watched_shows(state)
        _merge_playback(state)
    except Exception as e:
        _log(f"trakt playback load error: {e}", xbmc.LOGWARNING)
    return _state_rows_by_status(state, "started")


def trakt_show_row(tmdb_id: str) -> dict:
    tmdb_id = _str(tmdb_id)
    if not tmdb_id or not trakt_client.is_connected():
        return {}

    state = trakt_state()
    row = state.get(tmdb_id) if isinstance(state.get(tmdb_id), dict) else {}
    return copy.deepcopy(row)


def _row_sources(row: dict) -> list:
    sources = (row or {}).get("sources")
    if not isinstance(sources, dict):
        return []
    return [src for src in sources.values() if isinstance(src, dict)]


def _source_episode_pair(src: dict):
    season = _to_int((src or {}).get("season"))
    episode = _to_int((src or {}).get("episode"))
    if season is None or episode is None:
        return None
    return season, episode


def _source_status(src: dict) -> str:
    status = _str((src or {}).get("status")).lower()
    if status in ("finished", "watched", "complete", "completed"):
        return "finished"
    if status in ("started", "progress", "paused", "playing"):
        return "started"
    ratio = _to_float((src or {}).get("last_ratio"), default=0.0)
    if ratio >= 0.90:
        return "finished"
    if ratio > 0.0:
        return "started"
    return ""


def get_row_episode_status(row: dict, season, episode) -> str:
    season_i = _to_int(season)
    episode_i = _to_int(episode)
    if season_i is None or episode_i is None:
        return ""

    found_started = False
    for src in _row_sources(row):
        if _source_episode_pair(src) != (season_i, episode_i):
            continue
        status = _source_status(src)
        if status == "finished":
            return "finished"
        if status == "started":
            found_started = True
    return "started" if found_started else ""


def get_row_season_status(row: dict, season, total_episodes=None) -> str:
    season_i = _to_int(season)
    if season_i is None:
        return ""

    touched = set()
    finished = set()
    for src in _row_sources(row):
        pair = _source_episode_pair(src)
        if not pair or pair[0] != season_i:
            continue
        touched.add(pair[1])
        if _source_status(src) == "finished":
            finished.add(pair[1])

    total_i = _to_int(total_episodes)
    if total_i and total_i > 0 and len(finished) >= total_i:
        return "finished"
    if touched:
        return "started"
    return ""


def iter_items_by_status(target_status: str, force_remote: bool = False, include_trakt: bool = True):
    target_status = _str(target_status).lower()
    out = []
    for tmdb_id, row in (merged_state(force_remote=force_remote, include_trakt=include_trakt) or {}).items():
        if not isinstance(row, dict):
            continue
        if tmdb_playback_state.get_status_bucket(row) != target_status:
            continue
        out.append((_str(row.get("last_played_at")), tmdb_id, row))
    out.sort(key=lambda item: item[0], reverse=True)
    return out

# -*- coding: utf-8 -*-
import sys
import re
import json
import time
import urllib.parse
import urllib.request
import html
import http.cookiejar
from collections import Counter
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
BASE_PATH = sys.argv[0] if len(sys.argv) > 0 else ""


def _setting_enabled(setting_id: str, default: bool = True) -> bool:
    value = (addon.getSetting(setting_id) or "").strip().lower()
    if not value:
        return default
    return value == "true"


def _webshare_connected() -> bool:
    status = (addon.getSetting("status") or "").strip().lower()
    return status in ("připojeno", "pripojeno", "přihlášen", "prihlasen")

# ---------------------------
# HTTP (urllib + cookies)
# ---------------------------

_COOKIEJAR = http.cookiejar.CookieJar()
_OPENER = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_COOKIEJAR))


# ---------------------------
# ROUTING HELPERS
# ---------------------------

def build_url(query: dict) -> str:
    return BASE_PATH + "?" + urllib.parse.urlencode(query)


def main_menu():
    xbmcplugin.setContent(addon_handle, "files")

    items = [
        ("Přehraj.to", {"action": "other.prehrajto"}, "DefaultAddonProgram.png"),
        ("Hellspy",    {"action": "other.hellspy"},   "DefaultAddonProgram.png"),
        ("SkTonLine",  {"action": "other.sktonline"}, "DefaultAddonProgram.png"),
        ("WebShare", {"action": "film.search"}, "DefaultAddonProgram.png"),
    ]

    allowed_actions = set()
    if _setting_enabled("show_prehrajto", default=True):
        allowed_actions.add("other.prehrajto")
    if _setting_enabled("show_hellspy", default=True):
        allowed_actions.add("other.hellspy")
    if _setting_enabled("show_sktonline", default=True):
        allowed_actions.add("other.sktonline")
    if _setting_enabled("show_webshare", default=True) and _webshare_connected():
        allowed_actions.add("film.search")

    items = [
        (label, query, icon_p)
        for (label, query, icon_p) in items
        if (query.get("action") or "") in allowed_actions
    ]

    for label, query, icon_p in items:
        url = build_url(query)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon_p, "thumb": icon_p, "poster": icon_p})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


# ---------------------------
# COMMON HTTP (urllib, no gzip)
# ---------------------------
def _sanitize_url(url: str) -> str:
    """
    Kodi ti do params vrátí URL už dekódovanou (s diakritikou).
    urllib ale často chce percent-encoded URL.
    """
    try:
        p = urllib.parse.urlsplit(url)
        path = urllib.parse.quote(p.path, safe="/%")
        query = urllib.parse.quote(p.query, safe="=&%")
        frag = urllib.parse.quote(p.fragment, safe="%")
        return urllib.parse.urlunsplit((p.scheme, p.netloc, path, query, frag))
    except Exception:
        return url

def _http_get(url: str, timeout: int = 25, referer: str = None) -> str:
    url = _sanitize_url(url)

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer

    req = urllib.request.Request(url, headers=headers, method="GET")

    with _OPENER.open(req, timeout=timeout) as resp:
        raw = resp.read()

    try:
        return raw.decode("utf-8", errors="ignore")
    except Exception:
        return raw.decode(errors="ignore")


def _http_post(url: str, data: dict, timeout: int = 25, referer: str = None) -> str:
    url = _sanitize_url(url)
    body = urllib.parse.urlencode(data or {}).encode("utf-8")

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "close",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    if referer:
        headers["Referer"] = referer

    req = urllib.request.Request(url, data=body, headers=headers, method="POST")

    with _OPENER.open(req, timeout=timeout) as resp:
        raw = resp.read()

    try:
        return raw.decode("utf-8", errors="ignore")
    except Exception:
        return raw.decode(errors="ignore")


def _http_get_json(url: str, timeout: int = 25, referer: str = None, origin: str = None) -> dict:
    url = _sanitize_url(url)

    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "application/json,*/*",
        "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer
    else:
        headers["Referer"] = "https://www.hellspy.to/"
    if origin:
        headers["Origin"] = origin
    else:
        headers["Origin"] = "https://www.hellspy.to"

    req = urllib.request.Request(url, headers=headers, method="GET")

    try:
        with _OPENER.open(req, timeout=timeout) as resp:
            raw = resp.read()
        try:
            txt = raw.decode("utf-8", errors="ignore")
        except Exception:
            txt = raw.decode(errors="ignore")
        try:
            return json.loads(txt) if txt else {}
        except Exception:
            return {}
    except Exception:
        return {}


# ---------------------------
# PLAY HELPERS (Přehraj.to přehrávání používá)
# ---------------------------

def _is_direct_media_url(u: str) -> bool:
    if not u:
        return False
    ul = u.lower()
    return any(ext in ul for ext in (".mp4", ".m3u8", ".ts", ".mkv", ".avi", ".webm"))

def _kodi_url_with_headers(url: str, headers: dict) -> str:
    """
    Kodi headers v URL: https://...|Header=Value&Header2=Value2
    """
    if not headers:
        return url

    parts = []
    for k, v in headers.items():
        if v is None:
            continue
        vv = str(v)
        vv_enc = urllib.parse.quote_plus(vv, safe="")
        parts.append(f"{k}={vv_enc}")

    return url + "|" + "&".join(parts)

def play_url(title: str, stream_url: str, headers: dict = None):
    try:
        stream_url = _sanitize_url(stream_url)
    except Exception:
        pass

    final_url = stream_url
    if headers:
        final_url = _kodi_url_with_headers(final_url, headers)

    li = xbmcgui.ListItem(label=title)
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    li.setPath(final_url)

    li.setInfo("video", {"title": title})

    xbmcplugin.setResolvedUrl(addon_handle, True, li)

def _cookie_header_for_url_basic(url: str) -> str:
    """
    Vrátí Cookie header pro danou URL z _COOKIEJAR.
    (jednoduchá varianta, stačí na většinu hostů)
    """
    try:
        u = urllib.parse.urlsplit(url)
        host = (u.hostname or "").lower()
        path = u.path or "/"

        cookies = []
        for c in _COOKIEJAR:
            dom = (c.domain or "").lstrip(".").lower()
            if not dom:
                continue
            if not (host == dom or host.endswith("." + dom)):
                continue
            cpath = c.path or "/"
            if path.startswith(cpath):
                cookies.append(f"{c.name}={c.value}")

        return "; ".join(cookies)
    except Exception:
        return ""


# ---------------------------
# PREHRAJ.TO (vyhledání + zobrazení + přehrávání)
# ---------------------------

_PREHRAJTO_BASE = "https://prehrajto.cz"
_PREHRAJTO_SEARCH_PREFIX = "/hledej/"
_PREHRAJTO_PAGINATOR_PARAM = "videoListing-visualPaginator-page"
_PREHRAJTO_DETAIL_RE = re.compile(r"^/[^/]+/[0-9a-f]{10,}$", re.IGNORECASE)

def _build_prehrajto_search_url(query: str, page: int) -> str:
    q = urllib.parse.quote(query.strip())
    base = urllib.parse.urljoin(_PREHRAJTO_BASE, f"{_PREHRAJTO_SEARCH_PREFIX}{q}")
    return base + "?" + urllib.parse.urlencode({_PREHRAJTO_PAGINATOR_PARAM: page})

def _canonicalize_prehrajto_url(full: str) -> str:
    u = urllib.parse.urlparse(full)
    qs = [(k, v) for (k, v) in urllib.parse.parse_qsl(u.query, keep_blank_values=True) if k.lower() != "player"]
    new_query = urllib.parse.urlencode(qs, doseq=True)
    return urllib.parse.urlunparse((u.scheme, u.netloc, u.path, u.params, new_query, u.fragment))

def _extract_prehrajto_results(html_text: str):
    results = []
    seen = set()

    for m in re.finditer(r'<a[^>]+href="(?P<href>/[^"]+)"(?P<rest>[^>]*)>', html_text, re.IGNORECASE):
        href = (m.group("href") or "").strip()
        rest = m.group("rest") or ""

        if not href or href.startswith("#") or href.lower().startswith("javascript:"):
            continue
        if not _PREHRAJTO_DETAIL_RE.match(href):
            continue

        full = urllib.parse.urljoin(_PREHRAJTO_BASE, href)
        full = _canonicalize_prehrajto_url(full)

        if full in seen:
            continue
        seen.add(full)

        title = ""
        mt = re.search(r'title="([^"]+)"', rest, re.IGNORECASE)
        if mt:
            title = html.unescape(mt.group(1)).strip()

        if not title or len(title) < 2:
            seg = href.strip("/").split("/", 1)[0]
            title = seg

        title = re.sub(r"\s+", " ", title).strip()
        results.append({"title": title, "url": full})

    return results

def prehrajto_search_all_pages(query: str, max_pages: int = 30):
    all_results = []
    seen_urls = set()

    for page in range(1, max_pages + 1):
        url = _build_prehrajto_search_url(query, page)
        html_text = _http_get(url)
        page_results = _extract_prehrajto_results(html_text)

        if not page_results:
            break

        new_added = 0
        for it in page_results:
            if it["url"] in seen_urls:
                continue
            seen_urls.add(it["url"])
            all_results.append(it)
            new_added += 1

        if new_added == 0:
            break

    return all_results

def prehrajto_search_ui():
    q = xbmcgui.Dialog().input("Přehraj.to – zadej hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return

    results = prehrajto_search_all_pages(q.strip(), max_pages=30)

    xbmcplugin.setContent(addon_handle, "files")

    if not results:
        xbmcgui.Dialog().ok("Přehraj.to", "Nic nenalezeno.")
        main_menu()
        return

    for it in results:
        title = it.get("title") or "Bez názvu"
        url = it.get("url") or ""

        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")

        u = build_url({"action": "other.prehrajto_item", "title": title, "url": url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def _try_extract_sources_from_html(html_text: str):
    m = re.search(r"var\s+sources\s*=\s*(\[[\s\S]*?\])\s*;", html_text, re.IGNORECASE)
    if not m:
        return None

    arr_txt = m.group(1)

    mf = re.search(r'["\'](?:file|src)["\']\s*:\s*["\']([^"\']+)["\']', arr_txt, re.IGNORECASE)
    if not mf:
        mf = re.search(r'(?:file|src)\s*:\s*["\']([^"\']+)["\']', arr_txt, re.IGNORECASE)

    if mf:
        return html.unescape(mf.group(1)).strip()

    return None

def prehrajto_try_resolve_and_play(title: str, page_url: str) -> bool:
    try:
        detail_html = _http_get(page_url)
    except Exception:
        return False

    direct = _try_extract_sources_from_html(detail_html)
    if not direct:
        return False

    if direct.startswith("/"):
        direct = urllib.parse.urljoin(_PREHRAJTO_BASE, direct)

    play_url(title, direct)
    return True


# ---------------------------
# HELLLSPY (vyhledání + zobrazení + přehrávání pokud API dá direct URL)
# ---------------------------

_HELLSPY_API_BASE = "https://api.hellspy.to"
_HELLSPY_SEARCH_ENDPOINT = _HELLSPY_API_BASE + "/gw/search"
_HELLSPY_SITE_BASE = "https://www.hellspy.to/"
_HELLSPY_LIMIT = 64

def _hellspy_build_search_url(query: str, offset: int, limit: int) -> str:
    return _HELLSPY_SEARCH_ENDPOINT + "?" + urllib.parse.urlencode({
        "query": query,
        "offset": str(offset),
        "limit": str(limit),
    })

def _hellspy_extract_items_and_next(payload: dict):
    if not isinstance(payload, dict):
        return [], None
    items = payload.get("items")
    if not isinstance(items, list):
        items = []
    nxt = payload.get("nextOffset")
    try:
        nxt = int(nxt) if nxt is not None else None
    except Exception:
        nxt = None
    return items, nxt

def _hellspy_pick_direct_url(item: dict) -> str:
    """
    BEZPEČNÉ: jen pokud API už v odpovědi vrací přímé URL (mp4/m3u8).
    Neparsuje HTML stránky ani player.
    """
    if not isinstance(item, dict):
        return ""

    candidates = []

    # přímé klíče
    for key in (
        "stream", "streamUrl", "hls", "hlsUrl", "mp4", "mp4Url",
        "url", "file", "fileUrl", "download", "downloadUrl"
    ):
        v = item.get(key)
        if isinstance(v, str) and v.strip():
            candidates.append(v.strip())

    # vnořené struktury
    media = item.get("media")
    if isinstance(media, dict):
        for key in ("url", "hls", "hlsUrl", "mp4", "mp4Url"):
            v = media.get(key)
            if isinstance(v, str) and v.strip():
                candidates.append(v.strip())

    streams = item.get("streams")
    if isinstance(streams, dict):
        for key in ("hls", "mp4", "url"):
            v = streams.get(key)
            if isinstance(v, str) and v.strip():
                candidates.append(v.strip())
        # někdy je to list
    if isinstance(streams, list):
        for s in streams:
            if isinstance(s, dict):
                v = s.get("url") or s.get("src") or s.get("file")
                if isinstance(v, str) and v.strip():
                    candidates.append(v.strip())

    # vyber první, co vypadá jako přímé video
    for u in candidates:
        if _is_direct_media_url(u):
            return u

    return ""

def _hellspy_get_stream(video_id: str, video_hash: str) -> str:
    if not video_id or not video_hash:
        return ""

    try:
        response = requests.get(
            f"{_HELLSPY_API_BASE}/gw/video/{video_id}/{video_hash}/download",
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/122.0.0.0 Safari/537.36"
                ),
                "Accept": "*/*",
                "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
                "Accept-Encoding": "identity",
                "Connection": "close",
                "Referer": "https://www.hellspy.to/",
                "Origin": "https://www.hellspy.to",
            },
            allow_redirects=False,
            timeout=25
        )

        if response.status_code in (301, 302, 303, 307, 308):
            return (response.headers.get("Location") or "").strip()

        return ""
    except Exception:
        return ""

def hellspy_search_all(query: str, limit: int = _HELLSPY_LIMIT, max_pages: int = 50, sleep_s: float = 0.0):
    seen = set()
    out = []

    offset = 0
    next_offset = None

    for _page in range(1, max_pages + 1):
        use_offset = next_offset if next_offset is not None else offset
        url = _hellspy_build_search_url(query, use_offset, limit)

        payload = _http_get_json(url)
        items, nxt = _hellspy_extract_items_and_next(payload)

        if not items:
            break

        added = 0
        for it in items:
            title = (it.get("title") or "").strip()
            vid = it.get("id")
            hsh = it.get("fileHash") or it.get("hash")
            if not (title and vid and hsh):
                continue

            item_url = f"{_HELLSPY_SITE_BASE}video/{hsh}/{vid}"
            if item_url in seen:
                continue
            seen.add(item_url)

            # direct ber jen pokud už ho search API samo vrátí
            direct = _hellspy_pick_direct_url(it)

            out.append({
                "title": re.sub(r"\s+", " ", title),
                "url": item_url,
                "direct": direct,
                "id": str(vid),
                "fileHash": str(hsh),
            })
            added += 1

        if added == 0:
            break

        if nxt is not None and nxt != use_offset:
            next_offset = nxt
        else:
            offset = use_offset + limit
            next_offset = None

        if sleep_s > 0:
            time.sleep(sleep_s)

    return out

def hellspy_search_ui():
    q = xbmcgui.Dialog().input("Hellspy – zadej hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return

    results = hellspy_search_all(q.strip(), limit=_HELLSPY_LIMIT, max_pages=20, sleep_s=0.0)

    xbmcplugin.setContent(addon_handle, "files")

    if not results:
        xbmcgui.Dialog().ok("Hellspy", "Nic nenalezeno.")
        main_menu()
        return

    for it in results:
        title = it.get("title") or "Bez názvu"
        url = it.get("url") or ""
        direct = it.get("direct") or ""

        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")

        u = build_url({
            "action": "other.hellspy_item",
            "title": title,
            "url": url,
            "direct": direct,
            "id": it.get("id") or "",
            "fileHash": it.get("fileHash") or "",
        })
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


# ---------------------------
# SKTONLINE (vyhledání + zobrazení) - bez requests/bs4 (Kodi-friendly)
# ---------------------------

_SKTONLINE_BASE = "https://online.sktorrent.eu/"

def _sktonline_abs(url: str, base: str) -> str:
    return urllib.parse.urljoin(base, url)

def _sktonline_parse_forms(html_text: str):
    forms = []
    for m in re.finditer(r"<form\b([^>]*)>([\s\S]*?)</form>", html_text, re.IGNORECASE):
        attrs = m.group(1) or ""
        inner = m.group(2) or ""
        forms.append({"attrs": attrs, "inner": inner})
    return forms

def _sktonline_attr(attrs: str, name: str) -> str:
    m = re.search(r'\b' + re.escape(name) + r'\s*=\s*"([^"]*)"', attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*'([^']*)'", attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*([^\s>]+)", attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    return ""

def _sktonline_find_search_form(home_html: str):
    best = None

    for f in _sktonline_parse_forms(home_html):
        attrs = f["attrs"]
        inner = f["inner"]

        method = (_sktonline_attr(attrs, "method") or "GET").upper()
        action = _sktonline_attr(attrs, "action") or _SKTONLINE_BASE
        action_url = _sktonline_abs(action, _SKTONLINE_BASE)

        inputs = []
        for im in re.finditer(r"<input\b([^>]*)>", inner, re.IGNORECASE):
            iattrs = im.group(1) or ""
            itype = (_sktonline_attr(iattrs, "type") or "").lower()
            name = _sktonline_attr(iattrs, "name") or ""
            ph = (_sktonline_attr(iattrs, "placeholder") or "").lower()
            val = _sktonline_attr(iattrs, "value") or ""
            inputs.append({"type": itype, "name": name, "ph": ph, "value": val, "attrs": iattrs})

        cand_inputs = [i for i in inputs if i["type"] in ("search", "text")]
        if not cand_inputs:
            continue

        def score_input(i):
            nm = (i["name"] or "").lower()
            it = (i["type"] or "").lower()
            sc = 0
            if it in ("search", "text"):
                sc += 2
            if any(k in nm for k in ["q", "query", "search", "s"]):
                sc += 3
            if "search" in (i["ph"] or "") or "vyhled" in (i["ph"] or ""):
                sc += 1
            return sc

        inp = max(cand_inputs, key=score_input)
        sc = score_input(inp)

        act_low = (action_url or "").lower()
        if "search" in act_low or "vyhled" in act_low:
            sc += 2

        extra = {}
        for i in inputs:
            if (i["type"] or "").lower() == "hidden":
                hn = i["name"]
                if hn:
                    extra[hn] = i.get("value", "")

        input_name = inp["name"] or "q"

        if best is None or sc > best[0]:
            best = (sc, method, action_url, input_name, extra)

    if not best:
        return None

    return best[1], best[2], best[3], best[4]

def _sktonline_extract_results(results_html: str, base_url: str):
    def _strip_tags(s: str) -> str:
        s = re.sub(r"<[^>]+>", " ", s or "")
        s = html.unescape(s)
        s = re.sub(r"\s+", " ", s).strip()
        return s

    links = []

    for m in re.finditer(r'<a\b([^>]*?)href=["\']([^"\']+)["\']([^>]*)>([\s\S]*?)</a>',
                         results_html, re.IGNORECASE):
        pre = m.group(1) or ""
        href = (m.group(2) or "").strip()
        post = m.group(3) or ""
        inner = m.group(4) or ""

        if not href or href.startswith("#") or href.lower().startswith("javascript:"):
            continue

        full = _sktonline_abs(href, base_url)
        u = urllib.parse.urlparse(full)

        if u.netloc and ("online.sktorrent.eu" not in u.netloc):
            continue

        path = u.path or "/"
        if path == "/":
            continue

        path_low = path.lower()
        if path_low.startswith("/static/") or path_low.startswith("/assets/"):
            continue

        attrs_all = (pre + " " + post)

        mt = re.search(r'title=["\']([^"\']+)["\']', attrs_all, re.IGNORECASE)
        title = html.unescape(mt.group(1)).strip() if mt else ""

        if not title:
            title = _strip_tags(inner)

        parts = [p for p in path.split("/") if p]
        if (not title) or title.strip().lower() in ("video", "nahrat video", "nahrát video"):
            if parts:
                cand = parts[-1]
                if cand.lower() == "video" and len(parts) >= 2:
                    cand = parts[-2]
                title = cand

        title = re.sub(r"\s+", " ", title).strip()

        low = (full + " " + title).lower()
        if any(x in low for x in [
            "login", "register", "signup", "sign-in", "logout",
            "contact", "about", "privacy", "terms",
            "dmca", "faq", "advertise", "webmasters",
        ]):
            continue

        links.append((full, path, title))

    if not links:
        return []

    segs = []
    banned_first_segments = {
        "search", "home", "index", "category", "tag", "genres", "years", "page",
        "static", "assets", "css", "js", "img", "images", "fonts",
    }

    for _, path, _ in links:
        parts = [p for p in path.split("/") if p]
        if len(parts) < 2:
            continue
        seg = parts[0].lower()
        if seg in banned_first_segments:
            continue
        segs.append(seg)

    seg = Counter(segs).most_common(1)[0][0] if segs else None

    results = []
    seen = set()

    for full, path, title in links:
        parts = [p for p in path.split("/") if p]
        if len(parts) < 2:
            continue

        if seg and parts[0].lower() != seg:
            continue

        if parts and parts[0].lower() in {"static", "assets"}:
            continue

        if full in seen:
            continue
        seen.add(full)

        results.append({"title": title, "url": full})

    return results

def _sktonline_find_next_page_url(current_html: str, current_url: str):
    m = re.search(r'<a[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']', current_html, re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1), current_url)

    pag = re.search(r'(<ul[^>]*class="[^"]*pagination[^"]*"[^>]*>[\s\S]*?</ul>)', current_html, re.IGNORECASE)
    if pag:
        ul = pag.group(1)
        mact = re.search(r'<li[^>]*class="[^"]*\bactive\b[^"]*"[^>]*>[\s\S]*?</li>\s*<li[^>]*>[\s\S]*?<a[^>]+href=["\']([^"\']+)["\']', ul, re.IGNORECASE)
        if mact:
            return _sktonline_abs(mact.group(1), current_url)

        mnext = re.search(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>\s*(?:»|&raquo;|next|další|dalsi|>)\s*</a>', ul, re.IGNORECASE)
        if mnext:
            return _sktonline_abs(mnext.group(1), current_url)

    return None

def sktonline_search_all_pages(query: str, max_pages: int = 50):
    home_html = _http_get(_SKTONLINE_BASE)
    form_info = _sktonline_find_search_form(home_html)

    if not form_info:
        method = "GET"
        action_url = _SKTONLINE_BASE
        input_name = "s"
        extra = {}
    else:
        method, action_url, input_name, extra = form_info

    data = dict(extra or {})
    data[input_name] = query

    if method == "POST":
        cur_url = action_url
        cur_html = _http_post(action_url, data=data)
    else:
        qs = urllib.parse.urlencode(data)
        sep = "&" if ("?" in action_url) else "?"
        cur_url = action_url + sep + qs
        cur_html = _http_get(cur_url)

    out = []
    seen_items = set()
    seen_pages = set()
    seen_pages.add(cur_url)

    for _page in range(1, max_pages + 1):
        results = _sktonline_extract_results(cur_html, cur_url)
        for r in results:
            u = r.get("url") or ""
            if not u or u in seen_items:
                continue
            seen_items.add(u)
            out.append(r)

        next_url = _sktonline_find_next_page_url(cur_html, cur_url)
        if not next_url:
            break

        if next_url in seen_pages:
            break
        seen_pages.add(next_url)
        cur_url = next_url
        cur_html = _http_get(cur_url)

    return out

def sktonline_search_ui():
    q = xbmcgui.Dialog().input("SkTonLine – zadej hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return

    results = sktonline_search_all_pages(q.strip(), max_pages=60)

    xbmcplugin.setContent(addon_handle, "files")

    if not results:
        xbmcgui.Dialog().ok("SkTonLine", "Nic nenalezeno.")
        main_menu()
        return

    for it in results:
        title = it.get("title") or "Bez názvu"
        url = it.get("url") or ""

        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")

        u = build_url({"action": "other.sktonline_item", "title": title, "url": url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


# ---------------------------
# SKTONLINE – resolver přímých streamů (detail/embed/script/download)
# ---------------------------

import xbmcvfs

def _dump_text_to_temp(filename: str, text: str):
    try:
        path = xbmcvfs.translatePath("special://temp/" + filename)
        f = xbmcvfs.File(path, "w")
        f.write(text or "")
        f.close()
        xbmc.log(f"[IKARUS][SKT] dumped: {path}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[IKARUS][SKT] dump failed: {e}", xbmc.LOGERROR)

def _sktonline_abs(url: str, base: str) -> str:
    return urllib.parse.urljoin(base, url)

def _sktonline_parse_tag_attr(tag_attrs: str, name: str) -> str:
    m = re.search(r'\b' + re.escape(name) + r'\s*=\s*"([^"]*)"', tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*'([^']*)'", tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*([^\s>]+)", tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    return ""

def _sktonline_guess_label_from_url(u: str) -> str:
    ul = (u or "").lower()
    m = re.search(r'(\d{3,4})p', ul)
    if m:
        return m.group(1) + "p"
    if ".m3u8" in ul:
        return "HLS"
    if ".mp4" in ul:
        return "MP4"
    return "Zdroj"

def _sktonline_find_embed_url_anywhere(detail_html: str, base_url: str):
    if not detail_html:
        return None

    txt = html.unescape(detail_html)

    m = re.search(r'<iframe\b[^>]*\bsrc\s*=\s*["\']([^"\']*?/embed/[^"\']+)["\']', txt, re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1).strip(), base_url)

    m = re.search(r'(https?://online\.sktorrent\.eu/embed/[a-zA-Z0-9]+)', txt, re.IGNORECASE)
    if m:
        return m.group(1).strip()

    m = re.search(r'(/embed/[a-zA-Z0-9]+)', txt, re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1).strip(), base_url)

    return None

def _sktonline_extract_video_sources(detail_html: str, page_url: str):
    if not detail_html:
        return []

    mv = re.search(r'(<video\b[^>]*>)([\s\S]*?)</video>', detail_html, re.IGNORECASE)
    if not mv:
        return []

    video_open = mv.group(1) or ""
    inner = mv.group(2) or ""
    out = []
    seen = set()

    for sm in re.finditer(r'<source\b([^>]*?)>', inner, re.IGNORECASE):
        attrs = sm.group(1) or ""
        src = _sktonline_parse_tag_attr(attrs, "src")
        if not src:
            continue
        src = html.unescape(src).strip()
        if not src:
            continue
        full = _sktonline_abs(src, page_url)
        if full in seen:
            continue
        seen.add(full)
        label = _sktonline_parse_tag_attr(attrs, "label") or _sktonline_parse_tag_attr(attrs, "res") or _sktonline_parse_tag_attr(attrs, "data-res")
        label = html.unescape(label).strip() if label else _sktonline_guess_label_from_url(full)
        out.append({"label": label, "src": full})

    if not out:
        vsrc = _sktonline_parse_tag_attr(video_open, "src") or _sktonline_parse_tag_attr(video_open, "data-src")
        if vsrc:
            full = _sktonline_abs(html.unescape(vsrc).strip(), page_url)
            out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    return out

def _sktonline_extract_sources_from_scripts(detail_html: str, base_url: str):
    if not detail_html:
        return []
    txt2 = html.unescape(detail_html)

    out = []
    seen = set()

    for m in re.finditer(r'(?:(?:"|\')?(?:file|src)(?:"|\')?\s*:\s*(?:"|\')([^"\']+?)(?:"|\'))', txt2, re.IGNORECASE):
        u = (m.group(1) or "").strip()
        if not u:
            continue
        ul = u.lower()
        if (".mp4" not in ul) and (".m3u8" not in ul) and ("m3u8" not in ul) and ("mp4" not in ul) and ("/hls" not in ul) and ("/stream" not in ul):
            continue
        full = _sktonline_abs(u, base_url)
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    for m in re.finditer(r'(https?://[^"\'\s<>]+?\.(?:m3u8|mp4)(?:\?[^"\'\s<>]+)?)', txt2, re.IGNORECASE):
        u = (m.group(1) or "").strip()
        if not u:
            continue
        if u in seen:
            continue
        seen.add(u)
        out.append({"label": _sktonline_guess_label_from_url(u), "src": u})

    for m in re.finditer(r'(["\'])(/[^"\']+?\.(?:m3u8|mp4)(?:\?[^"\']+)?)\1', txt2, re.IGNORECASE):
        u = (m.group(2) or "").strip()
        if not u:
            continue
        full = _sktonline_abs(u, base_url)
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    return out

def _sktonline_extract_download_links(html_text: str, base_url: str):
    out = []
    seen = set()
    if not html_text:
        return out

    txt2 = html.unescape(html_text)

    for m in re.finditer(r'<a\b([^>]*?)href=["\']([^"\']+)["\']([^>]*)>', txt2, re.IGNORECASE):
        pre = m.group(1) or ""
        href = (m.group(2) or "").strip()
        post = m.group(3) or ""
        if not href:
            continue
        low = href.lower()
        if not any(k in low for k in ("download", "/download/", "/get/", "/file/", "/dl/")):
            continue
        full = _sktonline_abs(href, base_url)
        if full in seen:
            continue
        seen.add(full)
        attrs = (pre + " " + post)
        mt = re.search(r'title=["\']([^"\']+)["\']', attrs, re.IGNORECASE)
        label = html.unescape(mt.group(1)).strip() if mt else _sktonline_guess_label_from_url(full)
        out.append({"label": label, "url": full})

    for m in re.finditer(r'(https?://[^"\'\s<>]+/(?:download|get|file|dl)/[^"\'\s<>]+)', txt2, re.IGNORECASE):
        full = html.unescape(m.group(1)).strip()
        if not full:
            continue
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "url": full})

    return out

def _http_follow_to_final_url(url: str, referer: str = None, timeout: int = 25) -> str:
    url = _sanitize_url(url)
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Accept": "*/*",
        "Accept-Language": "cs-CZ,cs;q=0.9,en;q=0.8",
        "Accept-Encoding": "identity",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer

    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with _OPENER.open(req, timeout=timeout) as resp:
            return resp.geturl() or url
    except Exception:
        return url

def _sktonline_merge_sources(*lists):
    out = []
    seen = set()
    for lst in lists:
        for s in (lst or []):
            u = (s.get("src") or "").strip()
            if not u:
                continue
            if u in seen:
                continue
            seen.add(u)
            lab = (s.get("label") or "").strip() or _sktonline_guess_label_from_url(u)
            out.append({"label": lab, "src": u})

    def _rank(label):
        m = re.search(r'(\d{3,4})p', (label or "").lower())
        if m:
            try:
                return -int(m.group(1))
            except Exception:
                pass
        if "hls" in (label or "").lower():
            return -1
        return 0

    out.sort(key=lambda x: _rank(x.get("label", "")))
    return out

def _cookie_header_for_url(url: str) -> str:
    try:
        u = urllib.parse.urlsplit(url)
        host = (u.hostname or "").lower()
        path = u.path or "/"

        def reg_domain(h: str) -> str:
            parts = [p for p in h.split(".") if p]
            return ".".join(parts[-2:]) if len(parts) >= 2 else h

        host_rd = reg_domain(host)

        cookies = []
        for c in _COOKIEJAR:
            dom = (c.domain or "").lstrip(".").lower()
            if not dom:
                continue

            dom_rd = reg_domain(dom)
            ok_domain = (host == dom) or host.endswith("." + dom)

            if not ok_domain and dom_rd and host_rd and (dom_rd == host_rd):
                ok_domain = True

            if not ok_domain:
                continue

            cpath = c.path or "/"
            if path.startswith(cpath):
                cookies.append(f"{c.name}={c.value}")

        return "; ".join(cookies)
    except Exception:
        return ""

def _probe_stream(url: str, headers: dict, timeout: int = 15):
    try:
        u = _sanitize_url(url)
        req_headers = dict(headers or {})
        req_headers.setdefault("Accept", "*/*")
        req_headers.setdefault("Range", "bytes=0-")

        req = urllib.request.Request(u, headers=req_headers, method="GET")
        with _OPENER.open(req, timeout=timeout) as resp:
            ct = resp.headers.get("Content-Type", "")
            code = getattr(resp, "status", None)
            final = resp.geturl()
            xbmc.log(f"[IKARUS][SKT][PROBE] code={code} ct={ct} final={final}", xbmc.LOGWARNING)
            resp.read(256)
    except Exception as e:
        xbmc.log(f"[IKARUS][SKT][PROBE] FAILED: {repr(e)}", xbmc.LOGERROR)

def sktonline_try_resolve_and_play(title: str, page_url: str) -> bool:
    detail_html = ""
    embed_html = ""
    embed_url = ""

    try:
        detail_html = _http_get(page_url, referer=_SKTONLINE_BASE)
    except Exception as e:
        _dump_text_to_temp("skt_detail.html", detail_html)
        _dump_text_to_temp("skt_embed.html", embed_html)
        _dump_text_to_temp("skt_debug.txt", f"page_url={page_url}\nembed_url={embed_url}\nerror={repr(e)}\n")
        return False

    embed_url = _sktonline_find_embed_url_anywhere(detail_html, page_url)
    embed_html = ""
    if embed_url:
        try:
            embed_html = _http_get(embed_url, referer=page_url)
        except Exception as e:
            embed_html = ""
            _dump_text_to_temp("skt_debug.txt", f"page_url={page_url}\nembed_url={embed_url}\nembed_error={repr(e)}\n")

    sources_detail = _sktonline_extract_video_sources(detail_html, page_url)
    sources_embed = _sktonline_extract_video_sources(embed_html, embed_url) if embed_html and embed_url else []

    sources_script_detail = _sktonline_extract_sources_from_scripts(detail_html, page_url)
    sources_script_embed = _sktonline_extract_sources_from_scripts(embed_html, embed_url) if embed_html and embed_url else []

    sources = _sktonline_merge_sources(sources_detail, sources_embed, sources_script_detail, sources_script_embed)

    if not sources:
        dl = []
        dl += _sktonline_extract_download_links(detail_html, page_url)
        if embed_html and embed_url:
            dl += _sktonline_extract_download_links(embed_html, embed_url)

        for it in dl:
            durl = it.get("url")
            if not durl:
                continue
            final = _http_follow_to_final_url(durl, referer=embed_url or page_url)
            if final and _is_direct_media_url(final):
                sources.append({"label": it.get("label") or _sktonline_guess_label_from_url(final), "src": final})

    if not sources:
        return False

    labels = [(s.get("label") or "Zdroj").strip() for s in sources]

    ref = _sanitize_url(page_url)

    base_headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Referer": ref,
        "Origin": "https://online.sktorrent.eu",
        "Accept": "*/*",
    }

    if len(sources) == 1:
        src1 = (sources[0].get("src") or "").strip()
        headers = dict(base_headers)

        ck = _cookie_header_for_url(src1)
        if ck:
            headers["Cookie"] = ck

        xbmc.log(f"[IKARUS][SKT] PLAY: {src1}", xbmc.LOGWARNING)
        xbmc.log(f"[IKARUS][SKT] HDR: {headers}", xbmc.LOGWARNING)
        _probe_stream(src1, headers)
        play_url(title, src1, headers=headers)
        return True

    idx = xbmcgui.Dialog().select("Vyber kvalitu", labels)
    if idx is None or idx < 0:
        return True

    picked = sources[idx]
    stream_url = (picked.get("src") or "").strip()
    if not stream_url:
        return False

    headers = dict(base_headers)
    ck = _cookie_header_for_url(stream_url)
    if ck:
        headers["Cookie"] = ck

    picked_label = (picked.get("label") or "").strip()
    play_title = f"{title} ({picked_label})" if picked_label else title

    xbmc.log(f"[IKARUS][SKT] PLAY: {stream_url}", xbmc.LOGWARNING)
    xbmc.log(f"[IKARUS][SKT] HDR: {headers}", xbmc.LOGWARNING)
    _probe_stream(stream_url, headers)
    play_url(play_title, stream_url, headers=headers)
    return True


# ---------------------------
# ROUTER
# ---------------------------

def router():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(paramstring)) if paramstring else {}
    action = params.get("action") or ""

    if not action or action == "other_sources":
        main_menu()
        return

    # Přehraj.to
    if action == "other.prehrajto":
        prehrajto_search_ui()
        return

    if action == "other.prehrajto_item":
        title = params.get("title") or "Přehraj.to"
        url = params.get("url") or ""

        if _is_direct_media_url(url):
            play_url(title, url)
            return

        ok = prehrajto_try_resolve_and_play(title, url)
        if ok:
            return

        xbmcgui.Dialog().ok(
            "Přehraj.to",
            "Nepodařilo se získat přímý odkaz ze stránky (FREE cesta).\n"
            "Na stránce se nepodařilo najít 'var sources' s položkou 'file/src'.\n\n"
            f"URL:\n{url}"
        )
        return

    # Hellspy
    if action == "other.hellspy":
        hellspy_search_ui()
        return

    if action == "other.hellspy_item":
        title = params.get("title") or "Hellspy"
        url = params.get("url") or ""
        direct = params.get("direct") or ""

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            ),
            "Referer": "https://www.hellspy.to/",
            "Origin": "https://www.hellspy.to",
            "Accept": "*/*",
        }

        # 1) když už direct máme, rovnou přehrát
        if direct:
            ck = _cookie_header_for_url_basic(direct)
            if ck:
                headers["Cookie"] = ck

            play_url(title, direct, headers=headers)
            return

        # 2) fallback: když by url samo bylo přehratelné
        if url and _is_direct_media_url(url):
            ck = _cookie_header_for_url_basic(url)
            if ck:
                headers["Cookie"] = ck

            play_url(title, url, headers=headers)
            return

        # 3) stejně jako v main.py: až po kliknutí vezmeme id + hash a získáme stream
        video_id = params.get("id") or ""
        video_hash = params.get("fileHash") or ""

        if video_id and video_hash:
            direct = _hellspy_get_stream(video_id, video_hash)
            if direct:
                ck = _cookie_header_for_url_basic(direct)
                if ck:
                    headers["Cookie"] = ck

                play_url(title, direct, headers=headers)
                return

        xbmcgui.Dialog().ok(
            "Hellspy",
            "Přehrávání není možné, protože se nepodařilo získat stream URL.\n\n"
            f"Stránka:\n{url}"
        )
        return

    # SkTonLine
    if action == "other.sktonline":
        sktonline_search_ui()
        return

    if action == "other.sktonline_item":
        title = params.get("title") or "SkTonLine"
        url = params.get("url") or ""

        if _is_direct_media_url(url):
            play_url(title, url)
            return

        ok = sktonline_try_resolve_and_play(title, url)
        if ok:
            return

        xbmcgui.Dialog().ok(
            "SkTonLine",
            "Nepodařilo se získat přímé zdroje z detailu / embedu."
            "Nenašel jsem <video>/<source>, přímé odkazy ve <script>, ani funkční download redirect."
            f"URL:\n{url}"
        )
        return

    # fallback
    main_menu()

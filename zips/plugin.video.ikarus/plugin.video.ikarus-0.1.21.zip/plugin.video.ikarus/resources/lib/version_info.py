# -*- coding: utf-8 -*-
import os
import xml.etree.ElementTree as ET

import xbmcaddon
import xbmcgui


ADDON_ID = "plugin.video.ikarus"


CHANGELOG_FALLBACK = """[B]0.1.21[/B] - oprava stavu zhlednuto a odolnejsi synchronizace Trakt.TV
- Opraveno nacitani kompletni historie Trakt.TV vcetne vsech stranek, opakovanych pokusu a kontroly neuplne odpovedi.
- Bezna menu serialu, sezon a epizod ted spojuji lokalni stav se stavem z Trakt.TV, takze se spravne zobrazi i drive zhlednute dily.
- Lokalni prubeh prehravani je oddeleny od posledniho platneho Trakt snapshotu a podezrele zkracena synchronizace uz neprepise dobra data.
- Zmeny prubehu, oznaceni zhlednuto i odebrani stavu maji trvalou frontu s opakovanim, takze se po docasnem vypadku Trakt.TV odeslou pozdeji.
- Ukladani stavu prehravani, fronty stahovani, vlastnich seznamu, prefetch fronty a verejnych oblibenych pouziva atomicky zapis, zalohu a ochranu proti soubehu.
- Stahovane soubory se nejprve dokonci do docasneho souboru a puvodni cil se pri chybe zachova.
- Prime odkazy, tokeny a citlive HTTP hlavicky se neukladaji do stavu prehravani a v diagnostickych lozich se skryvaji.
- Rozsirena diagnostika a automaticke testy synchronizace, front, uloziste, stahovani a zobrazeni stavu epizod.

----------------------------------------

[B]0.1.20[/B] - oprava automatickeho prehravani dalsiho dilu serialu
- Opraveno rozliseni prirozeneho konce epizody, rucniho zastaveni a chyby prehravace, aby se dalsi dil spoustel jen ve spravny okamzik.
- Po timeoutu TMDB nebo provideru se hledani znovu opakuje a prazdny chybovy vysledek uz neblokuje dalsi pokus v cache.
- Nahradni zdroje si pamatuji predchozi pokusy, neopakuji se v kruhu a maji bezpecny limit osmi zdroju.
- Prodlouzeno cekani na rozbeh streamu, prefetch se spousti pozdeji a dalsi epizoda uz nevrstvi sledovaci funkce predchozich dilu.
- SkTonLine pri automatickem pokracovani vybere nejlepsi kvalitu bez dialogu a Hellspy si pred prehranim vyzada cerstvy odkaz.
- Automaticke pokracovani preskakuje dosud neodvysilane epizody a ma volitelnou diagnostiku v nastaveni pluginu.

----------------------------------------

[B]0.1.19[/B] - velky uklid kodu, lokalizace a stabilnejsi prehravani
- Dokoncena velka revize lokalizace: bezne staticke texty v menu, dialozich, nastaveni, zdrojich, TMDB/Trakt seznamech a auto-next hlaskach jsou presunute do strings.po pro cs_cz i en_gb.
- Doplneny a sjednoceny preklady pro detaily zdroju, skupiny zdroju, profese u osob, fallbacky typu Zdroj/Seznam/Jazyk/Bez nazvu a chybove hlasky provideru.
- Pokracoval uklid nejvetsich modulu a opakovanych helperu: spolecne zpracovani zdroju, metadat, velikosti, kvality, jazyku a resolveru je sjednocovane do sdilenych pomocnych funkci.
- Zrychleno a zodolneno rucni hledani a prehravani u Prehraj.to, Hellspy, SkTonLine a WebShare; nefunkcni zdroje se lepe zachytavaji, loguji a ukoncuji.
- Vylepseno chovani po prehrani rucne nalezeneho zdroje, aby se seznam vysledku zbytecne neztracel a neotviral znovu dialog noveho hledani.
- Zrychleno vykreslovani verejnych Trakt.TV seznamu: stav zhlednuto/rozkoukano se pro stranku nacita jednou a zbytecne se nekopiruje pro kazdy radek.
- Opraveno dotahovani ceskych nazvu ve Zhlednute/Rozkoukane uz pri vykresleni seznamu, vcetne ulozeni informace, ze nazev je overeny z TMDB detailu.
- Zpresnen vyber lokalizovanych nazvu z TMDB, aby ceske alternativni nazvy mely prednost pred cizimi preklady typu Traques/Lov.
- Opravena volba pro automaticke prehrani pouze CZ/SK zdroje u dalsi epizody serialu a doplnen fallback na dalsi zdroj, kdyz prvni zdroj selze.
- Rezim vyberoveho dialogu pro dalsi epizodu ma novou zalozni synchronni pripravu, kdyz prefetch nestihne dobehnout, a tlacitka dialogu jsou lokalizovana pres strings.po.
- Provedena kompletni diagnostika Pythonu, XML, lokalizace, duplicitnich definic, mrtveho kodu, importu a ZIP balicku pred vydanim.

----------------------------------------

[B]0.1.18[/B] - Trakt seznamy a stabilnejsi synchronizace
- Po uspesnem prihlaseni k Trakt.TV se na pozadi rovnou synchronizuji zhlednute, rozkoukane i vsechny vlastni seznamy vcetne polozek.
- Vlastni seznamy synchronizovane z Trakt.TV si pri ulozeni doplnuji nazvy, rok, obrazky a hodnoceni z TMDB, aby se na dalsich zarizenich netlacily anglicke nazvy.
- Z menu Moje seznamy byla odstranena rucni synchronizace s Trakt.TV, protoze synchronizace probiha automaticky po prihlaseni a v servisni kontrole.
- Opraveno nacitani obsahu verejnych Trakt.TV seznamu, ktere mohlo koncit hlaskou o chybejicim parametru username.
- Opraveno hledani Prehraj.to ve spolecnem hledani zdroju, aby pouzivalo stejne varianty dotazu jako rucni hledani.
- Pri automatickem pokracovani serialu se do prehravace znovu predava kompletni nazev epizody vcetne SxxEyy a nazvu dilu.

----------------------------------------

[B]0.1.17[/B] - vylepsene rucni hledani a nahledy zdroju
- Rucni hledani si lepe pamatuje posledni vysledky a po prehrani se nevraci zbytecne na dialog noveho hledani.
- Prehraj.to umi prihlaseni pro dostupnejsi vysledky a zastavi nacitani pri duplicitnich strankach, aby se zbytecne nezdrzovalo.
- Prehraj.to vysledky maji doplnenou velikost souboru a nahled z prvniho obrazku videa.
- Hellspy vysledky maji doplneny nahled z API a velikost se zobrazuje i v popisu polozky.
- SkTonLine vysledky maji doplneny nahled z vysledkove karty a lepsi popis delky videa.
- WebShare rucni hledani zobrazuje prehlednejsi informace z file_info vcetne nazvu, jazyku, titulku, kvality, velikosti a nahledu.
- Sjednoceno zobrazovani tagu jazyka, kvality, velikosti a delky u manualnich provideru.
- Zrychleno a zodolneno nacitani Prehraj.to, Hellspy, SkTonLine a WebShare tak, aby nefunkcni zdroje rychleji koncily a lepe se logovaly.

----------------------------------------

[B]0.1.16[/B] - rychlejsi seznamy, hledani zdroju a stabilnejsi prehravani
- Zrychleno nacitani vlastnich seznamu, chytrych seznamu, rozkoukanych a zhlednutych polozek.
- Opraveno listovani ve vlastnich seznamech, aby navrat a prechod mezi strankami fungoval spravneji.
- Opraveno zobrazovani obrazku a popisu u polozek v chytrych seznamech.
- Zrychleno hledani zdroju ve filmech, serialech a rucnim hledani.
- Opraveno prehravani WebShare zdroju po upravach spolecneho prehravace.
- Lepe se oznacuji prehrane zdroje: lokalne prehrany konkretni zdroj se oznaci presneji, Trakt.TV stav zustava jen u nazvu filmu nebo serialu.
- Rucni hledani Prehraj.to, Hellspy, SkTonLine a WebShare ma spolecnejsi a odolnejsi zpracovani zdroju.
- Mrtve nebo nedostupne Hellspy streamy se zachyti driv a zapisi jasneji do logu.
- Do nastaveni byla pridana diagnostika Ikarusu pro rychlejsi kontrolu prihlaseni, Trakt.TV, seznamu, cache a fronty stahovani.
- Docasna cache nalezenych zdroju se cisti automaticky pri startu Kodi, ne pri kazdem otevreni menu.
- Doplneno podrobnejsi logovani zacatku, konce a trvani dulezitych akci, aby se lepe hledalo pripadne zaseknuti Kodi.
- Pridany dalsi ochrany proti chybejicim nebo spatnym parametrum u prehravani zdroju.

----------------------------------------
[B]0.1.15[/B] - dalsi zpřesnění seriálových názvů a epizod
- Zpřesněno hledání providerů Přehraj.to, Hellspy a WebShare pro seriály s nestandardně uloženými názvy epizod.
- Přidána podpora tolerantnější shody názvů epizod podle prefixu a významových tokenů u seriálů jako Životy slavných.
- Opraveno párování seriálu Sex O’Clock i v názvech typu S## O’Clock a S. O'Clock.
- U první série se nově rozpozná i zápis epizody ve stylu 10.díl nebo 10.diel.

----------------------------------------

[B]0.1.14[/B] - revize pokracovani serialu a zpresneni serialovych shod
- Udelana vetsi revize pokracovani na dalsi epizodu v TMDB prehravani.
- Auto-next zacina hledat dalsi epizodu driv i u kratsich dilu a ma zalozni synchronni pripravu na konci prehravani.
- Sjednocena kontrola, kdy je dalsi epizoda opravdu pripravena pro automaticke spusteni.
- Pro podporovane providery se dalsi epizoda pri auto-next snazi rozresolveovat a spoustet primo, aby byla mensi prodleva mezi dily a mene navrstvenych plugin behu.
- Zpresnena serialova filtrace na WebShare, aby kombinace spravneho cisla epizody a nazvu epizody zustala v hlavnich vysledcich.
- Slabe shody pouze podle nazvu epizody bez cisla se znovu odkladaji do posledni slozky mozne shody.

----------------------------------------

[B]0.1.13[/B] - dalsi ladeni zdroju a zrychleni hledani
- Rozkoukane a zhlednute seznamy uz berou nazvy prioritne z TMDB misto michani nazvu z Trakt.TV.
- Opraveno pokracovani na dalsi epizodu tak, aby se po rucnim zastaveni prehravani nespoustel dalsi dil.
- Zpresnen filtr serialovych zdroju na WebShare, aby se lepe oddelily spravne shody od cizich serialu a slabych shod podle samotneho nazvu epizody.
- Opraveno rozpoznavani serialu jako Akolytka / The Acolyte pro Hellspy, Prehraj.to a SkTOnline.
- Zrychleno hledani zdroju u provideru Prehraj.to, Hellspy, SkTOnline a WebShare bez omezeni poctu nalezenych zdroju.
- Zrychleno dotahovani detailu a playback stavu u vysledku, aby se seznam nalezenych zdroju zobrazoval rychleji i pri vetsim poctu polozek.
- Doplnene interni debug a casove logy pro lepsi ladeni hledani zdroju.

----------------------------------------

[B]0.1.12[/B] - sjednoceni zhlednutych a rozkoukanych s Trakt.TV
- Zhlednute a rozkoukane se zobrazuji sjednocene z lokalniho souboru a z Trakt.TV.
- Synchronizace prehravaciho stavu pres GitHub/Gist byla nahrazena lokalnim ulozenim a volitelnym napojenim na Trakt.TV.
- Pridana rucni synchronizace lokalnich zhlednutych a rozkoukanych na Trakt.TV.
- Rucni oznaceni a zruseni oznaceni filmu, epizod, serii a serialu se uklada lokalne i na Trakt.TV.
- Pri prehravani se na Trakt.TV odesila rozkoukany stav a po dokonceni prehravani zhlednuty stav.
- Pri opakovanem zhlednuti filmu nebo epizody se na Trakt.TV prepise datum zhlednuti na aktualni cas.
- Opravena ochrana proti duplicitam a zachovani puvodniho data zhlednuti pri rucni synchronizaci starsich lokalnich zaznamu.
- Opraveno nacitani popularnich filmu v TMDB menu.
- AI oprava nacitani polozek z Databaze TMDB.

----------------------------------------

[B]0.1.11[/B] - opravy hledani zdroju, znaceni a pokracovani serialu
- Zpresneno hledani zdroju pro serialove epizody, aby obecny nazev epizody jako Pilot nespoustel shody s cizimi serialy.
- Pri pokracovani na dalsi epizodu se bere prvni nejlepsi zdroj ze seznamu a pri mrtvem zdroji plugin automaticky zkusi dalsi zdroj v poradi.
- U automatickeho pokracovani se mrtve WebShare zdroje preskakuji rychleji a bez zbytecne chybove hlasky pro kazdy spatny zdroj.
- Opravena prubezna aktualizace barev, fajfek a rozkoukaneho stavu po dokonceni filmu nebo epizody.
- Slozky se stejnymi WebShare zdroji prebira stav svych polozek, takze je videt rozkoukany nebo zhlednuty stav uz na slozce.
- Opraveno znaceni stavu pres Kodi overlay/playcount bez vkladani symbolu primo do nazvu polozek.
- Upraveno pojmenovani WebShare zdroju u serialu na tvar Nazev serialu - S01E09 - nazev epizody bez roku.

----------------------------------------

[B]0.1.10[/B] - informativni upozorneni pri startu
- Pri spusteni pluginu se zobrazi informativni upozorneni s povinnym potvrzenim souhlasu.
- Hlavni menu Ikarusu se spusti az po potvrzeni informativniho upozorneni.
- Do nastaveni byla pridana volba Uz nezobrazovat informativni text pri startu.
- V nastaveni je dostupne i rucni zobrazeni celeho informativniho textu.
- Upozorneni ma vlastni interni verzi, takze ho lze pri nektere dalsi aktualizaci znovu vynutit.

----------------------------------------

[B]0.1.9[/B] - vyber audio stopy a titulku
- Do ostatniho nastaveni pridany volby pro primarni audio stopu, sekundarni audio stopu a preferovane titulky.
- Pri spusteni zdroje se plugin nejdrive pokusi prepnout na primarni audio jazyk.
- Pokud primarni audio stopa neni dostupna, plugin zkusi sekundarni audio jazyk.
- Pokud neni dostupna ani primarni ani sekundarni audio stopa, zdroj se ponecha s aktualni audio stopou.
- Titulky se automaticky zapnou jen kdyz se lisi jazykova skupina prehravane audio stopy a preferovanych titulku.
- Pokud prehravane audio patri mezi CZ/SK a preferovane titulky jsou CZ/SK, titulky se nezapnou.
- Pokud je prehravane audio EN a preferovane titulky jsou EN, titulky se nezapnou.
- Pokud zdroj nema primarni ani sekundarni audio stopu a obsahuje jinou audio stopu, plugin se vzdy pokusi zapnout preferovane titulky.
- Pokud preferovane titulky ve zdroji nejsou dostupne, titulky zustanou vypnute.

----------------------------------------

[B]0.1.8[/B] - razeni a pojmenovani WebShare zdroju
- Oprava v nastaveni Info o verzi a kontrola aktualizace pluginu.
- Opraveno razeni nalezenych WebShare zdroju v TMDB knihovne.
- WebShare zdroje se radi podle potvrzeneho audio jazyka: CZ, potom SK, potom EN a nakonec ostatni nebo nezname.
- V ramci stejneho jazyka se radi podle kvality: 4K, 1080p, 720p a nizsi kvality.
- Pri stejne kvalite rozhoduje velikost souboru, vetsi soubor je vyse.
- Interni score shody zustava zachovane pro ladeni a jako pomocne kriterium pri shode ostatnich hodnot.
- Nazev WebShare zdroje se sklada z tagu jazyka, kvality a velikosti, napr. [CZ][1080p][3.2 GB].
- Pokud ma zdroj potvrzene CZ audio, zobrazi se za tagy cesky nazev filmu nebo serialu s rokem misto dlouheho nazvu souboru.
- Pokud informace o souboru nejsou citelne nebo chybi, zobrazi se puvodni nazev souboru.
- Totozne WebShare zdroje se seskupuji do slozky s poctem zdroju.

----------------------------------------

[B]0.1.7[/B] - kontrola aktualizaci z pluginu
- Polozka Zkontrolovat aktualizace Ikarus odstranena z hlavniho menu.
- V nastaveni zustava samostatna leva polozka Zkontrolovat aktualizace.
- Sekce Info o verzi otevre cisty scrollovatelny prehled zmen.
- Akce spousti Kodi kontrolu povolenych repozitaru.

----------------------------------------

[B]0.1.6[/B] - prehled verzi jako obsah nastaveni
- Polozka Info o verzi zustava v levem menu nastaveni.
- Po prepnuti na Info o verzi se prehled zobrazi rovnou v hlavni casti okna.
- Prehled verzi je upraven do beznych radku nastaveni.

----------------------------------------

[B]0.1.5[/B] - info o verzi přímo v nastavení
- Informace o verzi se zobrazí hned po otevření položky Info o verzi.
- Odstraněno extra tlačítko Zobrazit přehled verzí.
- Přehled změn je vidět přímo uprostřed okna nastavení.

----------------------------------------

[B]0.1.4[/B] - úprava okna nastavení
- Opraveno otevření tlačítka Info o verzi z nastavení.
- Položka Info o verzi přesunuta pod Stahování v levém menu nastavení.
- Verze doplněna přímo do nadpisu okna nastavení.

----------------------------------------

[B]0.1.3[/B] - info o verzi v nastavení
- Přidáno tlačítko Info o verzi do nastavení v sekci Stahování.
- Přidán přehled aktuální verze a změn přímo v nastavení pluginu.
- Do nastavení doplněn viditelný řádek s aktuální verzí pluginu.

----------------------------------------

[B]0.1.2[/B] - zobrazení změn v Kodi
- Doplněn přehled změn do metadata položky news.
- Upraveno zobrazení informací pro okno Verze v Kodi.

----------------------------------------

[B]0.1.1[/B] - navazování další epizody
- Upraveno navázání další epizody u seriálů z TMDB.
- V nastavení je nová volba Pokračovat další epizodou: automatické pokračování nebo výběrový dialog.
- Výchozí režim je automatické spuštění další epizody.
- Při potvrzení další epizody dialogem už plugin zbytečně neukončuje aktuální přehrávání hned v 80 procentech.
- Testovací notifikace pro další epizodu jsou ve výchozím stavu vypnuté.

----------------------------------------

[B]0.1.0[/B] - první verze
- První zkušební verze pluginu v Kodi repozitáři.
- TMDB katalog: filmy, seriály, osoby, trendující obsah a vyhledávání.
- Přehled zhlédnutých a rozkoukaných filmů a seriálů.
- Vlastní seznamy, Trakt.TV seznamy a chytré seznamy.
- Hledání zdrojů na Přehraj.to, Hellspy, SkTonLine a WebShare.
- Přehrávání zdrojů z WebShare s podporou účtu a obnovy tokenu.
- Fronta stahování a volitelné ukládání nalezených zdrojů.
- Navazování další epizody u seriálů a volba preferovaného zdroje.
- Synchronizace stavu přehrávání přes GitHub Gist.
- Vlastní seznamy se synchronizují přes Trakt.TV."""


def _translate_path(path):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(path)
    except Exception:
        try:
            import xbmc
            return xbmc.translatePath(path)
        except Exception:
            return path


def _addon_news(addon):
    try:
        addon_path = _translate_path(addon.getAddonInfo("path") or "")
        addon_xml_path = os.path.join(addon_path, "addon.xml")
        root = ET.parse(addon_xml_path).getroot()
        for extension in root.findall("extension"):
            if extension.get("point") != "xbmc.addon.metadata":
                continue
            news = extension.findtext("news") or ""
            if news.strip():
                return news
    except Exception:
        pass

    return CHANGELOG_FALLBACK


def main():
    addon = xbmcaddon.Addon(ADDON_ID)
    version = addon.getAddonInfo("version") or "?"
    xbmcgui.Dialog().textviewer(
        "Ikarus - WebShare - ver {0}".format(version),
        _addon_news(addon),
    )


if __name__ == "__main__":
    main()

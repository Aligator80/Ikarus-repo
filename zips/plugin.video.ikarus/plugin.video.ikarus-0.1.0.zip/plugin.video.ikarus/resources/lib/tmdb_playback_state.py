# -*- coding: utf-8 -*-
import hashlib
import json
import os
import re
import time
from datetime import datetime

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import github_gist_sync


_CACHE_LOCK = None
_STATE_CACHE = None
_STATE_CACHE_TS = 0.0
_STATE_CACHE_TTL = 45.0
try:
    import threading
    _CACHE_LOCK = threading.RLock()
except Exception:
    threading = None


class _DummyLock:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False


if _CACHE_LOCK is None:
    _CACHE_LOCK = _DummyLock()


def _log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log(f"[IKARUS][TMDB PLAYBACK] {msg}", level)
    except Exception:
        pass


def _profile_dir():
    addon = xbmcaddon.Addon()
    base = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    path = os.path.join(base, "tmdb_state")
    try:
        xbmcvfs.mkdirs(path)
    except Exception:
        try:
            os.makedirs(path, exist_ok=True)
        except Exception:
            pass
    return path


def playback_state_path():
    return os.path.join(_profile_dir(), "tmdb_playback_state.json")


def _write_local_state(state):
    cleaned = {}
    for tmdb_id, row in (state or {}).items():
        if not isinstance(row, dict):
            continue
        sources = row.get("sources") or {}
        if not isinstance(sources, dict) or not sources:
            continue
        cleaned[str(tmdb_id)] = row

    fh = xbmcvfs.File(playback_state_path(), "w")
    ok = fh.write(json.dumps(cleaned, ensure_ascii=False, indent=2))
    fh.close()
    if not ok:
        _log("_write_local_state: write failed (disk full or permissions?)", xbmc.LOGWARNING)
    return cleaned


def _cache_get():
    with _CACHE_LOCK:
        if _STATE_CACHE is None:
            return None
        if (time.time() - _STATE_CACHE_TS) > _STATE_CACHE_TTL:
            return None
        try:
            return json.loads(json.dumps(_STATE_CACHE))
        except Exception:
            return dict(_STATE_CACHE)


def _cache_set(data):
    with _CACHE_LOCK:
        global _STATE_CACHE, _STATE_CACHE_TS
        try:
            _STATE_CACHE = json.loads(json.dumps(data if isinstance(data, dict) else {}))
        except Exception:
            _STATE_CACHE = dict(data if isinstance(data, dict) else {})
        _STATE_CACHE_TS = time.time()


def invalidate_cache():
    with _CACHE_LOCK:
        global _STATE_CACHE, _STATE_CACHE_TS
        _STATE_CACHE = None
        _STATE_CACHE_TS = 0.0


def flush_remote_if_due(force: bool = False):
    try:
        if _STATE_CACHE is None:
            return
        if not (github_gist_sync._enabled_playback_state()):
            return
        if not github_gist_sync.is_dirty(github_gist_sync.PLAYBACK_STATE_FILE):
            return
        due = github_gist_sync.get_due_time(github_gist_sync.PLAYBACK_STATE_FILE)
        if not force and due and time.time() < due:
            return
        snapshot = _cache_get()
        if snapshot is None:
            snapshot = {}
        github_gist_sync.sync_playback_state_save(snapshot)
    except Exception as e:
        _log(f"flush due save error: {e}", xbmc.LOGWARNING)


def playback_state_load(force_remote: bool = False):
    if force_remote:
        invalidate_cache()
        try:
            github_gist_sync.invalidate_remote_cache(github_gist_sync.PLAYBACK_STATE_FILE)
        except Exception:
            pass
    flush_remote_if_due(force=False)
    cached = _cache_get()
    if cached is not None:
        return cached

    path = playback_state_path()
    if not xbmcvfs.exists(path):
        data = github_gist_sync.sync_playback_state_load({}, force_remote=force_remote)
        try:
            _write_local_state(data)
        except Exception as e:
            _log(f"persist new load error: {e}", xbmc.LOGWARNING)
        _cache_set(data)
        return data

    try:
        fh = xbmcvfs.File(path)
        raw = fh.read()
        fh.close()
        if not raw:
            data = github_gist_sync.sync_playback_state_load({}, force_remote=force_remote)
            try:
                _write_local_state(data)
            except Exception as e:
                _log(f"persist empty load error: {e}", xbmc.LOGWARNING)
            _cache_set(data)
            return data
        local_data = json.loads(raw)
        local_data = local_data if isinstance(local_data, dict) else {}
        data = github_gist_sync.sync_playback_state_load(local_data, force_remote=force_remote)
        if data != local_data:
            try:
                _write_local_state(data)
            except Exception as e:
                _log(f"persist merged load error: {e}", xbmc.LOGWARNING)
        _cache_set(data)
        return data
    except Exception as e:
        _log(f"load error: {e}", xbmc.LOGERROR)
        data = github_gist_sync.sync_playback_state_load({}, force_remote=force_remote)
        try:
            _write_local_state(data)
        except Exception as persist_error:
            _log(f"persist fallback load error: {persist_error}", xbmc.LOGWARNING)
        _cache_set(data)
        return data


def refresh_from_remote():
    return playback_state_load(force_remote=True)


def playback_state_save(state, sync_remote: bool = True):
    try:
        cleaned = _write_local_state(state)
        _cache_set(cleaned)
        if sync_remote:
            github_gist_sync.sync_playback_state_save(cleaned)
    except Exception as e:
        _log(f"save error: {e}", xbmc.LOGERROR)


def _now_iso():
    return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


def _trakt_sync_playback_status(status: str, tmdb_id: str, pos_sec=None, total_sec=None,
                                ratio=None, meta: dict = None, source_meta: dict = None):
    try:
        from resources.lib import trakt_client
    except Exception:
        try:
            import trakt_client
        except Exception:
            return

    try:
        if not trakt_client.is_connected():
            return
        if str((source_meta or {}).get("provider") or "").strip().lower() == "trakt":
            return

        media_type = str((meta or {}).get("media_type") or "").strip().lower()
        season = (source_meta or {}).get("season")
        episode = (source_meta or {}).get("episode")
        mode = str((source_meta or {}).get("mode") or "").strip().lower()

        if mode == "serial_episode" or (season not in (None, "") and episode not in (None, "")):
            media_type = "episode"
        elif media_type in ("tv", "tvshow", "show", "series", "serial"):
            return
        else:
            media_type = "movie"

        try:
            progress = float(ratio) * 100.0
        except Exception:
            progress = 0.0
        if progress <= 0:
            try:
                total = float(total_sec or 0.0)
                pos = float(pos_sec or 0.0)
                progress = (pos / total) * 100.0 if total > 0 else 0.0
            except Exception:
                progress = 0.0
        if status == "finished":
            progress = max(progress, 100.0)
            scrobble_status = "stop"
        else:
            scrobble_status = "pause"

        trakt_client.scrobble_status(
            media_type=media_type,
            tmdb_id=tmdb_id,
            progress=progress,
            status=scrobble_status,
            season=season,
            episode=episode,
        )
    except Exception as e:
        _log(f"trakt sync {status} error: {e}", xbmc.LOGWARNING)


def make_source_key(provider: str, url: str = "", direct: str = "", source_id: str = "", file_hash: str = "") -> str:
    provider_norm = (provider or "").strip().lower()
    source_id_norm = (source_id or "").strip()
    file_hash_norm = (file_hash or "").strip()
    direct_norm = (direct or "").strip()
    url_norm = (url or "").strip()

    if source_id_norm or file_hash_norm:
        base = "|".join([provider_norm, source_id_norm, file_hash_norm])
    else:
        base = "|".join([provider_norm, direct_norm, url_norm])

    if not base.strip("|"):
        base = "unknown"
    return hashlib.md5(base.encode("utf-8")).hexdigest()


def update_item_meta(tmdb_id: str, meta: dict = None):
    tmdb_id = str(tmdb_id or "").strip()
    if not tmdb_id:
        return

    meta = dict(meta or {})
    state = playback_state_load()
    row = state.get(tmdb_id) or {}

    row["tmdb_id"] = tmdb_id
    for key in ("title", "original_title", "year", "poster", "plot", "rating", "media_type", "total_episodes", "total_seasons"):
        val = meta.get(key)
        if val not in (None, ""):
            row[key] = val

    row["updated_at"] = _now_iso()
    state[tmdb_id] = row
    playback_state_save(state, sync_remote=False)


def _ensure_row(state: dict, tmdb_id: str, meta: dict = None):
    row = state.get(tmdb_id) or {}
    row["tmdb_id"] = tmdb_id
    row["sources"] = row.get("sources") or {}
    for key in ("title", "original_title", "year", "poster", "plot", "rating", "media_type", "total_episodes", "total_seasons"):
        val = (meta or {}).get(key)
        if val not in (None, ""):
            row[key] = val
    return row


def mark_started(tmdb_id: str, source_key: str, pos_sec=None, total_sec=None, ratio=None,
                 meta: dict = None, source_meta: dict = None, sync_remote: bool = True,
                 sync_trakt: bool = True):
    tmdb_id = str(tmdb_id or "").strip()
    source_key = str(source_key or "").strip()
    if not tmdb_id or not source_key:
        return

    state = playback_state_load()
    row = _ensure_row(state, tmdb_id, meta)
    src = row["sources"].get(source_key) or {}
    now = _now_iso()

    src["status"] = "started"
    src["last_started_at"] = now
    src["last_position_sec"] = float(pos_sec or 0.0)
    src["last_duration_sec"] = float(total_sec or 0.0)
    src["last_ratio"] = float(ratio or 0.0)
    for key in ("provider", "source_id", "file_hash", "direct", "url", "play_url", "title", "display_title", "mode", "season", "episode", "episode_title", "season_name"):
        val = (source_meta or {}).get(key)
        if val not in (None, ""):
            src[key] = val

    row["sources"][source_key] = src
    row["last_played_at"] = now
    row["updated_at"] = now
    state[tmdb_id] = row
    playback_state_save(state, sync_remote=sync_remote)
    if sync_trakt:
        _trakt_sync_playback_status("started", tmdb_id, pos_sec=pos_sec, total_sec=total_sec,
                                    ratio=ratio, meta=meta, source_meta=source_meta)


def mark_finished(tmdb_id: str, source_key: str, pos_sec=None, total_sec=None, ratio=None,
                  meta: dict = None, source_meta: dict = None, sync_remote: bool = True,
                  sync_trakt: bool = True):
    tmdb_id = str(tmdb_id or "").strip()
    source_key = str(source_key or "").strip()
    if not tmdb_id or not source_key:
        return

    state = playback_state_load()
    row = _ensure_row(state, tmdb_id, meta)
    src = row["sources"].get(source_key) or {}
    now = _now_iso()

    src["status"] = "finished"
    src["last_finished_at"] = now
    src["last_position_sec"] = float(pos_sec or 0.0)
    src["last_duration_sec"] = float(total_sec or 0.0)
    src["last_ratio"] = float(ratio or 1.0)
    for key in ("provider", "source_id", "file_hash", "direct", "url", "play_url", "title", "display_title", "mode", "season", "episode", "episode_title", "season_name"):
        val = (source_meta or {}).get(key)
        if val not in (None, ""):
            src[key] = val

    row["sources"][source_key] = src
    row["last_played_at"] = now
    row["updated_at"] = now
    state[tmdb_id] = row
    playback_state_save(state, sync_remote=sync_remote)
    if sync_trakt:
        _trakt_sync_playback_status("finished", tmdb_id, pos_sec=pos_sec, total_sec=total_sec,
                                    ratio=ratio, meta=meta, source_meta=source_meta)


def checkpoint_playback(tmdb_id: str, source_key: str, pos_sec=None, total_sec=None, ratio=None,
                        meta: dict = None, source_meta: dict = None):
    try:
        ratio_val = float(ratio or 0.0)
    except Exception:
        ratio_val = 0.0

    if ratio_val >= 0.8:
        mark_finished(
            tmdb_id,
            source_key,
            pos_sec=pos_sec,
            total_sec=total_sec,
            ratio=ratio_val,
            meta=meta,
            source_meta=source_meta,
            sync_remote=False,
            sync_trakt=False,
        )
    elif ratio_val >= 0.1:
        mark_started(
            tmdb_id,
            source_key,
            pos_sec=pos_sec,
            total_sec=total_sec,
            ratio=ratio_val,
            meta=meta,
            source_meta=source_meta,
            sync_remote=False,
            sync_trakt=False,
        )


def mark_deleted(tmdb_id: str, source_key: str, meta: dict = None, source_meta: dict = None):
    tmdb_id = str(tmdb_id or "").strip()
    source_key = str(source_key or "").strip()
    if not tmdb_id or not source_key:
        return

    state = playback_state_load()
    row = _ensure_row(state, tmdb_id, meta)
    src = row["sources"].get(source_key) or {}
    now = _now_iso()

    src["status"] = "delete"
    src["last_deleted_at"] = now
    for key in ("provider", "source_id", "file_hash", "direct", "url", "play_url", "title", "display_title", "mode", "season", "episode", "episode_title", "season_name"):
        val = (source_meta or {}).get(key)
        if val not in (None, ""):
            src[key] = val
    row["sources"][source_key] = src
    row["last_played_at"] = now
    row["updated_at"] = now
    state[tmdb_id] = row
    playback_state_save(state)


def mark_movie_finished(tmdb_id: str, meta: dict = None):
    tmdb_id = str(tmdb_id or "").strip()
    if not tmdb_id:
        return

    source_key = make_source_key(
        provider="manual",
        url=f"tmdb://movie/{tmdb_id}",
        source_id="manual_finished",
    )
    source_meta = {
        "provider": "manual",
        "source_id": "manual_finished",
        "url": f"tmdb://movie/{tmdb_id}",
        "title": "Rucni oznaceni jako zhlednute",
    }
    mark_finished(
        tmdb_id,
        source_key,
        pos_sec=1.0,
        total_sec=1.0,
        ratio=1.0,
        meta=meta,
        source_meta=source_meta,
    )


def _manual_episode_source_parts(tmdb_id: str, season_i: int, episode_i: int,
                                 episode_title: str = "", season_name: str = ""):
    source_id = f"manual_finished_s{season_i:03d}e{episode_i:04d}"
    url = f"tmdb://tv/{tmdb_id}/season/{season_i}/episode/{episode_i}"
    source_key = make_source_key(
        provider="manual",
        url=url,
        source_id=source_id,
    )
    source_meta = {
        "provider": "manual",
        "source_id": source_id,
        "url": url,
        "title": episode_title or f"Rucni oznaceni S{season_i:02d}E{episode_i:02d}",
        "mode": "serial_episode",
        "season": str(season_i),
        "episode": str(episode_i),
        "episode_title": episode_title,
        "season_name": season_name,
    }
    return source_key, source_meta


def mark_episode_finished(tmdb_id: str, season, episode, meta: dict = None,
                          episode_title: str = "", season_name: str = ""):
    tmdb_id = str(tmdb_id or "").strip()
    season_i = _to_int(season)
    episode_i = _to_int(episode)
    if not tmdb_id or season_i is None or episode_i is None:
        return

    source_key, source_meta = _manual_episode_source_parts(
        tmdb_id,
        season_i,
        episode_i,
        episode_title=episode_title,
        season_name=season_name,
    )
    mark_finished(
        tmdb_id,
        source_key,
        pos_sec=1.0,
        total_sec=1.0,
        ratio=1.0,
        meta=meta,
        source_meta=source_meta,
    )


def mark_episodes_finished_bulk(tmdb_id: str, episodes, meta: dict = None) -> int:
    tmdb_id = str(tmdb_id or "").strip()
    if not tmdb_id:
        return 0

    state = playback_state_load()
    row = _ensure_row(state, tmdb_id, meta)
    sources = row.get("sources") or {}
    now = _now_iso()
    marked = 0

    for item in (episodes or []):
        if not isinstance(item, dict):
            continue
        season_i = _to_int(item.get("season"))
        episode_i = _to_int(item.get("episode"))
        if season_i is None or episode_i is None:
            continue

        source_key, source_meta = _manual_episode_source_parts(
            tmdb_id,
            season_i,
            episode_i,
            episode_title=str(item.get("episode_title") or "").strip(),
            season_name=str(item.get("season_name") or "").strip(),
        )
        src = sources.get(source_key) or {}
        src["status"] = "finished"
        src["last_finished_at"] = now
        src["last_position_sec"] = 1.0
        src["last_duration_sec"] = 1.0
        src["last_ratio"] = 1.0
        for key in ("provider", "source_id", "file_hash", "direct", "url", "play_url", "title", "display_title", "mode", "season", "episode", "episode_title", "season_name"):
            val = source_meta.get(key)
            if val not in (None, ""):
                src[key] = val
        sources[source_key] = src
        marked += 1

    if not marked:
        return 0

    row["sources"] = sources
    row["last_played_at"] = now
    row["updated_at"] = now
    state[tmdb_id] = row
    playback_state_save(state)
    return marked


def remove_episode(tmdb_id: str, season, episode) -> bool:
    tmdb_id = str(tmdb_id or "").strip()
    season_i = _to_int(season)
    episode_i = _to_int(episode)
    if not tmdb_id or season_i is None or episode_i is None:
        return False

    state = playback_state_load()
    row = state.get(tmdb_id)
    if not isinstance(row, dict):
        return False

    sources = row.get("sources") or {}
    changed = False
    for key, src in list(sources.items()):
        src_season, src_episode = _source_season_episode(src if isinstance(src, dict) else {})
        if src_season == season_i and src_episode == episode_i:
            sources.pop(key, None)
            changed = True

    if not changed:
        return False

    row["sources"] = sources
    row["updated_at"] = _now_iso()
    if sources:
        state[tmdb_id] = row
    else:
        state.pop(tmdb_id, None)
    playback_state_save(state)
    return True


def remove_season(tmdb_id: str, season) -> bool:
    tmdb_id = str(tmdb_id or "").strip()
    season_i = _to_int(season)
    if not tmdb_id or season_i is None:
        return False

    state = playback_state_load()
    row = state.get(tmdb_id)
    if not isinstance(row, dict):
        return False

    sources = row.get("sources") or {}
    changed = False
    for key, src in list(sources.items()):
        src_season, _ = _source_season_episode(src if isinstance(src, dict) else {})
        if src_season == season_i:
            sources.pop(key, None)
            changed = True

    if not changed:
        return False

    row["sources"] = sources
    row["updated_at"] = _now_iso()
    if sources:
        state[tmdb_id] = row
    else:
        state.pop(tmdb_id, None)
    playback_state_save(state)
    return True


def remove_item(tmdb_id: str):
    tmdb_id = str(tmdb_id or "").strip()
    if not tmdb_id:
        return False

    state = playback_state_load()
    if tmdb_id not in state:
        return False

    try:
        del state[tmdb_id]
    except Exception:
        state.pop(tmdb_id, None)
    playback_state_save(state)
    return True


def get_resume_seconds(tmdb_id: str, source_key: str):
    state = playback_state_load()
    row = state.get(str(tmdb_id or "").strip()) or {}
    src = (row.get("sources") or {}).get(str(source_key or "").strip()) or {}
    try:
        pos = float(src.get("last_position_sec") or 0.0)
    except Exception:
        pos = 0.0
    try:
        total = float(src.get("last_duration_sec") or 0.0)
    except Exception:
        total = 0.0
    try:
        ratio = float(src.get("last_ratio") or 0.0)
    except Exception:
        ratio = pos / total if total > 0 else 0.0

    if total > 0 and pos > 0 and 0.1 <= ratio <= 0.9:
        return pos
    return None


def _to_int(val):
    try:
        s = str(val).strip()
        if s == "":
            return None
        return int(s)
    except Exception:
        return None


def _source_season_episode(src: dict):
    season = _to_int((src or {}).get("season"))
    episode = _to_int((src or {}).get("episode"))
    if season is not None and episode is not None:
        return season, episode

    haystacks = [
        str((src or {}).get("title") or ""),
        str((src or {}).get("url") or ""),
        str((src or {}).get("play_url") or ""),
        str((src or {}).get("direct") or ""),
    ]

    for text in haystacks:
        if not text:
            continue
        m = re.search(r"[Ss]\s*(\d{1,3})\s*[Ee]\s*(\d{1,4})", text)
        if m:
            return int(m.group(1)), int(m.group(2))

    return season, episode


def _source_episode_keys(src: dict):
    season = _to_int((src or {}).get("season"))
    episode = _to_int((src or {}).get("episode"))
    if season is not None and episode is not None:
        return {(season, episode)}

    return set()


def _simple_status_bucket(row: dict):
    sources = (row or {}).get("sources") or {}
    any_started = False
    any_finished = False

    for src in sources.values():
        if not isinstance(src, dict):
            continue
        st = (src.get("status") or "").lower()
        if st == "finished":
            any_finished = True
            break
        if st == "started":
            any_started = True

    if any_finished:
        return "finished"
    if any_started:
        return "started"
    return ""


def _iter_filtered_sources(row: dict, provider: str = "", season=None, episode=None):
    provider = (provider or "").strip().lower()
    season = _to_int(season)
    episode = _to_int(episode)

    for src in ((row or {}).get("sources") or {}).values():
        if not isinstance(src, dict):
            continue
        st = (src.get("status") or "").strip().lower()
        if st not in ("started", "finished"):
            continue
        if provider and (src.get("provider") or "").strip().lower() != provider:
            continue
        if season is not None:
            keys = _source_episode_keys(src)
            if not keys or not any(src_key_season == season for src_key_season, _ in keys):
                continue
        if episode is not None:
            keys = _source_episode_keys(src)
            if not keys or (season, episode) not in keys:
                continue
        yield src


def _status_from_sources(sources) -> str:
    any_started = False
    any_finished = False

    for src in sources:
        st = (src.get("status") or "").strip().lower()
        if st == "finished":
            any_finished = True
            break
        if st == "started":
            any_started = True

    if any_finished:
        return "finished"
    if any_started:
        return "started"
    return ""


def get_provider_status(tmdb_id: str, provider: str, season=None, episode=None) -> str:
    row = (playback_state_load() or {}).get(str(tmdb_id or "").strip())
    if not isinstance(row, dict):
        return ""
    return _status_from_sources(_iter_filtered_sources(row, provider=provider, season=season, episode=episode))


def get_episode_status(tmdb_id: str, season, episode) -> str:
    row = (playback_state_load() or {}).get(str(tmdb_id or "").strip())
    if not isinstance(row, dict):
        return ""
    return _status_from_sources(_iter_filtered_sources(row, season=season, episode=episode))


def get_season_status(tmdb_id: str, season, total_episodes=None) -> str:
    row = (playback_state_load() or {}).get(str(tmdb_id or "").strip())
    if not isinstance(row, dict):
        return ""

    season_int = _to_int(season)
    total_episodes = _to_int(total_episodes)
    if season_int is None:
        return ""

    touched = set()
    finished = set()
    for src in _iter_filtered_sources(row, season=season_int):
        keys = {
            ep
            for src_season, ep in _source_episode_keys(src)
            if src_season == season_int
        }
        if not keys:
            continue
        touched.update(keys)
        if (src.get("status") or "").strip().lower() == "finished":
            finished.update(keys)

    if total_episodes and len(finished) >= total_episodes:
        return "finished"
    if touched:
        return "started"
    return ""


def get_status_bucket(row: dict, total_episodes=None):
    media_type = str((row or {}).get("media_type") or "").strip().lower()
    tv_like = media_type in ("tv", "tvshow", "show", "series", "serial")
    if not tv_like:
        for src in ((row or {}).get("sources") or {}).values():
            if not isinstance(src, dict):
                continue
            keys = _source_episode_keys(src)
            src_season, src_episode = _source_season_episode(src)
            if keys or src_season is not None or src_episode is not None:
                tv_like = True
                break

    if tv_like:
        touched = set()
        finished = set()
        for src in _iter_filtered_sources(row):
            keys = _source_episode_keys(src)
            if not keys:
                continue
            touched.update(keys)
            if (src.get("status") or "").strip().lower() == "finished":
                finished.update(keys)

        total = _to_int(total_episodes)
        if total is None:
            total = _to_int((row or {}).get("total_episodes"))

        if total and len(finished) >= total:
            return "finished"
        if touched:
            return "started"

    return _simple_status_bucket(row)


def get_item_status(tmdb_id: str) -> str:
    row = (playback_state_load() or {}).get(str(tmdb_id or "").strip())
    if not isinstance(row, dict):
        return ""
    return get_status_bucket(row)


def apply_status(li, status: str):
    status = (status or "").strip().lower()
    if not status:
        return None, 0

    try:
        icon_watched = xbmcgui.ICON_OVERLAY_WATCHED
        icon_partial = xbmcgui.ICON_OVERLAY_PARTIAL
    except Exception:
        icon_watched = 7
        icon_partial = 8

    if status == "finished":
        return icon_watched, 1

    if li is not None and status == "started":
        try:
            vit = li.getVideoInfoTag()
            vit.setResumePoint(1.0, 100.0)
        except Exception:
            try:
                li.setProperty("resumetime", "1")
                li.setProperty("totaltime", "100")
            except Exception:
                pass

    return icon_partial, 0


def apply_watch_state(li, tmdb_id):
    state = playback_state_load()
    row = state.get(str(tmdb_id or "").strip())
    if not isinstance(row, dict):
        return None, 0

    status = get_status_bucket(row)
    return apply_status(li, status)




def find_source_status(tmdb_id: str, provider: str = "", url: str = "", direct: str = "",
                       source_id: str = "", file_hash: str = "", title: str = "") -> str:
    state = playback_state_load() or {}
    row = state.get(str(tmdb_id or "").strip()) or {}
    sources = row.get("sources") or {}

    exact_key = make_source_key(provider=provider, url=url, direct=direct, source_id=source_id, file_hash=file_hash)
    exact = sources.get(exact_key) or {}
    status = (exact.get("status") or "").strip().lower()
    if status:
        return status

    provider = (provider or "").strip().lower()
    source_id = (source_id or "").strip()
    file_hash = (file_hash or "").strip()
    url = (url or "").strip()
    direct = (direct or "").strip()
    title = (title or "").strip().lower()

    for src in sources.values():
        if not isinstance(src, dict):
            continue
        st = (src.get("status") or "").strip().lower()
        if not st:
            continue
        if provider and (src.get("provider") or "").strip().lower() != provider:
            continue
        if source_id and (src.get("source_id") or "").strip() == source_id:
            return st
        if file_hash and (src.get("file_hash") or "").strip() == file_hash:
            return st
        if direct and (src.get("direct") or "").strip() == direct:
            return st
        if url and (src.get("url") or "").strip() == url:
            return st
        if url and (src.get("play_url") or "").strip() == url:
            return st
        src_title = (src.get("title") or "").strip().lower()
        if title and src_title and title == src_title:
            return st

    return ""


def iter_items_by_status(target_status: str):
    target_status = (target_status or "").strip().lower()
    out = []
    for tmdb_id, row in (playback_state_load() or {}).items():
        if not isinstance(row, dict):
            continue
        if get_status_bucket(row) != target_status:
            continue
        out.append((row.get("last_played_at") or "", tmdb_id, row))
    out.sort(key=lambda x: x[0], reverse=True)
    return out


def _kodi_url_with_headers(url: str, headers: dict = None) -> str:
    if not headers:
        return url
    import urllib.parse
    parts = []
    for key, val in headers.items():
        if val is None:
            continue
        parts.append(f"{key}={urllib.parse.quote_plus(str(val), safe='')}")
    if not parts:
        return url
    return url + "|" + "&".join(parts)

def _guess_stream_mimetype(url: str) -> str:
    ul = str(url or "").lower()
    if ".m3u8" in ul or "/hls" in ul:
        return "application/vnd.apple.mpegurl"
    if ".mp4" in ul:
        return "video/mp4"
    if ".ts" in ul:
        return "video/mp2t"
    if ".webm" in ul:
        return "video/webm"
    if ".mkv" in ul:
        return "video/x-matroska"
    if ".avi" in ul:
        return "video/x-msvideo"
    return "application/octet-stream"


def _fmt_time_hms(seconds):
    try:
        s = int(seconds or 0)
    except Exception:
        s = 0
    if s < 0:
        s = 0
    h = s // 3600
    m = (s % 3600) // 60
    s = s % 60
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def ask_resume(tmdb_id: str, source_key: str):
    pos = get_resume_seconds(tmdb_id, source_key)
    if not pos or pos <= 0:
        return None

    choice = xbmcgui.Dialog().contextmenu([
        f"Pokračovat od {_fmt_time_hms(pos)}",
        "Přehrát od začátku",
    ])
    if choice == 0:
        return pos
    if choice == 1:
        return None
    return "__cancel__"

def _addon_bool(setting_id: str, default: bool = False) -> bool:
    try:
        val = (xbmcaddon.Addon().getSetting(setting_id) or "").strip().lower()
    except Exception:
        val = ""
    if not val:
        return default
    return val == "true"


def _addon_enum_index(setting_id: str, default: int = 0) -> int:
    try:
        raw = (xbmcaddon.Addon().getSetting(setting_id) or "").strip()
        return int(raw) if raw != "" else int(default)
    except Exception:
        return int(default)

def _auto_next_debug_enabled() -> bool:
    return _addon_bool("tmdb_series_next_debug", default=True)

def _auto_next_notify(message: str, level=None):
    _log(f"auto next: {message}", xbmc.LOGINFO)
    if not _auto_next_debug_enabled():
        return
    try:
        xbmcgui.Dialog().notification(
            "Dalsi epizoda",
            str(message),
            level or xbmcgui.NOTIFICATION_INFO,
            2500,
            sound=False,
        )
    except Exception:
        pass

def _is_tmdb_serial_episode_source(source_meta: dict) -> bool:
    return (source_meta or {}).get("mode", "").strip() == "serial_episode"

def _start_next_episode_prefetch(tmdb_id: str, source_meta: dict, prefer_same_provider: bool):
    state = {"done": False, "result": {}, "error": ""}

    def _worker():
        try:
            _auto_next_notify("Hledam zdroj pro dalsi dil...")
            from resources.lib import TMDB_knihovna
            result = TMDB_knihovna.prepare_next_tv_episode_playback(
                tmdb_id=tmdb_id,
                source_meta=source_meta or {},
                prefer_same_provider=prefer_same_provider,
            )
            state["result"] = result or {}
            if result and (result.get("play_url") or result.get("search_url")):
                season = result.get("season") or "?"
                episode = result.get("episode") or "?"
                _auto_next_notify(f"Pripraven dalsi dil S{int(season):02d}E{int(episode):02d}" if str(season).isdigit() and str(episode).isdigit() else "Pripraven dalsi dil")
            else:
                _auto_next_notify("Dalsi dil nebo zdroj nenalezen", xbmcgui.NOTIFICATION_WARNING)
        except Exception as e:
            state["error"] = str(e)
            _log(f"auto next prefetch error: {e}", xbmc.LOGWARNING)
            _auto_next_notify("Hledani dalsiho dilu selhalo", xbmcgui.NOTIFICATION_WARNING)
        finally:
            state["done"] = True

    try:
        t = threading.Thread(target=_worker)
        t.daemon = True
        t.start()
        state["thread"] = t
    except Exception as e:
        state["done"] = True
        state["error"] = str(e)
        _log(f"auto next thread error: {e}", xbmc.LOGWARNING)

    return state

def _wait_for_prefetch(prefetch_state: dict, monitor, player, max_wait_sec: float = 8.0, require_playing: bool = True):
    waited = 0.0
    while (
        prefetch_state
        and not prefetch_state.get("done")
        and waited < max_wait_sec
        and not monitor.abortRequested()
        and ((not require_playing) or player.isPlayingVideo())
    ):
        monitor.waitForAbort(0.5)
        waited += 0.5
    return (prefetch_state or {}).get("result") or {}

class NextEpisodeDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.heading = kwargs.get("heading") or "Dalsi epizoda"
        self.message = kwargs.get("message") or ""
        self.timeout_sec = max(1, int(kwargs.get("timeout_sec") or 60))
        self.choice = False
        self.done = False

    def onInit(self):
        try:
            self.getControl(10).setLabel(self.heading)
        except Exception:
            pass
        try:
            self.getControl(20).setText(self.message)
        except Exception:
            try:
                self.getControl(20).setLabel(self.message)
            except Exception:
                pass

    def _update_countdown(self, seconds_left: int):
        try:
            self.getControl(30).setLabel(f"Cas do konce epizody - {_format_countdown(seconds_left)}")
        except Exception:
            pass

    def onClick(self, controlId):
        if controlId == 41:
            self.choice = True
            self.done = True
        elif controlId == 42:
            self.choice = False
            self.done = True

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = None
        if action_id in (9, 10, 92, 216, 247, 257, 275, 61467):
            self.choice = False
            self.done = True
            return
        super().onAction(action)

def _format_countdown(seconds_left: int) -> str:
    total = max(0, int(seconds_left))
    minutes, seconds = divmod(total, 60)
    if minutes >= 60:
        hours, minutes = divmod(minutes, 60)
        return f"{hours}:{minutes:02d}:{seconds:02d}"
    return f"{minutes}:{seconds:02d}"

def _confirm_next_episode(result: dict, timeout_sec: int) -> bool:
    season = result.get("season") or ""
    episode = result.get("episode") or ""
    episode_title = result.get("episode_title") or ""
    label = f"S{int(season):02d}E{int(episode):02d}" if str(season).isdigit() and str(episode).isdigit() else "Dalsi epizoda"
    if episode_title:
        label = f"{label} - {episode_title}"
    msg = label
    _auto_next_notify(f"Zobrazuji vyzvu: {label}")
    try:
        dlg = NextEpisodeDialog(
            "DialogNextEpisode.xml",
            xbmcaddon.Addon().getAddonInfo("path"),
            "Default",
            "720p",
            heading="Chcete pokracovat dalsim dilem ?",
            message=msg,
            timeout_sec=timeout_sec,
        )
        dlg.show()
        xbmc.sleep(150)

        monitor = xbmc.Monitor()
        remaining = max(1, int(timeout_sec))
        while remaining >= 0 and not monitor.abortRequested():
            try:
                dlg._update_countdown(remaining)
            except Exception:
                pass

            if getattr(dlg, "done", False):
                break

            if remaining == 0:
                break

            if monitor.waitForAbort(1.0):
                break
            remaining -= 1

        choice = bool(getattr(dlg, "choice", False)) if getattr(dlg, "done", False) else False
        try:
            dlg.close()
        except Exception:
            pass
        return choice
    except Exception:
        return False

def _run_plugin_delayed(plugin_url: str, delay_ms: int = 900):
    plugin_url = str(plugin_url or "").strip()
    if not plugin_url:
        return False

    def _worker():
        try:
            xbmc.sleep(max(0, int(delay_ms)))
            xbmc.executebuiltin(f'RunPlugin("{plugin_url}")')
        except Exception as e:
            _log(f"auto next delayed run error: {e}", xbmc.LOGWARNING)

    try:
        worker = threading.Thread(target=_worker)
        worker.daemon = True
        worker.start()
        return True
    except Exception as e:
        _log(f"auto next thread start error: {e}", xbmc.LOGWARNING)
        try:
            xbmc.executebuiltin(f'RunPlugin("{plugin_url}")')
            return True
        except Exception as inner:
            _log(f"auto next run fallback error: {inner}", xbmc.LOGWARNING)
            return False

def _open_next_episode_result(result: dict, auto_play: bool):
    play_url = (result or {}).get("play_url") or ""
    provider_search_url = (result or {}).get("provider_search_url") or ""
    search_url = (result or {}).get("search_url") or ""
    try:
        if play_url:
            if auto_play:
                return _run_plugin_delayed(play_url, delay_ms=1200)
            xbmc.executebuiltin(f'RunPlugin("{play_url}")')
            return True
        if provider_search_url:
            xbmc.executebuiltin(f'Container.Update("{provider_search_url}")')
            return True
        if search_url:
            xbmc.executebuiltin(f'Container.Update("{search_url}")')
            return True
    except Exception as e:
        _log(f"auto next open error: {e}", xbmc.LOGWARNING)
    return False


def play_and_record_progress(tmdb_id: str, source_key: str, play_url: str, headers: dict = None,
                             meta: dict = None, resume_sec: float = None, source_meta: dict = None):
    tmdb_id = str(tmdb_id or "").strip()
    source_key = str(source_key or "").strip()
    if not tmdb_id or not source_key or not play_url:
        return False

    final_url = _kodi_url_with_headers(play_url, headers)
    display_title = (
        (source_meta or {}).get("display_title")
        or (meta or {}).get("title")
        or (source_meta or {}).get("title")
        or "Zdroj"
    )
    display_title = str(display_title or "Zdroj").strip()

    try:
        if str(play_url).startswith("plugin://"):
            xbmc.executebuiltin(f'PlayMedia("{final_url}")')
        else:
            li = xbmcgui.ListItem(label=display_title, path=final_url)
            li.setProperty("IsPlayable", "true")
            li.setContentLookup(False)
            li.setMimeType(_guess_stream_mimetype(play_url))
            li.setInfo("video", {"title": display_title})
            xbmc.Player().play(final_url, li)
    except Exception:
        xbmc.executebuiltin(f'PlayMedia("{final_url}")')

    return monitor_current_playback(
        tmdb_id=tmdb_id,
        source_key=source_key,
        meta=meta,
        resume_sec=resume_sec,
        source_meta=source_meta,
    )


def monitor_current_playback(tmdb_id: str, source_key: str, meta: dict = None,
                             resume_sec: float = None,
                             source_meta: dict = None):
    tmdb_id = str(tmdb_id or "").strip()
    source_key = str(source_key or "").strip()
    if not tmdb_id or not source_key:
        return False

    monitor = xbmc.Monitor()
    player = xbmc.Player()
    started = False
    total = 0.0
    cur = 0.0
    delete_marked = False
    auto_next_enabled = (
        _addon_bool("tmdb_series_next_enabled", default=True)
        and _is_tmdb_serial_episode_source(source_meta)
    )
    auto_next_mode = _addon_enum_index("tmdb_series_next_mode", default=0)
    auto_play_next = auto_next_mode == 1
    prefer_same_provider = _addon_bool("tmdb_series_next_prefer_same_provider", default=True)
    next_prefetch = None
    next_result_to_open = None
    next_action_allowed = False
    next_dialog_shown = False
    next_dialog_accepted = False
    next_dialog_declined = False
    next_prefetch_result = {}
    last_playback_pos = 0.0
    auto_next_seek_cooldown = 0
    stop_for_next_episode = False
    last_checkpoint_time = 0.0
    last_checkpoint_ratio = 0.0
    checkpoint_finished_saved = False

    for i in range(40):
        if monitor.abortRequested():
            return False
        if player.isPlayingVideo():
            started = True
            try:
                total = float(player.getTotalTime() or 0.0)
            except Exception:
                total = 0.0

            if resume_sec is not None and resume_sec > 0:
                try:
                    player.seekTime(float(resume_sec))
                except Exception as e:
                    _log(f"seek error: {e}", xbmc.LOGERROR)
            break

        if (not delete_marked) and i >= 8:
            mark_deleted(tmdb_id, source_key, meta=meta, source_meta=source_meta)
            delete_marked = True
        monitor.waitForAbort(0.5)

    if not started:
        return False

    while (not monitor.abortRequested()) and player.isPlayingVideo():
        try:
            cur_tmp = float(player.getTime() or 0.0)
            tot_tmp = float(player.getTotalTime() or 0.0)
            if tot_tmp > 0:
                total = tot_tmp
            if cur_tmp >= 0:
                if last_playback_pos > 0 and abs(cur_tmp - last_playback_pos) > 30.0:
                    auto_next_seek_cooldown = 8
                cur = cur_tmp
                last_playback_pos = cur_tmp
        except Exception:
            pass

        if auto_next_seek_cooldown > 0:
            auto_next_seek_cooldown -= 1

        if auto_next_enabled and total > 0 and cur >= 60.0 and auto_next_seek_cooldown <= 0:
            if next_prefetch is None:
                next_prefetch = _start_next_episode_prefetch(
                    tmdb_id=tmdb_id,
                    source_meta=source_meta,
                    prefer_same_provider=prefer_same_provider,
                )

        ratio_live = (cur / total) if total > 0 else 0.0
        now_ts = time.time()
        if (
            total > 0
            and cur >= 30.0
            and ratio_live >= 0.1
            and (
                now_ts - last_checkpoint_time >= 60.0
                or ratio_live - last_checkpoint_ratio >= 0.05
                or (ratio_live >= 0.8 and not checkpoint_finished_saved)
            )
        ):
            checkpoint_playback(
                tmdb_id,
                source_key,
                pos_sec=cur,
                total_sec=total,
                ratio=ratio_live,
                meta=meta,
                source_meta=source_meta,
            )
            last_checkpoint_time = now_ts
            last_checkpoint_ratio = ratio_live
            if ratio_live >= 0.8:
                checkpoint_finished_saved = True

        if (
            auto_next_enabled
            and not auto_play_next
            and not next_dialog_shown
            and not next_dialog_declined
            and total > 0
            and ratio_live >= 0.8
        ):
            result = next_prefetch_result or {}
            if not result and next_prefetch is not None:
                result = _wait_for_prefetch(
                    next_prefetch,
                    monitor=monitor,
                    player=player,
                    max_wait_sec=6.0,
                    require_playing=True,
                )
                if result:
                    next_prefetch_result = result

            if result and (result.get("play_url") or result.get("search_url")):
                remaining = max(0.0, total - cur)
                timeout_sec = max(1, int(max(0.0, remaining - 3.0)))
                next_dialog_shown = True
                if _confirm_next_episode(result, timeout_sec=timeout_sec):
                    next_dialog_accepted = True
                    next_result_to_open = result
                    next_action_allowed = True
                    stop_for_next_episode = True
                    try:
                        player.stop()
                    except Exception as e:
                        _log(f"auto next stop error: {e}", xbmc.LOGERROR)
                    break
                else:
                    next_dialog_declined = True
            elif next_prefetch and next_prefetch.get("done"):
                next_dialog_shown = True
                next_dialog_declined = True

        monitor.waitForAbort(1.0)

    if stop_for_next_episode and total > 0:
        cur = max(cur, total * 0.8)

    ratio = (cur / total) if total > 0 else 0.0
    if ratio >= 0.8:
        mark_finished(tmdb_id, source_key, pos_sec=cur, total_sec=total, ratio=ratio, meta=meta, source_meta=source_meta)
    elif ratio >= 0.1:
        mark_started(tmdb_id, source_key, pos_sec=cur, total_sec=total, ratio=ratio, meta=meta, source_meta=source_meta)

    if auto_next_enabled and ratio >= 0.8:
        next_action_allowed = True

    if next_action_allowed:
        result = next_prefetch_result or {}
        if next_prefetch is not None:
            result = _wait_for_prefetch(
                next_prefetch,
                monitor=monitor,
                player=player,
                max_wait_sec=8.0,
                require_playing=False,
            )
            if result:
                next_prefetch_result = result
        if result and (result.get("play_url") or result.get("search_url")):
            if auto_play_next:
                next_result_to_open = result
            else:
                if next_dialog_accepted:
                    next_result_to_open = result
                elif (not next_dialog_shown) and (not next_dialog_declined):
                    if _confirm_next_episode(result, timeout_sec=60):
                        next_result_to_open = result
        elif auto_next_enabled:
            _auto_next_notify("Dalsi epizoda nebyla pripravena", xbmcgui.NOTIFICATION_WARNING)

    if next_result_to_open:
        _open_next_episode_result(next_result_to_open, auto_play=auto_play_next)

    return True

# -*- coding: utf-8 -*-
import xbmcaddon
import xbmcgui


ADDON_ID = "plugin.video.ikarus"


CHANGELOG = """[B]0.1.10[/B] - informativni upozorneni pri startu
- Pri spusteni pluginu se zobrazi informativni upozorneni s povinnym potvrzenim souhlasu.
- Hlavni menu Ikarusu se spusti az po potvrzeni informativniho upozorneni.
- Do nastaveni byla pridana volba Uz nezobrazovat informativni text pri startu.
- V nastaveni je dostupne i rucni zobrazeni celeho informativniho textu.
- Upozorneni ma vlastni interni verzi, takze ho lze pri nektere dalsi aktualizaci znovu vynutit.

----------------------------------------

[B]0.1.9[/B] - vyber audio stopy a titulku
- Do ostatniho nastaveni pridany volby pro primarni audio stopu, sekundarni audio stopu a preferovane titulky.
- Pri spusteni zdroje se plugin nejdrive pokusi prepnout na primarni audio jazyk.
- Pokud primarni audio stopa neni dostupna, plugin zkusi sekundarni audio jazyk.
- Pokud neni dostupna ani primarni ani sekundarni audio stopa, zdroj se ponecha s aktualni audio stopou.
- Titulky se automaticky zapnou jen kdyz se lisi jazykova skupina prehravane audio stopy a preferovanych titulku.
- Pokud prehravane audio patri mezi CZ/SK a preferovane titulky jsou CZ/SK, titulky se nezapnou.
- Pokud je prehravane audio EN a preferovane titulky jsou EN, titulky se nezapnou.
- Pokud zdroj nema primarni ani sekundarni audio stopu a obsahuje jinou audio stopu, plugin se vzdy pokusi zapnout preferovane titulky.
- Pokud preferovane titulky ve zdroji nejsou dostupne, titulky zustanou vypnute.

----------------------------------------

[B]0.1.8[/B] - razeni a pojmenovani WebShare zdroju
- Oprava v nastaveni Info o verzi a kontrola aktualizace pluginu.
- Opraveno razeni nalezenych WebShare zdroju v TMDB knihovne.
- WebShare zdroje se radi podle potvrzeneho audio jazyka: CZ, potom SK, potom EN a nakonec ostatni nebo nezname.
- V ramci stejneho jazyka se radi podle kvality: 4K, 1080p, 720p a nizsi kvality.
- Pri stejne kvalite rozhoduje velikost souboru, vetsi soubor je vyse.
- Interni score shody zustava zachovane pro ladeni a jako pomocne kriterium pri shode ostatnich hodnot.
- Nazev WebShare zdroje se sklada z tagu jazyka, kvality a velikosti, napr. [CZ][1080p][3.2 GB].
- Pokud ma zdroj potvrzene CZ audio, zobrazi se za tagy cesky nazev filmu nebo serialu s rokem misto dlouheho nazvu souboru.
- Pokud informace o souboru nejsou citelne nebo chybi, zobrazi se puvodni nazev souboru.
- Totozne WebShare zdroje se seskupuji do slozky s poctem zdroju.

----------------------------------------

[B]0.1.7[/B] - kontrola aktualizaci z pluginu
- Polozka Zkontrolovat aktualizace Ikarus odstranena z hlavniho menu.
- V nastaveni zustava samostatna leva polozka Zkontrolovat aktualizace.
- Sekce Info o verzi otevre cisty scrollovatelny prehled zmen.
- Akce spousti Kodi kontrolu povolenych repozitaru.

----------------------------------------

[B]0.1.6[/B] - prehled verzi jako obsah nastaveni
- Polozka Info o verzi zustava v levem menu nastaveni.
- Po prepnuti na Info o verzi se prehled zobrazi rovnou v hlavni casti okna.
- Prehled verzi je upraven do beznych radku nastaveni.

----------------------------------------

[B]0.1.5[/B] - info o verzi přímo v nastavení
- Informace o verzi se zobrazí hned po otevření položky Info o verzi.
- Odstraněno extra tlačítko Zobrazit přehled verzí.
- Přehled změn je vidět přímo uprostřed okna nastavení.

----------------------------------------

[B]0.1.4[/B] - úprava okna nastavení
- Opraveno otevření tlačítka Info o verzi z nastavení.
- Položka Info o verzi přesunuta pod Stahování v levém menu nastavení.
- Verze doplněna přímo do nadpisu okna nastavení.

----------------------------------------

[B]0.1.3[/B] - info o verzi v nastavení
- Přidáno tlačítko Info o verzi do nastavení v sekci Stahování.
- Přidán přehled aktuální verze a změn přímo v nastavení pluginu.
- Do nastavení doplněn viditelný řádek s aktuální verzí pluginu.

----------------------------------------

[B]0.1.2[/B] - zobrazení změn v Kodi
- Doplněn přehled změn do metadata položky news.
- Upraveno zobrazení informací pro okno Verze v Kodi.

----------------------------------------

[B]0.1.1[/B] - navazování další epizody
- Upraveno navázání další epizody u seriálů z TMDB.
- V nastavení je nová volba Pokračovat další epizodou: automatické pokračování nebo výběrový dialog.
- Výchozí režim je automatické spuštění další epizody.
- Při potvrzení další epizody dialogem už plugin zbytečně neukončuje aktuální přehrávání hned v 80 procentech.
- Testovací notifikace pro další epizodu jsou ve výchozím stavu vypnuté.

----------------------------------------

[B]0.1.0[/B] - první verze
- První zkušební verze pluginu v Kodi repozitáři.
- TMDB katalog: filmy, seriály, osoby, trendující obsah a vyhledávání.
- Přehled zhlédnutých a rozkoukaných filmů a seriálů.
- Vlastní seznamy, Trakt.TV seznamy a chytré seznamy.
- Hledání zdrojů na Přehraj.to, Hellspy, SkTonLine a WebShare.
- Přehrávání zdrojů z WebShare s podporou účtu a obnovy tokenu.
- Fronta stahování a volitelné ukládání nalezených zdrojů.
- Navazování další epizody u seriálů a volba preferovaného zdroje.
- Synchronizace stavu přehrávání přes GitHub Gist.
- Vlastní seznamy se synchronizují přes Trakt.TV."""


def main():
    addon = xbmcaddon.Addon(ADDON_ID)
    version = addon.getAddonInfo("version") or "?"
    xbmcgui.Dialog().textviewer(
        "Ikarus - WebShare - ver {0}".format(version),
        CHANGELOG,
    )


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
import sys
import re
import json
import time
import os
import hashlib
import urllib.parse
import urllib.request
import html
import http.cookiejar
import unicodedata
from collections import Counter
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import xbmcvfs

from resources.lib import diagnostics, playback_utils, source_common

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else 0
BASE_PATH = sys.argv[0] if len(sys.argv) > 0 else ""


def _refresh_runtime():
    global addon_handle, BASE_PATH
    try:
        addon_handle = int(sys.argv[1]) if len(sys.argv) > 1 else addon_handle
    except Exception:
        pass
    try:
        BASE_PATH = sys.argv[0] if len(sys.argv) > 0 else BASE_PATH
    except Exception:
        pass


def _setting_enabled(setting_id: str, default: bool = True) -> bool:
    value = (addon.getSetting(setting_id) or "").strip().lower()
    if not value:
        return default
    return value == "true"


def _webshare_connected() -> bool:
    status = (addon.getSetting("status") or "").strip().lower()
    return status in ("připojeno", "pripojeno", "přihlášen", "prihlasen")

# ---------------------------
# HTTP (urllib + cookies)
# ---------------------------

_COOKIEJAR = http.cookiejar.CookieJar()
_OPENER = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_COOKIEJAR))


# ---------------------------
# ROUTING HELPERS
# ---------------------------

def build_url(query: dict) -> str:
    _refresh_runtime()
    return BASE_PATH + "?" + urllib.parse.urlencode(query)


_MANUAL_SEARCH_CACHE_TTL = 20 * 60
_MANUAL_ACTIVE_SEARCH = {}


def _manual_cache_dir() -> str:
    try:
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        path = os.path.join(profile, "cache", "manual_search")
        os.makedirs(path, exist_ok=True)
        return path
    except Exception:
        return ""


def _manual_cache_key(provider: str, payload: dict) -> str:
    raw = json.dumps({"provider": provider, "payload": payload or {}}, sort_keys=True, ensure_ascii=False)
    return hashlib.md5(raw.encode("utf-8")).hexdigest()


def _manual_cache_get(provider: str, payload: dict):
    cache_dir = _manual_cache_dir()
    if not cache_dir:
        return None
    path = os.path.join(cache_dir, _manual_cache_key(provider, payload) + ".json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if (time.time() - float(data.get("_ts") or 0)) > _MANUAL_SEARCH_CACHE_TTL:
            return None
        return data.get("data")
    except Exception:
        return None


def _manual_cache_set(provider: str, payload: dict, data):
    cache_dir = _manual_cache_dir()
    if not cache_dir:
        return
    path = os.path.join(cache_dir, _manual_cache_key(provider, payload) + ".json")
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"_ts": int(time.time()), "data": data}, f, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"[IKARUS][MANUAL][CACHE] write failed provider={provider}: {repr(e)}", xbmc.LOGWARNING)


def _container_update(query: dict):
    target = build_url(query)
    try:
        xbmc.executebuiltin('Container.Update("{0}",replace)'.format(target.replace('"', "%22")))
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=False)
    except Exception as e:
        xbmc.log(f"[IKARUS][MANUAL] Container.Update failed: {repr(e)}", xbmc.LOGWARNING)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False, updateListing=False, cacheToDisc=False)


def _prompt_and_open_results(provider_label: str, prompt_title: str, result_action: str, extra: dict = None):
    q = xbmcgui.Dialog().input(prompt_title, type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return
    query = {"action": result_action, "q": q.strip()}
    if extra:
        query.update(extra)
    _container_update(query)


def _manual_remember(provider: str, q: str, **kwargs):
    provider = (provider or "").strip().lower()
    q = (q or "").strip()
    if not provider or not q:
        return
    payload = {"q": q}
    payload.update(kwargs or {})
    _MANUAL_ACTIVE_SEARCH[provider] = payload


def _manual_active(provider: str):
    return _MANUAL_ACTIVE_SEARCH.get((provider or "").strip().lower()) or {}


def _add_manual_nav(provider_label: str, search_action: str, refresh_query: dict):
    li_new = xbmcgui.ListItem(label="[Nove hledani]")
    li_new.setArt({"icon": "DefaultAddonsSearch.png", "thumb": "DefaultAddonsSearch.png"})
    xbmcplugin.addDirectoryItem(addon_handle, build_url({"action": search_action, "new": "1"}), li_new, isFolder=True)

    rq = dict(refresh_query or {})
    rq["force"] = "1"
    li_refresh = xbmcgui.ListItem(label="[Aktualizovat z webu]")
    li_refresh.setArt({"icon": "DefaultAddonProgram.png", "thumb": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(addon_handle, build_url(rq), li_refresh, isFolder=True)


def _add_empty_row(label: str):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png"})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({"action": "other_sources"}), listitem=li, isFolder=False)


def main_menu():
    xbmcplugin.setContent(addon_handle, "files")

    items = [
        ("Přehraj.to", {"action": "other.prehrajto"}, "DefaultAddonProgram.png"),
        ("Hellspy",    {"action": "other.hellspy"},   "DefaultAddonProgram.png"),
        ("SkTonLine",  {"action": "other.sktonline"}, "DefaultAddonProgram.png"),
        ("WebShare", {"action": "film.search"}, "DefaultAddonProgram.png"),
    ]

    allowed_actions = set()
    if _setting_enabled("show_prehrajto", default=True):
        allowed_actions.add("other.prehrajto")
    if _setting_enabled("show_hellspy", default=True):
        allowed_actions.add("other.hellspy")
    if _setting_enabled("show_sktonline", default=True):
        allowed_actions.add("other.sktonline")
    if _setting_enabled("show_webshare", default=True) and _webshare_connected():
        allowed_actions.add("film.search")

    items = [
        (label, query, icon_p)
        for (label, query, icon_p) in items
        if (query.get("action") or "") in allowed_actions
    ]

    for label, query, icon_p in items:
        url = build_url(query)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon_p, "thumb": icon_p, "poster": icon_p})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)


# ---------------------------
# COMMON HTTP (urllib, no gzip)
# ---------------------------
def _sanitize_url(url: str) -> str:
    return source_common.sanitize_url(url)

def _http_get(url: str, timeout: int = 25, referer: str = None) -> str:
    return source_common.http_get(url, _OPENER, timeout=timeout, referer=referer)

def _http_post(url: str, data: dict, timeout: int = 25, referer: str = None) -> str:
    return source_common.http_post(url, data, _OPENER, timeout=timeout, referer=referer)

def _http_get_json(url: str, timeout: int = 25, referer: str = None, origin: str = None) -> dict:
    return source_common.http_get_json(
        url,
        _OPENER,
        timeout=timeout,
        referer=referer,
        origin=origin,
        default_referer="https://www.hellspy.to/",
        default_origin="https://www.hellspy.to",
    )

def _is_direct_media_url(u: str) -> bool:
    return source_common.is_direct_media_url(u)

def _kodi_url_with_headers(url: str, headers: dict) -> str:
    """
    Kodi headers v URL: https://...|Header=Value&Header2=Value2
    """
    return playback_utils.kodi_url_with_headers(url, headers)

def play_url(title: str, stream_url: str, headers: dict = None):
    _refresh_runtime()
    try:
        stream_url = _sanitize_url(stream_url)
    except Exception:
        pass

    playback_utils.set_resolved_playback(addon_handle, title, stream_url, headers=headers)


def _fail_playback():
    _refresh_runtime()
    playback_utils.fail_playback(addon_handle)

def _manual_play_failed(provider: str, reason: str, title: str = "", url: str = "",
                        dialog_title: str = "", dialog_message: str = ""):
    _refresh_runtime()
    _manual_log(provider, "PLAY_FAIL", xbmc.LOGWARNING, reason=reason, title=title, url=url)
    playback_utils.log_source_failure(
        provider=provider,
        reason=reason,
        title=title,
        url=url,
    )
    if dialog_title and dialog_message:
        xbmcgui.Dialog().ok(dialog_title, dialog_message)
    _fail_playback()


def _manual_missing_param(provider: str, param_name: str, title: str = "", url: str = ""):
    _manual_play_failed(
        provider,
        "missing param " + str(param_name or ""),
        title=title,
        url=url,
        dialog_title="Ikarus",
        dialog_message="Chybi povinny parametr: " + str(param_name or ""),
    )


def _manual_elapsed_ms(start: float) -> int:
    try:
        return int((time.time() - start) * 1000)
    except Exception:
        return -1


def _manual_log(provider: str, event: str, level=xbmc.LOGINFO, **fields):
    provider = re.sub(r"[^A-Z0-9_]+", "_", str(provider or "GENERIC").upper()).strip("_") or "GENERIC"
    event = re.sub(r"[^A-Z0-9_]+", "_", str(event or "EVENT").upper()).strip("_") or "EVENT"
    parts = []
    for key, value in fields.items():
        if value is None:
            continue
        text = str(value).replace("\r", " ").replace("\n", " ").strip()
        if len(text) > 220:
            text = text[:217] + "..."
        parts.append(f"{key}={text}")
    msg = f"[IKARUS][MANUAL][{provider}][{event}]"
    if parts:
        msg += " " + " ".join(parts)
    try:
        xbmc.log(msg, level)
    except Exception:
        pass


def _manual_norm_text(text: str) -> str:
    try:
        text = "".join(
            ch for ch in unicodedata.normalize("NFKD", text or "")
            if not unicodedata.combining(ch)
        )
    except Exception:
        text = text or ""
    text = re.sub(r"[^a-zA-Z0-9]+", " ", text.lower())
    return re.sub(r"\s+", " ", text).strip()


def _manual_audio_tag(title: str) -> str:
    norm = _manual_norm_text(title)
    flat = norm.replace(" ", "")
    if any(x in flat for x in ("czdab", "czdabing", "ceskydabing")) or "cz dab" in norm:
        return "CZ dab"
    if any(x in flat for x in ("skdab", "skdabing", "slovenskydabing")) or "sk dab" in norm:
        return "SK dab"
    if any(x in flat for x in ("cztit", "cztitulky", "czsub", "czsubs")) or "cz tit" in norm:
        return "CZ tit"
    if any(x in flat for x in ("sktit", "sktitulky", "sksub", "sksubs")) or "sk tit" in norm:
        return "SK tit"
    if re.search(r"\bcz\b", norm):
        return "CZ"
    if re.search(r"\bsk\b", norm):
        return "SK"
    if re.search(r"\b(en|eng|english)\b", norm):
        return "EN"
    return ""


def _manual_quality_tag(title: str, fallback: str = "") -> str:
    text = f"{title or ''} {fallback or ''}"
    low = text.lower()
    norm = _manual_norm_text(text)
    if re.search(r"\b(4320p|8k)\b", low):
        return "8K"
    if re.search(r"\b(2160p|4k|uhd)\b", low):
        return "4K"
    for q in ("1080p", "720p", "576p", "480p", "360p"):
        if q in low:
            return q
    if "full hd" in low or "fullhd" in norm:
        return "1080p"
    if re.search(r"\bhd\b", norm):
        return "HD"
    if re.search(r"\bsd\b", norm):
        return "SD"
    return ""


def _manual_source_label(title: str, audio: str = "", quality: str = "", size: str = "", extra: str = "") -> str:
    title = (title or "Bez nazvu").strip()
    tags = []
    for tag in (audio, quality, size):
        tag = (tag or "").strip()
        if tag and tag not in tags:
            tags.append(tag)
    prefix = "".join(f"[{tag}]" for tag in tags)
    suffix = f" [{extra.strip()}]" if (extra or "").strip() else ""
    return f"{prefix} {title}{suffix}".strip()


def _cookie_header_for_url_basic(url: str) -> str:
    return source_common.cookie_header_for_url(_COOKIEJAR, url, relaxed_domain=False)


_PREHRAJTO_BASE = "https://prehrajto.cz"
_PREHRAJTO_SEARCH_PREFIX = "/hledej/"
_PREHRAJTO_PAGINATOR_PARAM = "videoListing-visualPaginator-page"
_PREHRAJTO_DETAIL_RE = re.compile(r"^/[^/]+/[0-9a-f]{10,}$", re.IGNORECASE)


def _build_prehrajto_search_url(query: str, page: int) -> str:
    q = urllib.parse.quote(query.strip())
    base = urllib.parse.urljoin(_PREHRAJTO_BASE, f"{_PREHRAJTO_SEARCH_PREFIX}{q}")
    return base + "?" + urllib.parse.urlencode({_PREHRAJTO_PAGINATOR_PARAM: page})

def _canonicalize_prehrajto_url(full: str) -> str:
    u = urllib.parse.urlparse(full)
    qs = [(k, v) for (k, v) in urllib.parse.parse_qsl(u.query, keep_blank_values=True) if k.lower() != "player"]
    new_query = urllib.parse.urlencode(qs, doseq=True)
    return urllib.parse.urlunparse((u.scheme, u.netloc, u.path, u.params, new_query, u.fragment))

def _extract_prehrajto_results(html_text: str):
    results = []
    seen = set()

    for m in re.finditer(r'<a[^>]+href="(?P<href>/[^"]+)"(?P<rest>[^>]*)>', html_text, re.IGNORECASE):
        href = (m.group("href") or "").strip()
        rest = m.group("rest") or ""

        if not href or href.startswith("#") or href.lower().startswith("javascript:"):
            continue
        if not _PREHRAJTO_DETAIL_RE.match(href):
            continue

        full = urllib.parse.urljoin(_PREHRAJTO_BASE, href)
        full = _canonicalize_prehrajto_url(full)

        if full in seen:
            continue
        seen.add(full)

        title = ""
        mt = re.search(r'title="([^"]+)"', rest, re.IGNORECASE)
        if mt:
            title = html.unescape(mt.group(1)).strip()

        if not title or len(title) < 2:
            seg = href.strip("/").split("/", 1)[0]
            title = seg

        title = re.sub(r"\s+", " ", title).strip()
        results.append({"title": title, "url": full})

    return results

def prehrajto_search_all_pages(query: str, max_pages: int = 30):
    all_results = []
    seen_urls = set()

    for page in range(1, max_pages + 1):
        url = _build_prehrajto_search_url(query, page)
        html_text = _http_get(url)
        page_results = _extract_prehrajto_results(html_text)

        if not page_results:
            break

        new_added = 0
        for it in page_results:
            if it["url"] in seen_urls:
                continue
            seen_urls.add(it["url"])
            all_results.append(it)
            new_added += 1

        if new_added == 0:
            break

    return all_results

def prehrajto_search_ui():
    q = xbmcgui.Dialog().input("Přehraj.to – zadej hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return

    results = prehrajto_search_all_pages(q.strip(), max_pages=30)

    xbmcplugin.setContent(addon_handle, "files")

    if not results:
        xbmcgui.Dialog().ok("Přehraj.to", "Nic nenalezeno.")
        main_menu()
        return

    for it in results:
        title = it.get("title") or "Bez názvu"
        url = it.get("url") or ""

        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")

        u = build_url({"action": "other.prehrajto_item", "title": title, "url": url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)

def _try_extract_sources_from_html(html_text: str):
    m = re.search(r"var\s+sources\s*=\s*(\[[\s\S]*?\])\s*;", html_text, re.IGNORECASE)
    if not m:
        return None

    arr_txt = m.group(1)

    mf = re.search(r'["\'](?:file|src)["\']\s*:\s*["\']([^"\']+)["\']', arr_txt, re.IGNORECASE)
    if not mf:
        mf = re.search(r'(?:file|src)\s*:\s*["\']([^"\']+)["\']', arr_txt, re.IGNORECASE)

    if mf:
        return html.unescape(mf.group(1)).strip()

    return None

def prehrajto_try_resolve_and_play(title: str, page_url: str) -> bool:
    start = time.time()
    try:
        detail_html = _http_get(page_url)
    except Exception as e:
        _manual_log("prehrajto", "RESOLVE_FAIL", xbmc.LOGWARNING, stage="detail", ms=_manual_elapsed_ms(start), title=title, error=repr(e), url=page_url)
        return False

    direct = _try_extract_sources_from_html(detail_html)
    if not direct:
        _manual_log("prehrajto", "RESOLVE_FAIL", xbmc.LOGWARNING, stage="sources", ms=_manual_elapsed_ms(start), title=title, url=page_url)
        return False

    if direct.startswith("/"):
        direct = urllib.parse.urljoin(_PREHRAJTO_BASE, direct)

    _manual_log("prehrajto", "PLAY", title=title, ms=_manual_elapsed_ms(start), url=direct)
    play_url(title, direct)
    return True


# ---------------------------
# HELLLSPY (vyhledání + zobrazení + přehrávání pokud API dá direct URL)
# ---------------------------

_HELLSPY_API_BASE = "https://api.hellspy.to"
_HELLSPY_SEARCH_ENDPOINT = _HELLSPY_API_BASE + "/gw/search"
_HELLSPY_SITE_BASE = "https://www.hellspy.to/"
_HELLSPY_LIMIT = 64

def _hellspy_build_search_url(query: str, offset: int, limit: int) -> str:
    return _HELLSPY_SEARCH_ENDPOINT + "?" + urllib.parse.urlencode({
        "query": query,
        "offset": str(offset),
        "limit": str(limit),
    })

def _hellspy_extract_items_and_next(payload: dict):
    if not isinstance(payload, dict):
        return [], None
    items = payload.get("items")
    if not isinstance(items, list):
        items = []
    nxt = payload.get("nextOffset")
    try:
        nxt = int(nxt) if nxt is not None else None
    except Exception:
        nxt = None
    return items, nxt

def _hellspy_pick_direct_url(item: dict) -> str:
    """
    BEZPEČNÉ: jen pokud API už v odpovědi vrací přímé URL (mp4/m3u8).
    Neparsuje HTML stránky ani player.
    """
    if not isinstance(item, dict):
        return ""

    candidates = []

    # přímé klíče
    for key in (
        "stream", "streamUrl", "hls", "hlsUrl", "mp4", "mp4Url",
        "url", "file", "fileUrl", "download", "downloadUrl"
    ):
        v = item.get(key)
        if isinstance(v, str) and v.strip():
            candidates.append(v.strip())

    # vnořené struktury
    media = item.get("media")
    if isinstance(media, dict):
        for key in ("url", "hls", "hlsUrl", "mp4", "mp4Url"):
            v = media.get(key)
            if isinstance(v, str) and v.strip():
                candidates.append(v.strip())

    streams = item.get("streams")
    if isinstance(streams, dict):
        for key in ("hls", "mp4", "url"):
            v = streams.get(key)
            if isinstance(v, str) and v.strip():
                candidates.append(v.strip())
        # někdy je to list
    if isinstance(streams, list):
        for s in streams:
            if isinstance(s, dict):
                v = s.get("url") or s.get("src") or s.get("file")
                if isinstance(v, str) and v.strip():
                    candidates.append(v.strip())

    # vyber první, co vypadá jako přímé video
    for u in candidates:
        if _is_direct_media_url(u):
            return u

    return ""

def _hellspy_get_stream(video_id: str, video_hash: str) -> str:
    return source_common.hellspy_download_stream(video_id, video_hash, timeout=25)

def _hellspy_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default

def _hellspy_size_label(size_bytes) -> str:
    size = _hellspy_int(size_bytes)
    if size <= 0:
        return ""
    units = ("B", "KB", "MB", "GB", "TB")
    value = float(size)
    idx = 0
    while value >= 1024 and idx < len(units) - 1:
        value /= 1024.0
        idx += 1
    if idx <= 1:
        return f"{int(value)} {units[idx]}"
    return f"{value:.1f} {units[idx]}"

def _hellspy_sort_key(row: dict):
    # Hellspy mixes older derived ids first; newer ids are much more likely to
    # produce live CDN links, so keep the API page but prefer the fresh entries.
    return (
        _hellspy_int((row or {}).get("id")),
        _hellspy_int((row or {}).get("size")),
        str((row or {}).get("title") or "").lower(),
    )

def hellspy_search_all(query: str, limit: int = _HELLSPY_LIMIT, max_pages: int = 50, sleep_s: float = 0.0):
    seen = set()
    out = []

    offset = 0
    next_offset = None

    for _page in range(1, max_pages + 1):
        use_offset = next_offset if next_offset is not None else offset
        url = _hellspy_build_search_url(query, use_offset, limit)

        payload = _http_get_json(url)
        items, nxt = _hellspy_extract_items_and_next(payload)

        if not items:
            break

        added = 0
        for it in items:
            title = (it.get("title") or "").strip()
            vid = it.get("id")
            hsh = it.get("fileHash") or it.get("hash")
            if not (title and vid and hsh):
                continue

            item_url = f"{_HELLSPY_SITE_BASE}video/{hsh}/{vid}"
            if item_url in seen:
                continue
            seen.add(item_url)

            # direct ber jen pokud už ho search API samo vrátí
            direct = _hellspy_pick_direct_url(it)

            out.append({
                "title": re.sub(r"\s+", " ", title),
                "url": item_url,
                "direct": direct,
                "id": str(vid),
                "fileHash": str(hsh),
            })
            added += 1

        if added == 0:
            break

        if nxt is not None and nxt != use_offset:
            next_offset = nxt
        else:
            offset = use_offset + limit
            next_offset = None

        if sleep_s > 0:
            time.sleep(sleep_s)

    return out

def hellspy_search_ui():
    q = xbmcgui.Dialog().input("Hellspy – zadej hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return

    results = hellspy_search_all(q.strip(), limit=_HELLSPY_LIMIT, max_pages=20, sleep_s=0.0)

    xbmcplugin.setContent(addon_handle, "files")

    if not results:
        xbmcgui.Dialog().ok("Hellspy", "Nic nenalezeno.")
        main_menu()
        return

    for it in results:
        title = it.get("title") or "Bez názvu"
        url = it.get("url") or ""
        direct = it.get("direct") or ""

        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")

        u = build_url({
            "action": "other.hellspy_item",
            "title": title,
            "url": url,
            "direct": direct,
            "id": it.get("id") or "",
            "fileHash": it.get("fileHash") or "",
        })
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


# ---------------------------
# SKTONLINE (vyhledání + zobrazení) - bez requests/bs4 (Kodi-friendly)
# ---------------------------

_SKTONLINE_BASE = "https://online.sktorrent.eu/"

def _sktonline_abs(url: str, base: str) -> str:
    return urllib.parse.urljoin(base, url)

def _sktonline_search_query(query: str) -> str:
    text = " ".join((query or "").split()).strip()
    try:
        text = "".join(
            ch for ch in unicodedata.normalize("NFKD", text)
            if not unicodedata.combining(ch)
        )
    except Exception:
        pass
    return text

def _sktonline_build_search_url(query: str) -> str:
    query = _sktonline_search_query(query)
    return _sktonline_abs(
        "/search/videos?search_query=" + urllib.parse.quote(query),
        _SKTONLINE_BASE,
    )

def _sktonline_parse_forms(html_text: str):
    forms = []
    for m in re.finditer(r"<form\b([^>]*)>([\s\S]*?)</form>", html_text, re.IGNORECASE):
        attrs = m.group(1) or ""
        inner = m.group(2) or ""
        forms.append({"attrs": attrs, "inner": inner})
    return forms

def _sktonline_attr(attrs: str, name: str) -> str:
    m = re.search(r'\b' + re.escape(name) + r'\s*=\s*"([^"]*)"', attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*'([^']*)'", attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*([^\s>]+)", attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    return ""

def _sktonline_find_search_form(home_html: str):
    best = None

    for f in _sktonline_parse_forms(home_html):
        attrs = f["attrs"]
        inner = f["inner"]

        method = (_sktonline_attr(attrs, "method") or "GET").upper()
        action = _sktonline_attr(attrs, "action") or _SKTONLINE_BASE
        action_url = _sktonline_abs(action, _SKTONLINE_BASE)

        inputs = []
        for im in re.finditer(r"<input\b([^>]*)>", inner, re.IGNORECASE):
            iattrs = im.group(1) or ""
            itype = (_sktonline_attr(iattrs, "type") or "").lower()
            name = _sktonline_attr(iattrs, "name") or ""
            ph = (_sktonline_attr(iattrs, "placeholder") or "").lower()
            val = _sktonline_attr(iattrs, "value") or ""
            inputs.append({"type": itype, "name": name, "ph": ph, "value": val, "attrs": iattrs})

        cand_inputs = [i for i in inputs if i["type"] in ("search", "text")]
        if not cand_inputs:
            continue

        def score_input(i):
            nm = (i["name"] or "").lower()
            it = (i["type"] or "").lower()
            sc = 0
            if it in ("search", "text"):
                sc += 2
            if any(k in nm for k in ["q", "query", "search", "s"]):
                sc += 3
            if "search" in (i["ph"] or "") or "vyhled" in (i["ph"] or ""):
                sc += 1
            return sc

        inp = max(cand_inputs, key=score_input)
        sc = score_input(inp)

        act_low = (action_url or "").lower()
        if "search" in act_low or "vyhled" in act_low:
            sc += 2

        extra = {}
        for i in inputs:
            if (i["type"] or "").lower() == "hidden":
                hn = i["name"]
                if hn:
                    extra[hn] = i.get("value", "")

        input_name = inp["name"] or "q"

        if best is None or sc > best[0]:
            best = (sc, method, action_url, input_name, extra)

    if not best:
        return None

    return best[1], best[2], best[3], best[4]

def _sktonline_extract_results(results_html: str, base_url: str):
    def _strip_tags(s: str) -> str:
        s = re.sub(r"<[^>]+>", " ", s or "")
        s = html.unescape(s)
        s = re.sub(r"\s+", " ", s).strip()
        return s

    video_results = []
    seen_video = set()
    for m in re.finditer(
        r'<a\b([^>]*?)href=["\'](?P<href>/video/[^"\']+)["\']([^>]*)>(?P<inner>[\s\S]*?)</a>',
        results_html,
        re.IGNORECASE,
    ):
        href = (m.group("href") or "").strip()
        inner = m.group("inner") or ""
        full = _sktonline_abs(href, base_url)
        if full in seen_video:
            continue
        seen_video.add(full)

        title = ""
        for pat in (
            r'<span[^>]+class=["\'][^"\']*\bvideo-title\b[^"\']*["\'][^>]*>([\s\S]*?)</span>',
            r'<img\b[^>]+title=["\']([^"\']+)["\']',
            r'<img\b[^>]+alt=["\']([^"\']+)["\']',
        ):
            mt = re.search(pat, inner, re.IGNORECASE)
            if mt:
                title = _strip_tags(mt.group(1))
                break

        if not title:
            parts = [p for p in urllib.parse.urlparse(full).path.split("/") if p]
            title = parts[2] if len(parts) >= 3 else parts[-1] if parts else "SkTonLine"

        duration = ""
        mdur = re.search(r'<div[^>]+class=["\'][^"\']*\bduration\b[^"\']*["\'][^>]*>([\s\S]*?)</div>', inner, re.IGNORECASE)
        if mdur:
            duration = _strip_tags(mdur.group(1))
        quality = "HD" if "hd-text-icon" in inner.lower() else ""

        video_results.append({
            "title": re.sub(r"\s+", " ", title).strip(),
            "url": full,
            "quality": quality,
            "duration": duration,
        })

    if video_results:
        return video_results

    return []

    links = []

    for m in re.finditer(r'<a\b([^>]*?)href=["\']([^"\']+)["\']([^>]*)>([\s\S]*?)</a>',
                         results_html, re.IGNORECASE):
        pre = m.group(1) or ""
        href = (m.group(2) or "").strip()
        post = m.group(3) or ""
        inner = m.group(4) or ""

        if not href or href.startswith("#") or href.lower().startswith("javascript:"):
            continue

        full = _sktonline_abs(href, base_url)
        u = urllib.parse.urlparse(full)

        if u.netloc and ("online.sktorrent.eu" not in u.netloc):
            continue

        path = u.path or "/"
        if path == "/":
            continue

        path_low = path.lower()
        if path_low.startswith("/static/") or path_low.startswith("/assets/"):
            continue

        attrs_all = (pre + " " + post)

        mt = re.search(r'title=["\']([^"\']+)["\']', attrs_all, re.IGNORECASE)
        title = html.unescape(mt.group(1)).strip() if mt else ""

        if not title:
            title = _strip_tags(inner)

        parts = [p for p in path.split("/") if p]
        if (not title) or title.strip().lower() in ("video", "nahrat video", "nahrát video"):
            if parts:
                cand = parts[-1]
                if cand.lower() == "video" and len(parts) >= 2:
                    cand = parts[-2]
                title = cand

        title = re.sub(r"\s+", " ", title).strip()

        low = (full + " " + title).lower()
        if any(x in low for x in [
            "login", "register", "signup", "sign-in", "logout",
            "contact", "about", "privacy", "terms",
            "dmca", "faq", "advertise", "webmasters",
        ]):
            continue

        links.append((full, path, title))

    if not links:
        return []

    segs = []
    banned_first_segments = {
        "search", "home", "index", "category", "tag", "genres", "years", "page",
        "static", "assets", "css", "js", "img", "images", "fonts",
    }

    for _, path, _ in links:
        parts = [p for p in path.split("/") if p]
        if len(parts) < 2:
            continue
        seg = parts[0].lower()
        if seg in banned_first_segments:
            continue
        segs.append(seg)

    seg = Counter(segs).most_common(1)[0][0] if segs else None

    results = []
    seen = set()

    for full, path, title in links:
        parts = [p for p in path.split("/") if p]
        if len(parts) < 2:
            continue

        if seg and parts[0].lower() != seg:
            continue

        if parts and parts[0].lower() in {"static", "assets"}:
            continue

        if full in seen:
            continue
        seen.add(full)

        results.append({"title": title, "url": full})

    return results

def _sktonline_find_next_page_url(current_html: str, current_url: str):
    m = re.search(r'<a[^>]+rel=["\']next["\'][^>]+href=["\']([^"\']+)["\']', current_html, re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1), current_url)

    pag = re.search(r'(<ul[^>]*class="[^"]*pagination[^"]*"[^>]*>[\s\S]*?</ul>)', current_html, re.IGNORECASE)
    if pag:
        ul = pag.group(1)
        mact = re.search(r'<li[^>]*class="[^"]*\bactive\b[^"]*"[^>]*>[\s\S]*?</li>\s*<li[^>]*>[\s\S]*?<a[^>]+href=["\']([^"\']+)["\']', ul, re.IGNORECASE)
        if mact:
            return _sktonline_abs(mact.group(1), current_url)

        mnext = re.search(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>\s*(?:»|&raquo;|next|další|dalsi|>)\s*</a>', ul, re.IGNORECASE)
        if mnext:
            return _sktonline_abs(mnext.group(1), current_url)

    return None

def sktonline_search_all_pages(query: str, max_pages: int = 50):
    home_html = _http_get(_SKTONLINE_BASE)
    form_info = _sktonline_find_search_form(home_html)

    if not form_info:
        method = "GET"
        action_url = _SKTONLINE_BASE
        input_name = "s"
        extra = {}
    else:
        method, action_url, input_name, extra = form_info

    data = dict(extra or {})
    data[input_name] = query

    if method == "POST":
        cur_url = action_url
        cur_html = _http_post(action_url, data=data)
    else:
        qs = urllib.parse.urlencode(data)
        sep = "&" if ("?" in action_url) else "?"
        cur_url = action_url + sep + qs
        cur_html = _http_get(cur_url)

    out = []
    seen_items = set()
    seen_pages = set()
    seen_pages.add(cur_url)

    for _page in range(1, max_pages + 1):
        results = _sktonline_extract_results(cur_html, cur_url)
        for r in results:
            u = r.get("url") or ""
            if not u or u in seen_items:
                continue
            seen_items.add(u)
            out.append(r)

        next_url = _sktonline_find_next_page_url(cur_html, cur_url)
        if not next_url:
            break

        if next_url in seen_pages:
            break
        seen_pages.add(next_url)
        cur_url = next_url
        cur_html = _http_get(cur_url)

    return out

def sktonline_search_ui():
    q = xbmcgui.Dialog().input("SkTonLine – zadej hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return

    results = sktonline_search_all_pages(q.strip(), max_pages=60)

    xbmcplugin.setContent(addon_handle, "files")

    if not results:
        xbmcgui.Dialog().ok("SkTonLine", "Nic nenalezeno.")
        main_menu()
        return

    for it in results:
        title = it.get("title") or "Bez názvu"
        url = it.get("url") or ""

        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")

        u = build_url({"action": "other.sktonline_item", "title": title, "url": url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle)


# ---------------------------
# SKTONLINE – resolver přímých streamů (detail/embed/script/download)
# ---------------------------

import xbmcvfs

def _dump_text_to_temp(filename: str, text: str):
    try:
        path = xbmcvfs.translatePath("special://temp/" + filename)
        f = xbmcvfs.File(path, "w")
        f.write(text or "")
        f.close()
        xbmc.log(f"[IKARUS][SKT] dumped: {path}", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log(f"[IKARUS][SKT] dump failed: {e}", xbmc.LOGERROR)

def _sktonline_abs(url: str, base: str) -> str:
    return urllib.parse.urljoin(base, url)

def _sktonline_parse_tag_attr(tag_attrs: str, name: str) -> str:
    m = re.search(r'\b' + re.escape(name) + r'\s*=\s*"([^"]*)"', tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*'([^']*)'", tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    m = re.search(r"\b" + re.escape(name) + r"\s*=\s*([^\s>]+)", tag_attrs, re.IGNORECASE)
    if m:
        return m.group(1)
    return ""

def _sktonline_guess_label_from_url(u: str) -> str:
    ul = (u or "").lower()
    m = re.search(r'(\d{3,4})p', ul)
    if m:
        return m.group(1) + "p"
    if ".m3u8" in ul:
        return "HLS"
    if ".mp4" in ul:
        return "MP4"
    return "Zdroj"

def _sktonline_find_embed_url_anywhere(detail_html: str, base_url: str):
    if not detail_html:
        return None

    txt = html.unescape(detail_html)

    m = re.search(r'<iframe\b[^>]*\bsrc\s*=\s*["\']([^"\']*?/embed/[^"\']+)["\']', txt, re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1).strip(), base_url)

    m = re.search(r'(https?://online\.sktorrent\.eu/embed/[a-zA-Z0-9]+)', txt, re.IGNORECASE)
    if m:
        return m.group(1).strip()

    m = re.search(r'(/embed/[a-zA-Z0-9]+)', txt, re.IGNORECASE)
    if m:
        return _sktonline_abs(m.group(1).strip(), base_url)

    return None

def _sktonline_extract_video_sources(detail_html: str, page_url: str):
    if not detail_html:
        return []

    mv = re.search(r'(<video\b[^>]*>)([\s\S]*?)</video>', detail_html, re.IGNORECASE)
    if not mv:
        return []

    video_open = mv.group(1) or ""
    inner = mv.group(2) or ""
    out = []
    seen = set()

    for sm in re.finditer(r'<source\b([^>]*?)>', inner, re.IGNORECASE):
        attrs = sm.group(1) or ""
        src = _sktonline_parse_tag_attr(attrs, "src")
        if not src:
            continue
        src = html.unescape(src).strip()
        if not src:
            continue
        full = _sktonline_abs(src, page_url)
        if full in seen:
            continue
        seen.add(full)
        label = _sktonline_parse_tag_attr(attrs, "label") or _sktonline_parse_tag_attr(attrs, "res") or _sktonline_parse_tag_attr(attrs, "data-res")
        label = html.unescape(label).strip() if label else _sktonline_guess_label_from_url(full)
        out.append({"label": label, "src": full})

    if not out:
        vsrc = _sktonline_parse_tag_attr(video_open, "src") or _sktonline_parse_tag_attr(video_open, "data-src")
        if vsrc:
            full = _sktonline_abs(html.unescape(vsrc).strip(), page_url)
            out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    return out

def _sktonline_extract_sources_from_scripts(detail_html: str, base_url: str):
    if not detail_html:
        return []
    txt2 = html.unescape(detail_html)

    out = []
    seen = set()

    for m in re.finditer(r'(?:(?:"|\')?(?:file|src)(?:"|\')?\s*:\s*(?:"|\')([^"\']+?)(?:"|\'))', txt2, re.IGNORECASE):
        u = (m.group(1) or "").strip()
        if not u:
            continue
        ul = u.lower()
        if (".mp4" not in ul) and (".m3u8" not in ul) and ("m3u8" not in ul) and ("mp4" not in ul) and ("/hls" not in ul) and ("/stream" not in ul):
            continue
        full = _sktonline_abs(u, base_url)
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    for m in re.finditer(r'(https?://[^"\'\s<>]+?\.(?:m3u8|mp4)(?:\?[^"\'\s<>]+)?)', txt2, re.IGNORECASE):
        u = (m.group(1) or "").strip()
        if not u:
            continue
        if u in seen:
            continue
        seen.add(u)
        out.append({"label": _sktonline_guess_label_from_url(u), "src": u})

    for m in re.finditer(r'(["\'])(/[^"\']+?\.(?:m3u8|mp4)(?:\?[^"\']+)?)\1', txt2, re.IGNORECASE):
        u = (m.group(2) or "").strip()
        if not u:
            continue
        full = _sktonline_abs(u, base_url)
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "src": full})

    return out

def _sktonline_extract_download_links(html_text: str, base_url: str):
    out = []
    seen = set()
    if not html_text:
        return out

    txt2 = html.unescape(html_text)

    for m in re.finditer(r'<a\b([^>]*?)href=["\']([^"\']+)["\']([^>]*)>', txt2, re.IGNORECASE):
        pre = m.group(1) or ""
        href = (m.group(2) or "").strip()
        post = m.group(3) or ""
        if not href:
            continue
        low = href.lower()
        if not any(k in low for k in ("download", "/download/", "/get/", "/file/", "/dl/")):
            continue
        full = _sktonline_abs(href, base_url)
        if full in seen:
            continue
        seen.add(full)
        attrs = (pre + " " + post)
        mt = re.search(r'title=["\']([^"\']+)["\']', attrs, re.IGNORECASE)
        label = html.unescape(mt.group(1)).strip() if mt else _sktonline_guess_label_from_url(full)
        out.append({"label": label, "url": full})

    for m in re.finditer(r'(https?://[^"\'\s<>]+/(?:download|get|file|dl)/[^"\'\s<>]+)', txt2, re.IGNORECASE):
        full = html.unescape(m.group(1)).strip()
        if not full:
            continue
        if full in seen:
            continue
        seen.add(full)
        out.append({"label": _sktonline_guess_label_from_url(full), "url": full})

    return out

def _http_follow_to_final_url(url: str, referer: str = None, timeout: int = 25) -> str:
    return source_common.follow_to_final_url(url, _OPENER, referer=referer, timeout=timeout)

def _sktonline_merge_sources(*lists):
    out = []
    seen = set()
    for lst in lists:
        for s in (lst or []):
            u = (s.get("src") or "").strip()
            if not u:
                continue
            if u in seen:
                continue
            seen.add(u)
            lab = (s.get("label") or "").strip() or _sktonline_guess_label_from_url(u)
            out.append({"label": lab, "src": u})

    def _rank(label):
        m = re.search(r'(\d{3,4})p', (label or "").lower())
        if m:
            try:
                return -int(m.group(1))
            except Exception:
                pass
        if "hls" in (label or "").lower():
            return -1
        return 0

    out.sort(key=lambda x: _rank(x.get("label", "")))
    return out

def _cookie_header_for_url(url: str) -> str:
    return source_common.cookie_header_for_url(_COOKIEJAR, url, relaxed_domain=True)

def _probe_stream(url: str, headers: dict, timeout: int = 15):
    return source_common.probe_stream(url, headers, _OPENER, timeout=timeout, log_prefix="[IKARUS][SKT][PROBE]")

def _hellspy_stream_is_available(url: str, headers: dict):
    info = source_common.probe_stream(
        url,
        headers,
        _OPENER,
        timeout=8,
        log_prefix="[IKARUS][HELLSPY][PROBE]",
    )
    if info.get("ok"):
        return True, ""
    return False, info.get("error") or "stream probe failed"

def sktonline_try_resolve_and_play(title: str, page_url: str) -> bool:
    start = time.time()
    detail_html = ""
    embed_html = ""
    embed_url = ""

    try:
        detail_html = _http_get(page_url, referer=_SKTONLINE_BASE)
    except Exception as e:
        _dump_text_to_temp("skt_detail.html", detail_html)
        _dump_text_to_temp("skt_embed.html", embed_html)
        _dump_text_to_temp("skt_debug.txt", f"page_url={page_url}\nembed_url={embed_url}\nerror={repr(e)}\n")
        _manual_log("sktonline", "RESOLVE_FAIL", xbmc.LOGWARNING, stage="detail", ms=_manual_elapsed_ms(start), title=title, error=repr(e), url=page_url)
        return False

    embed_url = _sktonline_find_embed_url_anywhere(detail_html, page_url)
    embed_html = ""
    if embed_url:
        try:
            embed_html = _http_get(embed_url, referer=page_url)
        except Exception as e:
            embed_html = ""
            _dump_text_to_temp("skt_debug.txt", f"page_url={page_url}\nembed_url={embed_url}\nembed_error={repr(e)}\n")

    sources_detail = _sktonline_extract_video_sources(detail_html, page_url)
    sources_embed = _sktonline_extract_video_sources(embed_html, embed_url) if embed_html and embed_url else []

    sources_script_detail = _sktonline_extract_sources_from_scripts(detail_html, page_url)
    sources_script_embed = _sktonline_extract_sources_from_scripts(embed_html, embed_url) if embed_html and embed_url else []

    sources = _sktonline_merge_sources(sources_detail, sources_embed, sources_script_detail, sources_script_embed)

    if not sources:
        dl = []
        dl += _sktonline_extract_download_links(detail_html, page_url)
        if embed_html and embed_url:
            dl += _sktonline_extract_download_links(embed_html, embed_url)

        for it in dl:
            durl = it.get("url")
            if not durl:
                continue
            final = _http_follow_to_final_url(durl, referer=embed_url or page_url)
            if final and _is_direct_media_url(final):
                sources.append({"label": it.get("label") or _sktonline_guess_label_from_url(final), "src": final})

    if not sources:
        _manual_log("sktonline", "RESOLVE_FAIL", xbmc.LOGWARNING, stage="sources", ms=_manual_elapsed_ms(start), title=title, embed=bool(embed_url), url=page_url)
        return False

    labels = [(s.get("label") or "Zdroj").strip() for s in sources]

    ref = _sanitize_url(page_url)

    base_headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/122.0.0.0 Safari/537.36"
        ),
        "Referer": ref,
        "Origin": "https://online.sktorrent.eu",
        "Accept": "*/*",
    }

    if len(sources) == 1:
        src1 = (sources[0].get("src") or "").strip()
        headers = dict(base_headers)

        ck = _cookie_header_for_url(src1)
        if ck:
            headers["Cookie"] = ck

        xbmc.log(f"[IKARUS][SKT] PLAY: {src1}", xbmc.LOGWARNING)
        xbmc.log(f"[IKARUS][SKT] HDR: {headers}", xbmc.LOGWARNING)
        probe = _probe_stream(src1, headers, timeout=6)
        if isinstance(probe, dict) and probe.get("ok") is False:
            _manual_log("sktonline", "RESOLVE_FAIL", xbmc.LOGWARNING, stage="probe", ms=_manual_elapsed_ms(start), title=title, url=src1, error=probe.get("error"))
            return False
        _manual_log("sktonline", "PLAY", title=title, sources=len(sources), ms=_manual_elapsed_ms(start), url=src1)
        play_url(title, src1, headers=headers)
        return True

    idx = xbmcgui.Dialog().select("Vyber kvalitu", labels)
    if idx is None or idx < 0:
        _manual_log("sktonline", "CANCEL", title=title, sources=len(sources), ms=_manual_elapsed_ms(start))
        return True

    picked = sources[idx]
    stream_url = (picked.get("src") or "").strip()
    if not stream_url:
        _manual_log("sktonline", "RESOLVE_FAIL", xbmc.LOGWARNING, stage="empty_source", ms=_manual_elapsed_ms(start), title=title)
        return False

    headers = dict(base_headers)
    ck = _cookie_header_for_url(stream_url)
    if ck:
        headers["Cookie"] = ck

    picked_label = (picked.get("label") or "").strip()
    play_title = f"{title} ({picked_label})" if picked_label else title

    xbmc.log(f"[IKARUS][SKT] PLAY: {stream_url}", xbmc.LOGWARNING)
    xbmc.log(f"[IKARUS][SKT] HDR: {headers}", xbmc.LOGWARNING)
    probe = _probe_stream(stream_url, headers, timeout=6)
    if isinstance(probe, dict) and probe.get("ok") is False:
        _manual_log("sktonline", "RESOLVE_FAIL", xbmc.LOGWARNING, stage="probe", ms=_manual_elapsed_ms(start), title=title, url=stream_url, error=probe.get("error"))
        return False
    _manual_log("sktonline", "PLAY", title=play_title, sources=len(sources), picked=picked_label, ms=_manual_elapsed_ms(start), url=stream_url)
    play_url(play_title, stream_url, headers=headers)
    return True


# ---------------------------
# FAST MANUAL SEARCH UI
# ---------------------------

def prehrajto_search_page(query: str, page: int = 1):
    page = max(1, int(page or 1))
    html_text = _http_get(_build_prehrajto_search_url(query, page), timeout=12)
    return _extract_prehrajto_results(html_text)


def prehrajto_search_ui():
    q = xbmcgui.Dialog().input("Prehraj.to - zadej hledany vyraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return
    _manual_remember("prehrajto", q.strip(), page=1)
    prehrajto_results_ui(q.strip(), page=1, force=True)


def prehrajto_results_ui(q: str, page: int = 1, force: bool = False):
    q = (q or "").strip()
    page = max(1, int(page or 1))
    if not q:
        prehrajto_search_ui()
        return

    cache_payload = {"q": q, "page": page}
    cached = None if force else _manual_cache_get("prehrajto", cache_payload)
    if cached is not None:
        results = cached or []
        _manual_log("prehrajto", "CACHE", q=q, page=page, rows=len(results))
    else:
        start = time.time()
        try:
            results = prehrajto_search_page(q, page=page)
        except Exception as e:
            _manual_log("prehrajto", "SEARCH_FAIL", xbmc.LOGERROR, q=q, page=page, ms=_manual_elapsed_ms(start), error=repr(e))
            results = []
        _manual_cache_set("prehrajto", cache_payload, results)
        _manual_log("prehrajto", "SEARCH", q=q, page=page, rows=len(results), ms=_manual_elapsed_ms(start))

    xbmcplugin.setContent(addon_handle, "files")
    xbmcplugin.setPluginCategory(addon_handle, f"Prehraj.to: {q}")
    _add_manual_nav("Prehraj.to", "other.prehrajto", {"action": "other.prehrajto.results", "q": q, "page": page})

    if not results:
        _add_empty_row("Nic nenalezeno.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True, cacheToDisc=True)
        return

    for it in results:
        title = it.get("title") or "Bez nazvu"
        url = it.get("url") or ""
        label = _manual_source_label(
            title,
            audio=_manual_audio_tag(title),
            quality=_manual_quality_tag(title),
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({"action": "other.prehrajto_item", "title": title, "url": url}),
            listitem=li,
            isFolder=False,
        )

    li_next = xbmcgui.ListItem(label="Dalsi stranka >>")
    li_next.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(
        handle=addon_handle,
        url=build_url({"action": "other.prehrajto.results", "q": q, "page": page + 1}),
        listitem=li_next,
        isFolder=True,
    )
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, cacheToDisc=True)


def hellspy_search_page(query: str, offset: int = 0, limit: int = _HELLSPY_LIMIT):
    offset = max(0, int(offset or 0))
    limit = max(1, min(100, int(limit or _HELLSPY_LIMIT)))
    payload = _http_get_json(_hellspy_build_search_url(query, offset, limit), timeout=12)
    items, next_offset = _hellspy_extract_items_and_next(payload)
    out = []
    seen = set()

    for it in items:
        title = (it.get("title") or "").strip()
        vid = it.get("id")
        hsh = it.get("fileHash") or it.get("hash")
        if not (title and vid and hsh):
            continue
        item_url = f"{_HELLSPY_SITE_BASE}video/{hsh}/{vid}"
        seen_key = str(hsh or item_url).strip()
        if seen_key in seen:
            continue
        seen.add(seen_key)
        size = it.get("size") or it.get("fileSize") or it.get("filesize") or 0
        duration = it.get("duration") or it.get("length") or ""
        out.append({
            "title": re.sub(r"\s+", " ", title),
            "url": item_url,
            "direct": _hellspy_pick_direct_url(it),
            "id": str(vid),
            "fileHash": str(hsh),
            "size": _hellspy_int(size),
            "duration": str(duration or ""),
        })

    out.sort(key=_hellspy_sort_key, reverse=True)
    if next_offset is None and len(items) >= limit:
        next_offset = offset + limit
    return out, next_offset


def hellspy_search_ui():
    q = xbmcgui.Dialog().input("Hellspy - zadej hledany vyraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return
    _manual_remember("hellspy", q.strip(), offset=0)
    hellspy_results_ui(q.strip(), offset=0, force=True)


def hellspy_results_ui(q: str, offset: int = 0, force: bool = False):
    q = (q or "").strip()
    offset = max(0, int(offset or 0))
    if not q:
        hellspy_search_ui()
        return

    cache_payload = {"q": q, "offset": offset, "limit": _HELLSPY_LIMIT, "order": "fresh-id-v1"}
    cached = None if force else _manual_cache_get("hellspy", cache_payload)
    if cached is not None:
        results = cached.get("results") or []
        next_offset = cached.get("next_offset")
        _manual_log("hellspy", "CACHE", q=q, offset=offset, rows=len(results), next=next_offset)
    else:
        start = time.time()
        try:
            results, next_offset = hellspy_search_page(q, offset=offset, limit=_HELLSPY_LIMIT)
        except Exception as e:
            _manual_log("hellspy", "SEARCH_FAIL", xbmc.LOGERROR, q=q, offset=offset, ms=_manual_elapsed_ms(start), error=repr(e))
            results, next_offset = [], None
        _manual_cache_set("hellspy", cache_payload, {"results": results, "next_offset": next_offset})
        _manual_log("hellspy", "SEARCH", q=q, offset=offset, rows=len(results), next=next_offset, ms=_manual_elapsed_ms(start))

    xbmcplugin.setContent(addon_handle, "files")
    xbmcplugin.setPluginCategory(addon_handle, f"Hellspy: {q}")
    _add_manual_nav("Hellspy", "other.hellspy", {"action": "other.hellspy.results", "q": q, "offset": offset})

    if not results:
        _add_empty_row("Nic nenalezeno.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True, cacheToDisc=True)
        return

    for it in results:
        title = it.get("title") or "Bez nazvu"
        size_label = _hellspy_size_label(it.get("size"))
        label = _manual_source_label(
            title,
            audio=_manual_audio_tag(title),
            quality=_manual_quality_tag(title),
            size=size_label,
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({
                "action": "other.hellspy_item",
                "title": title,
                "url": it.get("url") or "",
                "direct": it.get("direct") or "",
                "id": it.get("id") or "",
                "fileHash": it.get("fileHash") or "",
            }),
            listitem=li,
            isFolder=False,
        )

    if next_offset is not None and int(next_offset) != offset:
        li_next = xbmcgui.ListItem(label="Dalsi vysledky >>")
        li_next.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({"action": "other.hellspy.results", "q": q, "offset": int(next_offset)}),
            listitem=li_next,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, cacheToDisc=True)


def sktonline_search_page(query: str, page_url: str = ""):
    query = (query or "").strip()
    page_url = (page_url or "").strip()

    if page_url:
        cur_url = page_url
        cur_html = _http_get(cur_url, timeout=12)
    else:
        cur_url = _sktonline_build_search_url(query)
        cur_html = _http_get(cur_url, timeout=12)

    results = _sktonline_extract_results(cur_html, cur_url)
    next_url = _sktonline_find_next_page_url(cur_html, cur_url)
    if next_url == cur_url:
        next_url = ""
    return results, next_url or "", cur_url


def sktonline_search_ui():
    q = xbmcgui.Dialog().input("SkTonLine - zadej hledany vyraz", type=xbmcgui.INPUT_ALPHANUM)
    if not q or not q.strip():
        main_menu()
        return
    _manual_remember("sktonline", q.strip(), page_url="")
    sktonline_results_ui(q.strip(), page_url="", force=True)


def sktonline_results_ui(q: str, page_url: str = "", force: bool = False):
    q = (q or "").strip()
    page_url = (page_url or "").strip()
    if not q:
        sktonline_search_ui()
        return

    cache_payload = {"q": q, "page_url": page_url, "parser": "video-card-v4", "web_q": _sktonline_search_query(q)}
    cached = None if force else _manual_cache_get("sktonline", cache_payload)
    if cached is not None:
        results = cached.get("results") or []
        next_url = cached.get("next_url") or ""
        cur_url = cached.get("cur_url") or page_url
        _manual_log("sktonline", "CACHE", q=q, rows=len(results), next=bool(next_url), page_url=page_url)
    else:
        start = time.time()
        try:
            results, next_url, cur_url = sktonline_search_page(q, page_url=page_url)
        except Exception as e:
            _manual_log("sktonline", "SEARCH_FAIL", xbmc.LOGERROR, q=q, page_url=page_url, ms=_manual_elapsed_ms(start), error=repr(e))
            results, next_url, cur_url = [], "", page_url
        _manual_cache_set("sktonline", cache_payload, {"results": results, "next_url": next_url, "cur_url": cur_url})
        _manual_log("sktonline", "SEARCH", q=q, rows=len(results), next=bool(next_url), ms=_manual_elapsed_ms(start), page_url=page_url)

    xbmcplugin.setContent(addon_handle, "files")
    xbmcplugin.setPluginCategory(addon_handle, f"SkTonLine: {q}")
    _add_manual_nav(
        "SkTonLine",
        "other.sktonline",
        {"action": "other.sktonline.results", "q": q, "page_url": page_url},
    )

    if not results:
        _add_empty_row("Nic nenalezeno.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True, cacheToDisc=True)
        return

    for it in results:
        title = it.get("title") or "Bez nazvu"
        url = it.get("url") or ""
        label = _manual_source_label(
            title,
            audio=_manual_audio_tag(title),
            quality=_manual_quality_tag(title, it.get("quality") or ""),
            extra=it.get("duration") or "",
        )
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultVideo.png", "thumb": "DefaultVideo.png", "poster": "DefaultVideo.png"})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({"action": "other.sktonline_item", "title": title, "url": url}),
            listitem=li,
            isFolder=False,
        )

    if next_url:
        li_next = xbmcgui.ListItem(label="Dalsi stranka >>")
        li_next.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=build_url({"action": "other.sktonline.results", "q": q, "page_url": next_url}),
            listitem=li_next,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, cacheToDisc=True)


# ---------------------------
# ROUTER
# ---------------------------

def _router_impl():
    _refresh_runtime()
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(paramstring)) if paramstring else {}
    action = params.get("action") or ""

    if not action or action == "other_sources":
        main_menu()
        return

    # Přehraj.to
    if action == "other.prehrajto":
        active = _manual_active("prehrajto")
        if (params.get("new") or "") != "1" and active.get("q"):
            prehrajto_results_ui(active.get("q") or "", page=int(active.get("page") or 1), force=False)
            return
        prehrajto_search_ui()
        return

    if action == "other.prehrajto.results":
        _manual_remember("prehrajto", params.get("q") or "", page=int(params.get("page") or "1"))
        prehrajto_results_ui(
            params.get("q") or "",
            page=int(params.get("page") or "1"),
            force=(params.get("force") or "") == "1",
        )
        return

    if action == "other.prehrajto_item":
        play_start = time.time()
        title = params.get("title") or "Přehraj.to"
        url = params.get("url") or ""
        if not url:
            _manual_missing_param("prehrajto", "url", title=title)
            return

        if _is_direct_media_url(url):
            _manual_log("prehrajto", "PLAY", title=title, mode="direct", ms=_manual_elapsed_ms(play_start), url=url)
            play_url(title, url)
            return

        ok = prehrajto_try_resolve_and_play(title, url)
        if ok:
            return

        _manual_play_failed(
            "prehrajto",
            "manual resolve failed",
            title=title,
            url=url,
            dialog_title="Přehraj.to",
            dialog_message=(
            "Nepodařilo se získat přímý odkaz ze stránky (FREE cesta).\n"
            "Na stránce se nepodařilo najít 'var sources' s položkou 'file/src'.\n\n"
            f"URL:\n{url}"
            ),
        )
        return

    # Hellspy
    if action == "other.hellspy":
        active = _manual_active("hellspy")
        if (params.get("new") or "") != "1" and active.get("q"):
            hellspy_results_ui(active.get("q") or "", offset=int(active.get("offset") or 0), force=False)
            return
        hellspy_search_ui()
        return

    if action == "other.hellspy.results":
        _manual_remember("hellspy", params.get("q") or "", offset=int(params.get("offset") or "0"))
        hellspy_results_ui(
            params.get("q") or "",
            offset=int(params.get("offset") or "0"),
            force=(params.get("force") or "") == "1",
        )
        return

    if action == "other.hellspy_item":
        play_start = time.time()
        title = params.get("title") or "Hellspy"
        url = params.get("url") or ""
        direct = params.get("direct") or ""
        video_id = params.get("id") or ""
        video_hash = params.get("fileHash") or ""
        _manual_log("hellspy", "CLICK", title=title, id=video_id, hash=video_hash, has_direct=bool(direct))

        if not direct and not url and not (video_id and video_hash):
            _manual_missing_param("hellspy", "url/direct/id+fileHash", title=title)
            return
        if video_id and not video_hash:
            _manual_missing_param("hellspy", "fileHash", title=title, url=url)
            return
        if video_hash and not video_id:
            _manual_missing_param("hellspy", "id", title=title, url=url)
            return

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            ),
            "Referer": "https://www.hellspy.to/",
            "Origin": "https://www.hellspy.to",
            "Accept": "*/*",
        }

        # 1) když už direct máme, rovnou přehrát
        if direct:
            ck = _cookie_header_for_url_basic(direct)
            if ck:
                headers["Cookie"] = ck

            ok, reason = _hellspy_stream_is_available(direct, headers)
            if not ok:
                _manual_play_failed(
                    "hellspy",
                    "hellspy stream probe failed: " + reason,
                    title=title,
                    url=direct,
                    dialog_title="Hellspy",
                    dialog_message="Stream z Hellspy momentalne neodpovida. Zkus jiny zdroj.",
                )
                return

            xbmc.log(f"[IKARUS][HELLSPY] PLAY direct={direct}", xbmc.LOGWARNING)
            _manual_log("hellspy", "PLAY", title=title, mode="direct", id=video_id, ms=_manual_elapsed_ms(play_start), url=direct)
            play_url(title, direct, headers=headers)
            return

        # 2) fallback: když by url samo bylo přehratelné
        if url and _is_direct_media_url(url):
            ck = _cookie_header_for_url_basic(url)
            if ck:
                headers["Cookie"] = ck

            ok, reason = _hellspy_stream_is_available(url, headers)
            if not ok:
                _manual_play_failed(
                    "hellspy",
                    "hellspy stream probe failed: " + reason,
                    title=title,
                    url=url,
                    dialog_title="Hellspy",
                    dialog_message="Stream z Hellspy momentalne neodpovida. Zkus jiny zdroj.",
                )
                return

            xbmc.log(f"[IKARUS][HELLSPY] PLAY url={url}", xbmc.LOGWARNING)
            _manual_log("hellspy", "PLAY", title=title, mode="url", id=video_id, ms=_manual_elapsed_ms(play_start), url=url)
            play_url(title, url, headers=headers)
            return

        # 3) stejně jako v main.py: až po kliknutí vezmeme id + hash a získáme stream
        if video_id and video_hash:
            resolve_start = time.time()
            direct = _hellspy_get_stream(video_id, video_hash)
            _manual_log("hellspy", "DOWNLOAD", title=title, id=video_id, ok=bool(direct), ms=_manual_elapsed_ms(resolve_start))
            if direct:
                ck = _cookie_header_for_url_basic(direct)
                if ck:
                    headers["Cookie"] = ck

                ok, reason = _hellspy_stream_is_available(direct, headers)
                if not ok:
                    _manual_play_failed(
                        "hellspy",
                        "hellspy stream probe failed: " + reason,
                        title=title,
                        url=direct,
                        dialog_title="Hellspy",
                        dialog_message="Stream z Hellspy momentalne neodpovida. Zkus jiny zdroj.",
                    )
                    return

                xbmc.log(f"[IKARUS][HELLSPY] PLAY resolved={direct}", xbmc.LOGWARNING)
                _manual_log("hellspy", "PLAY", title=title, mode="resolved", id=video_id, ms=_manual_elapsed_ms(play_start), url=direct)
                play_url(title, direct, headers=headers)
                return

        _manual_play_failed(
            "hellspy",
            "manual stream url failed",
            title=title,
            url=url,
            dialog_title="Hellspy",
            dialog_message=(
            "Přehrávání není možné, protože se nepodařilo získat stream URL.\n\n"
            f"Stránka:\n{url}"
            ),
        )
        return

    # SkTonLine
    if action == "other.sktonline":
        active = _manual_active("sktonline")
        if (params.get("new") or "") != "1" and active.get("q"):
            sktonline_results_ui(active.get("q") or "", page_url=active.get("page_url") or "", force=False)
            return
        sktonline_search_ui()
        return

    if action == "other.sktonline.results":
        _manual_remember("sktonline", params.get("q") or "", page_url=params.get("page_url") or "")
        sktonline_results_ui(
            params.get("q") or "",
            page_url=params.get("page_url") or "",
            force=(params.get("force") or "") == "1",
        )
        return

    if action == "other.sktonline_item":
        play_start = time.time()
        title = params.get("title") or "SkTonLine"
        url = params.get("url") or ""
        if not url:
            _manual_missing_param("sktonline", "url", title=title)
            return

        if _is_direct_media_url(url):
            _manual_log("sktonline", "PLAY", title=title, mode="direct", ms=_manual_elapsed_ms(play_start), url=url)
            play_url(title, url)
            return

        ok = sktonline_try_resolve_and_play(title, url)
        if ok:
            return

        _manual_play_failed(
            "sktonline",
            "manual resolve failed",
            title=title,
            url=url,
            dialog_title="SkTonLine",
            dialog_message=(
            "Nepodařilo se získat přímé zdroje z detailu / embedu."
            "Nenašel jsem <video>/<source>, přímé odkazy ve <script>, ani funkční download redirect."
            f"URL:\n{url}"
            ),
        )
        return

    # fallback
    main_menu()


def router():
    _refresh_runtime()
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(paramstring)) if paramstring else {}
    action = params.get("action") or "other_sources"
    with diagnostics.action_scope("other_sources", action, params):
        return _router_impl()

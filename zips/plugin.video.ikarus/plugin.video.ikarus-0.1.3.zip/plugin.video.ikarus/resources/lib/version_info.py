# -*- coding: utf-8 -*-
import xbmcaddon
import xbmcgui


CHANGELOG = """[B]0.1.3[/B] - info o verzi v nastavení
- Přidáno tlačítko Info o verzi do nastavení v sekci Stahování.
- Přidán přehled aktuální verze a změn přímo v nastavení pluginu.
- Do nastavení doplněn viditelný řádek s aktuální verzí pluginu.

[B]0.1.2[/B] - zobrazení změn v Kodi
- Doplněn přehled změn do metadata položky news.
- Upraveno zobrazení informací pro okno Verze v Kodi.

[B]0.1.1[/B] - navazování další epizody
- Upraveno navázání další epizody u seriálů z TMDB.
- V nastavení je nová volba Pokračovat další epizodou: automatické pokračování nebo výběrový dialog.
- Výchozí režim je automatické spuštění další epizody.
- Při potvrzení další epizody dialogem už plugin zbytečně neukončuje aktuální přehrávání hned v 80 procentech.
- Testovací notifikace pro další epizodu jsou ve výchozím stavu vypnuté.

[B]0.1.0[/B] - první verze
- První zkušební verze pluginu v Kodi repozitáři."""


def main():
    addon = xbmcaddon.Addon()
    version = addon.getAddonInfo("version") or "?"
    xbmcgui.Dialog().textviewer(
        "Ikarus - WebShare - ver {0}".format(version),
        CHANGELOG,
    )


if __name__ == "__main__":
    main()


# -*- coding: utf-8 -*-
import xbmcaddon
import xbmcgui


ADDON_ID = "plugin.video.ikarus"
NOTICE_VERSION = "2026-05-17-1"
SETTING_HIDE_ON_STARTUP = "info_notice_hide_on_startup"
SETTING_ACCEPTED_VERSION = "info_notice_accepted_version"


NOTICE_TEXT = """[B]Vítejte v Ikarusu.[/B]

Plugin Ikarus slouží pouze jako vyhledávací a informační nástroj propojující veřejně dostupné internetové zdroje a služby třetích stran.
Neobsahuje žádný vlastní multimediální obsah, databázi médií ani žádná uložená data chráněná autorským právem.
Veškeré informace a odkazy jsou získávány z veřejně dostupných zdrojů na internetu.

Plugin byl vyvíjen primárně pro soukromé, vzdělávací a testovací účely.
Instalace a používání pluginu je zcela dobrovolné a každý uživatel používá plugin výhradně na vlastní odpovědnost.

Plugin může komunikovat s externími internetovými službami za účelem získávání veřejně dostupných dat, odkazů a metadat.
Dostupnost jednotlivých funkcí závisí na externích službách a může se kdykoliv změnit bez možnosti ovlivnění ze strany autora pluginu.

Autor pluginu není provozovatelem žádné z externích služeb a není nijak spojen s poskytovateli obsahu třetích stran.
Autor nenese odpovědnost za obsah externích webů, dostupnost služeb, změny API, nefunkčnost zdrojů ani za způsob, jakým uživatel s nalezenými daty, odkazy nebo informacemi naloží.

Výsledky vyhledávání nejsou autorem pluginu ručně kontrolovány, filtrovány ani schvalovány.
Uživatel je povinen dodržovat platné zákony své země a respektovat licenční a autorská práva třetích stran.

Některé názvy služeb, loga a ochranné známky použité v pluginu jsou majetkem jejich příslušných vlastníků.
Plugin Ikarus s nimi není oficiálně propojen ani podporován jejich provozovateli.

Autor pluginu neposkytuje žádnou záruku funkčnosti a nenese odpovědnost za případné škody, ztrátu dat, omezení zařízení, omezení služeb, zablokování účtů ani jiné následky vzniklé používáním pluginu Ikarus.
Podpora pluginu může být kdykoliv změněna, omezena nebo ukončena.

Používáním pluginu uživatel potvrzuje, že s těmito informacemi souhlasí."""


def _addon():
    try:
        return xbmcaddon.Addon(ADDON_ID)
    except Exception:
        return xbmcaddon.Addon()


def _is_true(value):
    return str(value or "").strip().lower() in ("true", "1", "yes")


def show_notice(require_confirm=False):
    addon = _addon()
    dialog = xbmcgui.Dialog()
    dialog.textviewer("Ikarus - informativní upozornění", NOTICE_TEXT)

    if not require_confirm:
        return True

    agreed = dialog.yesno(
        "Ikarus",
        "Pro spuštění pluginu je potřeba potvrdit souhlas s informativním upozorněním.\n\nSouhlasíte s uvedenými informacemi?",
        nolabel="Nesouhlasím",
        yeslabel="Souhlasím",
    )
    if agreed:
        addon.setSetting(SETTING_ACCEPTED_VERSION, NOTICE_VERSION)
        return True

    return False


def ensure_startup_notice():
    addon = _addon()
    accepted_version = addon.getSetting(SETTING_ACCEPTED_VERSION) or ""
    hide_on_startup = _is_true(addon.getSetting(SETTING_HIDE_ON_STARTUP))

    if accepted_version == NOTICE_VERSION and hide_on_startup:
        return True

    return show_notice(require_confirm=True)

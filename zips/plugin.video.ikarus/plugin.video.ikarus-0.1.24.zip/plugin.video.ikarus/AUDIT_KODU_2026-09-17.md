# Audit Ikarus 0.1.22 — 17. 9. 2026

Audit se zaměřuje na ztrátu dat, chyby přehrávání, synchronizaci, stahování a odolnost při výpadcích. V době původního auditu produkční kód nebyl upraven; následné opravy jsou zaznamenané níže.

## Promitnuti polozek smazanych na jinem zarizeni

- Seznam si uchovava potvrzene clenstvi `trakt_items_snapshot`. Po uplnem nacteni odstrani drive potvrzene polozky, ktere uz Trakt nevraci.
- Lokalni pridani ma jedinecny `sync_add_id`; odesilaji se pouze takto oznacene polozky. Uspech potvrzuje clenstvi a odstrani prislusnou znacku, soubezne nove pridani zustava ve fronte.
- Soubezna zmena metadat neblokuje vzdalene smazani; nove lokalni pridani nebo opetovne pridani se zachova.
- Strankovani kontroluje hlavicky, stabilni pocty a uplnost odpovedi. Chyba, chybejici identita filmu/serialu nebo duplicitni polozka neprepise referencni clenstvi.
- Kontrola na pozadi nacita obsah i pri stejnem nebo mensim poctu polozek (dosavadni interval 10 minut).
- Stare lokalni polozky bez potvrzene historie se pri prvnim nacteni zachovaji a automaticky neodesilaji. Jejich predchozi smazani nelze spolehlive odlisit od dosud neodeslaneho pridani; explicitni pridani je znovu zaradi k odeslani.
- Overeni: 54 lokalnich regresnich testu. Zive chovani na dvou instancich Kodi zatim neovereno; zmeny nejsou nasazene.


## Navázání po přerušení chatu — 17. 9. 2026

Tento oddíl popisuje ověřenou dokončenou část oprav, nikoli uzavření všech nálezů auditu. Pracovní složka je `plugin.video.ikarus`; Cinema mód nebyl v tomto navázání upravován. Změny zatím nebyly kopírovány do Kodi ani vydány.

- `tmdb_custom_lists.save()` po úspěšném zápisu aktualizuje revizi předaného slovníku. Opakované uložení stejného aktuálního objektu již samo nevyvolá konflikt; nezávislá zastaralá kopie je nadále odmítnuta.
- Lokální vytvoření, přejmenování, přidání a odstranění při konfliktu revize znovu načtou aktuální data a aplikují požadovanou změnu, nejvýše v pěti pokusech. Chyby zápisu se neopakují ani neskrývají. Síťové operace nejsou obalené tímto opakováním.
- Doplnění metadat položek zachovává aktuální členství seznamu a vlastnictví položek. Starší výsledek načítání detailů proto nesmaže nově přidaný titul ani neobnoví mezitím odstraněný titul.
- `json_storage` ověřuje cizí proces na Windows přes procesový handle a neblokující čekání. Předchozí `os.kill(pid, 0)` může na Windows proces ukončit; viz [dokumentace Pythonu](https://docs.python.org/3.13/library/os.html#os.kill). Neznámá chyba přístupu se nepovažuje za důkaz ukončení vlastníka.

Ověření: 9 nových testů v `tests/test_storage_regressions.py`, 3 stávající testy `test_json_storage.py` a 7 testů `test_playback_queue.py` prošly. Testy používají oddělené dočasné soubory a náhrady Kodi modulů. První běh blokovala oprávnění sandboxu k dočasným adresářům; úspěšný běh proběhl s povolením mimo sandbox. Syntaxe všech 55 Python souborů a parsování 21 XML souborů jsou v pořádku. Skutečné Kodi ani Trakt API nebyly při tomto navázání spuštěny.

Po této první části zbývalo zejména oddělení Trakt fronty, snapshotu a metadat podle účtu (řešené v další části níže); migrace identity film/seriál; bezpečné sloučení výsledků síťové synchronizace při souběžné lokální změně a zpracování chyb v UI. Kontrola revize zatím brání přepsání nových dat, ale sama neřeší opakování či sloučení vzdálených operací. U zámku je ještě třeba řešit souběh více procesů při odstraňování opuštěného zámku. Ostatní původní nálezy níže nejsou tímto oddílem označené za vyřešené.

### Další část — oddělení synchronizace přehrávání podle Trakt účtu

- Fronta, vzdálený snapshot, stavový index a synchronizační kurzor nyní používají `tmdb_state/trakt_accounts/<SHA256 UUID>/`. Identita pochází z `user.ids.uuid` autentizovaného `/users/settings`; jméno účtu se k identifikaci nepoužívá. [Trakt dokumentuje UUID jako globálně jedinečný identifikátor pro lokální použití aplikací](https://docs.trakt.tv/reference/getuserssettings).
- Skrytá hodnota `trakt_account_binding` váže UUID na hash aktuálního přístupového tokenu. Samotný token se do tohoto záznamu ani do názvů složek neukládá. Obnova tokenu zachovává identitu ověřeného účtu; nové přihlášení ji musí znovu ověřit. Neúspěšná identifikace nedovolí odesílání.
- Jeden synchronizační běh drží pevnou identitu a přihlašovací údaje. Při změně tokenu či účtu se další požadavky zastaví; probíhající požadavek smí dokončit pouze s původními údaji. Totéž platí pro pracovní vlákna stránkované historie. Výsledky a chyby původního běhu se ukládají do původního účtu.
- Obnova přihlášení kontroluje původní refresh token pod souborovým zámkem, aby opožděná odpověď nepřepsala novější přihlášení. Chyba obnovy již sama nemaže přihlášení jiného účtu.
- Nové lokální přehrávací zdroje nesou `trakt_account_id`; monitor jej zachytí pro celou relaci. Automatický hromadný upload bere pouze zdroje patřící aktuálnímu účtu. Lokální historie zůstává společná pro profil a čitelná.
- Původní soubory bez vlastníka zůstávají zachované na původních cestách a automaticky se nepřiřazují žádnému účtu. Nové události bez ověřené identity se uchovávají ve složce `unassigned`; nejsou automaticky odesílány. Starší lokální historie bez vlastníka se rovněž automaticky nenahrává. Diagnostika ukazuje počty `legacy_held` a `unassigned_held`. Případný ručně potvrzený import této historie je samostatná dosud nepřidaná funkce.
- Paměťová cache i závislosti stavového indexu rozlišují účet; odhlášení nezobrazuje snapshot dřívějšího účtu jako aktivní vzdálený stav.

Ověření této části: 15 nových offline testů v `tests/test_playback_accounts.py` používá skutečný klient, frontu a synchronizační modul s náhradním HTTP transportem. Pokrývají přepnutí A/B a návrat A, přepnutí během požadavku, obnovu tokenu, odhlášení, výpadek identifikace, neznámého vlastníka, cache, snapshot, souběžné načítání stránek a dokončení přehrávání po změně účtu včetně zařazení do původní fronty. Dále prošlo 9 testů seznamů/zámků, 4 existující testy stránkování historie a 3 existující testy lokálního stavu přehrávání — celkem 31 cílených testů. Syntaxe 56 Python souborů a parsování 21 XML souborů prošly. Žádné skutečné účty ani uživatelský profil Kodi nebyly použity.

Meze této části: oddělovala synchronizaci **přehrávání**; vlastní Trakt seznamy řeší následující část. Starší externí testy synchronizace se stubem klienta bez `account_session/current_account_id` bude nutné přizpůsobit novému rozhraní; nebyly zde označené za ověřené. Přímé ověření v Kodi a vydání stále zbývají. Cinema UI, číslo verze a instalovaná kopie doplňku nebyly měněné.

### Další část — vlastní seznamy, účty a souběžné změny

- Seznamy a záznamy o jejich smazání nesou `trakt_account_id`. Nové lokální seznamy patří aktuálnímu ověřenému účtu. Nabídka seznamů a jednotlivé lokální operace zpřístupňují jeho seznamy a staré neidentifikované lokální seznamy. Jiný ověřený účet nemůže tyto seznamy přejmenovat, doplňovat ani smazat. Sdílený JSON zachovává všechny účty; synchronizace načítá pouze záznamy s přesně odpovídajícím UUID.
- Staré seznamy bez vlastníka zůstávají dostupné lokálně, nejsou automaticky odesílány ani používány k odstranění dat na Traktu. Načtení vzdálených seznamů může vedle staré lokální kopie vytvořit novou kopii se známým vlastníkem. Ruční převzetí staré kopie k účtu není součástí této opravy.
- Všechny veřejné vstupy synchronizace seznamů používají připnutou přihlašovací relaci `account_session`. Síťové běhy jednoho účtu se serializují samostatným zámkem, který neblokuje lokální editace při čekání na HTTP. Čas poslední synchronizace je oddělen podle účtu. Stejné vzdálené slugy různých účtů dostávají odlišná lokální ID.
- `load_for_sync()` zachová původní kopii a `save_sync_result()` pod lokálním souborovým zámkem sloučí původní stav, výsledek synchronizace a aktuální stav. Pomocný modul `tmdb_list_merge.py` zachovává souběžné lokální přidání, přejmenování, odstranění i doplnění metadat. Ostatní účty a lokální seznamy bez vlastníka se nemění.
- Jedinečné revize lokálních změn a ID odstranění rozlišují i několik změn provedených ve stejné sekundě. Potvrzení staršího odstranění nesmaže novější požadavek na odstranění téže položky. Pokud uživatel seznam odstraní během jeho vzdáleného vytváření, vrácené vzdálené ID se uchová na záznamu o smazání pro následný úklid.
- Lokální přejmenování čekající na odeslání se nepřepíše starým názvem z přehledu Traktu. Režim pouze pro načtení přehledu už nevytváří vzdálené seznamy. Založení nového seznamu stejného názvu nezahazuje čekající odstranění předchozího seznamu.
- Neúplné stránkování či chybný typ odpovědi nejsou úspěšné načtení. Prázdná potvrzení změn položek a neúspěšná odstranění zachovávají čekající změny; částečné chyby se vracejí jako `partial_error`, nikoli úspěch. Selhání lokálního zápisu se vrací jako chyba.

Ověření: všech 44 testů v lokální složce `tests` prošlo společným během, včetně 20 nových testů seznamů. Testují skutečné ukládání/slučování a synchronizační funkce s náhradním Trakt klientem; předchozí testy přehrávání navíc používají skutečný klient s náhradním HTTP transportem. Syntaxe všech 58 Python souborů a parsování 21 XML souborů prošly. Skutečné Kodi a Trakt účty nebyly použity. Bez nasazení, změny verze nebo zásahu do Cinema UI.

Zbývá: obousměrné rozpoznání položek odstraněných na jiném zařízení pomocí posledního potvrzeného vzdáleného obsahu (současné `_merge_items` je stále převážně slučování přidáním), oddělení filmových a seriálových TMDB ID, migrace/ruční převzetí starých dat a integrační ověření v Kodi. Tato část tedy neuzavírá všechny nálezy původního auditu.

Rozsah: 54 Python souborů, 49 092 řádků, 21 XML souborů, oba soubory témat a česká i anglická lokalizace. Celý projekt prošel statickou analýzou syntaxe, globálních jmen a přímých volání mezi lokálními moduly. Ruční hloubková kontrola se soustředila na ukládání, synchronizaci, síťovou komunikaci, přehrávání a návaznost UI. Nejde o tvrzení, že každý tok všech 49 tisíc řádků byl spuštěn.

**Nejvyšší prioritu mají oddělení identity filmů a seriálů, transakční změny seznamů, potvrzování odchozí fronty a oddělení dat podle Trakt účtu.** Tyto chyby mohou poškodit stav uživatele, přestože aplikace zdánlivě funguje.

## Nálezy a konkrétní opravy

### 1. P1 — Film a seriál se stejným ID sdílejí stav

Místo: [resources/lib/tmdb_playback_state.py:593](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_playback_state.py:593>), [resources/lib/tmdb_playback_sync.py:547](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_playback_sync.py:547>).

Obě `_ensure_row()` používají jako klíč pouze `tmdb_id`. Typ média je až uvnitř záznamu a další zápis jej může přepsat. Vstup filmu a seriálu se stejným číselným ID proto skončí v jediném záznamu se společnými zdroji. Následkem může být chybné označení zhlédnutí, zobrazení ve špatném seznamu nebo nesprávné odstranění stavu.

**Oprava:** zavést centrální klíč `(media_type, tmdb_id)`, například `movie:123` a `tv:123`. Propagovat jej do lokálního stavu, snapshotu, stavového indexu i všech čtenářů. Připravit verzovanou migraci; smíchané staré záznamy rozdělovat podle typu jednotlivých zdrojů, ne pouze podle posledního `media_type` na rodiči. Před migrací zachovat původní soubor.

**Ověření:** izolované volání skutečné `_ensure_row()` vytvořilo z filmu a seriálu jediný záznam typu `tv`, který stále obsahoval filmový zdroj.

### 2. P1 — Souběžná synchronizace přepisuje změny vlastních seznamů

Místo: [resources/lib/tmdb_custom_lists.py:223](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_custom_lists.py:223>), [resources/lib/tmdb_custom_lists.py:368](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_custom_lists.py:368>), [resources/lib/tmdb_custom_lists.py:464](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_custom_lists.py:464>), [resources/lib/tmdb_trakt_list_sync.py:721](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_trakt_list_sync.py:721>).

Zápis používá atomické nahrazení souboru, ale celý postup načíst–upravit–uložit není zamčený. `sync_now()` načte seznamy, provádí síťové požadavky a nakonec uloží původní kopii. Pokud uživatel během čekání přidá titul nebo přejmenuje seznam, synchronizace může tuto změnu přepsat. Stejný vzor je v prefetch frontě a veřejných oblíbených.

**Oprava:** lokální změny provádět přes `json_storage.update_json()` nebo transakční úložiště. Síťové požadavky držet mimo zámek; jejich výsledek aplikovat na znovu načtená aktuální data, s kontrolou revize a zachováním lokálních změn a záznamů o smazání. Pouhé zamčení finálního `save()` problém neřeší.

**Ověření:** simulace dvou čtenářů nad skutečným JSON úložištěm: po zápisech A a B zůstala jen změna B. Jde o reprodukci mechanismu souběhu, ne o souběžný běh celého Kodi.

### 3. P1 — Fronta zahazuje operace bez potvrzení jejich provedení

Místo: [resources/lib/tmdb_playback_sync.py:326](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_playback_sync.py:326>), [resources/lib/trakt_client.py:1109](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/trakt_client.py:1109>), [resources/lib/trakt_client.py:1191](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/trakt_client.py:1191>).

Flusher po `add_history_items()` a `scrobble_status()` bez kontroly výsledku zavolá `mark_completed()`. Klient přitom při chybějícím tokenu nebo nepoužitelných parametrech vrací `{}`. Přihlášení může selhat až po úvodní kontrole připojení. Celá operace pak zmizí z fronty, ačkoli se nic neodeslalo. Ani obsah částečně úspěšné odpovědi se neposuzuje po položkách.

**Oprava:** rozlišit potvrzený úspěch, přechodnou chybu, odmítnutý vstup a částečný výsledek. `{}` nesmí znamenat úspěch. Dokončit jen potvrzené operace; ostatním zachovat ID, chybu a další termín pokusu. Chybějící autentizaci propagovat jako explicitní neúspěch.

**Ověření:** skutečný flusher s náhradou API vracející `{}` oznámil `sent=1, pending=0, errors=[]` a operaci odstranil.

### 4. P1 — Odchozí operace nejsou svázané s Trakt účtem

Místo: [resources/lib/tmdb_playback_sync.py:67](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_playback_sync.py:67>), [resources/lib/tmdb_playback_queue.py:80](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_playback_queue.py:80>), [resources/lib/trakt_client.py:1450](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/trakt_client.py:1450>).

Fronta a snapshot mají společné cesty pro celý profil doplňku. Operace neobsahuje identitu účtu. `logout()` odstraní přihlašovací údaje, ale neoddělí čekající operace. Po přihlášení účtu B tak lze odeslat změny vytvořené pro účet A, včetně odstranění historie. I snapshot a synchronizační kurzor zůstávají bez vlastníka účtu.

**Oprava:** ukládat vzdálený snapshot, frontu a synchronizační metadata podle stabilního ID Trakt účtu. Před odesláním ověřovat vlastníka operace. Starou frontu při změně účtu bezpečně odložit, nepřesměrovat automaticky na nový účet. Samostatně určit pravidla pro přenos čistě lokální historie.

**Ověření:** statické trasování formátu operací, cest, odhlášení a následné synchronizace. Skutečné účty nebyly přepínány.

### 5. P1 — Neúspěšný zápis videa může být označen jako úspěšné stažení

Místo: [resources/lib/service_downloads.py:360](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/service_downloads.py:360>), [resources/lib/service_downloads.py:526](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/service_downloads.py:526>), [resources/lib/service_downloads.py:695](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/service_downloads.py:695>).

`_write_chunk()` ignoruje návratovou hodnotu `write()`. Přímá větev přes urllib také volá `f.write(chunk)` bez kontroly. Počítadlo stažených bajtů se zvyšuje podle přijatých dat, nikoli potvrzeného zápisu. Pokud VFS oznámí selhání návratovou hodnotou, kontrola délky přesto může projít a poškozený `.part` může nahradit původní soubor.

**Oprava:** sjednotit zapisovač s kontrolou podle jeho smlouvy: u lokálního souboru hlídat počet zapsaných bajtů, u VFS explicitní neúspěch. Ověřit velikost dokončeného souboru před přejmenováním. Při selhání zachovat původní cíl a nastavit chybu úlohy.

**Ověření:** náhradní VFS zapisovač vracející `False` prošel skutečnou `_write_chunk()` bez výjimky. Chování plného disku nebo konkrétního síťového VFS je ještě třeba ověřit v Kodi.

### 6. P2 — Speciály S00 se do Traktu neodesílají při číselné nule

Místo: [resources/lib/trakt_client.py:1141](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/trakt_client.py:1141>), [resources/lib/trakt_client.py:1225](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/trakt_client.py:1225>).

Převod `int(str(season or "").strip())` zamění platné číslo `0` za prázdný řetězec. Fronta sezonu normalizuje právě na číslo, takže problém není omezen na neobvyklé externí vstupy. Epizoda se přeskočí nebo funkce vrátí `{}`; nález 3 pak může operaci odstranit.

**Oprava:** odlišit `None` a prázdný řetězec od nuly, například centrální funkcí pro celé číslo. Prověřit stejný vzor i ve vyhledávání zdrojů. Přidat případy `0`, `"0"`, `1`, `None` a nečíselná hodnota.

**Ověření:** `add_history_items()` s číselným `season=0` a `episode=1` vrátila `{}` před jakýmkoli HTTP požadavkem.

### 7. P2 — Dlouhé stahování zastaví pravidelnou synchronizaci

Místo: [resources/lib/service_downloads.py:898](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/service_downloads.py:898>).

Jediná servisní smyčka nejprve synchronizuje seznamy a historii a následně synchronně zavolá `_download_one(job)`. Dokud se soubor nestáhne, neproběhne další pravidelný tick ani prefetch. Naopak pomalý Trakt může oddálit start stahování. Samostatná vlákna při přehrávání mohou některé operace odeslat, ale pravidelnou obnovu celé služby nenahrazují.

**Oprava:** samostatný omezený pracovník pro stahování a nezávislý plánovač synchronizace. Zajistit jediného vlastníka stažení, ukončení přes `Monitor` a atomické převzetí úlohy. Nekládat síťovou práci do vlákna, které má řídit časování všeho ostatního.

**Ověření:** řídicí tok služby; měření během reálného dlouhého stahování zatím neproběhlo.

### 8. P2 — Časový limit zámku dovolí souběžné vlastníky

Místo: [resources/lib/json_storage.py:128](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/json_storage.py:128>), [resources/lib/tmdb_playback_sync.py:413](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_playback_sync.py:413>).

Zámek starší než `stale_after` se smaže bez ověření, zda jej stále používá živý vlastník. Flush používá limit 120 sekund, ale může provádět mnoho síťových volání. Další proces může mezitím zámek převzít. Původní vlastník při odchodu bezpodmínečně odstraní i nový zámek. Atomické zápisy tuto chybu vlastnictví neřeší.

**Oprava:** použít vhodný systémový zámek nebo zámek s ověřitelným vlastníkem, obnovováním platnosti a bezpečným odstraněním pouze vlastního záznamu. Pro timeouty použít monotónní hodiny. Délku platnosti nepovažovat za důkaz, že vlastník skončil.

**Ověření:** po umělém zestárnutí času souboru vstoupil druhý `file_lock()` do kritické sekce, zatímco první byl stále aktivní.

### 9. P2 — Opakované zhlédnutí stejného zdroje blokuje paměťová deduplikace

Místo: [resources/lib/tmdb_playback_state.py:404](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_playback_state.py:404>), [resources/lib/tmdb_playback_state.py:463](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_playback_state.py:463>).

Jakmile je v `_TRAKT_SCROBBLE_LAST` u historie `sent=True`, další historie stejného média a zdroje se bez časového omezení přeskočí. Klíč neobsahuje identitu relace ani datum zhlédnutí. Hodnota navíc znamená vložení do fronty, nikoli potvrzené odeslání. Při opakovaném použití interpretu se druhé zhlédnutí tímto tokem neodešle; pozdější servisní synchronizace může některé případy napravit.

**Oprava:** deduplikovat jen checkpointy jedné přehrávací relace. Nové spuštění musí mít novou identitu události. Stav `queued` oddělit od `confirmed` a paměťovou cache omezit životností nebo počtem položek.

**Ověření:** dvě volání s odlišným datem zhlédnutí vytvořila jen jednu historii ve frontě.

### 10. P2 — Smazání položky na jiném zařízení se nepromítne do seznamu

Místo: [resources/lib/tmdb_trakt_list_sync.py:310](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_trakt_list_sync.py:310>), [resources/lib/service_downloads.py:442](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/service_downloads.py:442>).

`_merge_items()` začíná všemi lokálními položkami a jen přidává či aktualizuje vzdálené. Absence položky ve vzdáleném seznamu ji neodstraní. Servis navíc dotahuje položky podle podmínky `remote_count > local_count`: nepozná výměnu titulu při stejném počtu ani vzdálené odstranění. Pozdější push může starou položku znovu přidat.

**Oprava:** ukládat poslední potvrzený vzdálený stav a porovnávat jej s aktuálním vzdáleným i lokálním stavem. Rozlišovat novou lokální položku od dříve synchronizované položky smazané vzdáleně. Obnovu řídit revizí či časem změny, ne pouze počtem položek. Prosté nahrazení seznamu vzdálenými daty by naopak ztrácelo lokální offline změny.

**Ověření:** sloučení lokálního seznamu s jednou položkou a prázdného vzdáleného seznamu ponechalo lokální položku.

### 11. P2 — Přechodné chyby přihlášení mohou zbytečně odhlásit uživatele

Místo: [resources/lib/trakt_client.py:88](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/trakt_client.py:88>), [resources/lib/trakt_client.py:194](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/trakt_client.py:194>), [nastaveni.py:196](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/nastaveni.py:196>).

Trakt při jakékoli HTTP 401/403 maže i refresh token, bez rozlišení konkrétního problému a bez jednoho řízeného obnovení a opakování původního požadavku. Obnova tokenu nemá společný zámek mezi servisním a pluginovým procesem. WebShare zase po síťově neúspěšném ověření a přihlášení končí v `_set_bad_credentials()`, která smaže token a oznámí špatné údaje.

**Oprava:** zavést výsledky „neplatné přihlášení“, „dočasně nedostupné“, „nedostatečné oprávnění“. Obnovu Trakt tokenu serializovat a po převzetí zámku znovu načíst aktuální token. Tokeny mazat až při potvrzeném zneplatnění přihlášení; při timeoutu uchovat dosavadní stav a umožnit opakování.

**Ověření:** statická kontrola chybových větví; výpadky skutečných účtů nebyly vyvolávány.

### 12. P2 — Chyba WebShare detailu se ukládá bez expirace

Místo: [resources/lib/Hledani_zdroje.py:485](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/Hledani_zdroje.py:485>).

Při nedostupném tokenu nebo chybě API se do `_WS_FILE_INFO_CACHE[ident]` uloží `{}`. Další volání vrátí tento záznam bez opakovaného pokusu. Cache nemá TTL ani vazbu na přihlášení. Dočasný výpadek proto může po zbytek života modulu vyřadit metadata, která rozhodují o jazyku a řazení zdrojů.

**Oprava:** necacheovat síťovou chybu jako potvrzeně prázdný výsledek. Zavést krátkou expiraci negativních výsledků, běžnou expiraci detailů, omezení velikosti a invalidaci při změně účtu. Podobně omezit ostatní rostoucí slovníkové cache.

### 13. P2 — Vyřešené URL a citlivé hlavičky se stále mohou dostat do souborů a logu

Místo: [resources/lib/Hledani_zdroje.py:6388](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/Hledani_zdroje.py:6388>), [resources/lib/download_manager.py:77](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/download_manager.py:77>), [resources/lib/Hledani_zdroje.py:6569](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/Hledani_zdroje.py:6569>).

Prehraj.to loguje `final={candidate}` bez existujícího redakčního helperu. Fronta stahování ukládá `resolved_url` a celé `headers`; vyčištění odstraňuje pouze klíč `ws_token`. Pokud hlavičky obsahují Cookie nebo URL nese podpis, zůstávají v JSON i jeho záloze. Pro jiné poskytovatele než WebShare se navíc URL vyřeší už při zařazení a před pozdějším stahováním se neobnoví, takže může expirovat.

**Oprava:** do fronty ukládat identitu zdroje, stránku a bezpečná metadata; krátkodobé URL a přihlášení získat až před stahováním. Všechny URL logovat přes `redact_url_for_log()` a sanitizovat i text výjimek. Ošetřit odstranění starých citlivých hodnot ze záloh. Nejde o zjištěný únik mimo zařízení, ale o konkrétní cestu jejich uložení.

### 14. P2 — Uložení seznamu může selhat, ale volající oznámí úspěch

Místo: [resources/lib/tmdb_custom_lists.py:368](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_custom_lists.py:368>), [resources/lib/tmdb_custom_lists.py:464](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_custom_lists.py:464>).

`save()` zachytí chybu a pouze ji zaloguje. Operace jako vytvoření, přejmenování a přidání potom dál vracejí úspěšný výsledek a označují lokální změnu. Při nedostatku místa či zamčeném souboru tak uživatel uvidí úspěch, který po obnovení seznamu zmizí.

**Oprava:** propagovat výjimku nebo strukturovaný výsledek až do UI. Vzdálený push a označení změny zahájit až po úspěšném lokálním uložení. Tuto smlouvu sjednotit se správou fronty stahování, která už úspěch vrací.

### 15. P3 — Tři chybějící globální názvy v okrajových větvích

- [resources/lib/tmdb_trakt_list_sync.py:850](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/tmdb_trakt_list_sync.py:850>): `time.time()` bez `import time`. Volání při připojení přímo vyvolá `NameError`. V aktuálním projektu nebyl nalezen přímý volající této pomocné funkce, proto nejde o potvrzený pád běžného menu.
- [film.py:862](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/film.py:862>): `sys.argv[0]` bez `import sys`. Běžný router předává `base_path`, takže chyba je skrytá ve fallbacku, když parametr chybí.
- [resources/lib/Hledani_zdroje.py:6372](<C:/Users/urbanpavel/Desktop/Python projekt/Ikarus ver.1 - plugin Kodi/plugin.video.ikarus/resources/lib/Hledani_zdroje.py:6372>): `_prehrajto_guess_label_from_url` není definován ani importován. Jde o fallback resolveru; primární parser jej může běžně obejít. Současně se zde `sources` nastaví pouze pro relativní `direct` začínající `/`, nikoli pro absolutní fallback URL.

**Oprava:** doplnit chybějící importy, přesunout vytvoření `sources` mimo podmínku relativní adresy a přidat lint na nedefinovaná jména. Poté rozhodnout, zda nevolané pomocné funkce zachovat.

## Úpravy struktury a výkonu

1. **Rozdělit dva největší moduly postupně.** `TMDB_knihovna.py` má 16 705 řádků a `Hledani_zdroje.py` 6 854; dohromady téměř polovinu projektu. Oddělit API klienty, ukládání, vyhledávání providerů, přehrávací relaci a vykreslování. Zachovat rozhraní routeru a měnit vždy jednu oblast s regresními testy.
2. **UI načítat bez dlouhého blokování callbacku.** Například `ui_source_results.onInit()` synchronně provede `_load()`. Vyhledávání více providerů potřebuje průběžné výsledky, celkový časový rozpočet a zrušení při zavření okna. Konkrétní předávání aktualizací UI je nutné ověřit v Kodi.
3. **Sjednotit síťovou vrstvu.** Oddělit prázdný výsledek od chyby, zavést omezené opakování vhodných požadavků, jednotné timeouty a sanitizované logy. Zápisové požadavky neopakovat naslepo; fronta potřebuje kontrolu výsledků a deduplikaci událostí.
4. **Zpřesnit zachytávání výjimek.** Projekt obsahuje 1 246 obecných `except Exception` nebo holých `except`. Ne každé je problém, ale hranice zápisu, parsování a síťového volání musí vracet odlišitelné výsledky. Vnější router může chybu zachytit a zobrazit, neměl by však skrýt neúspěšnou změnu dat.
5. **Sjednotit všechny trvalé zápisy.** Vedle seznamů používají některé historie a cache přímé `open(..., "w")`. U odvoditelné cache lze akceptovat ztrátu; u historie a uživatelských změn je potřeba transakční změna a obnova. `read_json()` při obnově ze zálohy také zapisuje, takže se musí účastnit stejného pravidla synchronizace jako ostatní zapisovače.
6. **Oddělit stahování souboru a HLS.** Resolver i odhad přípony přijímají `.m3u8`, ale služba stahuje jediný HTTP objekt. To nestáhne segmenty streamu. Buď HLS ve stahování jasně odmítnout, nebo přidat samostatnou podporu manifestu, segmentů a finálního souboru.
7. **Validovat vnitřní strukturu JSON.** `expected_type=dict` ověří pouze kořen. Chybné typy `operations`, `sources` nebo `items` mohou stále rozbít iteraci. Přidat validaci jednotlivých záznamů a diagnostiku opravy, nepřepisovat nečitelná uživatelská data automaticky prázdným stavem.
8. **Dokončit lokalizaci Cinema UI.** Oba katalogy mají potřebná kontrolovaná číselná ID, ale nové dialogy stále obsahují české texty natvrdo. Přesunout je do existujícího systému `i18n.T()`.

## Doporučené pořadí práce

1. **Ochrana dat:** nálezy 1–5 a 14. Migraci identity a rozdělení účtů navrhnout společně, aby se formát úložiště neměnil opakovaně.
2. **Správnost synchronizace:** S00, vlastnictví zámků, opakované zhlédnutí, vzdálené mazání a obnova přihlášení.
3. **Odolnost a odezva:** samostatný downloader, obnovování URL, cache s expirací, zrušitelné načítání.
4. **Údržba:** odstranit nedefinovaná jména, přidat lint a testy, postupně dělit největší moduly a dokončit lokalizaci.

Malé opravy S00, chybějících importů a redakce logu lze provést samostatně, aniž by čekaly na refaktoring. U identity médií a účtů naopak nestačí lokální oprava jedné funkce.

## Ověření a jeho meze

- Python AST, XML a JSON konfigurace se parsují bez chyby. Není to důkaz bezchybného běhu; statická kontrola globálních jmen našla tři výše popsané nedostatky.
- V kontrolovaných přímých voláních lokálních modulů nebyla nalezena chybějící cílová funkce. Dynamická volání tím nejsou pokrytá.
- V XML nebyla nalezena duplicitní ID ovládacích prvků. U jednoznačně přiřazených dialogů sedí kontrolovatelná konstantní `getControl()` ID. Dynamické výrazy a chování ovládání vyžadují Kodi.
- České i anglické `strings.po` mají po 813 ID bez duplicit; číselné literály volání `i18n.T()` byly v českém katalogu nalezeny. Odkazované lokální obrázky obou témat existují.
- Bylo provedeno devět izolovaných reprodukcí: kolize ID, ztracená souběžná změna, falešné potvrzení fronty, ignorovaný neúspěch zápisu, S00, převzetí aktivního zámku, potlačené druhé zhlédnutí, ignorované vzdálené smazání a chybějící import `time`. Použité funkce byly načteny z aktuálních souborů; Kodi a síťové závislosti byly nahrazené. Testovací JSON soubory byly oddělené od profilu Kodi a uklizené.
- V dodané složce nebyla nalezena automatická testovací sada, přestože ji changelog zmiňuje. To nevylučuje její existenci mimo tento balíček. Doporučuji dodat testy společně se zdrojovým projektem.
- Kodi, skutečné streamy, cizí účty ani externí API se při auditu nespouštěly. Nelze proto potvrdit aktuální dostupnost providerů ani skutečné přehrávání na jednotlivých platformách. Syntaxe byla kontrolována Pythonem 3.13.5, ne všemi verzemi Pythonu dodávanými s podporovaným Kodi.

Před vydáním oprav je potřeba integračně ověřit alespoň: přehrání a ruční stop, přirozený konec a další epizodu, obnovení pozice, speciál S00, timeout provideru, přepnutí Trakt účtu, přerušení zápisu, plný disk a souběh UI se servisní synchronizací. Testy mají chránit tyto scénáře, nikoli pouze kopírovat implementaci.

## Klasicky styl pri startu a kod pro Cinema

Na vyslovne prani uzivatele je vychozi styl Classic. Cinema se odemyka chranenym kodem pouze v nastaveni. Odemceni je pouze ve window property aktualni relace Kodi; po restartu se neobnovi z ulozeneho nastaveni. Navrat na Classic odemceni zrusi. Overeno 58 regresnimi testy vcetne 4 scenaru odemykani, syntaxe Pythonu a XML. Zive ovladani dialogu v Kodi zbyva overit uzivatelem.

## WebShare cache detailu souboru

Cache detailu WebShare ma platnost 15 minut, negativni vysledek pouze 30 sekund a nejvyse 800 zaznamu. Detail je vazany na otisk aktualniho tokenu, aby se po zmene uctu nepouzil vysledek predchoziho prihlaseni. Pri chybe API se prazdny vysledek po kratke dobe znovu nacita. Overeno dvema cilenymi testy expirace a oddeleni uctu.

## Obousmerna historie zhlédnutých a Trakt.TV

Starsi snimek Trakt historie byl ulozen mimo novou adresarovou strukturu podle uctu. Pri prvnim overenem prihlaseni se proto jednou zkopiruje do daneho uctu; dalsi ucet jej neprevezme. Plne nacteni Trakt ted spojuje historii prehrani i tituly samostatne oznacene jako zhlédnuté. Lokalni dokonceni se dale odesila pres odchozi frontu a po potvrzeni se znovu nacte vzdaleny stav. Overeno cilenymi testy migrace, vzdalenych zhlédnutých titulu a izolace uctu.

## Odpojeni Trakt pri soukromem seznamu

Po uspesnem prihlaseni mohla synchronizace narazit na soukromy nebo smazany seznam (HTTP 403). Chybova vetev jej nespravne povazovala za neplatny ucet a smazala vsechny Trakt tokeny. HTTP 403 nyni pouze necha operaci seznamu selhat; odhlasi se jen pri HTTP 401. Overeno testem soukromeho seznamu se zachovanym prihlasenim.

## Slouceni duplicitnich seznamu Trakt.TV

Pri prechodu ze starsiho lokalniho uloziste na seznamy oddelene podle Trakt uctu zustal puvodni zaznam bez `trakt_account_id` vedle nove vytvorene prazdne kopie stejneho seznamu. Pri dalsi synchronizaci se pred vytvorenim pracovniho snimku potvrzene dvojice slouci podle Trakt ID, pripadne slugu, a starsi lokalni ID se zachova. Sjednoti se polozky, cekajici mazani a snimek vzdalenych polozek. Samotny shodny nazev nikdy nestaci ke slouceni. Overeno dvema regresnimi testy prevzeti stareho seznamu a slouceni dvou kopii s rozdilnym obsahem; cela sada ma 65 testu.

## WebShare: možne shody odděleně od ověřených zdrojů

Vyhledávání WebShare nyní rozděluje výsledky podle jistoty. Potvrzená shoda filmu musí mít souhlasný rok, jednoznačný víceslovný název nebo přesný název; jiné epizody, hudba, ukázky a zjevně chybný rok se stále zahazují. Zbylé věrohodné, ale neověřené názvy se zobrazí až na konci jako složka **Možné shody**. Nejsou zahrnuty do automatického výběru další epizody. Overeno jednim cilenym testem klasifikace a celou sadou 66 testu.

# -*- coding: utf-8 -*-
"""Theme helpers for Ikarus directory based UI."""

import hashlib
import hmac
import json
import os

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui

from resources.lib import i18n
from xbmcvfs import translatePath


ADDON_ID = "plugin.video.ikarus"
DEFAULT_THEME = "classic"
_CINEMA_SESSION_PROPERTY = "IkarusCinemaUnlocked"
# The fixed code is intentionally stored only as a one-way digest. Do not add
# the readable value to UI text, release notes, or source files.
_CINEMA_CODE_DIGEST = "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4"

_THEME_CACHE = {}


def _addon():
    try:
        return xbmcaddon.Addon()
    except Exception:
        return None


def _addon_path():
    ad = _addon()
    if not ad:
        return ""
    try:
        return translatePath(ad.getAddonInfo("path"))
    except Exception:
        return ""


def _themes_root():
    base = _addon_path()
    return os.path.join(base, "resources", "themes") if base else ""


def _setting_theme_id():
    # Home-window properties live only for this Kodi session. A saved setting
    # from a previous run must never unlock Cinema on the next startup.
    try:
        if xbmcgui.Window(10000).getProperty(_CINEMA_SESSION_PROPERTY) == "1":
            return "cinema"
    except Exception:
        pass
    ad = _addon()
    if ad and ad.getSetting("ui_theme") != "0":
        ad.setSetting("ui_theme", "0")
    return DEFAULT_THEME


def _cinema_code_matches(value):
    value = str(value or "")
    if not value:
        return False
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
    return hmac.compare_digest(digest, _CINEMA_CODE_DIGEST)


def enable_cinema():
    code = xbmcgui.Dialog().input(
        i18n.T(32981, "Enter Cinema code"),
        type=xbmcgui.INPUT_ALPHANUM,
        option=xbmcgui.ALPHANUM_HIDE_INPUT,
    )
    if not _cinema_code_matches(code):
        if code:
            xbmcgui.Dialog().ok("Ikarus Cinema", i18n.T(32982, "Incorrect code"))
        return False
    xbmcgui.Window(10000).setProperty(_CINEMA_SESSION_PROPERTY, "1")
    ad = _addon()
    if ad:
        ad.setSetting("ui_theme", "1")
    return True


def disable_cinema():
    xbmcgui.Window(10000).clearProperty(_CINEMA_SESSION_PROPERTY)
    ad = _addon()
    if ad:
        ad.setSetting("ui_theme", "0")


def selected_theme_id():
    theme_id = _setting_theme_id()
    if theme_id == "classic":
        return theme_id
    root = _themes_root()
    if root and os.path.exists(os.path.join(root, theme_id, "theme.json")):
        return theme_id
    return DEFAULT_THEME


def current_theme():
    theme_id = selected_theme_id()
    cached = _THEME_CACHE.get(theme_id)
    if cached:
        return cached

    data = {"id": theme_id, "name": theme_id, "actions": {}, "view_modes": {}}
    root = _themes_root()
    path = os.path.join(root, theme_id, "theme.json") if root else ""
    try:
        with open(path, "r", encoding="utf-8") as fh:
            loaded = json.load(fh)
        if isinstance(loaded, dict):
            data.update(loaded)
    except Exception as exc:
        try:
            xbmc.log(f"[Ikarus][theme] Could not load {path}: {exc}", xbmc.LOGWARNING)
        except Exception:
            pass

    _THEME_CACHE[theme_id] = data
    return data


def _asset_path(theme_id, relative_path):
    relative_path = str(relative_path or "").strip().replace("/", os.sep)
    if not relative_path:
        return ""
    if relative_path.lower().startswith(("http://", "https://", "special://")):
        return relative_path
    root = _themes_root()
    path = os.path.join(root, theme_id, relative_path) if root else ""
    return path if path and os.path.exists(path) else ""


def theme_asset(relative_path):
    theme = current_theme()
    return _asset_path(theme.get("id") or selected_theme_id(), relative_path)


def fallback_fanart():
    theme = current_theme()
    return theme_asset(theme.get("fanart") or theme.get("background") or "")


def cinema_header_label(*segments):
    parts = ["Ikarus"]
    for segment in segments:
        value = str(segment or "").strip()
        if value:
            parts.append(value)
    return "[B]%s[/B]" % " / ".join(parts)


def set_cinema_header(window, *segments):
    """Apply the shared Cinema header icon and its complete breadcrumb label."""
    icon = theme_asset("art/brand_ikarus_icon.png")
    if icon:
        try:
            window.getControl(20).setImage(icon)
        except Exception:
            pass
    try:
        window.getControl(21).setLabel(cinema_header_label(*segments))
    except Exception:
        pass


def action_art(action, fallback_icon="DefaultFolder.png"):
    theme = current_theme()
    action = str(action or "").strip()
    entry = (theme.get("actions") or {}).get(action) or {}

    icon = theme_asset(entry.get("icon") or entry.get("thumb") or "") or fallback_icon
    thumb = theme_asset(entry.get("thumb") or entry.get("icon") or "") or icon
    poster = theme_asset(entry.get("poster") or entry.get("thumb") or entry.get("icon") or "") or thumb
    fanart = theme_asset(entry.get("fanart") or "") or fallback_fanart()

    art = {
        "icon": icon,
        "thumb": thumb,
        "poster": poster,
    }
    background = theme_asset(entry.get("background") or "")
    if background:
        art["background"] = background
    if fanart:
        art["fanart"] = fanart
        art["landscape"] = fanart
    return art


def provider_art(provider, fallback_icon="DefaultVideo.png"):
    theme = current_theme()
    key = str(provider or "").strip().lower()
    entry = (theme.get("providers") or {}).get(key) or {}
    icon = theme_asset(entry.get("icon") or "") or fallback_icon
    fanart = theme_asset(entry.get("fanart") or "") or fallback_fanart()
    art = {"icon": icon, "thumb": icon, "poster": icon}
    if fanart:
        art["fanart"] = fanart
        art["landscape"] = fanart
    return art


def decorate_item(li, action="", fallback_icon="DefaultFolder.png", title="", plot=""):
    try:
        li.setArt(action_art(action, fallback_icon))
    except Exception:
        pass

    if title or plot:
        try:
            li.setInfo("video", {"title": title or "", "plot": plot or ""})
        except Exception:
            pass

    try:
        li.setProperty("IkarusTheme", selected_theme_id())
    except Exception:
        pass


def force_view_modes_enabled():
    ad = _addon()
    if not ad:
        return True
    try:
        value = (ad.getSetting("ui_force_viewmode") or "true").strip().lower()
        return value in ("", "1", "true", "yes")
    except Exception:
        return True


def _view_mode_for(area, content="files"):
    theme = current_theme()
    view_modes = theme.get("view_modes") or {}
    for key in (str(area or ""), str(content or ""), "default"):
        value = str(view_modes.get(key) or "").strip()
        if value:
            return value
    return ""


def apply_view(area="", content="files"):
    if selected_theme_id() == "classic" or not force_view_modes_enabled():
        return
    mode = _view_mode_for(area, content)
    if not mode:
        return
    try:
        xbmc.executebuiltin(f"Container.SetViewMode({mode})")
    except Exception:
        pass


def set_content(handle, content="files"):
    try:
        xbmcplugin.setContent(handle, content)
    except Exception:
        pass


def end_directory(handle, area="", content="files", succeeded=True,
                  update_listing=False, cache_to_disc=False):
    set_content(handle, content)
    try:
        xbmcplugin.endOfDirectory(
            handle,
            succeeded=bool(succeeded),
            updateListing=bool(update_listing),
            cacheToDisc=bool(cache_to_disc),
        )
    except TypeError:
        xbmcplugin.endOfDirectory(handle)
    apply_view(area, content)

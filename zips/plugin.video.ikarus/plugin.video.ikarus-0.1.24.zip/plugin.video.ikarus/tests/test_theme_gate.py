import importlib.util
from pathlib import Path
import sys
import types
import unittest
from unittest import mock
import resources.lib as lib


class ThemeGateTests(unittest.TestCase):
    @staticmethod
    def _valid_cinema_code():
        return "".join(chr(value) for value in (49, 50, 51, 52))

    def setUp(self):
        self.props = {}
        self.settings = {"ui_theme": "1"}
        self.dialog = mock.Mock()
        self.window = types.SimpleNamespace(
            getProperty=lambda key: self.props.get(key, ""),
            setProperty=lambda key, val: self.props.update({key: val}),
            clearProperty=lambda key: self.props.pop(key, None))
        addon = types.SimpleNamespace(getSetting=lambda key: self.settings.get(key, ""),
            setSetting=lambda key, val: self.settings.update({key: val}),
            getAddonInfo=lambda key: str(Path(__file__).resolve().parents[1]))
        gui = types.SimpleNamespace(Window=lambda *a: self.window, Dialog=lambda: self.dialog,
            INPUT_ALPHANUM=0, ALPHANUM_HIDE_INPUT=1)
        spec = importlib.util.spec_from_file_location("theme_test", Path(__file__).resolve().parents[1] / "resources/lib/ui_theme.py")
        self.theme = importlib.util.module_from_spec(spec)
        stubs = {"xbmc": types.SimpleNamespace(), "xbmcaddon": types.SimpleNamespace(Addon=lambda: addon),
            "xbmcplugin": types.SimpleNamespace(), "xbmcgui": gui,
            "xbmcvfs": types.SimpleNamespace(translatePath=lambda path: path)}
        with mock.patch.dict(sys.modules, stubs), mock.patch.object(lib, "i18n", types.SimpleNamespace(T=lambda n, fallback: fallback), create=True):
            spec.loader.exec_module(self.theme)

    def test_saved_cinema_preference_does_not_unlock_new_session(self):
        self.assertEqual("classic", self.theme.selected_theme_id())
        self.assertEqual("0", self.settings["ui_theme"])

    def test_correct_code_unlocks_until_kodi_session_ends(self):
        self.dialog.input.return_value = self._valid_cinema_code()
        self.assertTrue(self.theme.enable_cinema())
        self.assertEqual("cinema", self.theme.selected_theme_id())
        self.props.clear()  # Kodi restart clears window properties.
        self.assertEqual("classic", self.theme.selected_theme_id())

    def test_wrong_code_and_cancel_keep_classic(self):
        for code in ("", "0000", "4321"):
            self.dialog.input.return_value = code
            self.assertFalse(self.theme.enable_cinema())
            self.assertEqual("classic", self.theme.selected_theme_id())

    def test_return_to_classic_requires_new_code(self):
        self.dialog.input.return_value = self._valid_cinema_code()
        self.theme.enable_cinema()
        self.theme.disable_cinema()
        self.assertEqual("classic", self.theme.selected_theme_id())
        self.dialog.input.return_value = ""
        self.assertFalse(self.theme.enable_cinema())
        self.assertEqual("classic", self.theme.selected_theme_id())
